(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var n = this || self;

    function ba(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = n, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    };

    function ca(a, ...b) {
        b = b.filter(Boolean).join("&");
        if (!b) return a;
        const c = a.match(/[?&]adurl=/);
        return c ? a.slice(0, c.index + 1) + b + "&" + a.slice(c.index + 1) : a + (a.indexOf("?") < 0 ? "?" : "&") + b
    }

    function da(a, b) {
        return a === 0 ? b ? "ri=1" : "" : a === 1 ? b ? "ri=24" : "ri=27" : a === 2 ? b ? "ri=25" : "ri=26" : ""
    }

    function r(a, b) {
        return b ? "&" + a + "=" + encodeURIComponent(b) : ""
    }

    function ea(a) {
        a = a.l;
        if (!a) return "";
        let b = r("uap", a.platform) + r("uapv", a.platformVersion) + r("uafv", a.uaFullVersion) + r("uaa", a.architecture) + r("uam", a.model) + r("uab", a.bitness);
        a.fullVersionList && (b += "&uafvl=" + encodeURIComponent(a.fullVersionList.map(c => encodeURIComponent(c.brand) + ";" + encodeURIComponent(c.version)).join("|")));
        a.wow64 != null && (b += "&uaw=" + Number(a.wow64));
        return b.slice(1)
    }

    function fa(a, b) {
        if (a.g.dsh === "1") return null;
        const c = a.g.ae;
        if (c === "1") {
            const d = a.g.adurl;
            if (d) try {
                return {
                    version: 3,
                    B: decodeURIComponent(d),
                    v: ca(a.h, "act=1", da(b, !0), ea(a))
                }
            } catch (e) {}
        }
        return c === "2" ? {
            version: 4,
            B: ca(a.h, "dct=1", "suid=" + a.j, da(b, !1)),
            v: ca(a.h, "act=1", da(b, !0), "suid=" + a.j)
        } : null
    }

    function ha(a, b) {
        return b === 2 ? ca(a.h, "ri=2") : b === 0 ? ca(a.h, "ri=16") : a.h
    }
    var ia = class {
        constructor({
            url: a,
            fa: b
        }) {
            this.h = a;
            this.l = b;
            this.j = (new Date).getTime() - 17040672E5;
            this.g = {};
            const c = /[?&]([^&=]+)=([^&]*)/g;
            for (; b = c.exec(a);) this.g[b[1]] = b[2]
        }
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var t = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g
            }
        },
        ka = new t("about:invalid#zClosurez");
    class la {
        constructor(a) {
            this.da = a
        }
    }

    function u(a) {
        return new la(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const ma = new la(a => /^[^:]*([/?#]|$)/.test(a));
    var na = u("http"),
        oa = u("https"),
        pa = u("ftp"),
        qa = u("mailto"),
        ra = u("intent"),
        sa = u("market"),
        ta = u("itms"),
        ua = u("itms-appss");
    const va = [u("data"), na, oa, qa, pa, ma];

    function wa(a, b = va) {
        if (a instanceof t) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof la && d.da(a)) return new t(a)
        }
    }

    function xa(a, b = va) {
        return wa(a, b) || ka
    }
    var ya = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function za(a, b) {
        if (b instanceof t)
            if (b instanceof t) b = b.g;
            else throw Error("");
        else b = ya.test(b) ? b : void 0;
        b !== void 0 && (a.href = b)
    };

    function Aa(a, b) {
        a: {
            const c = a.length,
                d = typeof a === "string" ? a.split("") : a;
            for (let e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    };

    function Ba(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };

    function Ca(a) {
        n.setTimeout(() => {
            throw a;
        }, 0)
    };

    function x(a) {
        var b;
        a: {
            if (b = n.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return b.indexOf(a) != -1
    };
    var Da = ba(748402147, ba(1, !1));

    function Ea() {
        return x("iPhone") && !x("iPod") && !x("iPad")
    };

    function Fa(a) {
        Fa[" "](a);
        return a
    }
    Fa[" "] = function() {};
    var Ga = Ea(),
        Ha = x("iPad");
    var Ia = Ea() || x("iPod"),
        Ja = x("iPad");
    var Ka = {},
        La = null;
    let Ma = void 0;

    function Na(a) {
        a = Error(a);
        Ba(a, "warning");
        return a
    };

    function Oa(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var Pa = Oa(),
        Qa = Oa(),
        Ra = Oa("m_m", !0);
    const y = Oa("jas", !0);
    var Sa;
    const Ta = [];
    Ta[y] = 7;
    Sa = Object.freeze(Ta);

    function Ua(a) {
        a[y] |= 34;
        return a
    };
    var Va = {};

    function A(a, b) {
        return b === void 0 ? a.g !== B && !!(2 & (a.i[y] | 0)) : !!(2 & b) && a.g !== B
    }
    const B = {};
    class Wa {
        constructor(a, b, c) {
            this.g = a;
            this.h = b;
            this.j = c
        }
        next() {
            const a = this.g.next();
            a.done || (a.value = this.h.call(this.j, a.value));
            return a
        }[Symbol.iterator]() {
            return this
        }
    }
    var Xa = Object.freeze({});
    var Ya = typeof n.BigInt === "function" && typeof n.BigInt(0) === "bigint";
    const Za = Number.MIN_SAFE_INTEGER.toString(),
        $a = Ya ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        ab = Number.MAX_SAFE_INTEGER.toString(),
        bb = Ya ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function cb(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (let c = 0; c < a.length; c++) {
            const d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    const db = Number.isFinite;

    function eb(a) {
        if (!db(a)) throw Na("enum");
        return a | 0
    }

    function fb(a) {
        return a == null ? a : db(a) ? a | 0 : void 0
    }

    function gb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return db(a) ? a | 0 : void 0
    }

    function C(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function ib(a, b, c, d) {
        if (a != null && a[Ra] === Va) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? ((a = b[Pa]) || (a = new b, Ua(a.i), a = b[Pa] = a), b = a) : b = new b : b = void 0, b;
        c = a[y] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[y] = d);
        return new b(a)
    }

    function jb(a, b, c) {
        if (b) {
            if (typeof a !== "string") throw Error();
            return a
        }
        let d;
        return (d = C(a)) != null ? d : c ? "" : void 0
    };

    function kb(a) {
        return a
    };
    const lb = {},
        nb = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function ob(a) {
        return a
    }

    function pb(a) {
        if (a.o & 2) throw Error("Cannot mutate an immutable Map");
    }
    var D = class extends nb {
        constructor(a, b, c = ob, d = ob) {
            super();
            this.o = a[y] | 0;
            this.m = b;
            this.C = c;
            this.W = this.m ? qb : d;
            for (let e = 0; e < a.length; e++) {
                const f = a[e],
                    g = c(f[0], !1, !0);
                let h = f[1];
                b ? h === void 0 && (h = null) : h = d(f[1], !1, !0, void 0, void 0, this.o);
                super.set(g, h)
            }
        }
        ea() {
            var a = rb;
            if (this.size !== 0) return Array.from(super.entries(), a)
        }
        V() {
            return Array.from(super.entries())
        }
        clear() {
            pb(this);
            super.clear()
        }
        delete(a) {
            pb(this);
            return super.delete(this.C(a, !0, !1))
        }
        entries() {
            if (this.m) {
                var a = super.keys();
                a = new Wa(a, sb,
                    this)
            } else a = super.entries();
            return a
        }
        values() {
            if (this.m) {
                var a = super.keys();
                a = new Wa(a, D.prototype.get, this)
            } else a = super.values();
            return a
        }
        forEach(a, b) {
            this.m ? super.forEach((c, d, e) => {
                a.call(b, e.get(d), d, e)
            }) : super.forEach(a, b)
        }
        set(a, b) {
            pb(this);
            a = this.C(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.W(b, !0, !0, this.m, !1, this.o))
        }
        has(a) {
            return super.has(this.C(a, !1, !1))
        }
        get(a) {
            a = this.C(a, !1, !1);
            const b = super.get(a);
            if (b !== void 0) {
                var c = this.m;
                return c ? (c = this.W(b, !1, !0, c, this.ca, this.o), c !== b && super.set(a, c), c) : b
            }
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    D.prototype.toJSON = void 0;

    function qb(a, b, c, d, e, f) {
        a = ib(a, d, c, f);
        e && (a = tb(a));
        return a
    }

    function sb(a) {
        return [a, this.get(a)]
    }
    let ub;

    function vb() {
        return ub || (ub = new D(Ua([]), void 0, void 0, void 0, lb))
    };

    function wb(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        const f = [];
        var g = a.length;
        let h, k = 4294967295,
            l = !1;
        const m = !!(b & 64),
            p = m ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1 || (h = g && a[g - 1], h != null && typeof h === "object" && h.constructor === Object ? (g--, k = g) : h = void 0, !m || b & 128 || e))) {
            l = !0;
            var q;
            k = ((q = xb) != null ? q : kb)(k - p, p, a, h, void 0) + p
        }
        b = void 0;
        for (e = 0; e < g; e++)
            if (q = a[e], q != null && (q = c(q, d)) != null)
                if (m && e >= k) {
                    const v = e - p;
                    let w;
                    ((w = b) != null ? w : b = {})[v] = q
                } else f[e] = q;
        if (h)
            for (let v in h) {
                a = h[v];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +v;
                let w;
                if (m && !Number.isNaN(g) && (w = g + p) < k) f[w] = a;
                else {
                    let z;
                    ((z = b) != null ? z : b = {})[v] = a
                }
            }
        b && (l ? f.push(b) : f[k] = b);
        return f
    }

    function rb(a) {
        a[0] = yb(a[0]);
        a[1] = yb(a[1]);
        return a
    }

    function yb(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return (Ya ? a >= $a && a <= bb : a[0] === "-" ? cb(a, Za) : cb(a, ab)) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    const b = a[y] | 0;
                    return a.length === 0 && b & 1 ? void 0 : wb(a, b, yb)
                }
                if (a != null && a[Ra] === Va) return E(a);
                if (a instanceof D) return a.ea();
                return
        }
        return a
    }
    let xb;

    function E(a) {
        a = a.i;
        return wb(a, a[y] | 0, yb)
    };

    function zb(a) {
        if (a == null) {
            var b = 32;
            a = []
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            b = a[y] | 0;
            if (Da && 1 & b) throw Error("rfarr");
            2048 & b && !(2 & b) && Ab();
            if (b & 256) throw Error("farr");
            if (b & 64) return b & 2048 || (a[y] = b | 2048), a;
            var c = a;
            b |= 64;
            var d = c.length;
            if (d) {
                var e = d - 1;
                d = c[e];
                if (d != null && typeof d === "object" && d.constructor === Object) {
                    const f = b & 128 ? 0 : -1;
                    e -= f;
                    if (e >= 1024) throw Error("pvtlmt");
                    for (const g in d) {
                        const h = +g;
                        if (h < e) c[h + f] = d[g], delete d[g];
                        else break
                    }
                    b = b & -8380417 | (e & 1023) << 13
                }
            }
        }
        a[y] = b | 2112;
        return a
    }

    function Ab() {
        if (Da) throw Error("carr");
        if (Qa != null) {
            var a;
            var b = (a = Ma) != null ? a : Ma = {};
            a = b[Qa] || 0;
            a >= 5 || (b[Qa] = a + 1, b = Error(), Ba(b, "incident"), Ca(b))
        }
    };

    function Bb(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[y] | 0;
            return a.length === 0 && c & 1 ? void 0 : Cb(a, c, b)
        }
        if (a != null && a[Ra] === Va) return Db(a);
        if (a instanceof D) {
            c = a.o;
            if (c & 2) return a;
            if (a.size) {
                b = Ua(a.V());
                if (a.m)
                    for (a = 0; a < b.length; a++) {
                        const d = b[a];
                        let e = d[1];
                        e == null || typeof e !== "object" ? e = void 0 : e != null && e[Ra] === Va ? e = Db(e) : Array.isArray(e) ? e = Cb(e, e[y] | 0, !!(c & 32)) : e = void 0;
                        d[1] = e
                    }
                return b
            }
        }
    }

    function Cb(a, b, c) {
        if (b & 2) return a;
        !c || 4096 & b || 16 & b ? a = Eb(a, b, !1, c && !(b & 16)) : (a[y] |= 34, b & 4 && Object.freeze(a));
        return a
    }

    function Fb(a, b, c) {
        a = new a.constructor(b);
        c && (a.g = B);
        a.h = B;
        return a
    }

    function Db(a) {
        const b = a.i,
            c = b[y] | 0;
        return A(a, c) ? a : Gb(a, b, c) ? Fb(a, b) : Eb(b, c)
    }

    function Hb(a) {
        const b = a.i,
            c = b[y] | 0;
        return Gb(a, b, c) ? Fb(a, b, !0) : new a.constructor(Eb(b, c, !1))
    }

    function Eb(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = wb(a, b, Bb, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        a[y] = b;
        return a
    }

    function tb(a) {
        const b = a.i,
            c = b[y] | 0;
        return A(a, c) ? Gb(a, b, c) ? Fb(a, b, !0) : new a.constructor(Eb(b, c, !1)) : a
    }

    function Ib(a) {
        if (a.g !== B) return !1;
        var b = a.i;
        b = Eb(b, b[y] | 0);
        b[y] |= 2048;
        a.i = b;
        a.g = void 0;
        a.h = void 0;
        return !0
    }

    function Jb(a) {
        if (!Ib(a) && A(a, a.i[y] | 0)) throw Error();
    }

    function Kb(a, b) {
        b === void 0 && (b = a[y] | 0);
        b & 32 && !(b & 4096) && (a[y] = b | 4096)
    }

    function Gb(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[y] = c | 2, a.g = B, !0) : !1
    };

    function G(a, b) {
        a = Lb(a.i, b);
        if (a !== null) return a
    }

    function Lb(a, b, c, d) {
        if (b === -1) return null;
        const e = b + (c ? 0 : -1),
            f = a.length - 1;
        let g, h;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f)
                if (g = a[f], g != null && typeof g === "object" && g.constructor === Object) c = g[b], h = !0;
                else if (e === f) c = g;
            else return;
            else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function Mb(a, b, c) {
        Jb(a);
        const d = a.i;
        H(d, d[y] | 0, b, c);
        return a
    }

    function H(a, b, c, d) {
        const e = c + -1;
        var f = a.length - 1;
        if (f >= 0 && e >= f) {
            const g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        if (d !== void 0) {
            let g;
            f = ((g = b) != null ? g : b = a[y] | 0) >> 13 & 1023 || 536870912;
            c >= f ? d != null && (a[f + -1] = {
                [c]: d
            }) : a[e] = d
        }
        return b
    }

    function J(a, b, c) {
        a = a.i;
        return Nb(a, a[y] | 0, b, c) !== void 0
    }

    function Ob(a, b, c, d, e) {
        let f = a.i,
            g = f[y] | 0;
        d = A(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && Ib(a) && (f = a.i, g = f[y] | 0);
        a = Pb(f, b);
        let h = a === Sa ? 7 : a[y] | 0,
            k = Qb(h, g);
        var l = 4 & k ? !1 : !0;
        if (l) {
            4 & k && (a = [...a], h = 0, k = Rb(k, g), g = H(f, g, b, a));
            let m = 0,
                p = 0;
            for (; m < a.length; m++) {
                const q = c(a[m]);
                q != null && (a[p++] = q)
            }
            p < m && (a.length = p);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (a[y] = k, 2 & k && Object.freeze(a));
        return a = Sb(a, k, f, g, b, d, l, e)
    }

    function Sb(a, b, c, d, e, f, g, h) {
        let k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Tb(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && (a[y] = b), Object.freeze(a)) : (f === 2 && Tb(b) && (a = [...a], k = 0, b = Rb(b, d), d = H(c, d, e, a)), Tb(b) || (h || (b |= 16), b !== k && (a[y] = b)));
        2 & b || !(4096 & b || 16 & b) || Kb(c, d);
        return a
    }

    function Pb(a, b) {
        a = Lb(a, b);
        return Array.isArray(a) ? a : Sa
    }

    function Qb(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Tb(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function M(a, b, c, d) {
        let e;
        var f = a.i,
            g = f[y] | 0;
        e = A(a, g);
        a: {!e && Ib(a) && (f = a.i, g = f[y] | 0);
            var h = Lb(f, b);a = !1;
            if (h == null) {
                if (e) {
                    b = vb();
                    break a
                }
                h = []
            } else if (h.constructor === D)
                if (h.o & 2 && !e) h = h.V();
                else {
                    b = h;
                    break a
                }
            else Array.isArray(h) ? a = !!((h[y] | 0) & 2) : h = [];
            if (e) {
                if (!h.length) {
                    b = vb();
                    break a
                }
                a || (a = !0, Ua(h))
            } else if (a) {
                a = !1;
                h = [...h];
                for (let k = 0; k < h.length; k++) {
                    const l = h[k] = [...h[k]];
                    Array.isArray(l[1]) && (l[1] = Ua(l[1]))
                }
            }!a && g & 32 && (h[y] |= 32);d = new D(h, c, jb, d);g = H(f, g, b, d);a || Kb(f, g);b = d
        }!e && c && (b.ca = !0);
        return b
    }

    function Nb(a, b, c, d) {
        let e = !1;
        d = Lb(a, d, void 0, f => {
            const g = ib(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !A(d) && Kb(a, b), d
    }

    function N(a, b, c) {
        let d = a.i,
            e = d[y] | 0;
        b = Nb(d, e, b, c);
        if (b == null) return b;
        e = d[y] | 0;
        if (!A(a, e)) {
            const f = tb(b);
            f !== b && (Ib(a) && (d = a.i, e = d[y] | 0), b = f, e = H(d, e, c, b), Kb(d, e))
        }
        return b
    }

    function Rb(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Q(a, b) {
        a = G(a, b);
        a = a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0;
        return a != null ? a : !1
    }

    function Ub(a, b) {
        let c;
        return (c = gb(G(a, b))) != null ? c : 0
    }

    function R(a, b) {
        let c;
        return (c = C(G(a, b))) != null ? c : ""
    }

    function S(a, b, c = 0) {
        let d;
        return (d = fb(G(a, b))) != null ? d : c
    }

    function Vb(a, b, c) {
        if (c != null && typeof c !== "boolean") throw a = typeof c, Error(`Expected boolean but got ${a!="object"?a:c?Array.isArray(c)?"array":a:"null"}: ${c}`);
        return Mb(a, b, c)
    }

    function Wb(a, b, c) {
        if (c != null) {
            if (typeof c !== "number") throw Na("int32");
            if (!db(c)) throw Na("int32");
            c |= 0
        }
        Mb(a, b, c)
    }

    function T(a, b, c) {
        if (c != null && typeof c !== "string") throw Error();
        return Mb(a, b, c)
    }

    function Xb(a, b, c) {
        Mb(a, b, c == null ? c : eb(c))
    };
    var U = class {
        constructor(a) {
            this.i = zb(a)
        }
        toJSON() {
            return E(this)
        }
    };
    U.prototype[Ra] = Va;
    U.prototype.toString = function() {
        return this.i.toString()
    };
    var Yb = class extends U {};
    var Zb = class extends U {};
    var $b = class extends U {};
    var ac = class extends U {};
    var bc = class extends U {};
    var cc = class extends U {
        A() {
            return R(this, 3)
        }
        U(a) {
            Vb(this, 5, a)
        }
    };
    var V = class extends U {
        A() {
            return R(this, 1)
        }
        U(a) {
            Vb(this, 2, a)
        }
    };
    var dc = class extends U {};
    var ec = class extends U {};

    function fc(a) {
        var b = a.i,
            c = b;
        b = b[y] | 0;
        var d = void 0 === Xa ? 2 : 4,
            e = A(a, b);
        const f = e ? 1 : d;
        d = f === 3;
        var g = !e;
        (f === 2 || g) && Ib(a) && (c = a.i, b = c[y] | 0);
        a = Pb(c, 7);
        var h = a === Sa ? 7 : a[y] | 0,
            k = Qb(h, b);
        if (e = !(4 & k)) {
            var l = a,
                m = b;
            const p = !!(2 & k);
            p && (m |= 2);
            let q = !p,
                v = !0,
                w = 0,
                z = 0;
            for (; w < l.length; w++) {
                const O = ib(l[w], cc, !1, m);
                if (O instanceof cc) {
                    if (!p) {
                        const K = A(O);
                        q && (q = !K);
                        v && (v = K)
                    }
                    l[z++] = O
                }
            }
            z < w && (l.length = z);
            k |= 4;
            k = v ? k & -4097 : k | 4096;
            k = q ? k | 8 : k & -9
        }
        k !== h && (a[y] = k, 2 & k && Object.freeze(a));
        if (g && !(8 & k || !a.length && (f === 1 || (f !== 4 ? 0 : 2 &
                k || !(16 & k) && 32 & b)))) {
            Tb(k) && (a = [...a], k = Rb(k, b), b = H(c, b, 7, a));
            g = a;
            h = k;
            for (l = 0; l < g.length; l++) k = g[l], m = tb(k), k !== m && (g[l] = m);
            h |= 8;
            k = h = g.length ? h | 4096 : h & -4097;
            a[y] = k
        }
        return a = Sb(a, k, c, b, 7, f, e, d)
    }
    var hc = class extends U {};
    var ic = class extends U {};
    var jc = class extends U {};

    function kc(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };

    function lc(a) {
        let b = 0;
        for (const c in a) b++
    };

    function mc(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function nc(a = document) {
        return a.createElement("img")
    };
    let oc = [];

    function pc() {
        const a = oc;
        oc = [];
        for (const b of a) try {
            b()
        } catch (c) {}
    }

    function qc(a) {
        oc.push(a);
        oc.length === 1 && (window.Promise ? Promise.resolve().then(pc) : (a = window.setImmediate, typeof a === "function" ? a(pc) : setTimeout(pc, 0)))
    };
    var rc = {
            capture: !0
        },
        sc = {
            passive: !0
        },
        tc = kc(() => {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                n.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function uc(a) {
        return a ? a.passive && tc() ? a : a.capture || !1 : !1
    }

    function W(a, b, c, d) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, uc(d))
    }

    function vc(a) {
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    }

    function wc(a) {
        var b = X;
        b.readyState === "complete" || b.readyState === "interactive" ? qc(a) : b.addEventListener("DOMContentLoaded", a)
    }

    function xc(a) {
        var b = window;
        b.document.readyState === "complete" ? qc(a) : b.addEventListener("load", a)
    };

    function yc(a, b, c = null, d = !1) {
        zc(a, b, c, d)
    }

    function zc(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const e = nc(a.document);
        if (c || d) {
            const f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    const h = Array.prototype.indexOf.call(g, e, void 0);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, uc());
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, uc())
            };
            W(e, "load", f);
            W(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    }

    function Ac(a) {
        var b = window,
            c;
        if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
        c && typeof b.navigator.sendBeacon === "function" ? b.navigator.sendBeacon(a) : yc(b, a, void 0, !1)
    };
    let Bc = 0;

    function Cc() {
        const a = Hc(Bc, document.currentScript);
        a && (a.dataset.initialized = "true")
    }

    function Ic(a) {
        return (a = Hc(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function Hc(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[${"data-jc"}="${a}"]`)
    }

    function Jc(a) {
        if (!(Math.random() > .01)) {
            const b = Hc(a, document.currentScript);
            a = `https://${b&&b.getAttribute("data-jc-rcd")==="true"?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=${a}&version=${Ic(a)}&sample=${.01}`;
            Ac(a)
        }
    };
    var X = document,
        Kc = window;
    var Lc = a => {
        var b = X;
        try {
            return b.querySelectorAll("*[" + a + "]")
        } catch (c) {
            return []
        }
    };
    var Mc = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function Nc(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    const Oc = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Pc = class {
            constructor(a, b) {
                this.g = a;
                this.h = b
            }
        },
        Qc = class {
            constructor(a, b) {
                this.url = a;
                this.g = !!b;
                this.depth = null
            }
        };
    let Rc = null;

    function Sc() {
        const a = n.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Tc() {
        const a = n.performance;
        return a && a.now ? a.now() : null
    };
    var Uc = class {
        constructor(a, b) {
            var c = Tc() || Sc();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const Y = n.performance,
        Vc = !!(Y && Y.mark && Y.measure && Y.clearMarks),
        Wc = kc(() => {
            var a;
            if (a = Vc) {
                var b;
                a = window;
                if (Rc === null) {
                    Rc = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (Rc = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Rc;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function Xc(a) {
        a && Y && Wc() && (Y.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Y.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function Yc(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function Zc(a, b, c, d, e) {
        const f = [];
        mc(a, (g, h) => {
            (g = $c(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function $c(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push($c(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Zc(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function ad(a) {
        let b = 1;
        for (const c in a.h) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function bd(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = ad(a) - b.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.h[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = b == null ? g : b;
                    break
                }
                let l = Zc(h[k], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = b == null ? g : b
                }
            }
        }
        a = "";
        b != null && (a = `${e}${"trn"}=${b}`);
        return c + a
    }
    var cd = class {
        constructor() {
            this.j = "&";
            this.h = {};
            this.l = 0;
            this.g = []
        }
    };
    var dd = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function ed(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        c < 0 && (c = a.length);
        let d = a.indexOf("?"),
            e;
        d < 0 || d > c ? (d = c, e = "") : e = a.substring(d + 1, c);
        a = [a.slice(0, d), e, a.slice(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }

    function fd(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) fd(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    }

    function gd(a, b, c, d) {
        const e = c.length;
        for (;
            (b = a.indexOf(c, b)) >= 0 && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (f == 38 || f == 63)
                if (f = a.charCodeAt(b + e), !f || f == 61 || f == 38 || f == 35) return b;
            b += e + 1
        }
        return -1
    }
    var hd = /#|$/;

    function id(a, b) {
        const c = a.search(hd);
        let d = gd(a, 0, b, c);
        if (d < 0) return null;
        let e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    }
    var jd = /[?&]($|#)/;

    function kd(a, b) {
        const c = a.search(hd);
        let d = 0,
            e;
        const f = [];
        for (;
            (e = gd(a, d, b, c)) >= 0;) f.push(a.substring(d, e)), d = Math.min(a.indexOf("&", e) + 1 || c, c);
        f.push(a.slice(d));
        return f.join("").replace(jd, "$1")
    }

    function ld(a, b) {
        a = kd(a, "label");
        b = b != null ? "=" + encodeURIComponent(String(b)) : "";
        return ed(a, "label" + b)
    };

    function md(a, b, c) {
        let d, e;
        try {
            a.g && a.g.g ? (e = a.g.start(b.toString(), 3), d = c(), a.g.end(e)) : d = c()
        } catch (f) {
            c = !0;
            try {
                Xc(e), c = a.u(b, new Mc(f, {
                    message: Nc(f)
                }), void 0, void 0)
            } catch (g) {
                a.l(217, g)
            }
            if (c) {
                let g, h;
                (g = window.console) == null || (h = g.error) == null || h.call(g, f)
            } else throw f;
        }
        return d
    }

    function nd(a, b) {
        var c = od;
        return (...d) => md(c, a, () => b.apply(void 0, d))
    }
    var rd = class {
        constructor(a = null) {
            this.pinger = pd;
            this.g = a;
            this.h = null;
            this.j = !1;
            this.u = this.l
        }
        l(a, b, c, d, e) {
            e = e || "jserror";
            let f = void 0;
            try {
                const L = new cd;
                var g = L;
                g.g.push(1);
                g.h[1] = Yc("context", a);
                b.error && b.meta && b.id || (b = new Mc(b, {
                    message: Nc(b)
                }));
                g = b;
                if (g.msg) {
                    b = L;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.h[2] = Yc("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.h) try {
                    this.h(h)
                } catch (I) {}
                if (d) try {
                    d(h)
                } catch (I) {}
                d = L;
                k = [k];
                d.g.push(3);
                d.h[3] = k;
                var l;
                if (!(l = v)) {
                    d = n;
                    k = [];
                    let I;
                    h = null;
                    do {
                        var m = d;
                        try {
                            var p;
                            if (p = !!m && m.location.href != null) b: {
                                try {
                                    Fa(m.foo);
                                    p = !0;
                                    break b
                                } catch (F) {}
                                p = !1
                            }
                            var q = p
                        } catch (F) {
                            q = !1
                        }
                        q ? (I = m.location.href, h = m.document && m.document.referrer || null) : (I = h, h = null);
                        k.push(new Qc(I || ""));
                        try {
                            d = m.parent
                        } catch (F) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let F = 0, Dc = k.length - 1; F <= Dc; ++F) k[F].depth = Dc - F;
                    m = n;
                    if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length === k.length - 1)
                        for (q = 1; q < k.length; ++q) {
                            const F = k[q];
                            F.url || (F.url = m.location.ancestorOrigins[q - 1] || "", F.g = !0)
                        }
                    l = k
                }
                var v = l;
                let P = new Qc(n.location.href, !1);
                l = null;
                const aa = v.length - 1;
                for (m = aa; m >= 0; --m) {
                    var w = v[m];
                    !l && Oc.test(w.url) && (l = w);
                    if (w.url && !w.g) {
                        P = w;
                        break
                    }
                }
                w = null;
                const Qd = v.length && v[aa].url;
                P.depth !== 0 && Qd && (w = v[aa]);
                f = new Pc(P, w);
                if (f.h) {
                    v = L;
                    var z = f.h.url || "";
                    v.g.push(4);
                    v.h[4] = Yc("top", z)
                }
                var O = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    const I = f.g.url.match(dd);
                    var K = I[1],
                        Ec = I[3],
                        Fc = I[4];
                    z = "";
                    K && (z += K + ":");
                    Ec && (z += "//", z += Ec, Fc && (z += ":" + Fc));
                    var Gc = z
                } else Gc = "";
                K = L;
                O = [O, {
                    url: Gc
                }];
                K.g.push(5);
                K.h[5] = O;
                qd(this.pinger, e, L, this.j, c)
            } catch (L) {
                try {
                    let P,
                        aa;
                    qd(this.pinger, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Nc(L),
                        url: (aa = (P = f) == null ? void 0 : P.g.url) != null ? aa : ""
                    }, this.j, c)
                } catch (P) {}
            }
            return !0
        }
    };
    class sd {};

    function qd(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof cd ? f = c : (f = new cd, mc(c, (h, k) => {
                var l = f;
                const m = l.l++;
                h = Yc(k, h);
                l.g.push(m);
                l.h[m] = h
            }));
            const g = bd(f, "/pagead/gen_204?id=" + b + "&");
            g && yc(n, g)
        } catch (f) {}
    }

    function td() {
        var a = pd,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.g = b)
    }
    var ud = class {
        constructor() {
            this.g = Math.random()
        }
    };
    const vd = [na, oa, qa, pa, ma, sa, ta, ra, ua];

    function wd(a, b) {
        if (a instanceof t) return a;
        const c = xa(a, vd);
        c === ka && b(a);
        return c
    }

    function xd(a) {
        var b = `${Kc.location.protocol==="http:"?"http:":"https:"}//${"pagead2.googlesyndication.com"}/pagead/gen_204`;
        return c => {
            c = {
                id: "unsafeurl",
                ctx: a,
                url: c
            };
            const d = [];
            for (e in c) fd(e, c[e], d);
            var e = ed(b, d.join("&"));
            navigator.sendBeacon && navigator.sendBeacon(e, "")
        }
    };
    let pd, od;
    const Z = new class {
        constructor(a, b) {
            this.h = [];
            this.j = b || n;
            let c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.h = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.g = Wc() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Uc(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Y && Wc() && Y.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (Tc() || Sc()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Y && Wc() && Y.mark(b);
                !this.g ||
                    this.h.length > 2048 || this.h.push(a)
            }
        }
    }(1, window);

    function yd() {
        window.google_measure_js_timing || (Z.g = !1, Z.h !== Z.j.google_js_reporting_queue && (Wc() && Array.prototype.forEach.call(Z.h, Xc, void 0), Z.h.length = 0))
    }(function(a) {
        pd = a != null ? a : new ud;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        td();
        od = new rd(Z);
        od.h = b => {
            const c = Bc;
            c !== 0 && (b.jc = String(c), b.shv = Ic(c))
        };
        od.j = !0;
        window.document.readyState === "complete" ? yd() : Z.g && W(window, "load", () => {
            yd()
        })
    })();

    function zd(a, b) {
        return nd(a, b)
    }

    function Ad(a, b) {
        var c = sd;
        var d = "T";
        c.T && c.hasOwnProperty(d) || (d = new c, c.T = d);
        c = [];
        !b.eid && c.length && (b.eid = c.toString());
        qd(pd, a, b, !0)
    };

    function Bd(a = window) {
        return a
    };
    lc({
        ra: 0,
        qa: 1,
        na: 2,
        ha: 3,
        oa: 4,
        ia: 5,
        pa: 6,
        la: 7,
        ma: 8,
        ga: 9,
        ka: 10,
        sa: 11
    });
    lc({
        ua: 0,
        va: 1,
        ta: 2
    });

    function Cd(a) {
        var b = new Dd;
        Jb(b);
        b = Ob(b, 1, fb, 2, !0);
        if (Array.isArray(a)) {
            var c = a.length;
            for (let d = 0; d < c; d++) b.push(eb(a[d]))
        } else
            for (c of a) b.push(eb(c))
    }
    var Dd = class extends U {};
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    Cd([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23]);
    Cd([1, 6, 7, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23]);
    Cd([1, 6, 7, 9, 10, 11, 12, 22, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21, 23]);
    new Dd;
    var Ed = (a, b) => {
            b = R(a, 2) || b;
            if (!b) return "";
            if (Q(a, 13)) return b;
            const c = /[?&]adurl=([^&]+)/.exec(b);
            if (!c) return b;
            const d = [b.slice(0, c.index + 1)];
            M(a, 4, void 0, jb).forEach((e, f) => {
                d.push(encodeURIComponent(f) + "=" + encodeURIComponent(e) + "&")
            });
            d.push(b.slice(c.index + 1));
            return d.join("")
        },
        Fd = (a, b = []) => {
            b = b.length > 0 ? b : Lc("data-asoch-targets");
            a = M(a, 1, hc);
            const c = [];
            for (let h = 0; h < b.length; ++h) {
                var d = b[h].getAttribute("data-asoch-targets"),
                    e = d.split(","),
                    f = !0;
                for (let k of e)
                    if (!a.has(k)) {
                        f = !1;
                        break
                    }
                if (f) {
                    f =
                        a.get(e[0]);
                    for (d = 1; d < e.length; ++d) {
                        var g = a.get(e[d]);
                        f = Hb(f);
                        f = E(f);
                        g = E(g);
                        const k = Math.max(f.length, g.length);
                        for (let l = 0; l < k; ++l) f[l] == null && (f[l] = g[l]);
                        f = new hc(f)
                    }
                    e = M(f, 4, void 0, jb);
                    fb(G(f, 5)) != null && e.set("nb", S(f, 5).toString());
                    c.push({
                        element: b[h],
                        data: f
                    })
                } else Ad("gdn-asoch", {
                    type: 1,
                    data: d
                })
            }
            return c
        },
        Id = (a, b, c, d) => {
            c = Ed(b, c);
            if (c.length !== 0) {
                var e = d === 609;
                if (id(c, "ase") === "2" && d !== 1087) {
                    var f;
                    const g = !((f = X.featurePolicy) == null || !f.allowedFeatures().includes("attribution-reporting"));
                    f =
                        e ? 4 : g ? 6 : 5;
                    let h = "";
                    const k = fa(new ia({
                        url: c
                    }), 0);
                    e || g && (!k || k.version !== 3) ? (c = Gd(c, "nis", f.toString()), a.setAttribute("attributionsrc", h)) : g && k && k.version === 3 && (h = Gd(k.v, "nis", f.toString()), a.setAttribute("attributionsrc", h))
                }
                e && J(b, Yb, 24) && (e = N(b, Yb, 24), a.setAttribute("attributionDestination", R(e, 2)), a.setAttribute("attributionSourceNonce", R(e, 1)));
                (e = (e = Hc(35)) && e.dataset.expanded ? e.dataset.expanded : null) && d === 557 && (c = Hd(c, "expanded", e));
                za(a, wd(c, xd(d)));
                a.target || (a.target = C(G(b, 11)) != null ? R(b,
                    11) : "_top")
            }
        },
        Jd = a => {
            for (const b of a)
                if (a = b.data, b.element.tagName == "A" && !Q(a, 1)) {
                    const c = b.element;
                    Id(c, a, c.href, 609)
                }
        },
        Hd = (a, b, c) => {
            b = encodeURIComponent(b);
            const d = encodeURIComponent(c);
            c = new RegExp("[?&]" + b + "=([^&]+)");
            const e = c.exec(a);
            b = b + "=" + d;
            return e ? a.replace(c, e[0].charAt(0) + b) : a.replace("?", "?" + b + "&")
        },
        Kd = a => {
            var b = n.oneAfmaInstance;
            if (b)
                for (var c of a) {
                    var d = c.data;
                    if (d && J(d, dc, 8) && (a = N(d, dc, 8), a = R(a, 4))) {
                        c = b.fetchAppStoreOverlay;
                        d = N(d, dc, 8);
                        d = R(d, 6);
                        c.call(b, a, void 0, d);
                        break
                    }
                }
        },
        Ld =
        (a, b = 500) => {
            const c = [],
                d = [];
            for (var e of a)(a = e.data) && J(a, V, 12) && (d.push(N(a, V, 12)), c.push(N(a, V, 12).A()));
            e = (f, g) => {
                if (g)
                    for (const h of d) g[h.A()] && h.U(!0)
            };
            a = n.oneAfmaInstance;
            for (const f of c) {
                let g;
                (g = a) == null || g.canOpenAndroidApp(f, e, () => {}, b)
            }
        },
        Nd = (a, b, c, d) => {
            if (!b || !J(b, dc, 8)) return !1;
            const e = N(b, dc, 8);
            let f = R(e, 2);
            M(b, 10, void 0, jb).forEach((p, q) => {
                f = Hd(f, q, p)
            });
            Md(b) && Q(b, 15) && !/[?&]label=/.test(c) && (c = Gd(c, "label", "deep_link_fallback"));
            (a == null ? 0 : Q(a, 1)) && Ad("skspvc", {});
            var g = a == null ?
                void 0 : Q(a, 7);
            const h = R(b, 9);
            let k = void 0,
                l = void 0,
                m = -1;
            if (g && h) {
                const p = ld(h, "skspvc_triggered"),
                    q = ld(h, "skspvc_registered"),
                    v = ld(h, "skspvc_dismissed");
                k = () => {
                    Ac(p);
                    m = setTimeout(() => {
                        Ac(q)
                    }, 3E3)
                };
                l = () => {
                    Ac(v);
                    clearTimeout(m)
                }
            }
            g = p => d.openStoreOverlay(p, k, l, R(e, 6));
            return d.redirectForStoreU2({
                clickUrl: c,
                trackingUrl: R(e, 3),
                finalUrl: f,
                pingFunc: Q(b, 13) ? d.httpTrack : d.click,
                openFunc: (a == null ? 0 : Q(a, 1)) ? g : d.openIntentOrNativeApp,
                isExternalClickUrl: Q(b, 13)
            })
        },
        Od = (a, b, c, d) => {
            c && c.startsWith("intent:") ? d.openIntentOrNativeApp(c) :
                a ? b ? d.openBrowser(c) : d.openChromeCustomTab(c) : d.openSystemBrowser(c, {
                    useFirstPackage: !0,
                    useRunningProcess: !0
                })
        },
        Rd = (a, b, c, d, e, f, g, h = !1, k = !1) => {
            const l = Q(e, 15);
            if (!k && l && C(G(e, 22)) != null) Od(c, d, R(e, 22), g);
            else {
                var m = fa(new ia({
                    url: f
                }), 0);
                k = l && (m && m.version === 3 || k);
                if (a && b && !k && (f = Pd(f, g.click, !0), h && (e == null ? 0 : Q(e, 21)))) return;
                Od(c, d, f, g)
            }
        },
        Pd = (a, b = null, c = !1) => {
            if (b === null) {
                var d = new ia({
                    url: a,
                    fa: null
                });
                d.g.dsh === "1" || d.g.aspm !== "1" ? b = (b = fa(d, 0)) ? navigator.sendBeacon ? navigator.sendBeacon(b.v, "") ? b.B :
                    ha(d, 2) : ha(d, 0) : a : (b = fa(d, 1)) ? (fetch(b.v, {
                        keepalive: !0,
                        mode: "no-cors",
                        credentials: "include"
                    }), b = b.B) : b = a;
                return b
            }
            d = fa(new ia({
                url: a
            }), 0);
            if (!d) return a;
            a = d.v;
            if (d.version === 4 && c) {
                var e = encodeURIComponent("ase");
                c = encodeURIComponent("3");
                e = new RegExp("[?&]" + e + "=([^&]+)", "g");
                let f = 0;
                const g = [];
                for (let h = e.exec(a); h !== null;) {
                    if (h[1] == c) {
                        let k = h[0].charAt(0) == "?" ? 1 : 0;
                        g.push(a.slice(f, h.index + k));
                        f = h.index + h[0].length + k
                    }
                    h = e.exec(a)
                }
                g.push(a.slice(f));
                a = g.join("")
            }
            b(a);
            return d.B
        },
        Sd = (a, b = !0) => {
            b && Kc.fetch ?
                Kc.fetch(a, {
                    method: "GET",
                    keepalive: !0,
                    mode: "no-cors"
                }).then(c => {
                    c.ok || yc(Kc, a)
                }) : yc(Kc, a)
        },
        Gd = (a, b, c) => {
            b = encodeURIComponent(String(b));
            c = encodeURIComponent(String(c));
            return a.replace("?", "?" + b + "=" + c + "&")
        },
        Md = a => {
            for (const b of fc(a))
                if (S(b, 1) === 3 && R(b, 2)) return !0;
            return !1
        };
    var Td = (a, b) => a && (a = a.match(b + "=([^&]+)")) && a.length == 2 ? a[1] : "";
    var Ud = class extends U {};

    function Vd(a, b) {
        return T(a, 2, b)
    }

    function Wd(a, b) {
        return T(a, 3, b)
    }

    function Xd(a, b) {
        return T(a, 4, b)
    }

    function Yd(a, b) {
        return T(a, 5, b)
    }

    function Zd(a, b) {
        return T(a, 9, b)
    }

    function $d(a, b) {
        {
            Jb(a);
            const l = a.i;
            let m = l[y] | 0;
            if (b == null) H(l, m, 10);
            else {
                var c = b === Sa ? 7 : b[y] | 0,
                    d = c,
                    e = Tb(c),
                    f = e || Object.isFrozen(b),
                    g = !0,
                    h = !0;
                for (let p = 0; p < b.length; p++) {
                    var k = b[p];
                    e || (k = A(k), g && (g = !k), h && (h = k))
                }
                e || (c = g ? 13 : 5, c = h ? c & -4097 : c | 4096);
                f && c === d || (b = [...b], d = 0, c = Rb(c, m));
                c !== d && (b[y] = c);
                m = H(l, m, 10, b);
                2 & c || !(4096 & c || 16 & c) || Kb(l, m)
            }
        }
        return a
    }

    function ae(a, b) {
        return Vb(a, 11, b)
    }

    function be(a, b) {
        return T(a, 1, b)
    }

    function ce(a, b) {
        return Vb(a, 7, b)
    }
    var de = class extends U {};
    const ee = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function fe(a) {
        let b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function ge(a) {
        let b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function he() {
        var a = window;
        if (!ge(a)) return null;
        const b = fe(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(ee).then(c => {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function ie(a) {
        let b;
        return ae($d(Yd(Vd(be(Xd(ce(Zd(Wd(new de, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(c => {
            var d = new Ud;
            d = T(d, 1, c.brand);
            return T(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function je() {
        let a, b;
        return (b = (a = he()) == null ? void 0 : a.then(c => ie(c))) != null ? b : null
    };

    function ke(a) {
        for (const b of a)
            if (b.element.tagName == "A") {
                a = b.element;
                const c = b.data;
                C(G(c, 2)) == null && T(c, 2, a.href)
            }
    }

    function le(a, b) {
        return Aa(a, c => c.element === b)
    }

    function me(a) {
        wc(zd(556, () => {
            new ne(a || {})
        }))
    }

    function oe(a, b) {
        if (!b.defaultPrevented || a.J === b) {
            for (var c, d, e = b.target;
                (!c || !d) && e;) {
                d || e.tagName != "A" || (d = e);
                var f = e.hasAttribute("data-asoch-targets"),
                    g = e.hasAttribute("data-asoch-fixed-value");
                if (!c)
                    if (g) c = new hc(JSON.parse(e.getAttribute("data-asoch-fixed-value")) || []);
                    else if (e.tagName == "A" || f)
                    if (f = f && e.getAttribute("data-asoch-is-dynamic") === "true" ? Fd(a.h, [e]) : a.g, f = le(f, e)) c = f.data;
                e = e.parentElement
            }
            e = c && !Q(c, 1);
            if (a.G && a.l && b.defaultPrevented) pe(a, b, d, e ? c : a.l);
            else {
                if (e) {
                    if (!a.G && b.defaultPrevented) {
                        pe(a,
                            b, d, c);
                        return
                    }
                    f = c;
                    for (var h of Ob(f, 6, C, void 0 === Xa ? 2 : 4)) Sd(h)
                }
                a.K && e && Q(c, 21) && vc(b);
                if (d && e) {
                    c = e ? c : null;
                    (h = le(a.g, d)) ? h = h.data: (h = new hc, T(h, 2, d.href), T(h, 11, d.target || "_top"), a.g.push({
                        element: d,
                        data: h
                    }));
                    Id(d, c || h, R(h, 2), 557);
                    qe(a, b, d, c);
                    for (var k of Ob(a.h, 17, C, void 0 === Xa ? 2 : 4)) h = X.body, e = {}, typeof window.CustomEvent === "function" ? f = new CustomEvent(k, e) : (f = document.createEvent("CustomEvent"), f.initCustomEvent(k, !!e.bubbles, !!e.cancelable, e.detail)), h.dispatchEvent(f);
                    var l;
                    if (c == null ? 0 : (l = N(c,
                            ec, 26)) == null ? 0 : C(G(l, 1)) != null) {
                        l = new Zb;
                        fb(G(c, 5)) != null ? (k = l, h = S(c, 5), Xb(k, 1, h)) : (k = Td(d.href, "nb"), k != "" && Xb(l, 1, +k));
                        k = Td(d.href, "nx");
                        k != "" && Wb(l, 2, +k);
                        k = Td(d.href, "ny");
                        k != "" && Wb(l, 3, +k);
                        k = Td(d.href, "bg");
                        k != "" && T(l, 4, k);
                        k = Td(d.href, "nm");
                        k != "" && Wb(l, 5, +k);
                        k = Td(d.href, "mb");
                        k != "" && Wb(l, 6, +k);
                        k = kd(d.href, "bg");
                        za(d, wd(k, xd(1211)));
                        k = N(c, ec, 26);
                        f = R(k, 1);
                        k = N(c, ec, 26);
                        k = R(k, 2);
                        h = gb(G(c, 20)) != null ? Ub(c, 20) : null;
                        g = JSON.stringify(E(l));
                        l = a.D;
                        e = Bd(n);
                        var m = new jc;
                        f = T(m, 1, f);
                        f = T(f, 4, g);
                        f = T(f, 10, Date.now().toString());
                        h !== null && Wb(f, 2, h);
                        l !== null && T(f, 3, l);
                        Xb(f, 9, 7);
                        var p;
                        e == null || (p = e.fence) == null || p.setReportEventDataForAutomaticBeacons({
                            eventType: "reserved.top_navigation_start",
                            eventData: JSON.stringify(f),
                            destination: ["buyer"],
                            once: !0
                        });
                        var q;
                        e == null || (q = e.fence) == null || q.reportEvent({
                            eventType: "click",
                            eventData: k,
                            destination: ["component-seller"]
                        })
                    }
                    Q(a.h, 16) || a.N ? re(a, b, d, c) : (p = "", (q = n.oneAfmaInstance) && (p = q.appendClickSignals(d.href)), se(a, b, d, c, p))
                }
            }
        }
    }

    function pe(a, b, c, d) {
        if (a.J === b && a.F) {
            var e = new ac(a.F),
                f = R(d, 9),
                g = "";
            switch (S(e, 4, 1)) {
                case 2:
                    if (Ub(e, 2)) g = "blocked_fast_click";
                    else if (R(e, 1) || R(e, 7)) g = "blocked_border_click";
                    break;
                case 3:
                    g = X;
                    g = g.getElementById ? g.getElementById("common_15click_anchor") : null;
                    var h = window;
                    if (typeof h.copfcChm === "function" && g) {
                        d = Hb(d);
                        Xb(d, 5, 12);
                        M(d, 4, void 0, jb).set("nb", (12).toString());
                        var k = le(a.g, g);
                        k ? k.data = d : a.g.push({
                            element: g,
                            data: d
                        });
                        !a.S && c && (qe(a, b, c, d), T(d, 2, c.href));
                        c = h;
                        h = c.copfcChm;
                        k = Ed(d, g.href);
                        J(e,
                            $b, 10) ? (e = N(e, $b, 10), e = JSON.stringify(E(e))) : e = null;
                        h.call(c, b, k, null, e);
                        a.S && qe(a, b, g, d)
                    }
                    g = "onepointfiveclick_first_click"
            }
            f && g && (f = f + "&label=" + g, g === "onepointfiveclick_first_click" && (f += "&ccx=" + b.clientX + "&ccy=" + b.clientY), Sd(f, !1));
            Jc(a.O)
        }
    }

    function qe(a, b, c, d) {
        if (!Q(d, 13)) {
            var e = c.href;
            var f = /[?&]adurl=([^&]+)/.exec(e);
            e = f ? [e.slice(0, f.index), e.slice(f.index)] : [e, ""];
            for (za(c, wd(e[0], xd(557))); !c.id;)
                if (f = "asoch-id-" + (Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36)), !X.getElementById(f)) {
                    c.id = f;
                    break
                }
            f = c.id;
            typeof window.xy === "function" && window.xy(b, c, X.body);
            typeof window.mb === "function" && window.mb(c);
            typeof window.bgz === "function" && window.bgz(f);
            typeof window.ja ===
                "function" && window.ja(f, d ? S(d, 5) : 0);
            typeof window.vti === "function" && window.vti(c);
            a.j && typeof window.ss === "function" && (a.R ? window.ss(f, 1, a.j) : window.ss(a.j, 1));
            if (e.length > 0) {
                let g;
                b = a.D.length > 0 && (d == null || (g = N(d, ec, 26)) == null || C(G(g, 1)) == null) ? c.href + "&uach=" + encodeURIComponent(a.D) + e[1] : c.href + e[1];
                za(c, wd(b, xd(557)))
            }
        }
    }
    async function re(a, b, c, d) {
        let e = "";
        var f = n.oneAfmaInstance;
        if (f && (b.preventDefault(), e = await f.appendClickSignalsAsync(c.href) || "", a.N)) {
            if (a.Y) return;
            if (f = await f.getNativeClickMeta()) {
                if (f.customClickGestureEligible) return;
                e = Gd(e, "nas", f.encodedNas)
            }
        }
        se(a, b, c, d, e)
    }

    function se(a, b, c, d, e) {
        a.M++;
        a.H < 0 && (a.H = Date.now());
        const f = Q(a.h, 2),
            g = f && Date.now() - a.P > 300,
            h = n.oneAfmaInstance;
        h ? (vc(b), (() => {
            var k = Q(d, 13) ? e : h.logScionEventAndAddParam(e);
            if (!a.I && d && J(d, V, 12)) {
                var l = N(d, V, 12).A();
                var m = "";
                if (fc(d).length > 0)
                    for (const p of fc(d)) m += R(p, 2) + " " + p.A() + " ";
                m = N(d, V, 12);
                Q(m, 2) ? (h.click(k), h.openAndroidApp(l), l = !0) : l = !1
            } else l = !1;
            l || Nd(a.u, d, k, h) || Rd(f, g, a.aa, a.I, d, k, h, a.K, a.Z)
        })()) : (b = window, a.X && b.pawsig && typeof b.pawsig.clk === "function" ? (Ad("paw_sigs", {
            msg: "click",
            count: a.M.toString(),
            elapsed: (Date.now() - a.H).toString()
        }), g && b.pawsig.clk(c)) : g && (b = c.getAttribute("attributionsrc") != null && id(c.getAttribute("attributionsrc"), "nis") === "6" ? Pd(c.href, () => {}) : Pd(c.href), b !== c.href && za(c, wd(b, xd(599)))));
        g && (a.P = Date.now());
        Jc(a.O)
    }
    var ne = class {
        constructor(a) {
            this.I = Ia || Ga || Ja || Ha;
            var b = Lc("data-asoch-meta");
            if (b.length !== 1) Ad("gdn-asoch", {
                type: 2,
                data: b.length
            });
            else {
                this.O = 70;
                this.h = new ic(JSON.parse(b[0].getAttribute("data-asoch-meta")) || []);
                this.L = a["extra-meta"] ? new ic(JSON.parse(a["extra-meta"])) : null;
                this.N = a["is-fsn"] === "true";
                this.Y = a["is-tap-disabled-for-fsn"] === "true";
                this.u = a["ios-store-overlay-config"] ? new bc(JSON.parse(a["ios-store-overlay-config"])) : null;
                this.aa = a["use-cct-over-browser"] === "true";
                this.S = a["correct-redirect-url-for-och-15-click"] ===
                    "true";
                this.Z = a["spitzer-use-click-url-for-fallback"] === "true";
                this.G = a["default-msg-in-och"] === "true";
                this.X = a["enable-paw"] === "true";
                this.K = a["allow-redirection-muted-in-och"] === "true";
                this.D = "";
                b = je();
                b != null && b.then(d => {
                    var e = JSON.stringify(E(d));
                    d = [];
                    var f = 0;
                    for (var g = 0; g < e.length; g++) {
                        var h = e.charCodeAt(g);
                        h > 255 && (d[f++] = h & 255, h >>= 8);
                        d[f++] = h
                    }
                    e = 3;
                    e === void 0 && (e = 0);
                    if (!La)
                        for (La = {}, f = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), g = ["+/=", "+/", "-_=", "-_.", "-_"], h =
                            0; h < 5; h++) {
                            var k = f.concat(g[h].split(""));
                            Ka[h] = k;
                            for (var l = 0; l < k.length; l++) {
                                var m = k[l];
                                La[m] === void 0 && (La[m] = l)
                            }
                        }
                    e = Ka[e];
                    f = Array(Math.floor(d.length / 3));
                    g = e[64] || "";
                    for (h = k = 0; k < d.length - 2; k += 3) {
                        var p = d[k],
                            q = d[k + 1];
                        m = d[k + 2];
                        l = e[p >> 2];
                        p = e[(p & 3) << 4 | q >> 4];
                        q = e[(q & 15) << 2 | m >> 6];
                        m = e[m & 63];
                        f[h++] = l + p + q + m
                    }
                    l = 0;
                    m = g;
                    switch (d.length - k) {
                        case 2:
                            l = d[k + 1], m = e[(l & 15) << 2] || g;
                        case 1:
                            d = d[k], f[h] = e[d >> 2] + e[(d & 3) << 4 | l >> 4] + m + g
                    }
                    this.D = f.join("")
                });
                this.g = Fd(this.h);
                this.G && (this.l = null, M(this.h, 1, hc).forEach(d => {
                    this.l !=
                        null || C(G(d, 2)) == null || C(G(d, 9)) == null || Q(d, 13) || (this.l = d)
                }));
                this.ba = Number(a["deeplink-and-android-app-validation-timeout"]) || 500;
                this.P = -Infinity;
                this.H = this.M = 0;
                this.j = R(this.h, 5) || "";
                this.R = Q(this.h, 11);
                this.L && (this.R = Q(this.L, 11));
                this.F = this.J = null;
                Q(this.h, 3) || (Jd(this.g), Vb(this.h, 3, !0));
                ke(this.g);
                a = n.oneAfmaInstance;
                !this.I && a && Ld(this.g, this.ba);
                var c;
                if (a && ((c = this.u) == null ? 0 : Q(c, 2))) switch (c = () => {
                    const d = Ub(this.u, 4);
                    d > 0 ? n.setTimeout(() => {
                        Kd(this.g)
                    }, d) : Kd(this.g)
                }, S(this.u, 3)) {
                    case 1:
                        a.runOnOnShowEvent(c);
                        break;
                    case 2:
                        xc(c);
                        break;
                    default:
                        Kd(this.g)
                }
                W(X, "click", zd(557, d => {
                    oe(this, d)
                }), rc);
                W(X, "auxclick", zd(557, d => {
                    d.button === 1 && oe(this, d)
                }), rc);
                this.j && typeof window.ss === "function" && W(X.body, "mouseover", zd(626, () => {
                    window.ss(this.j, 0)
                }), sc);
                typeof window.ivti === "function" && window.ivti(X.body);
                c = window;
                c.googqscp && typeof c.googqscp.registerCallback === "function" && c.googqscp.registerCallback((d, e) => {
                    this.J = d;
                    this.F = e
                });
                Cc()
            }
        }
    };
    var te = zd(555, a => me(a));
    Bc = 70;
    const ue = Hc(70, document.currentScript);
    if (ue == null) throw Error("JSC not found 70");
    const ve = {},
        we = ue.attributes;
    for (let a = we.length - 1; a >= 0; a--) {
        const b = we[a].name;
        b.indexOf("data-jcp-") === 0 && (ve[b.substring(9)] = we[a].value)
    }
    te(ve);
}).call(this);