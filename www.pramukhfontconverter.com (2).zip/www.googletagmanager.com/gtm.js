// Copyright 2012 Google Inc. All rights reserved.

(function() {

    var data = {
        "resource": {
            "version": "2",

            "macros": [{
                "function": "__e"
            }, {
                "function": "__gas",
                "vtp_cookieDomain": "auto",
                "vtp_doubleClick": false,
                "vtp_setTrackerName": false,
                "vtp_useDebugVersion": false,
                "vtp_useHashAutoLink": false,
                "vtp_decorateFormsAutoLink": false,
                "vtp_enableLinkId": false,
                "vtp_enableEcommerce": false,
                "vtp_trackingId": "UA-2909129-12",
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false
            }, {
                "function": "__u",
                "vtp_component": "URL",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "HOST",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__u",
                "vtp_component": "PATH",
                "vtp_enableMultiQueryKeys": false,
                "vtp_enableIgnoreEmptyQueryParam": false
            }, {
                "function": "__f",
                "vtp_component": "URL"
            }, {
                "function": "__e"
            }],
            "tags": [{
                "function": "__ua",
                "once_per_event": true,
                "vtp_overrideGaSettings": false,
                "vtp_trackType": "TRACK_PAGEVIEW",
                "vtp_gaSettings": ["macro", 1],
                "vtp_enableRecaptchaOption": false,
                "vtp_enableUaRlsa": false,
                "vtp_enableUseInternalVersion": false,
                "vtp_enableFirebaseCampaignData": true,
                "tag_id": 1
            }, {
                "function": "__html",
                "once_per_load": true,
                "vtp_html": "\n\u003Cscript type=\"text\/gtmscript\"\u003Evar Tawk_API=Tawk_API||{},Tawk_LoadStart=new Date;(function(){var a=document.createElement(\"script\"),b=document.getElementsByTagName(\"script\")[0];a.async=!0;a.src=\"https:\/\/embed.tawk.to\/59c56d064854b82732ff1a4a\/default\";a.charset=\"UTF-8\";a.setAttribute(\"crossorigin\",\"*\");b.parentNode.insertBefore(a,b)})();\u003C\/script\u003E\n",
                "vtp_supportDocumentWrite": false,
                "vtp_enableIframeMode": false,
                "vtp_enableEditJsMacroBehavior": false,
                "tag_id": 2
            }],
            "predicates": [{
                "function": "_eq",
                "arg0": ["macro", 0],
                "arg1": "gtm.js"
            }],
            "rules": [
                [
                    ["if", 0],
                    ["add", 0, 1]
                ]
            ]
        },
        "runtime": [
            [50, "__e", [46, "a"],
                [36, [13, [41, "$0"],
                    [3, "$0", ["require", "internal.getEventData"]],
                    ["$0", "event"]
                ]]
            ],
            [50, "__f", [46, "a"],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "getReferrerUrl"]],
                [52, "d", ["require", "makeString"]],
                [52, "e", ["require", "parseUrl"]],
                [52, "f", [15, "__module_legacyUrls"]],
                [52, "g", [30, ["b", "gtm.referrer", 1],
                    ["c"]
                ]],
                [22, [28, [15, "g"]],
                    [46, [36, ["d", [15, "g"]]]]
                ],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "C", [7, [15, "g"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
                        [5, [46, [36, [2, [15, "f"], "E", [7, [15, "g"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [22, [17, [15, "a"], "queryKey"],
                                [46, [53, [36, [2, [15, "f"], "H", [7, [15, "g"],
                                    [17, [15, "a"], "queryKey"]
                                ]]]]]
                            ],
                            [52, "h", ["e", [15, "g"]]],
                            [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]]
                        ]],
                        [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]]
                    ]
                ]
            ],
            [50, "__html", [46, "a"],
                [52, "b", ["require", "internal.injectHtml"]],
                ["b", [17, [15, "a"], "html"],
                    [17, [15, "a"], "gtmOnSuccess"],
                    [17, [15, "a"], "gtmOnFailure"],
                    [17, [15, "a"], "useIframe"],
                    [17, [15, "a"], "supportDocumentWrite"]
                ]
            ],
            [50, "__u", [46, "a"],
                [50, "k", [46, "l", "m"],
                    [52, "n", [17, [15, "m"], "multiQueryKeys"]],
                    [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
                    [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
                    [22, [20, [15, "o"], ""],
                        [46, [53, [52, "r", [2, [17, ["i", [15, "l"]], "search"], "replace", [7, "?", ""]]],
                            [36, [39, [1, [28, [15, "r"]],
                                    [15, "p"]
                                ],
                                [44],
                                [15, "r"]
                            ]]
                        ]]
                    ],
                    [41, "q"],
                    [22, [15, "n"],
                        [46, [53, [22, [20, ["e", [15, "o"]], "array"],
                            [46, [53, [3, "q", [15, "o"]]]],
                            [46, [53, [52, "r", ["c", "\\s+", "g"]],
                                [3, "q", [2, [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]], "split", [7, ","]]]
                            ]]
                        ]]],
                        [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]]
                    ],
                    [65, "r", [15, "q"],
                        [46, [53, [52, "s", [2, [15, "h"], "H", [7, [15, "l"],
                                [15, "r"]
                            ]]],
                            [22, [29, [15, "s"],
                                    [44]
                                ],
                                [46, [53, [22, [1, [15, "p"],
                                            [20, [15, "s"], ""]
                                        ],
                                        [46, [53, [6]]]
                                    ],
                                    [36, [15, "s"]]
                                ]]
                            ]
                        ]]
                    ],
                    [36, [44]]
                ],
                [52, "b", ["require", "copyFromDataLayer"]],
                [52, "c", ["require", "internal.createRegex"]],
                [52, "d", ["require", "getUrl"]],
                [52, "e", ["require", "getType"]],
                [52, "f", ["require", "makeString"]],
                [52, "g", ["require", "parseUrl"]],
                [52, "h", [15, "__module_legacyUrls"]],
                [52, "i", ["require", "internal.legacyParseUrl"]],
                [41, "j"],
                [22, [17, [15, "a"], "customUrlSource"],
                    [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
                    [46, [53, [3, "j", ["b", "gtm.url", 1]]]]
                ],
                [3, "j", [30, [15, "j"],
                    ["d"]
                ]],
                [38, [17, [15, "a"], "component"],
                    [46, "PROTOCOL", "HOST", "PORT", "PATH", "EXTENSION", "QUERY", "FRAGMENT", "URL"],
                    [46, [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "C", [7, [15, "j"],
                            [17, [15, "a"], "stripWww"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
                        [5, [46, [36, [2, [15, "h"], "E", [7, [15, "j"],
                            [17, [15, "a"], "defaultPages"]
                        ]]]]],
                        [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
                        [5, [46, [36, ["k", [15, "j"],
                            [15, "a"]
                        ]]]],
                        [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
                        [5, [46]],
                        [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]]
                    ]
                ]
            ],
            [52, "__module_legacyUrls", [13, [41, "$0"],
                [3, "$0", [51, "", [7],
                    [50, "a", [46],
                        [50, "h", [46, "p"],
                            [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                            [36, [39, [23, [15, "q"], 0],
                                [15, "p"],
                                [2, [15, "p"], "substring", [7, 0, [15, "q"]]]
                            ]]
                        ],
                        [50, "i", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                            [36, [39, [15, "q"],
                                [2, [15, "q"], "replace", [7, ":", ""]], ""
                            ]]
                        ],
                        [50, "j", [46, "p", "q"],
                            [41, "r"],
                            [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                            [22, [28, [15, "r"]],
                                [46, [36, ""]]
                            ],
                            [52, "s", ["b", ":[0-9]+"]],
                            [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                            [22, [15, "q"],
                                [46, [53, [52, "t", ["b", "^www\\d*\\."]],
                                    [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                                    [22, [1, [15, "u"],
                                            [16, [15, "u"], 0]
                                        ],
                                        [46, [3, "r", [2, [15, "r"], "substring", [7, [17, [16, [15, "u"], 0], "length"]]]]]
                                    ]
                                ]]
                            ],
                            [36, [15, "r"]]
                        ],
                        [50, "k", [46, "p"],
                            [52, "q", ["e", [15, "p"]]],
                            [41, "r"],
                            [3, "r", ["f", [17, [15, "q"], "port"]]],
                            [22, [28, [15, "r"]],
                                [46, [53, [22, [20, [17, [15, "q"], "protocol"], "http:"],
                                    [46, [53, [3, "r", 80]]],
                                    [46, [22, [20, [17, [15, "q"], "protocol"], "https:"],
                                        [46, [53, [3, "r", 443]]],
                                        [46, [53, [3, "r", ""]]]
                                    ]]
                                ]]]
                            ],
                            [36, ["g", [15, "r"]]]
                        ],
                        [50, "l", [46, "p", "q"],
                            [52, "r", ["e", [15, "p"]]],
                            [41, "s"],
                            [3, "s", [39, [20, [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]], 0],
                                [17, [15, "r"], "pathname"],
                                [0, "/", [17, [15, "r"], "pathName"]]
                            ]],
                            [22, [20, ["d", [15, "q"]], "array"],
                                [46, [53, [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                                    [22, [19, [2, [15, "q"], "indexOf", [7, [16, [15, "t"],
                                            [37, [17, [15, "t"], "length"], 1]
                                        ]]], 0],
                                        [46, [53, [43, [15, "t"],
                                                [37, [17, [15, "t"], "length"], 1], ""
                                            ],
                                            [3, "s", [2, [15, "t"], "join", [7, "/"]]]
                                        ]]
                                    ]
                                ]]
                            ],
                            [36, [15, "s"]]
                        ],
                        [50, "m", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                            [52, "r", [2, [15, "q"], "split", [7, "."]]],
                            [41, "s"],
                            [3, "s", [39, [18, [17, [15, "r"], "length"], 1],
                                [16, [15, "r"],
                                    [37, [17, [15, "r"], "length"], 1]
                                ], ""
                            ]],
                            [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]]
                        ],
                        [50, "n", [46, "p"],
                            [52, "q", [17, ["e", [15, "p"]], "hash"]],
                            [36, [2, [15, "q"], "replace", [7, "#", ""]]]
                        ],
                        [50, "o", [46, "p", "q"],
                            [50, "s", [46, "t"],
                                [36, ["c", [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]]]]
                            ],
                            [52, "r", [2, [17, ["e", [15, "p"]], "search"], "replace", [7, "?", ""]]],
                            [65, "t", [2, [15, "r"], "split", [7, "&"]],
                                [46, [53, [52, "u", [2, [15, "t"], "split", [7, "="]]],
                                    [22, [21, ["s", [16, [15, "u"], 0]],
                                            [15, "q"]
                                        ],
                                        [46, [6]]
                                    ],
                                    [36, ["s", [2, [2, [15, "u"], "slice", [7, 1]], "join", [7, "="]]]]
                                ]]
                            ],
                            [36]
                        ],
                        [52, "b", ["require", "internal.createRegex"]],
                        [52, "c", ["require", "decodeUriComponent"]],
                        [52, "d", ["require", "getType"]],
                        [52, "e", ["require", "internal.legacyParseUrl"]],
                        [52, "f", ["require", "makeNumber"]],
                        [52, "g", ["require", "makeString"]],
                        [36, [8, "F", [15, "m"], "H", [15, "o"], "G", [15, "n"], "C", [15, "j"], "E", [15, "l"], "D", [15, "k"], "B", [15, "i"], "A", [15, "h"]]]
                    ],
                    [36, ["a"]]
                ]],
                ["$0"]
            ]]

        ],
        "entities": {
            "__e": {
                "2": true,
                "5": true
            },
            "__f": {
                "2": true,
                "5": true
            },
            "__u": {
                "2": true,
                "5": true
            }


        },
        "blob": {
            "1": "2",
            "10": "GTM-W77HWDF",
            "14": "57u1",
            "15": "0",
            "16": "ChEI8LTBxAYQs5bB7Yb6ive7ARIkAL/qOsWnbUTCwPEf8IluNMRUpnyD+sazvNFs9MCSPe6Ul9uDGgIkmw==",
            "19": "dataLayer",
            "20": "",
            "21": "www.googletagmanager.com",
            "22": "eyIwIjoiSU4iLCIxIjoiSU4tR0oiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jby5pbiIsIjQiOiIiLCI1Ijp0cnVlLCI2IjpmYWxzZSwiNyI6ImFkX3N0b3JhZ2V8YW5hbHl0aWNzX3N0b3JhZ2V8YWRfdXNlcl9kYXRhfGFkX3BlcnNvbmFsaXphdGlvbiJ9",
            "23": "google.tagmanager.debugui2.queue",
            "24": "tagassistant.google.com",
            "27": 0.005,
            "3": "www.googletagmanager.com",
            "30": "IN",
            "31": "IN-GJ",
            "32": true,
            "36": "https://adservice.google.com/pagead/regclk",
            "37": "__TAGGY_INSTALLED",
            "38": "cct.google",
            "39": "googTaggyReferrer",
            "40": "https://cct.google/taggy/agent.js",
            "41": "google.tagmanager.ta.prodqueue",
            "42": 0.01,
            "43": "{\"keys\":[{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BIcex10ZRK2Thjnfl+GH1KYkLVfdNfsPBF03pmaqsQcd8ipv3I2XGVWJayXjFxFxOP34UObrkGvnnt8YpFvsJHk=\",\"version\":0},\"id\":\"fe55c9bb-9c64-4baa-9806-265b40e80b39\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BDYYhWAcUM1gE1YOi1yo3B0Jp/ilaKND1oq/pt19mc2ah+by6e835/tA/o/TGYv6BftvduzFgaa9zXmG9kfAMC0=\",\"version\":0},\"id\":\"e71ee716-7588-4c60-8b63-c9d30662ab46\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BDyFOSfvhm9NTA/ekT4WFTbASLUWXlM1uCAPXVE8u6ASuEUfOx0UV+AQrxccjqeszTi1CKcylZY1LtSmFJ+qzDE=\",\"version\":0},\"id\":\"a2200690-e194-4f01-84d9-27c130d58925\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BKnwXjPn7sIaO2YpJSKyRskp45su115J6h48AyTqippqGPrjZc0LQADe7vrmdOEVR8KQkT7y9wAKsSiuRhRlb6g=\",\"version\":0},\"id\":\"57859353-b187-4b1d-b0ed-47d173f10bbc\"},{\"hpkePublicKey\":{\"params\":{\"aead\":\"AES_128_GCM\",\"kdf\":\"HKDF_SHA256\",\"kem\":\"DHKEM_P256_HKDF_SHA256\"},\"publicKey\":\"BJMPpKJEAnH7teaCuytn1CySD6aF/aIhQhFW0RRA7psBrH/AnkItOEvZ8dv889aIbaSGPUkxSwoBZd3IPS/axkE=\",\"version\":0},\"id\":\"13ca10f8-cb13-4f9d-b007-22fb419a4d00\"}]}",
            "44": "101509157~103116026~103200004~103233427~104684208~104684211~105087538~105087540~105103161~105103163",
            "5": "GTM-W77HWDF",
            "8": "res_ts:1557851497460000,srv_cl:789254913,ds:live,cv:2",
            "9": "GTM-W77HWDF"
        },
        "permissions": {
            "__e": {
                "read_event_data": {
                    "eventDataAccess": "specific",
                    "keyPatterns": ["event"]
                }
            },
            "__f": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.referrer"]
                },
                "get_referrer": {
                    "urlParts": "any"
                }
            },
            "__html": {
                "unsafe_inject_arbitrary_html": {}
            },
            "__u": {
                "read_data_layer": {
                    "keyPatterns": ["gtm.url"]
                },
                "get_url": {
                    "urlParts": "any"
                }
            }


        }



        ,
        "security_groups": {
            "customScripts": [
                "__html"

            ],
            "google": [
                "__e",
                "__f",
                "__u"

            ]


        }



    };




    var k, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            for (var b = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global], c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d && d.Math == Math) return d
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ia = {},
        la = {},
        ma = function(a, b, c) {
            if (!c || a != null) {
                var d = la[b];
                if (d == null) return a[b];
                var e = a[d];
                return e !== void 0 ? e : a[b]
            }
        },
        na = function(a, b, c) {
            if (b) a: {
                var d = a.split("."),
                    e = d.length === 1,
                    f = d[0],
                    g;!e && f in ia ? g = ia : g = da;
                for (var h = 0; h < d.length - 1; h++) {
                    var m = d[h];
                    if (!(m in g)) break a;
                    g = g[m]
                }
                var n = d[d.length - 1],
                    p = fa && c === "es6" ? g[n] : null,
                    q = b(p);
                if (q != null)
                    if (e) ba(ia, n, {
                        configurable: !0,
                        writable: !0,
                        value: q
                    });
                    else if (q !== p) {
                    if (la[n] === void 0) {
                        var r =
                            Math.random() * 1E9 >>> 0;
                        la[n] = fa ? da.Symbol(n) : "$jscp$" + r + "$" + n
                    }
                    ba(g, la[n], {
                        configurable: !0,
                        writable: !0,
                        value: q
                    })
                }
            }
        };
    na("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.C = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.C
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    var oa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        pa;
    if (fa && typeof Object.setPrototypeOf == "function") pa = Object.setPrototypeOf;
    else {
        var qa;
        a: {
            var ra = {
                    a: !0
                },
                sa = {};
            try {
                sa.__proto__ = ra;
                qa = sa.a;
                break a
            } catch (a) {}
            qa = !1
        }
        pa = qa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ta = pa,
        va = function(a, b) {
            a.prototype = oa(b.prototype);
            a.prototype.constructor = a;
            if (ta) ta(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.xq = b.prototype
        },
        l = function(a) {
            var b = typeof ia.Symbol != "undefined" && ia.Symbol.iterator && a[ia.Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        xa = function(a) {
            for (var b,
                    c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        ya = function(a) {
            return a instanceof Array ? a : xa(l(a))
        },
        Aa = function(a) {
            return za(a, a)
        },
        za = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        Ba = fa && typeof ma(Object, "assign") == "function" ? ma(Object, "assign") : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };
    na("Object.assign", function(a) {
        return a || Ba
    }, "es6");
    var Ca = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Da = this || self,
        Ea = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.xq = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.wr = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Fa = function(a, b) {
        this.type = a;
        this.data = b
    };
    var Ga = function() {
        this.map = {};
        this.C = {}
    };
    Ga.prototype.get = function(a) {
        return this.map["dust." + a]
    };
    Ga.prototype.set = function(a, b) {
        var c = "dust." + a;
        this.C.hasOwnProperty(c) || (this.map[c] = b)
    };
    Ga.prototype.has = function(a) {
        return this.map.hasOwnProperty("dust." + a)
    };
    Ga.prototype.remove = function(a) {
        var b = "dust." + a;
        this.C.hasOwnProperty(b) || delete this.map[b]
    };
    var Ha = function(a, b) {
        var c = [],
            d;
        for (d in a.map)
            if (a.map.hasOwnProperty(d)) {
                var e = d.substring(5);
                switch (b) {
                    case 1:
                        c.push(e);
                        break;
                    case 2:
                        c.push(a.map[d]);
                        break;
                    case 3:
                        c.push([e, a.map[d]])
                }
            }
        return c
    };
    Ga.prototype.xa = function() {
        return Ha(this, 1)
    };
    Ga.prototype.yc = function() {
        return Ha(this, 2)
    };
    Ga.prototype.ac = function() {
        return Ha(this, 3)
    };
    var Ia = function() {};
    Ia.prototype.reset = function() {};
    var Ja = function(a, b) {
        this.P = a;
        this.parent = b;
        this.M = this.C = void 0;
        this.Bb = !1;
        this.H = function(c, d, e) {
            return c.apply(d, e)
        };
        this.values = new Ga
    };
    Ja.prototype.add = function(a, b) {
        Ka(this, a, b, !1)
    };
    Ja.prototype.ph = function(a, b) {
        Ka(this, a, b, !0)
    };
    var Ka = function(a, b, c, d) {
        if (!a.Bb)
            if (d) {
                var e = a.values;
                e.set(b, c);
                e.C["dust." + b] = !0
            } else a.values.set(b, c)
    };
    k = Ja.prototype;
    k.set = function(a, b) {
        this.Bb || (!this.values.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.values.set(a, b))
    };
    k.get = function(a) {
        return this.values.has(a) ? this.values.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.values.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.qb = function() {
        var a = new Ja(this.P, this);
        this.C && a.Lb(this.C);
        a.Tc(this.H);
        a.Qd(this.M);
        return a
    };
    k.Hd = function() {
        return this.P
    };
    k.Lb = function(a) {
        this.C = a
    };
    k.Wl = function() {
        return this.C
    };
    k.Tc = function(a) {
        this.H = a
    };
    k.Yi = function() {
        return this.H
    };
    k.Ra = function() {
        this.Bb = !0
    };
    k.Qd = function(a) {
        this.M = a
    };
    k.rb = function() {
        return this.M
    };
    var La = function() {
        this.value = {};
        this.prefix = "gtm."
    };
    La.prototype.set = function(a, b) {
        this.value[this.prefix + String(a)] = b
    };
    La.prototype.get = function(a) {
        return this.value[this.prefix + String(a)]
    };
    La.prototype.has = function(a) {
        return this.value.hasOwnProperty(this.prefix + String(a))
    };

    function Ma() {
        try {
            return Map ? new Map : new La
        } catch (a) {
            return new La
        }
    };
    var Na = function() {
        this.values = []
    };
    Na.prototype.add = function(a) {
        this.values.indexOf(a) === -1 && this.values.push(a)
    };
    Na.prototype.has = function(a) {
        return this.values.indexOf(a) > -1
    };
    var Oa = function(a, b) {
        this.fa = a;
        this.parent = b;
        this.P = this.H = void 0;
        this.Bb = !1;
        this.M = function(d, e, f) {
            return d.apply(e, f)
        };
        this.C = Ma();
        var c;
        try {
            c = Set ? new Set : new Na
        } catch (d) {
            c = new Na
        }
        this.R = c
    };
    Oa.prototype.add = function(a, b) {
        Pa(this, a, b, !1)
    };
    Oa.prototype.ph = function(a, b) {
        Pa(this, a, b, !0)
    };
    var Pa = function(a, b, c, d) {
        a.Bb || a.R.has(b) || (d && a.R.add(b), a.C.set(b, c))
    };
    k = Oa.prototype;
    k.set = function(a, b) {
        this.Bb || (!this.C.has(a) && this.parent && this.parent.has(a) ? this.parent.set(a, b) : this.R.has(a) || this.C.set(a, b))
    };
    k.get = function(a) {
        return this.C.has(a) ? this.C.get(a) : this.parent ? this.parent.get(a) : void 0
    };
    k.has = function(a) {
        return !!this.C.has(a) || !(!this.parent || !this.parent.has(a))
    };
    k.qb = function() {
        var a = new Oa(this.fa, this);
        this.H && a.Lb(this.H);
        a.Tc(this.M);
        a.Qd(this.P);
        return a
    };
    k.Hd = function() {
        return this.fa
    };
    k.Lb = function(a) {
        this.H = a
    };
    k.Wl = function() {
        return this.H
    };
    k.Tc = function(a) {
        this.M = a
    };
    k.Yi = function() {
        return this.M
    };
    k.Ra = function() {
        this.Bb = !0
    };
    k.Qd = function(a) {
        this.P = a
    };
    k.rb = function() {
        return this.P
    };
    var Qa = function(a, b, c) {
        var d;
        d = Error.call(this, a.message);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.im = a;
        this.Ol = c === void 0 ? !1 : c;
        this.debugInfo = [];
        this.C = b
    };
    va(Qa, Error);
    var Ra = function(a) {
        return a instanceof Qa ? a : new Qa(a, void 0, !0)
    };
    var Sa = [],
        Ta = {};

    function Ua(a) {
        return Sa[a] === void 0 ? !1 : Sa[a]
    };
    var Wa = Ma();

    function Xa(a, b) {
        for (var c, d = l(b), e = d.next(); !e.done && !(c = Ya(a, e.value), c instanceof Fa); e = d.next());
        return c
    }

    function Ya(a, b) {
        try {
            if (Ua(16)) {
                var c = b[0],
                    d = b.slice(1),
                    e = String(c),
                    f = Wa.has(e) ? Wa.get(e) : a.get(e);
                if (!f || typeof f.invoke !== "function") throw Ra(Error("Attempting to execute non-function " + b[0] + "."));
                return f.apply(a, d)
            }
            var g = l(b),
                h = g.next().value,
                m = xa(g),
                n = a.get(String(h));
            if (!n || typeof n.invoke !== "function") throw Ra(Error("Attempting to execute non-function " + b[0] + "."));
            return n.invoke.apply(n, [a].concat(ya(m)))
        } catch (q) {
            var p = a.Wl();
            p && p(q, b.context ? {
                id: b[0],
                line: b.context.line
            } : null);
            throw q;
        }
    };
    var Za = function() {
        this.H = new Ia;
        this.C = Ua(16) ? new Oa(this.H) : new Ja(this.H)
    };
    k = Za.prototype;
    k.Hd = function() {
        return this.H
    };
    k.Lb = function(a) {
        this.C.Lb(a)
    };
    k.Tc = function(a) {
        this.C.Tc(a)
    };
    k.execute = function(a) {
        return this.zj([a].concat(ya(Ca.apply(1, arguments))))
    };
    k.zj = function() {
        for (var a, b = l(Ca.apply(0, arguments)), c = b.next(); !c.done; c = b.next()) a = Ya(this.C, c.value);
        return a
    };
    k.Zn = function(a) {
        var b = Ca.apply(1, arguments),
            c = this.C.qb();
        c.Qd(a);
        for (var d, e = l(b), f = e.next(); !f.done; f = e.next()) d = Ya(c, f.value);
        return d
    };
    k.Ra = function() {
        this.C.Ra()
    };
    var ab = function() {
        this.Ea = !1;
        this.Z = new Ga
    };
    k = ab.prototype;
    k.get = function(a) {
        return this.Z.get(a)
    };
    k.set = function(a, b) {
        this.Ea || this.Z.set(a, b)
    };
    k.has = function(a) {
        return this.Z.has(a)
    };
    k.remove = function(a) {
        this.Ea || this.Z.remove(a)
    };
    k.xa = function() {
        return this.Z.xa()
    };
    k.yc = function() {
        return this.Z.yc()
    };
    k.ac = function() {
        return this.Z.ac()
    };
    k.Ra = function() {
        this.Ea = !0
    };
    k.Bb = function() {
        return this.Ea
    };

    function bb() {
        for (var a = cb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
        return b
    }

    function db() {
        var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        a += a.toLowerCase() + "0123456789-_";
        return a + "."
    }
    var cb, eb;

    function fb(a) {
        cb = cb || db();
        eb = eb || bb();
        for (var b = [], c = 0; c < a.length; c += 3) {
            var d = c + 1 < a.length,
                e = c + 2 < a.length,
                f = a.charCodeAt(c),
                g = d ? a.charCodeAt(c + 1) : 0,
                h = e ? a.charCodeAt(c + 2) : 0,
                m = f >> 2,
                n = (f & 3) << 4 | g >> 4,
                p = (g & 15) << 2 | h >> 6,
                q = h & 63;
            e || (q = 64, d || (p = 64));
            b.push(cb[m], cb[n], cb[p], cb[q])
        }
        return b.join("")
    }

    function gb(a) {
        function b(m) {
            for (; d < a.length;) {
                var n = a.charAt(d++),
                    p = eb[n];
                if (p != null) return p;
                if (!/^[\s\xa0]*$/.test(n)) throw Error("Unknown base64 encoding at char: " + n);
            }
            return m
        }
        cb = cb || db();
        eb = eb || bb();
        for (var c = "", d = 0;;) {
            var e = b(-1),
                f = b(0),
                g = b(64),
                h = b(64);
            if (h === 64 && e === -1) return c;
            c += String.fromCharCode(e << 2 | f >> 4);
            g !== 64 && (c += String.fromCharCode(f << 4 & 240 | g >> 2), h !== 64 && (c += String.fromCharCode(g << 6 & 192 | h)))
        }
    };
    var hb = {};

    function ib(a, b) {
        hb[a] = hb[a] || [];
        hb[a][b] = !0
    }

    function jb() {
        hb.GTAG_EVENT_FEATURE_CHANNEL = kb
    }

    function lb(a) {
        var b = hb[a];
        if (!b || b.length === 0) return "";
        for (var c = [], d = 0, e = 0; e < b.length; e++) e % 8 === 0 && e > 0 && (c.push(String.fromCharCode(d)), d = 0), b[e] && (d |= 1 << e % 8);
        d > 0 && c.push(String.fromCharCode(d));
        return fb(c.join("")).replace(/\.+$/, "")
    }

    function mb() {
        for (var a = [], b = hb.fdr || [], c = 0; c < b.length; c++) b[c] && a.push(c);
        return a.length > 0 ? a : void 0
    };

    function nb() {}

    function ob(a) {
        return typeof a === "function"
    }

    function pb(a) {
        return typeof a === "string"
    }

    function qb(a) {
        return typeof a === "number" && !isNaN(a)
    }

    function rb(a) {
        return Array.isArray(a) ? a : [a]
    }

    function sb(a, b) {
        if (a && Array.isArray(a))
            for (var c = 0; c < a.length; c++)
                if (a[c] && b(a[c])) return a[c]
    }

    function tb(a, b) {
        if (!qb(a) || !qb(b) || a > b) a = 0, b = 2147483647;
        return Math.floor(Math.random() * (b - a + 1) + a)
    }

    function ub(a, b) {
        for (var c = new vb, d = 0; d < a.length; d++) c.set(a[d], !0);
        for (var e = 0; e < b.length; e++)
            if (c.get(b[e])) return !0;
        return !1
    }

    function wb(a, b) {
        for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(c, a[c])
    }

    function xb(a) {
        return !!a && (Object.prototype.toString.call(a) === "[object Arguments]" || Object.prototype.hasOwnProperty.call(a, "callee"))
    }

    function yb(a) {
        return Math.round(Number(a)) || 0
    }

    function zb(a) {
        return "false" === String(a).toLowerCase() ? !1 : !!a
    }

    function Ab(a) {
        var b = [];
        if (Array.isArray(a))
            for (var c = 0; c < a.length; c++) b.push(String(a[c]));
        return b
    }

    function Bb(a) {
        return a ? a.replace(/^\s+|\s+$/g, "") : ""
    }

    function Cb() {
        return new Date(Date.now())
    }

    function Db() {
        return Cb().getTime()
    }
    var vb = function() {
        this.prefix = "gtm.";
        this.values = {}
    };
    vb.prototype.set = function(a, b) {
        this.values[this.prefix + a] = b
    };
    vb.prototype.get = function(a) {
        return this.values[this.prefix + a]
    };
    vb.prototype.contains = function(a) {
        return this.get(a) !== void 0
    };

    function Eb(a, b, c) {
        return a && a.hasOwnProperty(b) ? a[b] : c
    }

    function Fb(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = void 0;
                try {
                    c()
                } catch (d) {}
            }
        }
    }

    function Gb(a, b) {
        for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c])
    }

    function Hb(a, b) {
        for (var c = [], d = 0; d < a.length; d++) c.push(a[d]), c.push.apply(c, b[a[d]] || []);
        return c
    }

    function Ib(a, b) {
        return a.length >= b.length && a.substring(0, b.length) === b
    }

    function Jb(a, b, c) {
        c = c || [];
        for (var d = a, e = 0; e < b.length - 1; e++) {
            if (!d.hasOwnProperty(b[e])) return;
            d = d[b[e]];
            if (c.indexOf(d) >= 0) return
        }
        return d
    }

    function Kb(a, b) {
        for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++) d = d[e[f]] = {};
        d[e[e.length - 1]] = b;
        return c
    }
    var Lb = /^\w{1,9}$/;

    function Mb(a, b) {
        a = a || {};
        b = b || ",";
        var c = [];
        wb(a, function(d, e) {
            Lb.test(d) && e && c.push(d)
        });
        return c.join(b)
    }

    function Nb(a, b) {
        function c() {
            e && ++d === b && (e(), e = null, c.done = !0)
        }
        var d = 0,
            e = a;
        c.done = !1;
        return c
    }

    function Ob(a) {
        if (!a) return a;
        var b = a;
        try {
            b = decodeURIComponent(a)
        } catch (d) {}
        var c = b.split(",");
        return c.length === 2 && c[0] === c[1] ? c[0] : a
    }

    function Pb(a, b, c) {
        function d(n) {
            var p = n.split("=")[0];
            if (a.indexOf(p) < 0) return n;
            if (c !== void 0) return p + "=" + c
        }

        function e(n) {
            return n.split("&").map(d).filter(function(p) {
                return p !== void 0
            }).join("&")
        }
        var f = b.href.split(/[?#]/)[0],
            g = b.search,
            h = b.hash;
        g[0] === "?" && (g = g.substring(1));
        h[0] === "#" && (h = h.substring(1));
        g = e(g);
        h = e(h);
        g !== "" && (g = "?" + g);
        h !== "" && (h = "#" + h);
        var m = "" + f + g + h;
        m[m.length - 1] === "/" && (m = m.substring(0, m.length - 1));
        return m
    }

    function Qb(a) {
        for (var b = 0; b < 3; ++b) try {
            var c = decodeURIComponent(a).replace(/\+/g, " ");
            if (c === a) break;
            a = c
        } catch (d) {
            return ""
        }
        return a
    }

    function Rb() {
        var a = x.crypto || x.msCrypto;
        if (a && a.getRandomValues) try {
            var b = new Uint8Array(25);
            a.getRandomValues(b);
            return btoa(String.fromCharCode.apply(String, ya(b))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
        } catch (c) {}
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Sb = globalThis.trustedTypes,
        Tb;

    function Ub() {
        var a = null;
        if (!Sb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Sb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    }

    function Vb() {
        Tb === void 0 && (Tb = Ub());
        return Tb
    };
    var Wb = function(a) {
        this.C = a
    };
    Wb.prototype.toString = function() {
        return this.C + ""
    };

    function Xb(a) {
        var b = a,
            c = Vb(),
            d = c ? c.createScriptURL(b) : b;
        return new Wb(d)
    }

    function Yb(a) {
        if (a instanceof Wb) return a.C;
        throw Error("");
    };
    var Zb = Aa([""]),
        $b = za(["\x00"], ["\\0"]),
        bc = za(["\n"], ["\\n"]),
        cc = za(["\x00"], ["\\u0000"]);

    function dc(a) {
        return a.toString().indexOf("`") === -1
    }
    dc(function(a) {
        return a(Zb)
    }) || dc(function(a) {
        return a($b)
    }) || dc(function(a) {
        return a(bc)
    }) || dc(function(a) {
        return a(cc)
    });
    var ec = function(a) {
        this.C = a
    };
    ec.prototype.toString = function() {
        return this.C
    };
    var fc = function(a) {
        this.Mp = a
    };

    function hc(a) {
        return new fc(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    }
    var ic = [hc("data"), hc("http"), hc("https"), hc("mailto"), hc("ftp"), new fc(function(a) {
        return /^[^:]*([/?#]|$)/.test(a)
    })];

    function jc(a) {
        var b;
        b = b === void 0 ? ic : b;
        if (a instanceof ec) return a;
        for (var c = 0; c < b.length; ++c) {
            var d = b[c];
            if (d instanceof fc && d.Mp(a)) return new ec(a)
        }
    }
    var kc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function lc(a) {
        var b;
        if (a instanceof ec)
            if (a instanceof ec) b = a.C;
            else throw Error("");
        else b = kc.test(a) ? a : void 0;
        return b
    };

    function mc(a, b) {
        var c = lc(b);
        c !== void 0 && (a.action = c)
    };

    function nc(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    var oc = function(a) {
        this.C = a
    };
    oc.prototype.toString = function() {
        return this.C + ""
    };
    var qc = function() {
        this.C = pc[0].toLowerCase()
    };
    qc.prototype.toString = function() {
        return this.C
    };

    function rc(a, b) {
        var c = [new qc];
        if (c.length === 0) throw Error("");
        var d = c.map(function(f) {
                var g;
                if (f instanceof qc) g = f.C;
                else throw Error("");
                return g
            }),
            e = b.toLowerCase();
        if (d.every(function(f) {
                return e.indexOf(f) !== 0
            })) throw Error('Attribute "' + b + '" does not match any of the allowed prefixes.');
        a.setAttribute(b, "true")
    };
    var tc = Array.prototype.indexOf ? function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function uc(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a
    };
    var x = window,
        vc = window.history,
        A = document,
        wc = navigator;

    function xc() {
        var a;
        try {
            a = wc.serviceWorker
        } catch (b) {
            return
        }
        return a
    }
    var yc = A.currentScript,
        zc = yc && yc.src;

    function Ac(a, b) {
        var c = x,
            d = c[a];
        c[a] = d === void 0 ? b : d;
        return c[a]
    }

    function Bc(a) {
        return (wc.userAgent || "").indexOf(a) !== -1
    }

    function Cc() {
        return Bc("Firefox") || Bc("FxiOS")
    }

    function Ec() {
        return (Bc("GSA") || Bc("GoogleApp")) && (Bc("iPhone") || Bc("iPad"))
    }

    function Fc() {
        return Bc("Edg/") || Bc("EdgA/") || Bc("EdgiOS/")
    }
    var Gc = {
            async: 1,
            nonce: 1,
            onerror: 1,
            onload: 1,
            src: 1,
            type: 1
        },
        Hc = {
            height: 1,
            onload: 1,
            src: 1,
            style: 1,
            width: 1
        };

    function Ic(a, b, c) {
        b && wb(b, function(d, e) {
            d = d.toLowerCase();
            c.hasOwnProperty(d) || a.setAttribute(d, e)
        })
    }

    function Jc(a, b, c, d, e) {
        var f = A.createElement("script");
        Ic(f, d, Gc);
        f.type = "text/javascript";
        f.async = d && d.async === !1 ? !1 : !0;
        var g;
        g = Xb(uc(a));
        f.src = Yb(g);
        var h, m = f.ownerDocument;
        m = m === void 0 ? document : m;
        var n, p, q = (p = (n = m).querySelector) == null ? void 0 : p.call(n, "script[nonce]");
        (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") && f.setAttribute("nonce", h);
        b && (f.onload = b);
        c && (f.onerror = c);
        if (e) e.appendChild(f);
        else {
            var r = A.getElementsByTagName("script")[0] || A.body || A.head;
            r.parentNode.insertBefore(f, r)
        }
        return f
    }

    function Kc() {
        if (zc) {
            var a = zc.toLowerCase();
            if (a.indexOf("https://") === 0) return 2;
            if (a.indexOf("http://") === 0) return 3
        }
        return 1
    }

    function Lc(a, b, c, d, e, f) {
        f = f === void 0 ? !0 : f;
        var g = e,
            h = !1;
        g || (g = A.createElement("iframe"), h = !0);
        Ic(g, c, Hc);
        d && wb(d, function(n, p) {
            g.dataset[n] = p
        });
        f && (g.height = "0", g.width = "0", g.style.display = "none", g.style.visibility = "hidden");
        a !== void 0 && (g.src = a);
        if (h) {
            var m = A.body && A.body.lastChild || A.body || A.head;
            m.parentNode.insertBefore(g, m)
        }
        b && (g.onload = b);
        return g
    }

    function Mc(a, b, c, d) {
        return Nc(a, b, c, d)
    }

    function Oc(a, b, c, d) {
        a.addEventListener && a.addEventListener(b, c, !!d)
    }

    function Pc(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c, !1)
    }

    function Qc(a) {
        x.setTimeout(a, 0)
    }

    function Rc(a, b) {
        return a && b && a.attributes && a.attributes[b] ? a.attributes[b].value : null
    }

    function Sc(a) {
        var b = a.innerText || a.textContent || "";
        b && b !== " " && (b = b.replace(/^[\s\xa0]+/g, ""), b = b.replace(/[\s\xa0]+$/g, ""));
        b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
        return b
    }

    function Tc(a) {
        var b = A.createElement("div"),
            c = b,
            d, e = uc("A<div>" + a + "</div>"),
            f = Vb(),
            g = f ? f.createHTML(e) : e;
        d = new oc(g);
        if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName)) throw Error("");
        var h;
        if (d instanceof oc) h = d.C;
        else throw Error("");
        c.innerHTML = h;
        b = b.lastChild;
        for (var m = []; b && b.firstChild;) m.push(b.removeChild(b.firstChild));
        return m
    }

    function Uc(a, b, c) {
        c = c || 100;
        for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
        for (var f = a, g = 0; f && g <= c; g++) {
            if (d[String(f.tagName).toLowerCase()]) return f;
            f = f.parentElement
        }
        return null
    }

    function Vc(a, b, c) {
        var d;
        try {
            d = wc.sendBeacon && wc.sendBeacon(a)
        } catch (e) {
            ib("TAGGING", 15)
        }
        d ? b == null || b() : Nc(a, b, c)
    }

    function Wc(a, b) {
        try {
            return wc.sendBeacon(a, b)
        } catch (c) {
            ib("TAGGING", 15)
        }
        return !1
    }
    var Xc = {
        cache: "no-store",
        credentials: "include",
        keepalive: !0,
        method: "POST",
        mode: "no-cors",
        redirect: "follow"
    };

    function Yc(a, b, c, d, e) {
        if (Zc()) {
            var f = ma(Object, "assign").call(Object, {}, Xc);
            b && (f.body = b);
            c && (c.attributionReporting && (f.attributionReporting = c.attributionReporting), c.browsingTopics && (f.browsingTopics = c.browsingTopics), c.credentials && (f.credentials = c.credentials), c.mode && (f.mode = c.mode), c.method && (f.method = c.method));
            try {
                var g = x.fetch(a, f);
                if (g) return g.then(function(m) {
                    m && (m.ok || m.status === 0) ? d == null || d() : e == null || e()
                }).catch(function() {
                    e == null || e()
                }), !0
            } catch (m) {}
        }
        if (c && c.Eh) return e == null || e(), !1;
        if (b) {
            var h = Wc(a, b);
            h ? d == null || d() : e == null || e();
            return h
        }
        $c(a, d, e);
        return !0
    }

    function Zc() {
        return typeof x.fetch === "function"
    }

    function ad(a, b) {
        var c = a[b];
        c && typeof c.animVal === "string" && (c = c.animVal);
        return c
    }

    function bd() {
        var a = x.performance;
        if (a && ob(a.now)) return a.now()
    }

    function cd() {
        var a, b = x.performance;
        if (b && b.getEntriesByType) try {
            var c = b.getEntriesByType("navigation");
            c && c.length > 0 && (a = c[0].type)
        } catch (d) {
            return "e"
        }
        if (!a) return "u";
        switch (a) {
            case "navigate":
                return "n";
            case "back_forward":
                return "h";
            case "reload":
                return "r";
            case "prerender":
                return "p";
            default:
                return "x"
        }
    }

    function dd() {
        return x.performance || void 0
    }

    function ed() {
        var a = x.webPixelsManager;
        return a ? a.createShopifyExtend !== void 0 : !1
    }
    var Nc = function(a, b, c, d) {
            var e = new Image(1, 1);
            Ic(e, d, {});
            e.onload = function() {
                e.onload = null;
                b && b()
            };
            e.onerror = function() {
                e.onerror = null;
                c && c()
            };
            e.src = a;
            return e
        },
        $c = Vc;

    function fd(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function gd(a, b) {
        return this.evaluate(a) === this.evaluate(b)
    }

    function hd(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function id(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        return String(c).indexOf(String(d)) > -1
    }

    function jd(a, b) {
        var c = String(this.evaluate(a)),
            d = String(this.evaluate(b));
        return c.substring(0, d.length) === d
    }

    function kd(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        switch (c) {
            case "pageLocation":
                var e = x.location.href;
                d instanceof ab && d.get("stripProtocol") && (e = e.replace(/^https?:\/\//, ""));
                return e
        }
    };
    /*
     jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
    */
    var ld = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
        md = function(a) {
            if (a == null) return String(a);
            var b = ld.exec(Object.prototype.toString.call(Object(a)));
            return b ? b[1].toLowerCase() : "object"
        },
        nd = function(a, b) {
            return Object.prototype.hasOwnProperty.call(Object(a), b)
        },
        od = function(a) {
            if (!a || md(a) != "object" || a.nodeType || a == a.window) return !1;
            try {
                if (a.constructor && !nd(a, "constructor") && !nd(a.constructor.prototype, "isPrototypeOf")) return !1
            } catch (c) {
                return !1
            }
            for (var b in a);
            return b === void 0 ||
                nd(a, b)
        },
        pd = function(a, b) {
            var c = b || (md(a) == "array" ? [] : {}),
                d;
            for (d in a)
                if (nd(a, d)) {
                    var e = a[d];
                    md(e) == "array" ? (md(c[d]) != "array" && (c[d] = []), c[d] = pd(e, c[d])) : od(e) ? (od(c[d]) || (c[d] = {}), c[d] = pd(e, c[d])) : c[d] = e
                }
            return c
        };

    function qd(a) {
        if (a == void 0 || Array.isArray(a) || od(a)) return !0;
        switch (typeof a) {
            case "boolean":
            case "number":
            case "string":
            case "function":
                return !0
        }
        return !1
    }

    function rd(a) {
        return typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0 || typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a)
    };
    var sd = function(a) {
        a = a === void 0 ? [] : a;
        this.Z = new Ga;
        this.values = [];
        this.Ea = !1;
        for (var b in a) a.hasOwnProperty(b) && (rd(b) ? this.values[Number(b)] = a[Number(b)] : this.Z.set(b, a[b]))
    };
    k = sd.prototype;
    k.toString = function(a) {
        if (a && a.indexOf(this) >= 0) return "";
        for (var b = [], c = 0; c < this.values.length; c++) {
            var d = this.values[c];
            d === null || d === void 0 ? b.push("") : d instanceof sd ? (a = a || [], a.push(this), b.push(d.toString(a)), a.pop()) : b.push(String(d))
        }
        return b.join(",")
    };
    k.set = function(a, b) {
        if (!this.Ea)
            if (a === "length") {
                if (!rd(b)) throw Ra(Error("RangeError: Length property must be a valid integer."));
                this.values.length = Number(b)
            } else rd(a) ? this.values[Number(a)] = b : this.Z.set(a, b)
    };
    k.get = function(a) {
        return a === "length" ? this.length() : rd(a) ? this.values[Number(a)] : this.Z.get(a)
    };
    k.length = function() {
        return this.values.length
    };
    k.xa = function() {
        for (var a = this.Z.xa(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(String(b));
        return a
    };
    k.yc = function() {
        for (var a = this.Z.yc(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push(this.values[b]);
        return a
    };
    k.ac = function() {
        for (var a = this.Z.ac(), b = 0; b < this.values.length; b++) this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
        return a
    };
    k.remove = function(a) {
        rd(a) ? delete this.values[Number(a)] : this.Ea || this.Z.remove(a)
    };
    k.pop = function() {
        return this.values.pop()
    };
    k.push = function() {
        return this.values.push.apply(this.values, ya(Ca.apply(0, arguments)))
    };
    k.shift = function() {
        return this.values.shift()
    };
    k.splice = function(a, b) {
        var c = Ca.apply(2, arguments);
        return b === void 0 && c.length === 0 ? new sd(this.values.splice(a)) : new sd(this.values.splice.apply(this.values, [a, b || 0].concat(ya(c))))
    };
    k.unshift = function() {
        return this.values.unshift.apply(this.values, ya(Ca.apply(0, arguments)))
    };
    k.has = function(a) {
        return rd(a) && this.values.hasOwnProperty(a) || this.Z.has(a)
    };
    k.Ra = function() {
        this.Ea = !0;
        Object.freeze(this.values)
    };
    k.Bb = function() {
        return this.Ea
    };

    function td(a) {
        for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
        return b
    };
    var ud = function(a, b) {
        this.functionName = a;
        this.Fd = b;
        this.Z = new Ga;
        this.Ea = !1
    };
    k = ud.prototype;
    k.toString = function() {
        return this.functionName
    };
    k.getName = function() {
        return this.functionName
    };
    k.getKeys = function() {
        return new sd(this.xa())
    };
    k.invoke = function(a) {
        return this.Fd.call.apply(this.Fd, [new vd(this, a)].concat(ya(Ca.apply(1, arguments))))
    };
    k.apply = function(a, b) {
        return this.Fd.apply(new vd(this, a), b)
    };
    k.Jb = function(a) {
        var b = Ca.apply(1, arguments);
        try {
            return this.invoke.apply(this, [a].concat(ya(b)))
        } catch (c) {}
    };
    k.get = function(a) {
        return this.Z.get(a)
    };
    k.set = function(a, b) {
        this.Ea || this.Z.set(a, b)
    };
    k.has = function(a) {
        return this.Z.has(a)
    };
    k.remove = function(a) {
        this.Ea || this.Z.remove(a)
    };
    k.xa = function() {
        return this.Z.xa()
    };
    k.yc = function() {
        return this.Z.yc()
    };
    k.ac = function() {
        return this.Z.ac()
    };
    k.Ra = function() {
        this.Ea = !0
    };
    k.Bb = function() {
        return this.Ea
    };
    var wd = function(a, b) {
        ud.call(this, a, b)
    };
    va(wd, ud);
    var xd = function(a, b) {
        ud.call(this, a, b)
    };
    va(xd, ud);
    var vd = function(a, b) {
        this.Fd = a;
        this.J = b
    };
    vd.prototype.evaluate = function(a) {
        var b = this.J;
        return Array.isArray(a) ? Ya(b, a) : a
    };
    vd.prototype.getName = function() {
        return this.Fd.getName()
    };
    vd.prototype.Hd = function() {
        return this.J.Hd()
    };
    var yd = function() {
        this.map = new Map
    };
    yd.prototype.set = function(a, b) {
        this.map.set(a, b)
    };
    yd.prototype.get = function(a) {
        return this.map.get(a)
    };
    var zd = function() {
        this.keys = [];
        this.values = []
    };
    zd.prototype.set = function(a, b) {
        this.keys.push(a);
        this.values.push(b)
    };
    zd.prototype.get = function(a) {
        var b = this.keys.indexOf(a);
        if (b > -1) return this.values[b]
    };

    function Ad() {
        try {
            return Map ? new yd : new zd
        } catch (a) {
            return new zd
        }
    };
    var Bd = function(a) {
        if (a instanceof Bd) return a;
        if (qd(a)) throw Error("Type of given value has an equivalent Pixie type.");
        this.value = a
    };
    Bd.prototype.getValue = function() {
        return this.value
    };
    Bd.prototype.toString = function() {
        return String(this.value)
    };
    var Dd = function(a) {
        this.promise = a;
        this.Ea = !1;
        this.Z = new Ga;
        this.Z.set("then", Cd(this));
        this.Z.set("catch", Cd(this, !0));
        this.Z.set("finally", Cd(this, !1, !0))
    };
    k = Dd.prototype;
    k.get = function(a) {
        return this.Z.get(a)
    };
    k.set = function(a, b) {
        this.Ea || this.Z.set(a, b)
    };
    k.has = function(a) {
        return this.Z.has(a)
    };
    k.remove = function(a) {
        this.Ea || this.Z.remove(a)
    };
    k.xa = function() {
        return this.Z.xa()
    };
    k.yc = function() {
        return this.Z.yc()
    };
    k.ac = function() {
        return this.Z.ac()
    };
    var Cd = function(a, b, c) {
        b = b === void 0 ? !1 : b;
        c = c === void 0 ? !1 : c;
        return new wd("", function(d, e) {
            b && (e = d, d = void 0);
            c && (e = d);
            d instanceof wd || (d = void 0);
            e instanceof wd || (e = void 0);
            var f = this.J.qb(),
                g = function(m) {
                    return function(n) {
                        try {
                            return c ? (m.invoke(f), a.promise) : m.invoke(f, n)
                        } catch (p) {
                            return Promise.reject(p instanceof Error ? new Bd(p) : String(p))
                        }
                    }
                },
                h = a.promise.then(d && g(d), e && g(e));
            return new Dd(h)
        })
    };
    Dd.prototype.Ra = function() {
        this.Ea = !0
    };
    Dd.prototype.Bb = function() {
        return this.Ea
    };

    function C(a, b, c) {
        var d = Ad(),
            e = function(g, h) {
                for (var m = g.xa(), n = 0; n < m.length; n++) h[m[n]] = f(g.get(m[n]))
            },
            f = function(g) {
                if (g === null || g === void 0) return g;
                var h = d.get(g);
                if (h) return h;
                if (g instanceof sd) {
                    var m = [];
                    d.set(g, m);
                    for (var n = g.xa(), p = 0; p < n.length; p++) m[n[p]] = f(g.get(n[p]));
                    return m
                }
                if (g instanceof Dd) return g.promise.then(function(u) {
                    return C(u, b, 1)
                }, function(u) {
                    return Promise.reject(C(u, b, 1))
                });
                if (g instanceof ab) {
                    var q = {};
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                if (g instanceof wd) {
                    var r = function() {
                        for (var u = [], v = 0; v < arguments.length; v++) u[v] = Ed(arguments[v], b, c);
                        var w = new Ja(b ? b.Hd() : new Ia);
                        b && w.Qd(b.rb());
                        return f(Ua(16) ? g.apply(w, u) : g.invoke.apply(g, [w].concat(ya(u))))
                    };
                    d.set(g, r);
                    e(g, r);
                    return r
                }
                var t = !1;
                switch (c) {
                    case 1:
                        t = !0;
                        break;
                    case 2:
                        t = !1;
                        break;
                    case 3:
                        t = !1;
                        break;
                    default:
                }
                if (g instanceof Bd && t) return g.getValue();
                switch (typeof g) {
                    case "boolean":
                    case "number":
                    case "string":
                    case "undefined":
                        return g;
                    case "object":
                        if (g === null) return null
                }
            };
        return f(a)
    }

    function Ed(a, b, c) {
        var d = Ad(),
            e = function(g, h) {
                for (var m in g) g.hasOwnProperty(m) && h.set(m, f(g[m]))
            },
            f = function(g) {
                var h = d.get(g);
                if (h) return h;
                if (Array.isArray(g) || xb(g)) {
                    var m = new sd;
                    d.set(g, m);
                    for (var n in g) g.hasOwnProperty(n) && m.set(n, f(g[n]));
                    return m
                }
                if (od(g)) {
                    var p = new ab;
                    d.set(g, p);
                    e(g, p);
                    return p
                }
                if (typeof g === "function") {
                    var q = new wd("", function() {
                        for (var u = Ca.apply(0, arguments), v = [], w = 0; w < u.length; w++) v[w] = C(this.evaluate(u[w]), b, c);
                        return f(this.J.Yi()(g, g, v))
                    });
                    d.set(g, q);
                    e(g, q);
                    return q
                }
                var r = typeof g;
                if (g === null || r === "string" || r === "number" || r === "boolean") return g;
                var t = !1;
                switch (c) {
                    case 1:
                        t = !0;
                        break;
                    case 2:
                        t = !1;
                        break;
                    default:
                }
                if (g !== void 0 && t) return new Bd(g)
            };
        return f(a)
    };
    var Fd = {
        supportedMethods: "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(" "),
        concat: function(a) {
            for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
            for (var d = 1; d < arguments.length; d++)
                if (arguments[d] instanceof sd)
                    for (var e = arguments[d], f = 0; f < e.length(); f++) b.push(e.get(f));
                else b.push(arguments[d]);
            return new sd(b)
        },
        every: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() &&
                d < c; d++)
                if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
            return !0
        },
        filter: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
            return new sd(d)
        },
        forEach: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++) this.has(d) && b.invoke(a, this.get(d), d, this)
        },
        hasOwnProperty: function(a, b) {
            return this.has(b)
        },
        indexOf: function(a, b, c) {
            var d = this.length(),
                e = c === void 0 ? 0 : Number(c);
            e < 0 && (e = Math.max(d + e, 0));
            for (var f =
                    e; f < d; f++)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        join: function(a, b) {
            for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
            return c.join(b)
        },
        lastIndexOf: function(a, b, c) {
            var d = this.length(),
                e = d - 1;
            c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
            for (var f = e; f >= 0; f--)
                if (this.has(f) && this.get(f) === b) return f;
            return -1
        },
        map: function(a, b) {
            for (var c = this.length(), d = [], e = 0; e < this.length() && e < c; e++) this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
            return new sd(d)
        },
        pop: function() {
            return this.pop()
        },
        push: function(a) {
            return this.push.apply(this,
                ya(Ca.apply(1, arguments)))
        },
        reduce: function(a, b, c) {
            var d = this.length(),
                e, f = 0;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw Ra(Error("TypeError: Reduce on List with no elements."));
                for (var g = 0; g < d; g++)
                    if (this.has(g)) {
                        e = this.get(g);
                        f = g + 1;
                        break
                    }
                if (g === d) throw Ra(Error("TypeError: Reduce on List with no elements."));
            }
            for (var h = f; h < d; h++) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reduceRight: function(a, b, c) {
            var d = this.length(),
                e, f = d - 1;
            if (c !== void 0) e = c;
            else {
                if (d === 0) throw Ra(Error("TypeError: ReduceRight on List with no elements."));
                for (var g = 1; g <= d; g++)
                    if (this.has(d - g)) {
                        e = this.get(d - g);
                        f = d - (g + 1);
                        break
                    }
                if (g > d) throw Ra(Error("TypeError: ReduceRight on List with no elements."));
            }
            for (var h = f; h >= 0; h--) this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
            return e
        },
        reverse: function() {
            for (var a = td(this), b = a.length - 1, c = 0; b >= 0; b--, c++) a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
            return this
        },
        shift: function() {
            return this.shift()
        },
        slice: function(a, b, c) {
            var d = this.length();
            b === void 0 && (b = 0);
            b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
            c = c ===
                void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
            c = Math.max(b, c);
            for (var e = [], f = b; f < c; f++) e.push(this.get(f));
            return new sd(e)
        },
        some: function(a, b) {
            for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
                if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
            return !1
        },
        sort: function(a, b) {
            var c = td(this);
            b === void 0 ? c.sort() : c.sort(function(e, f) {
                return Number(b.invoke(a, e, f))
            });
            for (var d = 0; d < c.length; d++) c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
            return this
        },
        splice: function(a, b, c) {
            return this.splice.apply(this, [b, c].concat(ya(Ca.apply(3, arguments))))
        },
        toString: function() {
            return this.toString()
        },
        unshift: function(a) {
            return this.unshift.apply(this, ya(Ca.apply(1, arguments)))
        }
    };
    var Gd = {
            charAt: 1,
            concat: 1,
            indexOf: 1,
            lastIndexOf: 1,
            match: 1,
            replace: 1,
            search: 1,
            slice: 1,
            split: 1,
            substring: 1,
            toLowerCase: 1,
            toLocaleLowerCase: 1,
            toString: 1,
            toUpperCase: 1,
            toLocaleUpperCase: 1,
            trim: 1
        },
        Hd = new Fa("break"),
        Id = new Fa("continue");

    function Jd(a, b) {
        return this.evaluate(a) + this.evaluate(b)
    }

    function Kd(a, b) {
        return this.evaluate(a) && this.evaluate(b)
    }

    function Ld(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!(f instanceof sd)) throw Error("Error: Non-List argument given to Apply instruction.");
        if (d === null || d === void 0) throw Ra(Error("TypeError: Can't read property " + e + " of " + d + "."));
        var g = typeof d === "number";
        if (typeof d === "boolean" || g) {
            if (e === "toString") {
                if (g && f.length()) {
                    var h = C(f.get(0));
                    try {
                        return d.toString(h)
                    } catch (v) {}
                }
                return d.toString()
            }
            throw Ra(Error("TypeError: " + d + "." + e + " is not a function."));
        }
        if (typeof d ===
            "string") {
            if (Gd.hasOwnProperty(e)) {
                var m = 2;
                m = 1;
                var n = C(f, void 0, m);
                return Ed(d[e].apply(d, n), this.J)
            }
            throw Ra(Error("TypeError: " + e + " is not a function"));
        }
        if (d instanceof sd) {
            if (d.has(e)) {
                var p = d.get(String(e));
                if (p instanceof wd) {
                    var q = td(f);
                    return Ua(16) ? p.apply(this.J, q) : p.invoke.apply(p, [this.J].concat(ya(q)))
                }
                throw Ra(Error("TypeError: " + e + " is not a function"));
            }
            if (Fd.supportedMethods.indexOf(e) >= 0) {
                var r = td(f);
                return Fd[e].call.apply(Fd[e], [d, this.J].concat(ya(r)))
            }
        }
        if (d instanceof wd || d instanceof ab || d instanceof Dd) {
            if (d.has(e)) {
                var t = d.get(e);
                if (t instanceof wd) {
                    var u = td(f);
                    return Ua(16) ? t.apply(this.J, u) : t.invoke.apply(t, [this.J].concat(ya(u)))
                }
                throw Ra(Error("TypeError: " + e + " is not a function"));
            }
            if (e === "toString") return d instanceof wd ? d.getName() : d.toString();
            if (e === "hasOwnProperty") return d.has(f.get(0))
        }
        if (d instanceof Bd && e === "toString") return d.toString();
        throw Ra(Error("TypeError: Object has no '" + e + "' property."));
    }

    function Md(a, b) {
        a = this.evaluate(a);
        if (typeof a !== "string") throw Error("Invalid key name given for assignment.");
        var c = this.J;
        if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
        var d = this.evaluate(b);
        c.set(a, d);
        return d
    }

    function Nd() {
        var a = Ca.apply(0, arguments),
            b = this.J.qb(),
            c = Xa(b, a);
        if (c instanceof Fa) return c
    }

    function Od() {
        return Hd
    }

    function Qd(a) {
        for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
            var d = this.evaluate(b[c]);
            if (d instanceof Fa) return d
        }
    }

    function Rd() {
        for (var a = this.J, b = 0; b < arguments.length - 1; b += 2) {
            var c = arguments[b];
            if (typeof c === "string") {
                var d = this.evaluate(arguments[b + 1]);
                a.ph(c, d)
            }
        }
    }

    function Sd() {
        return Id
    }

    function Td(a, b) {
        return new Fa(a, this.evaluate(b))
    }

    function Ud(a, b) {
        var c = Ca.apply(2, arguments),
            d;
        d = new sd;
        for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
        var g = [51, a, d].concat(ya(c));
        this.J.add(a, this.evaluate(g))
    }

    function Vd(a, b) {
        return this.evaluate(a) / this.evaluate(b)
    }

    function Wd(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b),
            e = c instanceof Bd,
            f = d instanceof Bd;
        return e || f ? e && f ? c.getValue() === d.getValue() : !1 : c == d
    }

    function Xd() {
        for (var a, b = 0; b < arguments.length; b++) a = this.evaluate(arguments[b]);
        return a
    }

    function Yd(a, b, c, d) {
        for (var e = 0; e < b(); e++) {
            var f = a(c(e)),
                g = Xa(f, d);
            if (g instanceof Fa) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
        }
    }

    function Zd(a, b, c) {
        if (typeof b === "string") return Yd(a, function() {
            return b.length
        }, function(f) {
            return f
        }, c);
        if (b instanceof ab || b instanceof Dd || b instanceof sd || b instanceof wd) {
            var d = b.xa(),
                e = d.length;
            return Yd(a, function() {
                return e
            }, function(f) {
                return d[f]
            }, c)
        }
    }

    function $d(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return Zd(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function ae(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return Zd(function(h) {
            var m = g.qb();
            m.ph(d, h);
            return m
        }, e, f)
    }

    function be(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return Zd(function(h) {
            var m = g.qb();
            m.add(d, h);
            return m
        }, e, f)
    }

    function ce(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return de(function(h) {
            g.set(d, h);
            return g
        }, e, f)
    }

    function ee(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return de(function(h) {
            var m = g.qb();
            m.ph(d, h);
            return m
        }, e, f)
    }

    function fe(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c),
            g = this.J;
        return de(function(h) {
            var m = g.qb();
            m.add(d, h);
            return m
        }, e, f)
    }

    function de(a, b, c) {
        if (typeof b === "string") return Yd(a, function() {
            return b.length
        }, function(d) {
            return b[d]
        }, c);
        if (b instanceof sd) return Yd(a, function() {
            return b.length()
        }, function(d) {
            return b.get(d)
        }, c);
        throw Ra(Error("The value is not iterable."));
    }

    function ge(a, b, c, d) {
        function e(q, r) {
            for (var t = 0; t < f.length(); t++) {
                var u = f.get(t);
                r.add(u, q.get(u))
            }
        }
        var f = this.evaluate(a);
        if (!(f instanceof sd)) throw Error("TypeError: Non-List argument given to ForLet instruction.");
        var g = this.J,
            h = this.evaluate(d),
            m = g.qb();
        for (e(g, m); Ya(m, b);) {
            var n = Xa(m, h);
            if (n instanceof Fa) {
                if (n.type === "break") break;
                if (n.type === "return") return n
            }
            var p = g.qb();
            e(m, p);
            Ya(p, c);
            m = p
        }
    }

    function he(a, b) {
        var c = Ca.apply(2, arguments),
            d = this.J,
            e = this.evaluate(b);
        if (!(e instanceof sd)) throw Error("Error: non-List value given for Fn argument names.");
        return new wd(a, function() {
            return function() {
                var f = Ca.apply(0, arguments),
                    g = d.qb();
                g.rb() === void 0 && g.Qd(this.J.rb());
                for (var h = [], m = 0; m < f.length; m++) {
                    var n = this.evaluate(f[m]);
                    h[m] = n
                }
                for (var p = e.get("length"), q = 0; q < p; q++) q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
                g.add("arguments", new sd(h));
                var r = Xa(g, c);
                if (r instanceof Fa) return r.type ===
                    "return" ? r.data : r
            }
        }())
    }

    function ie(a) {
        var b = this.evaluate(a),
            c = this.J;
        if (je && !c.has(b)) throw new ReferenceError(b + " is not defined.");
        return c.get(b)
    }

    function ke(a, b) {
        var c, d = this.evaluate(a),
            e = this.evaluate(b);
        if (d === void 0 || d === null) throw Ra(Error("TypeError: Cannot read properties of " + d + " (reading '" + e + "')"));
        if (d instanceof ab || d instanceof Dd || d instanceof sd || d instanceof wd) c = d.get(e);
        else if (typeof d === "string") e === "length" ? c = d.length : rd(e) && (c = d[e]);
        else if (d instanceof Bd) return;
        return c
    }

    function le(a, b) {
        return this.evaluate(a) > this.evaluate(b)
    }

    function me(a, b) {
        return this.evaluate(a) >= this.evaluate(b)
    }

    function ne(a, b) {
        var c = this.evaluate(a),
            d = this.evaluate(b);
        c instanceof Bd && (c = c.getValue());
        d instanceof Bd && (d = d.getValue());
        return c === d
    }

    function oe(a, b) {
        return !ne.call(this, a, b)
    }

    function pe(a, b, c) {
        var d = [];
        this.evaluate(a) ? d = this.evaluate(b) : c && (d = this.evaluate(c));
        var e = Xa(this.J, d);
        if (e instanceof Fa) return e
    }
    var je = !1;

    function qe(a, b) {
        return this.evaluate(a) < this.evaluate(b)
    }

    function re(a, b) {
        return this.evaluate(a) <= this.evaluate(b)
    }

    function se() {
        for (var a = new sd, b = 0; b < arguments.length; b++) {
            var c = this.evaluate(arguments[b]);
            a.push(c)
        }
        return a
    }

    function te() {
        for (var a = new ab, b = 0; b < arguments.length - 1; b += 2) {
            var c = String(this.evaluate(arguments[b])),
                d = this.evaluate(arguments[b + 1]);
            a.set(c, d)
        }
        return a
    }

    function ue(a, b) {
        return this.evaluate(a) % this.evaluate(b)
    }

    function ve(a, b) {
        return this.evaluate(a) * this.evaluate(b)
    }

    function we(a) {
        return -this.evaluate(a)
    }

    function xe(a) {
        return !this.evaluate(a)
    }

    function ye(a, b) {
        return !Wd.call(this, a, b)
    }

    function ze() {
        return null
    }

    function Ae(a, b) {
        return this.evaluate(a) || this.evaluate(b)
    }

    function Be(a, b) {
        var c = this.evaluate(a);
        this.evaluate(b);
        return c
    }

    function Ce(a) {
        return this.evaluate(a)
    }

    function De() {
        return Ca.apply(0, arguments)
    }

    function Ee(a) {
        return new Fa("return", this.evaluate(a))
    }

    function Fe(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (d === null || d === void 0) throw Ra(Error("TypeError: Can't set property " + e + " of " + d + "."));
        (d instanceof wd || d instanceof sd || d instanceof ab) && d.set(String(e), f);
        return f
    }

    function Ge(a, b) {
        return this.evaluate(a) - this.evaluate(b)
    }

    function He(a, b, c) {
        var d = this.evaluate(a),
            e = this.evaluate(b),
            f = this.evaluate(c);
        if (!Array.isArray(e) || !Array.isArray(f)) throw Error("Error: Malformed switch instruction.");
        for (var g, h = !1, m = 0; m < e.length; m++)
            if (h || d === this.evaluate(e[m]))
                if (g = this.evaluate(f[m]), g instanceof Fa) {
                    var n = g.type;
                    if (n === "break") return;
                    if (n === "return" || n === "continue") return g
                } else h = !0;
        if (f.length === e.length + 1 && (g = this.evaluate(f[f.length - 1]), g instanceof Fa && (g.type === "return" || g.type === "continue"))) return g
    }

    function Ie(a, b, c) {
        return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c)
    }

    function Je(a) {
        var b = this.evaluate(a);
        return b instanceof wd ? "function" : typeof b
    }

    function Ke() {
        for (var a = this.J, b = 0; b < arguments.length; b++) {
            var c = arguments[b];
            typeof c !== "string" || a.add(c, void 0)
        }
    }

    function Le(a, b, c, d) {
        var e = this.evaluate(d);
        if (this.evaluate(c)) {
            var f = Xa(this.J, e);
            if (f instanceof Fa) {
                if (f.type === "break") return;
                if (f.type === "return") return f
            }
        }
        for (; this.evaluate(a);) {
            var g = Xa(this.J, e);
            if (g instanceof Fa) {
                if (g.type === "break") break;
                if (g.type === "return") return g
            }
            this.evaluate(b)
        }
    }

    function Me(a) {
        return ~Number(this.evaluate(a))
    }

    function Ne(a, b) {
        return Number(this.evaluate(a)) << Number(this.evaluate(b))
    }

    function Oe(a, b) {
        return Number(this.evaluate(a)) >> Number(this.evaluate(b))
    }

    function Pe(a, b) {
        return Number(this.evaluate(a)) >>> Number(this.evaluate(b))
    }

    function Qe(a, b) {
        return Number(this.evaluate(a)) & Number(this.evaluate(b))
    }

    function Se(a, b) {
        return Number(this.evaluate(a)) ^ Number(this.evaluate(b))
    }

    function Te(a, b) {
        return Number(this.evaluate(a)) | Number(this.evaluate(b))
    }

    function Ue() {}

    function Ve(a, b, c) {
        try {
            var d = this.evaluate(b);
            if (d instanceof Fa) return d
        } catch (h) {
            if (!(h instanceof Qa && h.Ol)) throw h;
            var e = this.J.qb();
            a !== "" && (h instanceof Qa && (h = h.im), e.add(a, new Bd(h)));
            var f = this.evaluate(c),
                g = Xa(e, f);
            if (g instanceof Fa) return g
        }
    }

    function We(a, b) {
        var c, d;
        try {
            d = this.evaluate(a)
        } catch (f) {
            if (!(f instanceof Qa && f.Ol)) throw f;
            c = f
        }
        var e = this.evaluate(b);
        if (e instanceof Fa) return e;
        if (c) throw c;
        if (d instanceof Fa) return d
    };
    var Ye = function() {
        this.C = new Za;
        Xe(this)
    };
    Ye.prototype.execute = function(a) {
        return this.C.zj(a)
    };
    var Xe = function(a) {
        var b = function(c, d) {
            var e = new xd(String(c), d);
            e.Ra();
            var f = String(c);
            a.C.C.set(f, e);
            Wa.set(f, e)
        };
        b("map", te);
        b("and", fd);
        b("contains", id);
        b("equals", gd);
        b("or", hd);
        b("startsWith", jd);
        b("variable", kd)
    };
    Ye.prototype.Lb = function(a) {
        this.C.Lb(a)
    };
    var $e = function() {
        this.H = !1;
        this.C = new Za;
        Ze(this);
        this.H = !0
    };
    $e.prototype.execute = function(a) {
        return af(this.C.zj(a))
    };
    var bf = function(a, b, c) {
        return af(a.C.Zn(b, c))
    };
    $e.prototype.Ra = function() {
        this.C.Ra()
    };
    var Ze = function(a) {
        var b = function(c, d) {
            var e = String(c),
                f = new xd(e, d);
            f.Ra();
            a.C.C.set(e, f);
            Wa.set(e, f)
        };
        b(0, Jd);
        b(1, Kd);
        b(2, Ld);
        b(3, Md);
        b(56, Qe);
        b(57, Ne);
        b(58, Me);
        b(59, Te);
        b(60, Oe);
        b(61, Pe);
        b(62, Se);
        b(53, Nd);
        b(4, Od);
        b(5, Qd);
        b(68, Ve);
        b(52, Rd);
        b(6, Sd);
        b(49, Td);
        b(7, se);
        b(8, te);
        b(9, Qd);
        b(50, Ud);
        b(10, Vd);
        b(12, Wd);
        b(13, Xd);
        b(67, We);
        b(51, he);
        b(47, $d);
        b(54, ae);
        b(55, be);
        b(63, ge);
        b(64, ce);
        b(65, ee);
        b(66, fe);
        b(15, ie);
        b(16, ke);
        b(17, ke);
        b(18, le);
        b(19, me);
        b(20, ne);
        b(21, oe);
        b(22, pe);
        b(23, qe);
        b(24, re);
        b(25, ue);
        b(26,
            ve);
        b(27, we);
        b(28, xe);
        b(29, ye);
        b(45, ze);
        b(30, Ae);
        b(32, Be);
        b(33, Be);
        b(34, Ce);
        b(35, Ce);
        b(46, De);
        b(36, Ee);
        b(43, Fe);
        b(37, Ge);
        b(38, He);
        b(39, Ie);
        b(40, Je);
        b(44, Ue);
        b(41, Ke);
        b(42, Le)
    };
    $e.prototype.Hd = function() {
        return this.C.Hd()
    };
    $e.prototype.Lb = function(a) {
        this.C.Lb(a)
    };
    $e.prototype.Tc = function(a) {
        this.C.Tc(a)
    };

    function af(a) {
        if (a instanceof Fa || a instanceof wd || a instanceof sd || a instanceof ab || a instanceof Dd || a instanceof Bd || a === null || a === void 0 || typeof a === "string" || typeof a === "number" || typeof a === "boolean") return a
    };
    var cf = function(a) {
        this.message = a
    };

    function df(a) {
        a.Er = !0;
        return a
    };
    var ef = df(function(a) {
        return typeof a === "string"
    });

    function ff(a) {
        var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [a];
        return b === void 0 ? new cf("Value " + a + " can not be encoded in web-safe base64 dictionary.") : b
    };

    function gf(a) {
        switch (a) {
            case 1:
                return "1";
            case 2:
            case 4:
                return "0";
            default:
                return "-"
        }
    };
    var hf = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;

    function jf(a, b) {
        for (var c = "", d = !0; a > 7;) {
            var e = a & 31;
            a >>= 5;
            d ? d = !1 : e |= 32;
            c = "" + ff(e) + c
        }
        a <<= 2;
        d || (a |= 32);
        return c = "" + ff(a | b) + c
    }

    function kf(a, b) {
        var c;
        var d = a.Sc,
            e = a.Ch;
        d === void 0 ? c = "" : (e || (e = 0), c = "" + jf(1, 1) + ff(d << 2 | e));
        var f = a.Nl,
            g = a.Io,
            h = "4" + c + (f ? "" + jf(2, 1) + ff(f) : "") + (g ? "" + jf(12, 1) + ff(g) : ""),
            m, n = a.Aj;
        m = n && hf.test(n) ? "" + jf(3, 2) + n : "";
        var p, q = a.wj;
        p = q ? "" + jf(4, 1) + ff(q) : "";
        var r;
        var t = a.ctid;
        if (t && b) {
            var u = jf(5, 3),
                v = t.split("-"),
                w = v[0].toUpperCase();
            if (w !== "GTM" && w !== "OPT") r = "";
            else {
                var y = v[1];
                r = "" + u + ff(1 + y.length) + (a.Zl || 0) + y
            }
        } else r = "";
        var z = a.wq,
            B = a.xe,
            D = a.La,
            G = a.Ir,
            I = h + m + p + r + (z ? "" + jf(6, 1) + ff(z) : "") + (B ? "" + jf(7, 3) + ff(B.length) +
                B : "") + (D ? "" + jf(8, 3) + ff(D.length) + D : "") + (G ? "" + jf(9, 3) + ff(G.length) + G : ""),
            M;
        var S = a.Pl;
        S = S === void 0 ? {} : S;
        for (var ea = [], P = l(Object.keys(S)), V = P.next(); !V.done; V = P.next()) {
            var ka = V.value;
            ea[Number(ka)] = S[ka]
        }
        if (ea.length) {
            var ja = jf(10, 3),
                Y;
            if (ea.length === 0) Y = ff(0);
            else {
                for (var W = [], ha = 0, wa = !1, ua = 0; ua < ea.length; ua++) {
                    wa = !0;
                    var Va = ua % 6;
                    ea[ua] && (ha |= 1 << Va);
                    Va === 5 && (W.push(ff(ha)), ha = 0, wa = !1)
                }
                wa && W.push(ff(ha));
                Y = W.join("")
            }
            var $a = Y;
            M = "" + ja + ff($a.length) + $a
        } else M = "";
        var sc = a.jm,
            Dc = a.lq;
        return I + M + (sc ? "" +
            jf(11, 3) + ff(sc.length) + sc : "") + (Dc ? "" + jf(13, 3) + ff(Dc.length) + Dc : "")
    };
    var lf = function() {
        function a(b) {
            return {
                toString: function() {
                    return b
                }
            }
        }
        return {
            Mm: a("consent"),
            Pj: a("convert_case_to"),
            Qj: a("convert_false_to"),
            Rj: a("convert_null_to"),
            Sj: a("convert_true_to"),
            Tj: a("convert_undefined_to"),
            Jq: a("debug_mode_metadata"),
            Oa: a("function"),
            yi: a("instance_name"),
            co: a("live_only"),
            eo: a("malware_disabled"),
            METADATA: a("metadata"),
            ho: a("original_activity_id"),
            ar: a("original_vendor_template_id"),
            Zq: a("once_on_load"),
            fo: a("once_per_event"),
            pl: a("once_per_load"),
            gr: a("priority_override"),
            jr: a("respected_consent_types"),
            xl: a("setup_tags"),
            nh: a("tag_id"),
            Fl: a("teardown_tags")
        }
    }();
    var Hf;
    var If = [],
        Jf = [],
        Kf = [],
        Lf = [],
        Mf = [],
        Nf, Of, Pf;

    function Qf(a) {
        Pf = Pf || a
    }

    function Rf() {
        for (var a = data.resource || {}, b = a.macros || [], c = 0; c < b.length; c++) If.push(b[c]);
        for (var d = a.tags || [], e = 0; e < d.length; e++) Lf.push(d[e]);
        for (var f = a.predicates || [], g = 0; g < f.length; g++) Kf.push(f[g]);
        for (var h = a.rules || [], m = 0; m < h.length; m++) {
            for (var n = h[m], p = {}, q = 0; q < n.length; q++) {
                var r = n[q][0];
                p[r] = Array.prototype.slice.call(n[q], 1);
                r !== "if" && r !== "unless" || Sf(p[r])
            }
            Jf.push(p)
        }
    }

    function Sf(a) {}
    var Tf, Uf = [],
        Vf = [];

    function Wf(a, b) {
        var c = {};
        c[lf.Oa] = "__" + a;
        for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
        return c
    }

    function Xf(a, b, c) {
        try {
            return Of(Yf(a, b, c))
        } catch (d) {
            JSON.stringify(a)
        }
        return 2
    }
    var Yf = function(a, b, c) {
            c = c || [];
            var d = {},
                e;
            for (e in a) a.hasOwnProperty(e) && (d[e] = Zf(a[e], b, c));
            return d
        },
        Zf = function(a, b, c) {
            if (Array.isArray(a)) {
                var d;
                switch (a[0]) {
                    case "function_id":
                        return a[1];
                    case "list":
                        d = [];
                        for (var e = 1; e < a.length; e++) d.push(Zf(a[e], b, c));
                        return d;
                    case "macro":
                        var f = a[1];
                        if (c[f]) return;
                        var g = If[f];
                        if (!g || b.isBlocked(g)) return;
                        c[f] = !0;
                        var h = String(g[lf.yi]);
                        try {
                            var m = Yf(g, b, c);
                            m.vtp_gtmEventId = b.id;
                            b.priorityId && (m.vtp_gtmPriorityId = b.priorityId);
                            d = $f(m, {
                                event: b,
                                index: f,
                                type: 2,
                                name: h
                            });
                            Tf && (d = Tf.Jo(d, m))
                        } catch (z) {
                            b.logMacroError && b.logMacroError(z, Number(f), h), d = !1
                        }
                        c[f] = !1;
                        return d;
                    case "map":
                        d = {};
                        for (var n = 1; n < a.length; n += 2) d[Zf(a[n], b, c)] = Zf(a[n + 1], b, c);
                        return d;
                    case "template":
                        d = [];
                        for (var p = !1, q = 1; q < a.length; q++) {
                            var r = Zf(a[q], b, c);
                            Pf && (p = p || Pf.Jp(r));
                            d.push(r)
                        }
                        return Pf && p ? Pf.Oo(d) : d.join("");
                    case "escape":
                        d = Zf(a[1], b, c);
                        if (Pf && Array.isArray(a[1]) && a[1][0] === "macro" && Pf.Kp(a)) return Pf.Zp(d);
                        d = String(d);
                        for (var t = 2; t < a.length; t++) sf[a[t]] && (d = sf[a[t]](d));
                        return d;
                    case "tag":
                        var u = a[1];
                        if (!Lf[u]) throw Error("Unable to resolve tag reference " + u + ".");
                        return {
                            Tl: a[2],
                            index: u
                        };
                    case "zb":
                        var v = {
                            arg0: a[2],
                            arg1: a[3],
                            ignore_case: a[5]
                        };
                        v[lf.Oa] = a[1];
                        var w = Xf(v, b, c),
                            y = !!a[4];
                        return y || w !== 2 ? y !== (w === 1) : null;
                    default:
                        throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
                }
            }
            return a
        },
        $f = function(a, b) {
            var c = a[lf.Oa],
                d = b && b.event;
            if (!c) throw Error("Error: No function name given for function call.");
            var e = Nf[c],
                f = b && b.type === 2 && (d == null ? void 0 : d.reportMacroDiscrepancy) &&
                e && Uf.indexOf(c) !== -1,
                g = {},
                h = {},
                m;
            for (m in a) a.hasOwnProperty(m) && Ib(m, "vtp_") && (e && (g[m] = a[m]), !e || f) && (h[m.substring(4)] = a[m]);
            e && d && d.cachedModelValues && (g.vtp_gtmCachedValues = d.cachedModelValues);
            if (b) {
                if (b.name == null) {
                    var n;
                    a: {
                        var p = b.type,
                            q = b.index;
                        if (q == null) n = "";
                        else {
                            var r;
                            switch (p) {
                                case 2:
                                    r = If[q];
                                    break;
                                case 1:
                                    r = Lf[q];
                                    break;
                                default:
                                    n = "";
                                    break a
                            }
                            var t = r && r[lf.yi];
                            n = t ? String(t) : ""
                        }
                    }
                    b.name = n
                }
                e && (g.vtp_gtmEntityIndex = b.index, g.vtp_gtmEntityName = b.name)
            }
            var u, v, w;
            if (f && Vf.indexOf(c) === -1) {
                Vf.push(c);
                var y = Db();
                u = e(g);
                var z = Db() - y,
                    B = Db();
                v = Hf(c, h, b);
                w = z - (Db() - B)
            } else if (e && (u = e(g)), !e || f) v = Hf(c, h, b);
            f && d && (d.reportMacroDiscrepancy(d.id, c, void 0, !0), qd(u) ? (Array.isArray(u) ? Array.isArray(v) : od(u) ? od(v) : typeof u === "function" ? typeof v === "function" : u === v) || d.reportMacroDiscrepancy(d.id, c) : u !== v && d.reportMacroDiscrepancy(d.id, c), w !== void 0 && d.reportMacroDiscrepancy(d.id, c, w));
            return e ? u : v
        };
    var ag = function(a, b, c) {
        var d;
        d = Error.call(this, c);
        this.message = d.message;
        "stack" in d && (this.stack = d.stack);
        this.permissionId = a;
        this.parameters = b;
        this.name = "PermissionError"
    };
    va(ag, Error);
    ag.prototype.getMessage = function() {
        return this.message
    };

    function bg(a, b) {
        if (Array.isArray(a)) {
            Object.defineProperty(a, "context", {
                value: {
                    line: b[0]
                }
            });
            for (var c = 1; c < a.length; c++) bg(a[c], b[c])
        }
    };

    function cg() {
        return function(a, b) {
            var c;
            var d = dg;
            a instanceof Qa ? (a.C = d, c = a) : c = new Qa(a, d);
            var e = c;
            b && e.debugInfo.push(b);
            throw e;
        }
    }

    function dg(a) {
        if (!a.length) return a;
        a.push({
            id: "main",
            line: 0
        });
        for (var b = a.length - 1; b > 0; b--) qb(a[b].id) && a.splice(b++, 1);
        for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
        a.splice(0, 1);
        return a
    };

    function eg(a) {
        function b(r) {
            for (var t = 0; t < r.length; t++) d[r[t]] = !0
        }
        for (var c = [], d = [], e = fg(a), f = 0; f < Jf.length; f++) {
            var g = Jf[f],
                h = gg(g, e);
            if (h) {
                for (var m = g.add || [], n = 0; n < m.length; n++) c[m[n]] = !0;
                b(g.block || [])
            } else h === null && b(g.block || []);
        }
        for (var p = [], q = 0; q < Lf.length; q++) c[q] && !d[q] && (p[q] = !0);
        return p
    }

    function gg(a, b) {
        for (var c = a["if"] || [], d = 0; d < c.length; d++) {
            var e = b(c[d]);
            if (e === 0) return !1;
            if (e === 2) return null
        }
        for (var f = a.unless || [], g = 0; g < f.length; g++) {
            var h = b(f[g]);
            if (h === 2) return null;
            if (h === 1) return !1
        }
        return !0
    }

    function fg(a) {
        var b = [];
        return function(c) {
            b[c] === void 0 && (b[c] = Xf(Kf[c], a));
            return b[c]
        }
    };

    function hg(a, b) {
        b[lf.Pj] && typeof a === "string" && (a = b[lf.Pj] === 1 ? a.toLowerCase() : a.toUpperCase());
        b.hasOwnProperty(lf.Rj) && a === null && (a = b[lf.Rj]);
        b.hasOwnProperty(lf.Tj) && a === void 0 && (a = b[lf.Tj]);
        b.hasOwnProperty(lf.Sj) && a === !0 && (a = b[lf.Sj]);
        b.hasOwnProperty(lf.Qj) && a === !1 && (a = b[lf.Qj]);
        return a
    };
    var ig = function() {
            this.C = {}
        },
        kg = function(a, b) {
            var c = jg.C,
                d;
            (d = c.C)[a] != null || (d[a] = []);
            c.C[a].push(function() {
                return b.apply(null, ya(Ca.apply(0, arguments)))
            })
        };

    function lg(a, b, c, d) {
        if (a)
            for (var e = 0; e < a.length; e++) {
                var f = void 0,
                    g = "A policy function denied the permission request";
                try {
                    f = a[e](b, c, d), g += "."
                } catch (h) {
                    g = typeof h === "string" ? g + (": " + h) : h instanceof Error ? g + (": " + h.message) : g + "."
                }
                if (!f) throw new ag(c, d, g);
            }
    }

    function mg(a, b, c) {
        return function(d) {
            if (d) {
                var e = a.C[d],
                    f = a.C.all;
                if (e || f) {
                    var g = c.apply(void 0, [d].concat(ya(Ca.apply(1, arguments))));
                    lg(e, b, d, g);
                    lg(f, b, d, g)
                }
            }
        }
    };
    var qg = function() {
            var a = data.permissions || {},
                b = ng.ctid,
                c = this;
            this.H = {};
            this.C = new ig;
            var d = {},
                e = {},
                f = mg(this.C, b, function(g) {
                    return g && d[g] ? d[g].apply(void 0, [g].concat(ya(Ca.apply(1, arguments)))) : {}
                });
            wb(a, function(g, h) {
                function m(p) {
                    var q = Ca.apply(1, arguments);
                    if (!n[p]) throw og(p, {}, "The requested additional permission " + p + " is not configured.");
                    f.apply(null, [p].concat(ya(q)))
                }
                var n = {};
                wb(h, function(p, q) {
                    var r = pg(p, q);
                    n[p] = r.assert;
                    d[p] || (d[p] = r.T);
                    r.Ll && !e[p] && (e[p] = r.Ll)
                });
                c.H[g] = function(p,
                    q) {
                    var r = n[p];
                    if (!r) throw og(p, {}, "The requested permission " + p + " is not configured.");
                    var t = Array.prototype.slice.call(arguments, 0);
                    r.apply(void 0, t);
                    f.apply(void 0, t);
                    var u = e[p];
                    u && u.apply(null, [m].concat(ya(t.slice(1))))
                }
            })
        },
        rg = function(a) {
            return jg.H[a] || function() {}
        };

    function pg(a, b) {
        var c = Wf(a, b);
        c.vtp_permissionName = a;
        c.vtp_createPermissionError = og;
        try {
            return $f(c)
        } catch (d) {
            return {
                assert: function(e) {
                    throw new ag(e, {}, "Permission " + e + " is unknown.");
                },
                T: function() {
                    throw new ag(a, {}, "Permission " + a + " is unknown.");
                }
            }
        }
    }

    function og(a, b, c) {
        return new ag(a, b, c)
    };
    var sg = !1;
    var tg = {};
    tg.Dm = zb('');
    tg.Wo = zb('');
    var yg = [];

    function zg(a) {
        switch (a) {
            case 1:
                return 0;
            case 216:
                return 15;
            case 38:
                return 12;
            case 219:
                return 9;
            case 220:
                return 10;
            case 53:
                return 1;
            case 54:
                return 2;
            case 52:
                return 6;
            case 203:
                return 16;
            case 75:
                return 3;
            case 103:
                return 13;
            case 197:
                return 14;
            case 114:
                return 11;
            case 116:
                return 4;
            case 135:
                return 8;
            case 136:
                return 5
        }
    }

    function Ag(a, b) {
        yg[a] = b;
        var c = zg(a);
        c !== void 0 && (Sa[c] = b)
    }

    function E(a) {
        Ag(a, !0)
    }
    E(39);
    E(34);
    E(35);
    E(36);
    E(56);
    E(145);
    E(153);
    E(144);
    E(120);
    E(5);
    E(111);
    E(139);
    E(87);
    E(92);
    E(159);
    E(132);
    E(20);
    E(72);
    E(113);
    E(154);
    E(116);
    Ag(23, !1), E(24);
    E(29);
    Bg(26, 25);
    E(37);
    E(9);
    E(91);
    E(123);
    E(158);
    E(71);
    E(136);
    E(127);
    E(27);
    E(69);
    E(135);
    E(95);
    E(38);
    E(103);
    E(112);
    E(63);
    E(152);
    E(101);
    E(122);
    E(121);
    E(134);
    E(22);

    E(19);
    E(83);
    E(90);
    E(114);
    E(59);
    E(175);
    E(177);
    E(185);
    E(190);
    E(186);

    E(192);
    E(200);

    E(213);
    E(224);

    function F(a) {
        return !!yg[a]
    }

    function Bg(a, b) {
        for (var c = !1, d = !1, e = 0; c === d;)
            if (c = ((Math.random() * 4294967296 | 0) & 1) === 0, d = ((Math.random() * 4294967296 | 0) & 1) === 0, e++, e > 30) return;
        c ? E(b) : E(a)
    };
    var Dg = {},
        Eg = (Dg.uaa = !0, Dg.uab = !0, Dg.uafvl = !0, Dg.uamb = !0, Dg.uam = !0, Dg.uap = !0, Dg.uapv = !0, Dg.uaw = !0, Dg);
    var Mg = function(a, b) {
            for (var c = 0; c < b.length; c++) {
                var d = a,
                    e = b[c];
                if (!Kg.exec(e)) throw Error("Invalid key wildcard");
                var f = e.indexOf(".*"),
                    g = f !== -1 && f === e.length - 2,
                    h = g ? e.slice(0, e.length - 2) : e,
                    m;
                a: if (d.length === 0) m = !1;
                    else {
                        for (var n = d.split("."), p = 0; p < n.length; p++)
                            if (!Lg.exec(n[p])) {
                                m = !1;
                                break a
                            }
                        m = !0
                    }
                if (!m || h.length > d.length || !g && d.length !== e.length ? 0 : g ? Ib(d, h) && (d === h || d.charAt(h.length) === ".") : d === h) return !0
            }
            return !1
        },
        Lg = /^[a-z$_][\w-$]*$/i,
        Kg = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
    var Ng = ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"];

    function Og(a, b) {
        var c = String(a),
            d = String(b),
            e = c.length - d.length;
        return e >= 0 && c.indexOf(d, e) === e
    }

    function Pg(a, b) {
        return String(a).split(",").indexOf(String(b)) >= 0
    }
    var Qg = new vb;

    function Rg(a, b, c) {
        var d = c ? "i" : void 0;
        try {
            var e = String(b) + String(d),
                f = Qg.get(e);
            f || (f = new RegExp(b, d), Qg.set(e, f));
            return f.test(a)
        } catch (g) {
            return !1
        }
    }

    function Sg(a, b) {
        return String(a).indexOf(String(b)) >= 0
    }

    function Tg(a, b) {
        return String(a) === String(b)
    }

    function Ug(a, b) {
        return Number(a) >= Number(b)
    }

    function Vg(a, b) {
        return Number(a) <= Number(b)
    }

    function Wg(a, b) {
        return Number(a) > Number(b)
    }

    function Xg(a, b) {
        return Number(a) < Number(b)
    }

    function Yg(a, b) {
        return Ib(String(a), String(b))
    };
    var eh = /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
        fh = {
            Fn: "function",
            PixieMap: "Object",
            List: "Array"
        };

    function gh(a, b) {
        for (var c = ["input:!*"], d = 0; d < c.length; d++) {
            var e = eh.exec(c[d]);
            if (!e) throw Error("Internal Error in " + a);
            var f = e[1],
                g = e[2] === "!",
                h = e[3],
                m = b[d];
            if (m == null) {
                if (g) throw Error("Error in " + a + ". Required argument " + f + " not supplied.");
            } else if (h !== "*") {
                var n = typeof m;
                m instanceof wd ? n = "Fn" : m instanceof sd ? n = "List" : m instanceof ab ? n = "PixieMap" : m instanceof Dd ? n = "PixiePromise" : m instanceof Bd && (n = "OpaqueValue");
                if (n !== h) throw Error("Error in " + a + ". Argument " + f + " has type " + ((fh[n] || n) + ", which does not match required type ") +
                    ((fh[h] || h) + "."));
            }
        }
    }

    function H(a, b, c) {
        for (var d = [], e = l(c), f = e.next(); !f.done; f = e.next()) {
            var g = f.value;
            g instanceof wd ? d.push("function") : g instanceof sd ? d.push("Array") : g instanceof ab ? d.push("Object") : g instanceof Dd ? d.push("Promise") : g instanceof Bd ? d.push("OpaqueValue") : d.push(typeof g)
        }
        return Error("Argument error in " + a + ". Expected argument types [" + (b.join(",") + "], but received [") + (d.join(",") + "]."))
    }

    function hh(a) {
        return a instanceof ab
    }

    function ih(a) {
        return hh(a) || a === null || jh(a)
    }

    function kh(a) {
        return a instanceof wd
    }

    function lh(a) {
        return kh(a) || a === null || jh(a)
    }

    function mh(a) {
        return a instanceof sd
    }

    function nh(a) {
        return a instanceof Bd
    }

    function oh(a) {
        return typeof a === "string"
    }

    function ph(a) {
        return oh(a) || a === null || jh(a)
    }

    function qh(a) {
        return typeof a === "boolean"
    }

    function rh(a) {
        return qh(a) || jh(a)
    }

    function sh(a) {
        return qh(a) || a === null || jh(a)
    }

    function th(a) {
        return typeof a === "number"
    }

    function jh(a) {
        return a === void 0
    };

    function uh(a) {
        return "" + a
    }

    function vh(a, b) {
        var c = [];
        return c
    };

    function wh(a, b) {
        var c = new wd(a, function() {
            for (var d = Array.prototype.slice.call(arguments, 0), e = 0; e < d.length; e++) d[e] = this.evaluate(d[e]);
            try {
                return b.apply(this, d)
            } catch (g) {
                throw Ra(g);
            }
        });
        c.Ra();
        return c
    }

    function xh(a, b) {
        var c = new ab,
            d;
        for (d in b)
            if (b.hasOwnProperty(d)) {
                var e = b[d];
                ob(e) ? c.set(d, wh(a + "_" + d, e)) : od(e) ? c.set(d, xh(a + "_" + d, e)) : (qb(e) || pb(e) || typeof e === "boolean") && c.set(d, e)
            }
        c.Ra();
        return c
    };

    function yh(a, b) {
        if (!oh(a)) throw H(this.getName(), ["string"], arguments);
        if (!ph(b)) throw H(this.getName(), ["string", "undefined"], arguments);
        var c = {},
            d = new ab;
        return d = xh("AssertApiSubject",
            c)
    };

    function zh(a, b) {
        if (!ph(b)) throw H(this.getName(), ["string", "undefined"], arguments);
        if (a instanceof Dd) throw Error("Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported.");
        var c = {},
            d = new ab;
        return d = xh("AssertThatSubject", c)
    };

    function Ah(a) {
        return function() {
            for (var b = Ca.apply(0, arguments), c = [], d = this.J, e = 0; e < b.length; ++e) c.push(C(b[e], d));
            return Ed(a.apply(null, c))
        }
    }

    function Bh() {
        for (var a = Math, b = Ch, c = {}, d = 0; d < b.length; d++) {
            var e = b[d];
            a.hasOwnProperty(e) && (c[e] = Ah(a[e].bind(a)))
        }
        return c
    };

    function Dh(a) {
        return a != null && Ib(a, "__cvt_")
    };

    function Eh(a) {
        var b;
        return b
    };

    function Fh(a) {
        var b;
        if (!oh(a)) throw H(this.getName(), ["string"], arguments);
        try {
            b = decodeURIComponent(a)
        } catch (c) {}
        return b
    };

    function Gh(a) {
        try {
            return encodeURI(a)
        } catch (b) {}
    };

    function Hh(a) {
        try {
            return encodeURIComponent(String(a))
        } catch (b) {}
    };

    function Mh(a) {
        if (!ph(a)) throw H(this.getName(), ["string|undefined"], arguments);
    };

    function Nh(a, b) {
        if (!th(a) || !th(b)) throw H(this.getName(), ["number", "number"], arguments);
        return tb(a, b)
    };

    function Oh() {
        return (new Date).getTime()
    };

    function Ph(a) {
        if (a === null) return "null";
        if (a instanceof sd) return "array";
        if (a instanceof wd) return "function";
        if (a instanceof Bd) {
            var b = a.getValue();
            if ((b == null ? void 0 : b.constructor) === void 0 || b.constructor.name === void 0) {
                var c = String(b);
                return c.substring(8, c.length - 1)
            }
            return String(b.constructor.name)
        }
        return typeof a
    };

    function Qh(a) {
        function b(c) {
            return function(d) {
                try {
                    return c(d)
                } catch (e) {
                    (sg || tg.Dm) && a.call(this, e.message)
                }
            }
        }
        return {
            parse: b(function(c) {
                return Ed(JSON.parse(c))
            }),
            stringify: b(function(c) {
                return JSON.stringify(C(c))
            }),
            publicName: "JSON"
        }
    };

    function Rh(a) {
        return yb(C(a, this.J))
    };

    function Sh(a) {
        return Number(C(a, this.J))
    };

    function Th(a) {
        return a === null ? "null" : a === void 0 ? "undefined" : a.toString()
    };

    function Uh(a, b, c) {
        var d = null,
            e = !1;
        return e ? d : null
    };
    var Ch = "floor ceil round max min abs pow sqrt".split(" ");

    function Vh() {
        var a = {};
        return {
            kp: function(b) {
                return a.hasOwnProperty(b) ? a[b] : void 0
            },
            Am: function(b, c) {
                a[b] = c
            },
            reset: function() {
                a = {}
            }
        }
    }

    function Wh(a, b) {
        return function() {
            return wd.prototype.invoke.apply(a, [b].concat(ya(Ca.apply(0, arguments))))
        }
    }

    function Xh(a, b) {
        if (!oh(a)) throw H(this.getName(), ["string", "any"], arguments);
    }

    function Yh(a, b) {
        if (!oh(a) || !hh(b)) throw H(this.getName(), ["string", "PixieMap"], arguments);
    };
    var Zh = {};
    Zh.keys = function(a) {
        return new sd
    };
    Zh.values = function(a) {
        return new sd
    };
    Zh.entries = function(a) {
        return new sd
    };
    Zh.freeze = function(a) {
        return a
    };
    Zh.delete = function(a, b) {
        return !1
    };

    function J(a, b) {
        var c = Ca.apply(2, arguments),
            d = a.J.rb();
        if (!d) throw Error("Missing program state.");
        if (d.iq) {
            try {
                d.Ml.apply(null, [b].concat(ya(c)))
            } catch (e) {
                throw ib("TAGGING", 21), e;
            }
            return
        }
        d.Ml.apply(null, [b].concat(ya(c)))
    };
    var ai = function() {
        this.H = {};
        this.C = {};
        this.M = !0;
    };
    ai.prototype.get = function(a, b) {
        var c = this.contains(a) ? this.H[a] : void 0;
        return c
    };
    ai.prototype.contains = function(a) {
        return this.H.hasOwnProperty(a)
    };
    ai.prototype.add = function(a, b, c) {
        if (this.contains(a)) throw Error("Attempting to add a function which already exists: " + a + ".");
        if (this.C.hasOwnProperty(a)) throw Error("Attempting to add an API with an existing private API name: " + a + ".");
        this.H[a] = c ? void 0 : ob(b) ? wh(a, b) : xh(a, b)
    };

    function bi(a, b) {
        var c = void 0;
        return c
    };

    function ci() {
        var a = {};
        return a
    };
    var K = {
        m: {
            Ia: "ad_personalization",
            U: "ad_storage",
            V: "ad_user_data",
            ia: "analytics_storage",
            hc: "region",
            da: "consent_updated",
            tg: "wait_for_update",
            Vm: "app_remove",
            Wm: "app_store_refund",
            Xm: "app_store_subscription_cancel",
            Ym: "app_store_subscription_convert",
            Zm: "app_store_subscription_renew",
            bn: "consent_update",
            Xj: "add_payment_info",
            Yj: "add_shipping_info",
            Ud: "add_to_cart",
            Vd: "remove_from_cart",
            Zj: "view_cart",
            Vc: "begin_checkout",
            Wd: "select_item",
            jc: "view_item_list",
            Dc: "select_promotion",
            kc: "view_promotion",
            ub: "purchase",
            Xd: "refund",
            Nb: "view_item",
            bk: "add_to_wishlist",
            dn: "exception",
            fn: "first_open",
            gn: "first_visit",
            ra: "gtag.config",
            Ob: "gtag.get",
            hn: "in_app_purchase",
            Wc: "page_view",
            jn: "screen_view",
            kn: "session_start",
            ln: "source_update",
            mn: "timing_complete",
            nn: "track_social",
            Yd: "user_engagement",
            on: "user_id_update",
            Ne: "gclid_link_decoration_source",
            Oe: "gclid_storage_source",
            mc: "gclgb",
            wb: "gclid",
            dk: "gclid_len",
            Zd: "gclgs",
            ae: "gcllp",
            be: "gclst",
            Aa: "ads_data_redaction",
            Pe: "gad_source",
            Qe: "gad_source_src",
            Xc: "gclid_url",
            ek: "gclsrc",
            Re: "gbraid",
            ce: "wbraid",
            Ga: "allow_ad_personalization_signals",
            Ag: "allow_custom_scripts",
            Se: "allow_direct_google_requests",
            Bg: "allow_display_features",
            Cg: "allow_enhanced_conversions",
            Pb: "allow_google_signals",
            jb: "allow_interest_groups",
            pn: "app_id",
            qn: "app_installer_id",
            rn: "app_name",
            sn: "app_version",
            nc: "auid",
            tn: "auto_detection_enabled",
            Yc: "aw_remarketing",
            Ph: "aw_remarketing_only",
            Dg: "discount",
            Eg: "aw_feed_country",
            Fg: "aw_feed_language",
            wa: "items",
            Gg: "aw_merchant_id",
            fk: "aw_basket_type",
            Te: "campaign_content",
            Ue: "campaign_id",
            Ve: "campaign_medium",
            We: "campaign_name",
            Xe: "campaign",
            Ye: "campaign_source",
            Ze: "campaign_term",
            Qb: "client_id",
            gk: "rnd",
            Qh: "consent_update_type",
            un: "content_group",
            vn: "content_type",
            kb: "conversion_cookie_prefix",
            af: "conversion_id",
            Ta: "conversion_linker",
            Rh: "conversion_linker_disabled",
            Zc: "conversion_api",
            Hg: "cookie_deprecation",
            xb: "cookie_domain",
            yb: "cookie_expires",
            Cb: "cookie_flags",
            bd: "cookie_name",
            Rb: "cookie_path",
            lb: "cookie_prefix",
            Ec: "cookie_update",
            dd: "country",
            Ya: "currency",
            Sh: "customer_buyer_stage",
            bf: "customer_lifetime_value",
            Th: "customer_loyalty",
            Uh: "customer_ltv_bucket",
            cf: "custom_map",
            Vh: "gcldc",
            ed: "dclid",
            hk: "debug_mode",
            ma: "developer_id",
            wn: "disable_merchant_reported_purchases",
            fd: "dc_custom_params",
            xn: "dc_natural_search",
            ik: "dynamic_event_settings",
            jk: "affiliation",
            Ig: "checkout_option",
            Wh: "checkout_step",
            kk: "coupon",
            df: "item_list_name",
            Xh: "list_name",
            yn: "promotions",
            de: "shipping",
            lk: "tax",
            Jg: "engagement_time_msec",
            Kg: "enhanced_client_id",
            Yh: "enhanced_conversions",
            mk: "enhanced_conversions_automatic_settings",
            ef: "estimated_delivery_date",
            Zh: "euid_logged_in_state",
            ff: "event_callback",
            zn: "event_category",
            Sb: "event_developer_id_string",
            An: "event_label",
            gd: "event",
            Lg: "event_settings",
            Mg: "event_timeout",
            Bn: "description",
            Cn: "fatal",
            Dn: "experiments",
            ai: "firebase_id",
            ee: "first_party_collection",
            Ng: "_x_20",
            qc: "_x_19",
            nk: "fledge_drop_reason",
            pk: "fledge",
            qk: "flight_error_code",
            rk: "flight_error_message",
            sk: "fl_activity_category",
            tk: "fl_activity_group",
            bi: "fl_advertiser_id",
            uk: "fl_ar_dedupe",
            hf: "match_id",
            vk: "fl_random_number",
            wk: "tran",
            xk: "u",
            Og: "gac_gclid",
            fe: "gac_wbraid",
            yk: "gac_wbraid_multiple_conversions",
            zk: "ga_restrict_domain",
            di: "ga_temp_client_id",
            En: "ga_temp_ecid",
            hd: "gdpr_applies",
            Ak: "geo_granularity",
            jd: "value_callback",
            Fc: "value_key",
            rc: "google_analysis_params",
            he: "_google_ng",
            ie: "google_signals",
            Bk: "google_tld",
            jf: "gpp_sid",
            kf: "gpp_string",
            Pg: "groups",
            Ck: "gsa_experiment_id",
            lf: "gtag_event_feature_usage",
            Dk: "gtm_up",
            Gc: "iframe_state",
            nf: "ignore_referrer",
            ei: "internal_traffic_results",
            Ek: "_is_fpm",
            Hc: "is_legacy_converted",
            Ic: "is_legacy_loaded",
            Qg: "is_passthrough",
            kd: "_lps",
            zb: "language",
            Rg: "legacy_developer_id_string",
            Ua: "linker",
            pf: "accept_incoming",
            Jc: "decorate_forms",
            na: "domains",
            ld: "url_position",
            md: "merchant_feed_label",
            nd: "merchant_feed_language",
            od: "merchant_id",
            Fk: "method",
            Gn: "name",
            Gk: "navigation_type",
            qf: "new_customer",
            Sg: "non_interaction",
            Hn: "optimize_id",
            Hk: "page_hostname",
            rf: "page_path",
            Va: "page_referrer",
            Db: "page_title",
            Ik: "passengers",
            Jk: "phone_conversion_callback",
            In: "phone_conversion_country_code",
            Kk: "phone_conversion_css_class",
            Jn: "phone_conversion_ids",
            Lk: "phone_conversion_number",
            Mk: "phone_conversion_options",
            Kn: "_platinum_request_status",
            Ln: "_protected_audience_enabled",
            je: "quantity",
            Tg: "redact_device_info",
            fi: "referral_exclusion_definition",
            Mq: "_request_start_time",
            Ub: "restricted_data_processing",
            Mn: "retoken",
            Nn: "sample_rate",
            gi: "screen_name",
            Kc: "screen_resolution",
            Nk: "_script_source",
            On: "search_term",
            mb: "send_page_view",
            pd: "send_to",
            rd: "server_container_url",
            tf: "session_duration",
            Ug: "session_engaged",
            hi: "session_engaged_time",
            Vb: "session_id",
            Vg: "session_number",
            uf: "_shared_user_id",
            ke: "delivery_postal_code",
            Nq: "_tag_firing_delay",
            Oq: "_tag_firing_time",
            Pq: "temporary_client_id",
            ii: "_timezone",
            ji: "topmost_url",
            Pn: "tracking_id",
            ki: "traffic_type",
            Na: "transaction_id",
            sc: "transport_url",
            Ok: "trip_type",
            ud: "update",
            Eb: "url_passthrough",
            Pk: "uptgs",
            vf: "_user_agent_architecture",
            wf: "_user_agent_bitness",
            xf: "_user_agent_full_version_list",
            yf: "_user_agent_mobile",
            zf: "_user_agent_model",
            Af: "_user_agent_platform",
            Bf: "_user_agent_platform_version",
            Cf: "_user_agent_wow64",
            Za: "user_data",
            li: "user_data_auto_latency",
            mi: "user_data_auto_meta",
            ni: "user_data_auto_multi",
            oi: "user_data_auto_selectors",
            ri: "user_data_auto_status",
            uc: "user_data_mode",
            Wg: "user_data_settings",
            Ja: "user_id",
            Wb: "user_properties",
            Qk: "_user_region",
            Df: "us_privacy_string",
            Ca: "value",
            Rk: "wbraid_multiple_conversions",
            wd: "_fpm_parameters",
            xi: "_host_name",
            al: "_in_page_command",
            bl: "_ip_override",
            kl: "_is_passthrough_cid",
            vc: "non_personalized_ads",
            Hi: "_sst_parameters",
            oc: "conversion_label",
            Ba: "page_location",
            Tb: "global_developer_id_string",
            sd: "tc_privacy_string"
        }
    };
    var di = {},
        ei = (di[K.m.da] = "gcu", di[K.m.mc] = "gclgb", di[K.m.wb] = "gclaw", di[K.m.dk] = "gclid_len", di[K.m.Zd] = "gclgs", di[K.m.ae] = "gcllp", di[K.m.be] = "gclst", di[K.m.nc] = "auid", di[K.m.Dg] = "dscnt", di[K.m.Eg] = "fcntr", di[K.m.Fg] = "flng", di[K.m.Gg] = "mid", di[K.m.fk] = "bttype", di[K.m.Qb] = "gacid", di[K.m.oc] = "label", di[K.m.Zc] = "capi", di[K.m.Hg] = "pscdl", di[K.m.Ya] = "currency_code", di[K.m.Sh] = "clobs", di[K.m.bf] = "vdltv", di[K.m.Th] = "clolo", di[K.m.Uh] = "clolb", di[K.m.hk] = "_dbg", di[K.m.ef] = "oedeld", di[K.m.Sb] = "edid", di[K.m.nk] =
            "fdr", di[K.m.pk] = "fledge", di[K.m.Og] = "gac", di[K.m.fe] = "gacgb", di[K.m.yk] = "gacmcov", di[K.m.hd] = "gdpr", di[K.m.Tb] = "gdid", di[K.m.he] = "_ng", di[K.m.jf] = "gpp_sid", di[K.m.kf] = "gpp", di[K.m.Ck] = "gsaexp", di[K.m.lf] = "_tu", di[K.m.Gc] = "frm", di[K.m.Qg] = "gtm_up", di[K.m.kd] = "lps", di[K.m.Rg] = "did", di[K.m.md] = "fcntr", di[K.m.nd] = "flng", di[K.m.od] = "mid", di[K.m.qf] = void 0, di[K.m.Db] = "tiba", di[K.m.Ub] = "rdp", di[K.m.Vb] = "ecsid", di[K.m.uf] = "ga_uid", di[K.m.ke] = "delopc", di[K.m.sd] = "gdpr_consent", di[K.m.Na] = "oid", di[K.m.Pk] =
            "uptgs", di[K.m.vf] = "uaa", di[K.m.wf] = "uab", di[K.m.xf] = "uafvl", di[K.m.yf] = "uamb", di[K.m.zf] = "uam", di[K.m.Af] = "uap", di[K.m.Bf] = "uapv", di[K.m.Cf] = "uaw", di[K.m.li] = "ec_lat", di[K.m.mi] = "ec_meta", di[K.m.ni] = "ec_m", di[K.m.oi] = "ec_sel", di[K.m.ri] = "ec_s", di[K.m.uc] = "ec_mode", di[K.m.Ja] = "userId", di[K.m.Df] = "us_privacy", di[K.m.Ca] = "value", di[K.m.Rk] = "mcov", di[K.m.xi] = "hn", di[K.m.al] = "gtm_ee", di[K.m.vc] = "npa", di[K.m.af] = null, di[K.m.Kc] = null, di[K.m.zb] = null, di[K.m.wa] = null, di[K.m.Ba] = null, di[K.m.Va] = null, di[K.m.ji] =
            null, di[K.m.wd] = null, di[K.m.Ne] = null, di[K.m.Oe] = null, di[K.m.rc] = null, di);

    function fi(a, b) {
        if (a) {
            var c = a.split("x");
            c.length === 2 && (gi(b, "u_w", c[0]), gi(b, "u_h", c[1]))
        }
    }

    function hi(a) {
        var b = ii;
        b = b === void 0 ? ji : b;
        var c;
        var d = b;
        if (a && a.length) {
            for (var e = [], f = 0; f < a.length; ++f) {
                var g = a[f];
                g && e.push({
                    item_id: d(g),
                    quantity: g.quantity,
                    value: g.price,
                    start_date: g.start_date,
                    end_date: g.end_date
                })
            }
            c = e
        } else c = [];
        var h;
        var m = c;
        if (m) {
            for (var n = [], p = 0; p < m.length; p++) {
                var q = m[p],
                    r = [];
                q && (r.push(ki(q.value)), r.push(ki(q.quantity)), r.push(ki(q.item_id)), r.push(ki(q.start_date)), r.push(ki(q.end_date)), n.push("(" + r.join("*") + ")"))
            }
            h = n.length > 0 ? n.join("") : ""
        } else h = "";
        return h
    }

    function ji(a) {
        return li(a.item_id, a.id, a.item_name)
    }

    function li() {
        for (var a = l(Ca.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            if (c !== null && c !== void 0) return c
        }
    }

    function mi(a) {
        if (a && a.length) {
            for (var b = [], c = 0; c < a.length; ++c) {
                var d = a[c];
                d && d.estimated_delivery_date ? b.push("" + d.estimated_delivery_date) : b.push("")
            }
            return b.join(",")
        }
    }

    function gi(a, b, c) {
        c === void 0 || c === null || c === "" && !Eg[b] || (a[b] = c)
    }

    function ki(a) {
        return typeof a !== "number" && typeof a !== "string" ? "" : a.toString()
    };
    var ni = {},
        oi = function() {
            for (var a = !1, b = !1, c = 0; a === b;)
                if (a = tb(0, 1) === 0, b = tb(0, 1) === 0, c++, c > 30) return;
            return a
        },
        qi = {
            nq: pi
        };

    function ri(a, b) {
        var c = ni[b],
            d = c.studyId,
            e = c.experimentId,
            f = c.probability;
        if (!(a.studies || {})[d]) {
            var g = a.studies || {};
            g[d] = !0;
            a.studies = g;
            ni[b].active || (ni[b].probability > .5 ? si(a, e) : f <= 0 || f > 1 || qi.nq(a, b))
        }
    }

    function pi(a, b) {
        var c = ni[b],
            d = c.controlId2;
        if (!(tb(0, 9999) < c.probability * (c.controlId2 && c.probability <= .25 ? 4 : 2) * 1E4)) return a;
        ti(a, {
            experimentId: c.experimentId,
            controlId: c.controlId,
            controlId2: c.controlId2 && c.probability <= .25 ? d : void 0,
            experimentCallback: function() {}
        });
        return a
    }

    function si(a, b) {
        var c = a.exp || {};
        c[b] = !0;
        a.exp = c
    }

    function ti(a, b) {
        var c = b.experimentId,
            d = b.controlId,
            e = b.controlId2,
            f = b.experimentCallback;
        if ((a.exp || {})[c]) f();
        else if (!((a.exp || {})[d] || e && (a.exp || {})[e])) {
            var g = oi() ? 0 : 1;
            e && (g |= (oi() ? 0 : 1) << 1);
            g === 0 ? (si(a, c), f()) : g === 1 ? si(a, d) : g === 2 && si(a, e)
        }
    };
    var ui = {
        O: {
            Jj: "call_conversion",
            ka: "conversion",
            Qn: "floodlight",
            Ff: "ga_conversion",
            Di: "landing_page",
            Qa: "page_view",
            Wa: "remarketing",
            Xb: "user_data_lead",
            ob: "user_data_web"
        }
    };

    function xi(a, b) {
        if (!yi) return null;
        if (Element.prototype.closest) try {
            return a.closest(b)
        } catch (e) {
            return null
        }
        var c = Element.prototype.matches || Element.prototype.webkitMatchesSelector || Element.prototype.mozMatchesSelector || Element.prototype.msMatchesSelector || Element.prototype.oMatchesSelector,
            d = a;
        if (!A.documentElement.contains(d)) return null;
        do {
            try {
                if (c.call(d, b)) return d
            } catch (e) {
                break
            }
            d = d.parentElement || d.parentNode
        } while (d !== null && d.nodeType === 1);
        return null
    }
    var zi = !1;
    if (A.querySelectorAll) try {
        var Ai = A.querySelectorAll(":root");
        Ai && Ai.length == 1 && Ai[0] == A.documentElement && (zi = !0)
    } catch (a) {}
    var yi = zi;
    var Bi = "email sha256_email_address phone_number sha256_phone_number first_name last_name".split(" "),
        Ci = "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(" ");

    function Di(a, b) {
        if (!b._tag_metadata) {
            for (var c = {}, d = 0, e = 0; e < a.length; e++) d += Ei(a[e], b, c) ? 1 : 0;
            d > 0 && (b._tag_metadata = c)
        }
    }

    function Ei(a, b, c) {
        var d = b[a];
        if (d === void 0) return !1;
        c[a] = Array.isArray(d) ? d.map(function() {
            return {
                mode: "c"
            }
        }) : {
            mode: "c"
        };
        return !0
    }

    function Fi(a) {
        if (F(178) && a) {
            Di(Bi, a);
            for (var b = rb(a.address), c = 0; c < b.length; c++) {
                var d = b[c];
                d && Di(Ci, d)
            }
            var e = a.home_address;
            e && Di(Ci, e)
        }
    }

    function Gi(a, b, c) {
        function d(f, g) {
            g = String(g).substring(0, 100);
            e.push("" + f + encodeURIComponent(g))
        }
        if (!c) return "";
        var e = [];
        d("i", String(a));
        d("f", b);
        c.mode && d("m", c.mode);
        c.isPreHashed && d("p", "1");
        c.rawLength && d("r", String(c.rawLength));
        c.normalizedLength && d("n", String(c.normalizedLength));
        c.location && d("l", c.location);
        c.selector && d("s", c.selector);
        return e.join(".")
    };

    function Hi(a) {
        switch (a) {
            case 0:
                break;
            case 9:
                return "e4";
            case 6:
                return "e5";
            case 14:
                return "e6";
            default:
                return "e7"
        }
    };

    function Ii(a, b) {
        if (a === "") return b;
        var c = Number(a);
        return isNaN(c) ? b : c
    };
    var Ji = [],
        Ki = [],
        Li, Mi;

    function Ni(a) {
        Li ? Li(a) : Ji.push(a)
    }

    function Oi(a, b) {
        if (!F(190)) return b;
        var c, d = !1;
        d = d === void 0 ? !1 : d;
        var e, f;
        c = ((e = data) == null ? 0 : (f = e.blob) == null ? 0 : f.hasOwnProperty(a)) ? !!data.blob[a] : d;
        return c !== b ? (Ni(a), b) : c
    }

    function Pi(a, b) {
        if (!F(190)) return b;
        var c = Qi(a, "");
        return c !== b ? (Ni(a), b) : c
    }

    function Qi(a, b) {
        b = b === void 0 ? "" : b;
        var c, d;
        return ((c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)) ? String(data.blob[a]) : b
    }

    function Ri(a, b) {
        if (!F(190)) return b;
        var c, d, e;
        c = ((d = data) == null ? 0 : (e = d.blob) == null ? 0 : e.hasOwnProperty(a)) ? Number(data.blob[a]) : 0;
        return c === b || isNaN(c) && isNaN(b) ? c : (Ni(a), b)
    }

    function Si(a, b) {
        var c;
        c = c === void 0 ? "" : c;
        if (!F(225)) return b;
        var d, e, f, g = (d = (e = data) == null ? void 0 : (f = e.blob) == null ? void 0 : f[46]) && (d == null ? 0 : d.hasOwnProperty(a)) ? String(d[a]) : c;
        return g !== b ? (Mi ? Mi(a) : Ki.push(a), b) : g
    }

    function Ti() {
        var a = Ui,
            b = Vi;
        Li = a;
        for (var c = l(Ji), d = c.next(); !d.done; d = c.next()) a(d.value);
        Ji.length = 0;
        if (F(225)) {
            Mi = b;
            for (var e = l(Ki), f = e.next(); !f.done; f = e.next()) b(f.value);
            Ki.length = 0
        }
    }

    function Wi() {
        var a = Ii(Si(6, '1'), 6E4);
        Ta[1] = a;
        var b = Ii(Si(7, '10'), 1);
        Ta[3] = b;
        var c = Ii(Si(35, ''), 50);
        Ta[2] = c
    };

    function Xi() {
        this.blockSize = -1
    };

    function Yi(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.M = Da.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.P = this.H = 0;
        this.C = [];
        this.fa = a;
        this.R = b;
        this.la = Da.Int32Array ? new Int32Array(64) : Array(64);
        Zi === void 0 && (Da.Int32Array ? Zi = new Int32Array($i) : Zi = $i);
        this.reset()
    }
    Ea(Yi, Xi);
    for (var aj = [], bj = 0; bj < 63; bj++) aj[bj] = 0;
    var cj = [].concat(128, aj);
    Yi.prototype.reset = function() {
        this.P = this.H = 0;
        var a;
        if (Da.Int32Array) a = new Int32Array(this.R);
        else {
            var b = this.R,
                c = b.length;
            if (c > 0) {
                for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
                a = d
            } else a = []
        }
        this.C = a
    };
    var dj = function(a) {
        for (var b = a.M, c = a.la, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (var f = 16; f < 64; f++) {
            var g = c[f - 15] | 0,
                h = c[f - 2] | 0;
            c[f] = ((c[f - 16] | 0) + ((g >>> 7 | g << 25) ^ (g >>> 18 | g << 14) ^ g >>> 3) | 0) + ((c[f - 7] | 0) + ((h >>> 17 | h << 15) ^ (h >>> 19 | h << 13) ^ h >>> 10) | 0) | 0
        }
        for (var m = a.C[0] | 0, n = a.C[1] | 0, p = a.C[2] | 0, q = a.C[3] | 0, r = a.C[4] | 0, t = a.C[5] | 0, u = a.C[6] | 0, v = a.C[7] | 0, w = 0; w < 64; w++) {
            var y = ((m >>> 2 | m << 30) ^ (m >>> 13 | m << 19) ^ (m >>> 22 | m << 10)) + (m & n ^ m & p ^ n & p) | 0,
                z = (v + ((r >>> 6 | r << 26) ^ (r >>> 11 | r << 21) ^ (r >>> 25 | r << 7)) |
                    0) + (((r & t ^ ~r & u) + (Zi[w] | 0) | 0) + (c[w] | 0) | 0) | 0;
            v = u;
            u = t;
            t = r;
            r = q + z | 0;
            q = p;
            p = n;
            n = m;
            m = z + y | 0
        }
        a.C[0] = a.C[0] + m | 0;
        a.C[1] = a.C[1] + n | 0;
        a.C[2] = a.C[2] + p | 0;
        a.C[3] = a.C[3] + q | 0;
        a.C[4] = a.C[4] + r | 0;
        a.C[5] = a.C[5] + t | 0;
        a.C[6] = a.C[6] + u | 0;
        a.C[7] = a.C[7] + v | 0
    };
    Yi.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.H;
        if (typeof a === "string")
            for (; c < b;) this.M[d++] = a.charCodeAt(c++), d == this.blockSize && (dj(this), d = 0);
        else {
            var e, f = typeof a;
            e = f != "object" ? f : a ? Array.isArray(a) ? "array" : f : "null";
            if (e == "array" || e == "object" && typeof a.length == "number")
                for (; c < b;) {
                    var g = a[c++];
                    if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0))) throw Error("message must be a byte array");
                    this.M[d++] = g;
                    d == this.blockSize && (dj(this), d = 0)
                } else throw Error("message must be string or array");
        }
        this.H = d;
        this.P += b
    };
    Yi.prototype.digest = function() {
        var a = [],
            b = this.P * 8;
        this.H < 56 ? this.update(cj, 56 - this.H) : this.update(cj, this.blockSize - (this.H - 56));
        for (var c = 63; c >= 56; c--) this.M[c] = b & 255, b /= 256;
        dj(this);
        for (var d = 0, e = 0; e < this.fa; e++)
            for (var f = 24; f >= 0; f -= 8) a[d++] = this.C[e] >> f & 255;
        return a
    };
    var $i = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        Zi;

    function ej() {
        Yi.call(this, 8, fj)
    }
    Ea(ej, Yi);
    var fj = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var gj = /^[0-9A-Fa-f]{64}$/;

    function hj(a) {
        try {
            return (new TextEncoder).encode(a)
        } catch (e) {
            for (var b = [], c = 0; c < a.length; c++) {
                var d = a.charCodeAt(c);
                d < 128 ? b.push(d) : d < 2048 ? b.push(192 | d >> 6, 128 | d & 63) : d < 55296 || d >= 57344 ? b.push(224 | d >> 12, 128 | d >> 6 & 63, 128 | d & 63) : (d = 65536 + ((d & 1023) << 10 | a.charCodeAt(++c) & 1023), b.push(240 | d >> 18, 128 | d >> 12 & 63, 128 | d >> 6 & 63, 128 | d & 63))
            }
            return new Uint8Array(b)
        }
    }

    function ij(a) {
        var b = x;
        if (a === "" || a === "e0") return Promise.resolve(a);
        var c;
        if ((c = b.crypto) == null ? 0 : c.subtle) {
            if (gj.test(a)) return Promise.resolve(a);
            try {
                var d = hj(a);
                return b.crypto.subtle.digest("SHA-256", d).then(function(e) {
                    return jj(e, b)
                }).catch(function() {
                    return "e2"
                })
            } catch (e) {
                return Promise.resolve("e2")
            }
        } else return Promise.resolve("e1")
    }

    function jj(a, b) {
        var c = Array.from(new Uint8Array(a)).map(function(d) {
            return String.fromCharCode(d)
        }).join("");
        return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
    };
    var kj = {
            Jm: Si(20, '5000'),
            Km: Si(21, '5000'),
            Tm: Si(15, ''),
            Um: Si(14, '1000'),
            Un: Si(16, 'US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD'),
            Vn: Si(17, 'US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD'),
            po: Pi(44, '101509157~103116026~103200004~103233427~104684208~104684211~105087538~105087540~105103161~105103163')
        },
        lj = {
            yo: Number(kj.Jm) || -1,
            zo: Number(kj.Km) || -1,
            Cr: Number(kj.Tm) ||
                0,
            Vo: Number(kj.Um) || 0,
            op: kj.Un.split("~"),
            pp: kj.Vn.split("~"),
            Fq: kj.po
        };
    ma(Object, "assign").call(Object, {}, lj);

    function L(a) {
        ib("GTM", a)
    };
    var Vj = {},
        Wj = (Vj[K.m.jb] = 1, Vj[K.m.rd] = 2, Vj[K.m.sc] = 2, Vj[K.m.Aa] = 3, Vj[K.m.bf] = 4, Vj[K.m.Ag] = 5, Vj[K.m.Ec] = 6, Vj[K.m.lb] = 6, Vj[K.m.xb] = 6, Vj[K.m.bd] = 6, Vj[K.m.Rb] = 6, Vj[K.m.Cb] = 6, Vj[K.m.yb] = 7, Vj[K.m.Ub] = 9, Vj[K.m.Bg] = 10, Vj[K.m.Pb] = 11, Vj),
        Xj = {},
        Yj = (Xj.unknown = 13, Xj.standard = 14, Xj.unique = 15, Xj.per_session = 16, Xj.transactions = 17, Xj.items_sold = 18, Xj);
    var kb = [];

    function Zj(a, b) {
        b = b === void 0 ? !1 : b;
        for (var c = Object.keys(a), d = l(Object.keys(Wj)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            if (c.includes(f)) {
                var g = Wj[f],
                    h = b;
                h = h === void 0 ? !1 : h;
                ib("GTAG_EVENT_FEATURE_CHANNEL", g);
                h && (kb[g] = !0)
            }
        }
    };
    var ak = function() {
            this.C = new Set;
            this.H = new Set
        },
        ck = function(a) {
            var b = bk.R;
            a = a === void 0 ? [] : a;
            var c = [].concat(ya(b.C)).concat([].concat(ya(b.H))).concat(a);
            c.sort(function(d, e) {
                return d - e
            });
            return c
        },
        dk = function() {
            var a = [].concat(ya(bk.R.C));
            a.sort(function(b, c) {
                return b - c
            });
            return a
        },
        ek = function() {
            var a = bk.R,
                b = lj.Fq;
            a.C = new Set;
            if (b !== "")
                for (var c = l(b.split("~")), d = c.next(); !d.done; d = c.next()) {
                    var e = Number(d.value);
                    isNaN(e) || a.C.add(e)
                }
        };
    var fk = {},
        gk = Pi(14, "57u1"),
        hk = Ri(15, Number("0")),
        ik = Pi(19, "dataLayer");
    Pi(20, "");
    Pi(16, "ChEI8LTBxAYQs5bB7Yb6ive7ARIkAL/qOsWnbUTCwPEf8IluNMRUpnyD+sazvNFs9MCSPe6Ul9uDGgIkmw\x3d\x3d");
    var jk = {
            __cl: 1,
            __ecl: 1,
            __ehl: 1,
            __evl: 1,
            __fal: 1,
            __fil: 1,
            __fsl: 1,
            __hl: 1,
            __jel: 1,
            __lcl: 1,
            __sdl: 1,
            __tl: 1,
            __ytl: 1
        },
        kk = {
            __paused: 1,
            __tg: 1
        },
        lk;
    for (lk in jk) jk.hasOwnProperty(lk) && (kk[lk] = 1);
    var mk = Oi(11, zb("")),
        nk = !1;

    function ok() {
        var a = !1;
        return a
    }
    var pk = F(218) ? Oi(45, ok()) : ok(),
        qk, rk = !1;
    qk = rk;
    fk.yg = Pi(3, "www.googletagmanager.com");
    var sk = "" + fk.yg + (pk ? "/gtag/js" : "/gtm.js"),
        tk = null,
        uk = null,
        vk = {},
        wk = {};
    fk.Nm = Oi(2, zb(""));
    var xk = "";
    fk.Ii = xk;
    var bk = new function() {
        this.R = new ak;
        this.C = this.M = !1;
        this.H = 0;
        this.Da = this.Pa = this.nb = this.P = "";
        this.fa = this.la = !1
    };

    function yk() {
        var a;
        a = a === void 0 ? [] : a;
        return ck(a).join("~")
    }

    function zk() {
        var a = bk.P.length;
        return bk.P[a - 1] === "/" ? bk.P.substring(0, a - 1) : bk.P
    }

    function Ak() {
        return bk.C ? F(84) ? bk.H === 0 : bk.H !== 1 : !1
    }

    function Bk(a) {
        for (var b = {}, c = l(a.split("|")), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return b
    };
    var Ck = new vb,
        Dk = {},
        Ek = {},
        Hk = {
            name: ik,
            set: function(a, b) {
                pd(Kb(a, b), Dk);
                Fk()
            },
            get: function(a) {
                return Gk(a, 2)
            },
            reset: function() {
                Ck = new vb;
                Dk = {};
                Fk()
            }
        };

    function Gk(a, b) {
        return b != 2 ? Ck.get(a) : Ik(a)
    }

    function Ik(a, b) {
        var c = a.split(".");
        b = b || [];
        for (var d = Dk, e = 0; e < c.length; e++) {
            if (d === null) return !1;
            if (d === void 0) break;
            d = d[c[e]];
            if (b.indexOf(d) !== -1) return
        }
        return d
    }

    function Jk(a, b) {
        Ek.hasOwnProperty(a) || (Ck.set(a, b), pd(Kb(a, b), Dk), Fk())
    }

    function Kk() {
        for (var a = ["gtm.allowlist", "gtm.blocklist", "gtm.whitelist", "gtm.blacklist", "tagTypeBlacklist"], b = 0; b < a.length; b++) {
            var c = a[b],
                d = Gk(c, 1);
            if (Array.isArray(d) || od(d)) d = pd(d, null);
            Ek[c] = d
        }
    }

    function Fk(a) {
        wb(Ek, function(b, c) {
            Ck.set(b, c);
            pd(Kb(b), Dk);
            pd(Kb(b, c), Dk);
            a && delete Ek[b]
        })
    }

    function Lk(a, b) {
        var c, d = (b === void 0 ? 2 : b) !== 1 ? Ik(a) : Ck.get(a);
        md(d) === "array" || md(d) === "object" ? c = pd(d, null) : c = d;
        return c
    };
    var Wk = /:[0-9]+$/,
        Xk = /^\d+\.fls\.doubleclick\.net$/;

    function Yk(a, b, c, d) {
        var e = Zk(a, !!d, b),
            f, g;
        return c ? (g = e[b]) != null ? g : [] : (f = e[b]) == null ? void 0 : f[0]
    }

    function Zk(a, b, c) {
        for (var d = {}, e = l(a.split("&")), f = e.next(); !f.done; f = e.next()) {
            var g = l(f.value.split("=")),
                h = g.next().value,
                m = xa(g),
                n = decodeURIComponent(h.replace(/\+/g, " "));
            if (c === void 0 || n === c) {
                var p = m.join("=");
                d[n] || (d[n] = []);
                d[n].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")))
            }
        }
        return d
    }

    function $k(a) {
        try {
            return decodeURIComponent(a)
        } catch (b) {}
    }

    function al(a, b, c, d, e) {
        b && (b = String(b).toLowerCase());
        if (b === "protocol" || b === "port") a.protocol = bl(a.protocol) || bl(x.location.protocol);
        b === "port" ? a.port = String(Number(a.hostname ? a.port : x.location.port) || (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")) : b === "host" && (a.hostname = (a.hostname || x.location.hostname).replace(Wk, "").toLowerCase());
        return cl(a, b, c, d, e)
    }

    function cl(a, b, c, d, e) {
        var f, g = bl(a.protocol);
        b && (b = String(b).toLowerCase());
        switch (b) {
            case "url_no_fragment":
                f = dl(a);
                break;
            case "protocol":
                f = g;
                break;
            case "host":
                f = a.hostname.replace(Wk, "").toLowerCase();
                if (c) {
                    var h = /^www\d*\./.exec(f);
                    h && h[0] && (f = f.substring(h[0].length))
                }
                break;
            case "port":
                f = String(Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : ""));
                break;
            case "path":
                a.pathname || a.hostname || ib("TAGGING", 1);
                f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
                var m = f.split("/");
                (d || []).indexOf(m[m.length -
                    1]) >= 0 && (m[m.length - 1] = "");
                f = m.join("/");
                break;
            case "query":
                f = a.search.replace("?", "");
                e && (f = Yk(f, e, !1));
                break;
            case "extension":
                var n = a.pathname.split(".");
                f = n.length > 1 ? n[n.length - 1] : "";
                f = f.split("/")[0];
                break;
            case "fragment":
                f = a.hash.replace("#", "");
                break;
            default:
                f = a && a.href
        }
        return f
    }

    function bl(a) {
        return a ? a.replace(":", "").toLowerCase() : ""
    }

    function dl(a) {
        var b = "";
        if (a && a.href) {
            var c = a.href.indexOf("#");
            b = c < 0 ? a.href : a.href.substring(0, c)
        }
        return b
    }
    var el = {},
        fl = 0;

    function gl(a) {
        var b = el[a];
        if (!b) {
            var c = A.createElement("a");
            a && (c.href = a);
            var d = c.pathname;
            d[0] !== "/" && (a || ib("TAGGING", 1), d = "/" + d);
            var e = c.hostname.replace(Wk, "");
            b = {
                href: c.href,
                protocol: c.protocol,
                host: c.host,
                hostname: e,
                pathname: d,
                search: c.search,
                hash: c.hash,
                port: c.port
            };
            fl < 5 && (el[a] = b, fl++)
        }
        return b
    }

    function hl(a, b, c) {
        var d = gl(a);
        return Pb(b, d, c)
    }

    function il(a) {
        var b = gl(x.location.href),
            c = al(b, "host", !1);
        if (c && c.match(Xk)) {
            var d = al(b, "path");
            if (d) {
                var e = d.split(a + "=");
                if (e.length > 1) return e[1].split(";")[0].split("?")[0]
            }
        }
    };
    var jl = {
            "https://www.google.com": "/g",
            "https://www.googleadservices.com": "/as",
            "https://pagead2.googlesyndication.com": "/gs"
        },
        kl = ["/as/d/ccm/conversion", "/g/d/ccm/conversion", "/gs/ccm/conversion", "/d/ccm/form-data"];

    function ll(a, b) {
        if (a) {
            var c = "" + a;
            c.indexOf("http://") !== 0 && c.indexOf("https://") !== 0 && (c = "https://" + c);
            c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
            return gl("" + c + b).href
        }
    }

    function ml(a, b) {
        if (Ak() || bk.M) return ll(a, b)
    }

    function nl() {
        return !!fk.Ii && fk.Ii.split("@@").join("") !== "SGTM_TOKEN"
    }

    function ol(a) {
        for (var b = l([K.m.rd, K.m.sc]), c = b.next(); !c.done; c = b.next()) {
            var d = N(a, c.value);
            if (d) return d
        }
    }

    function pl(a, b, c) {
        c = c === void 0 ? "" : c;
        if (!Ak()) return a;
        var d = b ? jl[a] || "" : "";
        d === "/gs" && (c = "");
        return "" + zk() + d + c
    }

    function ql(a) {
        if (!Ak()) return a;
        for (var b = l(kl), c = b.next(); !c.done; c = b.next())
            if (Ib(a, "" + zk() + c.value)) return a + "&_uip=" + encodeURIComponent("::");
        return a
    };

    function rl(a) {
        var b = String(a[lf.Oa] || "").replace(/_/g, "");
        return Ib(b, "cvt") ? "cvt" : b
    }
    var sl = x.location.search.indexOf("?gtm_latency=") >= 0 || x.location.search.indexOf("&gtm_latency=") >= 0;
    var tl = {
            jq: Ri(27, Number("0.005000")),
            So: Ri(42, Number("0.010000"))
        },
        ul = Math.random(),
        vl = sl || ul < Number(tl.jq),
        wl = sl || ul >= 1 - Number(tl.So);
    var xl = function(a, b) {
            var c = function() {};
            c.prototype = a.prototype;
            var d = new c;
            a.apply(d, Array.prototype.slice.call(arguments, 1));
            return d
        },
        yl = function(a) {
            var b = a;
            return function() {
                if (b) {
                    var c = b;
                    b = null;
                    c()
                }
            }
        };
    var zl, Al;
    a: {
        for (var Bl = ["CLOSURE_FLAGS"], Cl = Da, Dl = 0; Dl < Bl.length; Dl++)
            if (Cl = Cl[Bl[Dl]], Cl == null) {
                Al = null;
                break a
            }
        Al = Cl
    }
    var El = Al && Al[610401301];
    zl = El != null ? El : !1;

    function Fl() {
        var a = Da.navigator;
        if (a) {
            var b = a.userAgent;
            if (b) return b
        }
        return ""
    }
    var Gl, Hl = Da.navigator;
    Gl = Hl ? Hl.userAgentData || null : null;

    function Il(a) {
        if (!zl || !Gl) return !1;
        for (var b = 0; b < Gl.brands.length; b++) {
            var c = Gl.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function Jl(a) {
        return Fl().indexOf(a) != -1
    };

    function Kl() {
        return zl ? !!Gl && Gl.brands.length > 0 : !1
    }

    function Ll() {
        return Kl() ? !1 : Jl("Opera")
    }

    function Ml() {
        return Jl("Firefox") || Jl("FxiOS")
    }

    function Nl() {
        return Kl() ? Il("Chromium") : (Jl("Chrome") || Jl("CriOS")) && !(Kl() ? 0 : Jl("Edge")) || Jl("Silk")
    };
    var Ol = function(a) {
        Ol[" "](a);
        return a
    };
    Ol[" "] = function() {};
    var Pl = function(a) {
        return decodeURIComponent(a.replace(/\+/g, " "))
    };

    function Ql() {
        return zl ? !!Gl && !!Gl.platform : !1
    }

    function Rl() {
        return Jl("iPhone") && !Jl("iPod") && !Jl("iPad")
    }

    function Sl() {
        Rl() || Jl("iPad") || Jl("iPod")
    };
    Ll();
    Kl() || Jl("Trident") || Jl("MSIE");
    Jl("Edge");
    !Jl("Gecko") || Fl().toLowerCase().indexOf("webkit") != -1 && !Jl("Edge") || Jl("Trident") || Jl("MSIE") || Jl("Edge");
    Fl().toLowerCase().indexOf("webkit") != -1 && !Jl("Edge") && Jl("Mobile");
    Ql() || Jl("Macintosh");
    Ql() || Jl("Windows");
    (Ql() ? Gl.platform === "Linux" : Jl("Linux")) || Ql() || Jl("CrOS");
    Ql() || Jl("Android");
    Rl();
    Jl("iPad");
    Jl("iPod");
    Sl();
    Fl().toLowerCase().indexOf("kaios");
    var Tl = function(a) {
            try {
                var b;
                if (b = !!a && a.location.href != null) a: {
                    try {
                        Ol(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        },
        Ul = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        Vl = function(a, b) {
            for (var c = a, d = 0; d < 50; ++d) {
                var e;
                try {
                    e = !(!c.frames || !c.frames[b])
                } catch (h) {
                    e = !1
                }
                if (e) return c;
                var f;
                a: {
                    try {
                        var g = c.parent;
                        if (g && g != c) {
                            f = g;
                            break a
                        }
                    } catch (h) {}
                    f = null
                }
                if (!(c = f)) break
            }
            return null
        },
        Wl = function(a) {
            var b = x;
            if (b.top == b) return 0;
            if (a === void 0 ? 0 : a) {
                var c =
                    b.location.ancestorOrigins;
                if (c) return c[c.length - 1] == b.location.origin ? 1 : 2
            }
            return Tl(b.top) ? 1 : 2
        },
        Xl = function(a) {
            a = a === void 0 ? document : a;
            return a.createElement("img")
        },
        Yl = function() {
            for (var a = x, b = a; a && a != a.parent;) a = a.parent, Tl(a) && (b = a);
            return b
        };

    function Zl(a) {
        var b;
        b = b === void 0 ? document : b;
        var c;
        return !((c = b.featurePolicy) == null || !c.allowedFeatures().includes(a))
    };

    function $l() {
        return Zl("join-ad-interest-group") && ob(wc.joinAdInterestGroup)
    }

    function am(a, b, c) {
        var d = Ta[3] === void 0 ? 1 : Ta[3],
            e = 'iframe[data-tagging-id="' + b + '"]',
            f = [];
        try {
            if (d === 1) {
                var g = A.querySelector(e);
                g && (f = [g])
            } else f = Array.from(A.querySelectorAll(e))
        } catch (r) {}
        var h;
        a: {
            try {
                h = A.querySelectorAll('iframe[allow="join-ad-interest-group"][data-tagging-id*="-"]');
                break a
            } catch (r) {}
            h = void 0
        }
        var m = h,
            n = ((m == null ? void 0 : m.length) || 0) >= (Ta[2] === void 0 ? 50 : Ta[2]),
            p;
        if (p = f.length >= 1) {
            var q = Number(f[f.length - 1].dataset.loadTime);
            q !== void 0 && Db() - q < (Ta[1] === void 0 ? 6E4 : Ta[1]) ? (ib("TAGGING",
                9), p = !0) : p = !1
        }
        if (p) return !1;
        if (d === 1)
            if (f.length >= 1) bm(f[0]);
            else {
                if (n) return ib("TAGGING", 10), !1
            }
        else f.length >= d ? bm(f[0]) : n && bm(m[0]);
        Lc(a, c, {
            allow: "join-ad-interest-group"
        }, {
            taggingId: b,
            loadTime: Db()
        });
        return !0
    }

    function bm(a) {
        try {
            a.parentNode.removeChild(a)
        } catch (b) {}
    };

    function cm(a, b, c) {
        var d, e = a.GooglebQhCsO;
        e || (e = {}, a.GooglebQhCsO = e);
        d = e;
        if (d[b]) return !1;
        d[b] = [];
        d[b][0] = c;
        return !0
    };
    var dm = function(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        return b
    };
    Ml();
    Rl() || Jl("iPod");
    Jl("iPad");
    !Jl("Android") || Nl() || Ml() || Ll() || Jl("Silk");
    Nl();
    !Jl("Safari") || Nl() || (Kl() ? 0 : Jl("Coast")) || Ll() || (Kl() ? 0 : Jl("Edge")) || (Kl() ? Il("Microsoft Edge") : Jl("Edg/")) || (Kl() ? Il("Opera") : Jl("OPR")) || Ml() || Jl("Silk") || Jl("Android") || Sl();
    var em = {},
        fm = null,
        gm = function(a) {
            for (var b = [], c = 0, d = 0; d < a.length; d++) {
                var e = a.charCodeAt(d);
                e > 255 && (b[c++] = e & 255, e >>= 8);
                b[c++] = e
            }
            var f = 4;
            f === void 0 && (f = 0);
            if (!fm) {
                fm = {};
                for (var g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), h = ["+/=", "+/", "-_=", "-_.", "-_"], m = 0; m < 5; m++) {
                    var n = g.concat(h[m].split(""));
                    em[m] = n;
                    for (var p = 0; p < n.length; p++) {
                        var q = n[p];
                        fm[q] === void 0 && (fm[q] = p)
                    }
                }
            }
            for (var r = em[f], t = Array(Math.floor(b.length / 3)), u = r[64] || "", v = 0, w = 0; v < b.length - 2; v += 3) {
                var y = b[v],
                    z = b[v + 1],
                    B = b[v + 2],
                    D = r[y >> 2],
                    G = r[(y & 3) << 4 | z >> 4],
                    I = r[(z & 15) << 2 | B >> 6],
                    M = r[B & 63];
                t[w++] = "" + D + G + I + M
            }
            var S = 0,
                ea = u;
            switch (b.length - v) {
                case 2:
                    S = b[v + 1], ea = r[(S & 15) << 2] || u;
                case 1:
                    var P = b[v];
                    t[w] = "" + r[P >> 2] + r[(P & 3) << 4 | S >> 4] + ea + u
            }
            return t.join("")
        };
    var hm = function(a, b, c, d) {
            for (var e = b, f = c.length;
                (e = a.indexOf(c, e)) >= 0 && e < d;) {
                var g = a.charCodeAt(e - 1);
                if (g == 38 || g == 63) {
                    var h = a.charCodeAt(e + f);
                    if (!h || h == 61 || h == 38 || h == 35) return e
                }
                e += f + 1
            }
            return -1
        },
        im = /#|$/,
        jm = function(a, b) {
            var c = a.search(im),
                d = hm(a, 0, b, c);
            if (d < 0) return null;
            var e = a.indexOf("&", d);
            if (e < 0 || e > c) e = c;
            d += b.length + 1;
            return Pl(a.slice(d, e !== -1 ? e : 0))
        },
        km = /[?&]($|#)/,
        lm = function(a, b, c) {
            for (var d, e = a.search(im), f = 0, g, h = [];
                (g = hm(a, f, b, e)) >= 0;) h.push(a.substring(f, g)), f = Math.min(a.indexOf("&", g) +
                1 || e, e);
            h.push(a.slice(f));
            d = h.join("").replace(km, "$1");
            var m, n = c != null ? "=" + encodeURIComponent(String(c)) : "";
            var p = b + n;
            if (p) {
                var q, r = d.indexOf("#");
                r < 0 && (r = d.length);
                var t = d.indexOf("?"),
                    u;
                t < 0 || t > r ? (t = r, u = "") : u = d.substring(t + 1, r);
                q = [d.slice(0, t), u, d.slice(r)];
                var v = q[1];
                q[1] = p ? v ? v + "&" + p : p : v;
                m = q[0] + (q[1] ? "?" + q[1] : "") + q[2]
            } else m = d;
            return m
        };

    function mm(a, b, c, d, e, f, g) {
        var h = jm(c, "fmt");
        if (d) {
            var m = jm(c, "random"),
                n = jm(c, "label") || "";
            if (!m) return !1;
            var p = gm(Pl(n) + ":" + Pl(m));
            if (!cm(a, p, d)) return !1
        }
        h && Number(h) !== 4 && (c = lm(c, "rfmt", h));
        var q = lm(c, "fmt", 4),
            r = b.getElementsByTagName("script")[0].parentElement;
        g == null || nm(g);
        Jc(q, function() {
            g == null || om(g);
            a.google_noFurtherRedirects && d && (a.google_noFurtherRedirects = null, d())
        }, function() {
            g == null || om(g);
            e == null || e()
        }, f, r || void 0);
        return !0
    };
    var pm = {},
        qm = (pm[1] = {}, pm[2] = {}, pm[3] = {}, pm[4] = {}, pm);

    function rm(a, b, c) {
        var d = sm(b, c);
        if (d) {
            var e = qm[b][d];
            e || (e = qm[b][d] = []);
            e.push(ma(Object, "assign").call(Object, {}, a))
        }
    }

    function tm(a, b) {
        var c = sm(a, b);
        if (c) {
            var d = qm[a][c];
            d && (qm[a][c] = d.filter(function(e) {
                return !e.wm
            }))
        }
    }

    function um(a) {
        switch (a) {
            case "script-src":
            case "script-src-elem":
                return 1;
            case "frame-src":
                return 4;
            case "connect-src":
                return 2;
            case "img-src":
                return 3
        }
    }

    function sm(a, b) {
        var c = b;
        if (b[0] === "/") {
            var d;
            c = ((d = x.location) == null ? void 0 : d.origin) + b
        }
        try {
            var e = new URL(c);
            return a === 4 ? e.origin : e.origin + e.pathname
        } catch (f) {}
    }

    function vm(a) {
        var b = Ca.apply(1, arguments);
        wl && (rm(a, 2, b[0]), rm(a, 3, b[0]));
        Vc.apply(null, ya(b))
    }

    function wm(a) {
        var b = Ca.apply(1, arguments);
        wl && rm(a, 2, b[0]);
        return Wc.apply(null, ya(b))
    }

    function xm(a) {
        var b = Ca.apply(1, arguments);
        wl && rm(a, 3, b[0]);
        Mc.apply(null, ya(b))
    }

    function ym(a) {
        var b = Ca.apply(1, arguments),
            c = b[0];
        wl && (rm(a, 2, c), rm(a, 3, c));
        return Yc.apply(null, ya(b))
    }

    function zm(a) {
        var b = Ca.apply(1, arguments);
        wl && rm(a, 1, b[0]);
        Jc.apply(null, ya(b))
    }

    function Am(a) {
        var b = Ca.apply(1, arguments);
        b[0] && wl && rm(a, 4, b[0]);
        Lc.apply(null, ya(b))
    }

    function Bm(a) {
        var b = Ca.apply(1, arguments);
        wl && rm(a, 1, b[2]);
        return mm.apply(null, ya(b))
    }

    function Cm(a) {
        var b = Ca.apply(1, arguments);
        wl && rm(a, 4, b[0]);
        am.apply(null, ya(b))
    };
    var Dm = /gtag[.\/]js/,
        Em = /gtm[.\/]js/,
        Fm = !1;

    function Gm(a) {
        if (Fm) return "1";
        var b, c = (b = a.scriptElement) == null ? void 0 : b.src;
        if (c) {
            if (Dm.test(c)) return "3";
            if (Em.test(c)) return "2"
        }
        return "0"
    };

    function Hm(a, b, c) {
        var d = Im(),
            e = Jm().container[a];
        e && e.state !== 3 || (Jm().container[a] = {
            state: 1,
            context: b,
            parent: d
        }, Km({
            ctid: a,
            isDestination: !1
        }, c))
    }

    function Km(a, b) {
        var c = Jm();
        c.pending || (c.pending = []);
        sb(c.pending, function(d) {
            return d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
        }) || c.pending.push({
            target: a,
            onLoad: b
        })
    }

    function Lm() {
        var a = x.google_tags_first_party;
        Array.isArray(a) || (a = []);
        for (var b = {}, c = l(a), d = c.next(); !d.done; d = c.next()) b[d.value] = !0;
        return Object.freeze(b)
    }
    var Mm = function() {
        this.container = {};
        this.destination = {};
        this.canonical = {};
        this.pending = [];
        this.injectedFirstPartyContainers = {};
        this.injectedFirstPartyContainers = Lm()
    };

    function Jm() {
        var a = Ac("google_tag_data", {}),
            b = a.tidr;
        b && typeof b === "object" || (b = new Mm, a.tidr = b);
        var c = b;
        c.container || (c.container = {});
        c.destination || (c.destination = {});
        c.canonical || (c.canonical = {});
        c.pending || (c.pending = []);
        c.injectedFirstPartyContainers || (c.injectedFirstPartyContainers = Lm());
        return c
    };
    var Nm = {},
        ng = {
            ctid: Pi(5, "GTM-W77HWDF"),
            canonicalContainerId: Pi(6, ""),
            lm: Pi(10, "GTM-W77HWDF"),
            om: Pi(9, "GTM-W77HWDF")
        };
    Nm.se = Oi(7, zb(""));

    function Om() {
        return Nm.se && Pm().some(function(a) {
            return a === ng.ctid
        })
    }

    function Qm() {
        return ng.canonicalContainerId || "_" + ng.ctid
    }

    function Rm() {
        return ng.lm ? ng.lm.split("|") : [ng.ctid]
    }

    function Pm() {
        return ng.om ? ng.om.split("|").filter(function(a) {
            return a.indexOf("GTM-") !== 0
        }) : []
    }

    function Sm() {
        var a = Tm(Im()),
            b = a && a.parent;
        if (b) return Tm(b)
    }

    function Um() {
        var a = Tm(Im());
        if (a) {
            for (; a.parent;) {
                var b = Tm(a.parent);
                if (!b) break;
                a = b
            }
            return a
        }
    }

    function Tm(a) {
        var b = Jm();
        return a.isDestination ? b.destination[a.ctid] : b.container[a.ctid]
    }

    function Vm() {
        var a = Jm();
        if (a.pending) {
            for (var b, c = [], d = !1, e = Rm(), f = Pm(), g = {}, h = 0; h < a.pending.length; g = {
                    mg: void 0
                }, h++) g.mg = a.pending[h], sb(g.mg.target.isDestination ? f : e, function(m) {
                return function(n) {
                    return n === m.mg.target.ctid
                }
            }(g)) ? d || (b = g.mg.onLoad, d = !0) : c.push(g.mg);
            a.pending = c;
            if (b) try {
                b(Qm())
            } catch (m) {}
        }
    }

    function Wm() {
        for (var a = ng.ctid, b = Rm(), c = Pm(), d = function(n, p) {
                    var q = {
                        canonicalContainerId: ng.canonicalContainerId,
                        scriptContainerId: a,
                        state: 2,
                        containers: b.slice(),
                        destinations: c.slice()
                    };
                    yc && (q.scriptElement = yc);
                    zc && (q.scriptSource = zc);
                    if (Sm() === void 0) {
                        var r;
                        a: {
                            if ((q.scriptContainerId || "").indexOf("GTM-") >= 0) {
                                var t;
                                b: {
                                    var u, v = (u = q.scriptElement) == null ? void 0 : u.src;
                                    if (v) {
                                        for (var w = bk.C, y = gl(v), z = w ? y.pathname : "" + y.hostname + y.pathname, B = A.scripts, D = "", G = 0; G < B.length; ++G) {
                                            var I = B[G];
                                            if (!(I.innerHTML.length ===
                                                    0 || !w && I.innerHTML.indexOf(q.scriptContainerId || "SHOULD_NOT_BE_SET") < 0 || I.innerHTML.indexOf(z) < 0)) {
                                                if (I.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                                                    t = String(G);
                                                    break b
                                                }
                                                D = String(G)
                                            }
                                        }
                                        if (D) {
                                            t = D;
                                            break b
                                        }
                                    }
                                    t = void 0
                                }
                                var M = t;
                                if (M) {
                                    Fm = !0;
                                    r = M;
                                    break a
                                }
                            }
                            var S = [].slice.call(A.scripts);r = q.scriptElement ? String(S.indexOf(q.scriptElement)) : "-1"
                        }
                        q.htmlLoadOrder = r;
                        q.loadScriptType = Gm(q)
                    }
                    var ea = p ? e.destination : e.container,
                        P = ea[n];
                    P ? (p && P.state === 0 && L(93), ma(Object, "assign").call(Object, P, q)) : ea[n] = q
                }, e = Jm(), f = l(b),
                g = f.next(); !g.done; g = f.next()) d(g.value, !1);
        for (var h = l(c), m = h.next(); !m.done; m = h.next()) d(m.value, !0);
        e.canonical[Qm()] = {};
        Vm()
    }

    function Xm() {
        var a = Qm();
        return !!Jm().canonical[a]
    }

    function Ym(a) {
        return !!Jm().container[a]
    }

    function Zm(a) {
        var b = Jm().destination[a];
        return !!b && !!b.state
    }

    function Im() {
        return {
            ctid: ng.ctid,
            isDestination: Nm.se
        }
    }

    function $m() {
        var a = Jm().container,
            b;
        for (b in a)
            if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
        return !1
    }

    function an() {
        var a = {};
        wb(Jm().destination, function(b, c) {
            c.state === 0 && (a[b] = c)
        });
        return a
    }

    function bn(a) {
        return !!(a && a.parent && a.context && a.context.source === 1 && a.parent.ctid.indexOf("GTM-") !== 0)
    }

    function cn() {
        for (var a = Jm(), b = l(Rm()), c = b.next(); !c.done; c = b.next())
            if (a.injectedFirstPartyContainers[c.value]) return !0;
        return !1
    };
    var dn = {
        Ha: {
            ne: 0,
            qe: 1,
            Ei: 2
        }
    };
    dn.Ha[dn.Ha.ne] = "FULL_TRANSMISSION";
    dn.Ha[dn.Ha.qe] = "LIMITED_TRANSMISSION";
    dn.Ha[dn.Ha.Ei] = "NO_TRANSMISSION";
    var en = {
        W: {
            Fb: 0,
            Fa: 1,
            Cc: 2,
            Lc: 3
        }
    };
    en.W[en.W.Fb] = "NO_QUEUE";
    en.W[en.W.Fa] = "ADS";
    en.W[en.W.Cc] = "ANALYTICS";
    en.W[en.W.Lc] = "MONITORING";

    function fn() {
        var a = Ac("google_tag_data", {});
        return a.ics = a.ics || new gn
    }
    var gn = function() {
        this.entries = {};
        this.waitPeriodTimedOut = this.wasSetLate = this.accessedAny = this.accessedDefault = this.usedImplicit = this.usedUpdate = this.usedDefault = this.usedDeclare = this.active = !1;
        this.C = []
    };
    gn.prototype.default = function(a, b, c, d, e, f, g) {
        this.usedDefault || this.usedDeclare || !this.accessedDefault && !this.accessedAny || (this.wasSetLate = !0);
        this.usedDefault = this.active = !0;
        ib("TAGGING", 19);
        b == null ? ib("TAGGING", 18) : hn(this, a, b === "granted", c, d, e, f, g)
    };
    gn.prototype.waitForUpdate = function(a, b, c) {
        for (var d = 0; d < a.length; d++) hn(this, a[d], void 0, void 0, "", "", b, c)
    };
    var hn = function(a, b, c, d, e, f, g, h) {
        var m = a.entries,
            n = m[b] || {},
            p = n.region,
            q = d && pb(d) ? d.toUpperCase() : void 0;
        e = e.toUpperCase();
        f = f.toUpperCase();
        if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
            var r = !!(g && g > 0 && n.update === void 0),
                t = {
                    region: q,
                    declare_region: n.declare_region,
                    implicit: n.implicit,
                    default: c !== void 0 ? c : n.default,
                    declare: n.declare,
                    update: n.update,
                    quiet: r
                };
            if (e !== "" || n.default !== !1) m[b] = t;
            r && x.setTimeout(function() {
                m[b] === t && t.quiet && (ib("TAGGING", 2), a.waitPeriodTimedOut = !0, a.clearTimeout(b, void 0, h),
                    a.notifyListeners())
            }, g)
        }
    };
    k = gn.prototype;
    k.clearTimeout = function(a, b, c) {
        var d = [a],
            e = c.delegatedConsentTypes,
            f;
        for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
        var g = this.entries[a] || {},
            h = this.getConsentState(a, c);
        if (g.quiet) {
            g.quiet = !1;
            for (var m = l(d), n = m.next(); !n.done; n = m.next()) jn(this, n.value)
        } else if (b !== void 0 && h !== b)
            for (var p = l(d), q = p.next(); !q.done; q = p.next()) jn(this, q.value)
    };
    k.update = function(a, b, c) {
        this.usedDefault || this.usedDeclare || this.usedUpdate || !this.accessedAny || (this.wasSetLate = !0);
        this.usedUpdate = this.active = !0;
        if (b != null) {
            var d = this.getConsentState(a, c),
                e = this.entries;
            (e[a] = e[a] || {}).update = b === "granted";
            this.clearTimeout(a, d, c)
        }
    };
    k.declare = function(a, b, c, d, e) {
        this.usedDeclare = this.active = !0;
        var f = this.entries,
            g = f[a] || {},
            h = g.declare_region,
            m = c && pb(c) ? c.toUpperCase() : void 0;
        d = d.toUpperCase();
        e = e.toUpperCase();
        if (d === "" || m === e || (m === d ? h !== e : !m && !h)) {
            var n = {
                region: g.region,
                declare_region: m,
                declare: b === "granted",
                implicit: g.implicit,
                default: g.default,
                update: g.update,
                quiet: g.quiet
            };
            if (d !== "" || g.declare !== !1) f[a] = n
        }
    };
    k.implicit = function(a, b) {
        this.usedImplicit = !0;
        var c = this.entries,
            d = c[a] = c[a] || {};
        d.implicit !== !1 && (d.implicit = b === "granted")
    };
    k.getConsentState = function(a, b) {
        var c = this.entries,
            d = c[a] || {},
            e = d.update;
        if (e !== void 0) return e ? 1 : 2;
        if (b.usedContainerScopedDefaults) {
            var f = b.containerScopedDefaults[a];
            if (f === 3) return 1;
            if (f === 2) return 2
        } else if (e = d.default, e !== void 0) return e ? 1 : 2;
        if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
            var g = b.delegatedConsentTypes[a],
                h = c[g] || {};
            e = h.update;
            if (e !== void 0) return e ? 1 : 2;
            if (b.usedContainerScopedDefaults) {
                var m = b.containerScopedDefaults[g];
                if (m === 3) return 1;
                if (m === 2) return 2
            } else if (e =
                h.default, e !== void 0) return e ? 1 : 2
        }
        e = d.declare;
        if (e !== void 0) return e ? 1 : 2;
        e = d.implicit;
        return e !== void 0 ? e ? 3 : 4 : 0
    };
    k.addListener = function(a, b) {
        this.C.push({
            consentTypes: a,
            Fd: b
        })
    };
    var jn = function(a, b) {
        for (var c = 0; c < a.C.length; ++c) {
            var d = a.C[c];
            Array.isArray(d.consentTypes) && d.consentTypes.indexOf(b) !== -1 && (d.qm = !0)
        }
    };
    gn.prototype.notifyListeners = function(a, b) {
        for (var c = 0; c < this.C.length; ++c) {
            var d = this.C[c];
            if (d.qm) {
                d.qm = !1;
                try {
                    d.Fd({
                        consentEventId: a,
                        consentPriorityId: b
                    })
                } catch (e) {}
            }
        }
    };
    var kn = !1,
        ln = !1,
        mn = {},
        nn = {
            delegatedConsentTypes: {},
            corePlatformServices: {},
            usedCorePlatformServices: !1,
            selectedAllCorePlatformServices: !1,
            containerScopedDefaults: (mn.ad_storage = 1, mn.analytics_storage = 1, mn.ad_user_data = 1, mn.ad_personalization = 1, mn),
            usedContainerScopedDefaults: !1
        };

    function on(a) {
        var b = fn();
        b.accessedAny = !0;
        return (pb(a) ? [a] : a).every(function(c) {
            switch (b.getConsentState(c, nn)) {
                case 1:
                case 3:
                    return !0;
                case 2:
                case 4:
                    return !1;
                default:
                    return !0
            }
        })
    }

    function pn(a) {
        var b = fn();
        b.accessedAny = !0;
        return b.getConsentState(a, nn)
    }

    function qn(a) {
        var b = fn();
        b.accessedAny = !0;
        return !(b.entries[a] || {}).quiet
    }

    function rn() {
        if (!Ua(7)) return !1;
        var a = fn();
        a.accessedAny = !0;
        if (a.active) return !0;
        if (!nn.usedContainerScopedDefaults) return !1;
        for (var b = l(Object.keys(nn.containerScopedDefaults)), c = b.next(); !c.done; c = b.next())
            if (nn.containerScopedDefaults[c.value] !== 1) return !0;
        return !1
    }

    function sn(a, b) {
        fn().addListener(a, b)
    }

    function tn(a, b) {
        fn().notifyListeners(a, b)
    }

    function un(a, b) {
        function c() {
            for (var e = 0; e < b.length; e++)
                if (!qn(b[e])) return !0;
            return !1
        }
        if (c()) {
            var d = !1;
            sn(b, function(e) {
                d || c() || (d = !0, a(e))
            })
        } else a({})
    }

    function vn(a, b) {
        function c() {
            for (var h = [], m = 0; m < e.length; m++) {
                var n = e[m];
                on(n) && !f[n] && h.push(n)
            }
            return h
        }

        function d(h) {
            for (var m = 0; m < h.length; m++) f[h[m]] = !0
        }
        var e = pb(b) ? [b] : b,
            f = {},
            g = c();
        g.length !== e.length && (d(g), sn(e, function(h) {
            function m(q) {
                q.length !== 0 && (d(q), h.consentTypes = q, a(h))
            }
            var n = c();
            if (n.length !== 0) {
                var p = Object.keys(f).length;
                n.length + p >= e.length ? m(n) : x.setTimeout(function() {
                    m(c())
                }, 500)
            }
        }))
    };
    var wn = {},
        xn = (wn[en.W.Fb] = dn.Ha.ne, wn[en.W.Fa] = dn.Ha.ne, wn[en.W.Cc] = dn.Ha.ne, wn[en.W.Lc] = dn.Ha.ne, wn),
        yn = function(a, b) {
            this.C = a;
            this.consentTypes = b
        };
    yn.prototype.isConsentGranted = function() {
        switch (this.C) {
            case 0:
                return this.consentTypes.every(function(a) {
                    return on(a)
                });
            case 1:
                return this.consentTypes.some(function(a) {
                    return on(a)
                });
            default:
                nc(this.C, "consentsRequired had an unknown type")
        }
    };
    var zn = {},
        An = (zn[en.W.Fb] = new yn(0, []), zn[en.W.Fa] = new yn(0, ["ad_storage"]), zn[en.W.Cc] = new yn(0, ["analytics_storage"]), zn[en.W.Lc] = new yn(1, ["ad_storage", "analytics_storage"]), zn);
    var Cn = function(a) {
        var b = this;
        this.type = a;
        this.C = [];
        sn(An[a].consentTypes, function() {
            Bn(b) || b.flush()
        })
    };
    Cn.prototype.flush = function() {
        for (var a = l(this.C), b = a.next(); !b.done; b = a.next()) {
            var c = b.value;
            c()
        }
        this.C = []
    };
    var Bn = function(a) {
            return xn[a.type] === dn.Ha.Ei && !An[a.type].isConsentGranted()
        },
        Dn = function(a, b) {
            Bn(a) ? a.C.push(b) : b()
        },
        En = new Map;

    function Fn(a) {
        En.has(a) || En.set(a, new Cn(a));
        return En.get(a)
    };
    var Gn = {
        X: {
            Im: "aw_user_data_cache",
            Mh: "cookie_deprecation_label",
            zg: "diagnostics_page_id",
            Rn: "fl_user_data_cache",
            Tn: "ga4_user_data_cache",
            Gf: "ip_geo_data_cache",
            zi: "ip_geo_fetch_in_progress",
            ol: "nb_data",
            ql: "page_experiment_ids",
            Qf: "pt_data",
            rl: "pt_listener_set",
            wl: "service_worker_endpoint",
            yl: "shared_user_id",
            zl: "shared_user_id_requested",
            mh: "shared_user_id_source"
        }
    };
    var Hn = function(a) {
        return df(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    }(Gn.X);

    function In(a, b) {
        b = b === void 0 ? !1 : b;
        if (Hn(a)) {
            var c, d, e = (d = (c = Ac("google_tag_data", {})).xcd) != null ? d : c.xcd = {};
            if (e[a]) return e[a];
            if (b) {
                var f = void 0,
                    g = 1,
                    h = {},
                    m = {
                        set: function(n) {
                            f = n;
                            m.notify()
                        },
                        get: function() {
                            return f
                        },
                        subscribe: function(n) {
                            h[String(g)] = n;
                            return g++
                        },
                        unsubscribe: function(n) {
                            var p = String(n);
                            return h.hasOwnProperty(p) ? (delete h[p], !0) : !1
                        },
                        notify: function() {
                            for (var n = l(Object.keys(h)), p = n.next(); !p.done; p = n.next()) {
                                var q = p.value;
                                try {
                                    h[q](a, f)
                                } catch (r) {}
                            }
                        }
                    };
                return e[a] = m
            }
        }
    }

    function Jn(a, b) {
        var c = In(a, !0);
        c && c.set(b)
    }

    function Kn(a) {
        var b;
        return (b = In(a)) == null ? void 0 : b.get()
    }

    function Ln(a) {
        var b = {},
            c = In(a);
        if (!c) {
            c = In(a, !0);
            if (!c) return;
            c.set(b)
        }
        return c.get()
    }

    function Mn(a, b) {
        if (typeof b === "function") {
            var c;
            return (c = In(a, !0)) == null ? void 0 : c.subscribe(b)
        }
    }

    function Nn(a, b) {
        var c = In(a);
        return c ? c.unsubscribe(b) : !1
    };
    var On = "https://" + Pi(21, "www.googletagmanager.com"),
        Pn = "/td?id=" + ng.ctid,
        Qn = {},
        Rn = (Qn.tdp = 1, Qn.exp = 1, Qn.pid = 1, Qn.dl = 1, Qn.seq = 1, Qn.t = 1, Qn.v = 1, Qn),
        Sn = ["mcc"],
        Tn = {},
        Un = {},
        Vn = !1;

    function Wn(a, b, c) {
        Un[a] = b;
        (c === void 0 || c) && Xn(a)
    }

    function Xn(a, b) {
        Tn[a] !== void 0 && (b === void 0 || !b) || Ib(ng.ctid, "GTM-") && a === "mcc" || (Tn[a] = !0)
    }

    function Yn(a) {
        a = a === void 0 ? !1 : a;
        var b = Object.keys(Tn).filter(function(c) {
            return Tn[c] === !0 && Un[c] !== void 0 && (a || !Sn.includes(c))
        }).map(function(c) {
            var d = Un[c];
            typeof d === "function" && (d = d());
            return d ? "&" + c + "=" + d : ""
        }).join("");
        return "" + pl(On) + Pn + ("" + b + "&z=0")
    }

    function Zn() {
        Object.keys(Tn).forEach(function(a) {
            Rn[a] || (Tn[a] = !1)
        })
    }

    function $n(a) {
        a = a === void 0 ? !1 : a;
        if (bk.fa && wl && ng.ctid) {
            var b = Fn(en.W.Lc);
            if (Bn(b)) Vn || (Vn = !0, Dn(b, $n));
            else {
                var c = Yn(a),
                    d = {
                        destinationId: ng.ctid,
                        endpoint: 61
                    };
                a ? ym(d, c, void 0, {
                    Eh: !0
                }, void 0, function() {
                    xm(d, c + "&img=1")
                }) : xm(d, c);
                Zn();
                Vn = !1
            }
        }
    }

    function ao() {
        Object.keys(Tn).filter(function(a) {
            return Tn[a] && !Rn[a]
        }).length > 0 && $n(!0)
    }
    var bo;

    function co() {
        if (Kn(Gn.X.zg) === void 0) {
            var a = function() {
                Jn(Gn.X.zg, tb());
                bo = 0
            };
            a();
            x.setInterval(a, 864E5)
        } else Mn(Gn.X.zg, function() {
            bo = 0
        });
        bo = 0
    }

    function eo() {
        co();
        Wn("v", "3");
        Wn("t", "t");
        Wn("pid", function() {
            return String(Kn(Gn.X.zg))
        });
        Wn("seq", function() {
            return String(++bo)
        });
        Wn("exp", yk());
        Oc(x, "pagehide", ao)
    };
    var fo = ["ad_storage", "analytics_storage", "ad_user_data", "ad_personalization"],
        go = [K.m.rd, K.m.sc, K.m.ee, K.m.Qb, K.m.Vb, K.m.Ja, K.m.Ua, K.m.lb, K.m.xb, K.m.Rb],
        ho = !1,
        io = !1,
        jo = {},
        ko = {};

    function lo() {
        !io && ho && (fo.some(function(a) {
            return nn.containerScopedDefaults[a] !== 1
        }) || mo("mbc"));
        io = !0
    }

    function mo(a) {
        wl && (Wn(a, "1"), $n())
    }

    function no(a, b) {
        if (!jo[b] && (jo[b] = !0, ko[b]))
            for (var c = l(go), d = c.next(); !d.done; d = c.next())
                if (N(a, d.value)) {
                    mo("erc");
                    break
                }
    };

    function oo(a) {
        ib("HEALTH", a)
    };
    var po = {
            jp: Pi(22, "eyIwIjoiSU4iLCIxIjoiSU4tR0oiLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jby5pbiIsIjQiOiIiLCI1Ijp0cnVlLCI2IjpmYWxzZSwiNyI6ImFkX3N0b3JhZ2V8YW5hbHl0aWNzX3N0b3JhZ2V8YWRfdXNlcl9kYXRhfGFkX3BlcnNvbmFsaXphdGlvbiJ9")
        },
        qo = {},
        ro = !1;

    function so() {
        function a() {
            c !== void 0 && Nn(Gn.X.Gf, c);
            try {
                var e = Kn(Gn.X.Gf);
                qo = JSON.parse(e)
            } catch (f) {
                L(123), oo(2), qo = {}
            }
            ro = !0;
            b()
        }
        var b = to,
            c = void 0,
            d = Kn(Gn.X.Gf);
        d ? a(d) : (c = Mn(Gn.X.Gf, a), uo())
    }

    function uo() {
        function a(c) {
            Jn(Gn.X.Gf, c || "{}");
            Jn(Gn.X.zi, !1)
        }
        if (!Kn(Gn.X.zi)) {
            Jn(Gn.X.zi, !0);
            var b = "";
            b = "https://www.google.com/ccm/geo";
            try {
                x.fetch(b, {
                    method: "GET",
                    cache: "no-store",
                    mode: "cors",
                    credentials: "omit"
                }).then(function(c) {
                    c.ok ? c.text().then(function(d) {
                        a(d)
                    }, function() {
                        a()
                    }) : a()
                }, function() {
                    a()
                })
            } catch (c) {
                a()
            }
        }
    }

    function vo() {
        var a = po.jp;
        try {
            return JSON.parse(gb(a))
        } catch (b) {
            return L(123), oo(2), {}
        }
    }

    function wo() {
        return qo["0"] || ""
    }

    function xo() {
        return qo["1"] || ""
    }

    function yo() {
        var a = !1;
        return a
    }

    function zo() {
        return qo["6"] !== !1
    }

    function Ao() {
        var a = "";
        return a
    }

    function Bo() {
        var a = !1;
        return a
    }

    function Co() {
        var a = "";
        return a
    };
    var Do = {},
        Eo = Object.freeze((Do[K.m.Ga] = 1, Do[K.m.Bg] = 1, Do[K.m.Cg] = 1, Do[K.m.Pb] = 1, Do[K.m.wa] = 1, Do[K.m.xb] = 1, Do[K.m.yb] = 1, Do[K.m.Cb] = 1, Do[K.m.bd] = 1, Do[K.m.Rb] = 1, Do[K.m.lb] = 1, Do[K.m.Ec] = 1, Do[K.m.cf] = 1, Do[K.m.ma] = 1, Do[K.m.ik] = 1, Do[K.m.ff] = 1, Do[K.m.Lg] = 1, Do[K.m.Mg] = 1, Do[K.m.ee] = 1, Do[K.m.zk] = 1, Do[K.m.rc] = 1, Do[K.m.ie] = 1, Do[K.m.Bk] = 1, Do[K.m.Pg] = 1, Do[K.m.ei] = 1, Do[K.m.Hc] = 1, Do[K.m.Ic] = 1, Do[K.m.Ua] = 1, Do[K.m.fi] = 1, Do[K.m.Ub] = 1, Do[K.m.mb] = 1, Do[K.m.pd] = 1, Do[K.m.rd] = 1, Do[K.m.tf] = 1, Do[K.m.hi] = 1, Do[K.m.ke] = 1, Do[K.m.sc] =
            1, Do[K.m.ud] = 1, Do[K.m.Wg] = 1, Do[K.m.Wb] = 1, Do[K.m.wd] = 1, Do[K.m.Hi] = 1, Do));
    Object.freeze([K.m.Ba, K.m.Va, K.m.Db, K.m.zb, K.m.gi, K.m.Ja, K.m.ai, K.m.un]);
    var Fo = {},
        Go = Object.freeze((Fo[K.m.Vm] = 1, Fo[K.m.Wm] = 1, Fo[K.m.Xm] = 1, Fo[K.m.Ym] = 1, Fo[K.m.Zm] = 1, Fo[K.m.fn] = 1, Fo[K.m.gn] = 1, Fo[K.m.hn] = 1, Fo[K.m.kn] = 1, Fo[K.m.Yd] = 1, Fo)),
        Ho = {},
        Io = Object.freeze((Ho[K.m.Xj] = 1, Ho[K.m.Yj] = 1, Ho[K.m.Ud] = 1, Ho[K.m.Vd] = 1, Ho[K.m.Zj] = 1, Ho[K.m.Vc] = 1, Ho[K.m.Wd] = 1, Ho[K.m.jc] = 1, Ho[K.m.Dc] = 1, Ho[K.m.kc] = 1, Ho[K.m.ub] = 1, Ho[K.m.Xd] = 1, Ho[K.m.Nb] = 1, Ho[K.m.bk] = 1, Ho)),
        Jo = Object.freeze([K.m.Ga, K.m.Se, K.m.Pb, K.m.Ec, K.m.ee, K.m.nf, K.m.mb, K.m.ud]),
        Ko = Object.freeze([].concat(ya(Jo))),
        Lo = Object.freeze([K.m.yb,
            K.m.Mg, K.m.tf, K.m.hi, K.m.Jg
        ]),
        Mo = Object.freeze([].concat(ya(Lo))),
        No = {},
        Oo = (No[K.m.U] = "1", No[K.m.ia] = "2", No[K.m.V] = "3", No[K.m.Ia] = "4", No),
        Po = {},
        Qo = Object.freeze((Po.search = "s", Po.youtube = "y", Po.playstore = "p", Po.shopping = "h", Po.ads = "a", Po.maps = "m", Po));

    function Ro(a) {
        return typeof a !== "object" || a === null ? {} : a
    }

    function So(a) {
        return a === void 0 || a === null ? "" : typeof a === "object" ? a.toString() : String(a)
    }

    function To(a) {
        if (a !== void 0 && a !== null) return So(a)
    }

    function Uo(a) {
        return typeof a === "number" ? a : To(a)
    };

    function Vo(a) {
        return a && a.indexOf("pending:") === 0 ? Wo(a.substr(8)) : !1
    }

    function Wo(a) {
        if (a == null || a.length === 0) return !1;
        var b = Number(a),
            c = Db();
        return b < c + 3E5 && b > c - 9E5
    };
    var Xo = !1,
        Yo = !1,
        Zo = !1,
        $o = 0,
        ap = !1,
        bp = [];

    function cp(a) {
        if ($o === 0) ap && bp && (bp.length >= 100 && bp.shift(), bp.push(a));
        else if (dp()) {
            var b = Pi(41, 'google.tagmanager.ta.prodqueue'),
                c = Ac(b, []);
            c.length >= 50 && c.shift();
            c.push(a)
        }
    }

    function ep() {
        fp();
        Pc(A, "TAProdDebugSignal", ep)
    }

    function fp() {
        if (!Yo) {
            Yo = !0;
            gp();
            var a = bp;
            bp = void 0;
            a == null || a.forEach(function(b) {
                cp(b)
            })
        }
    }

    function gp() {
        var a = A.documentElement.getAttribute("data-tag-assistant-prod-present");
        Wo(a) ? $o = 1 : !Vo(a) || Xo || Zo ? $o = 2 : (Zo = !0, Oc(A, "TAProdDebugSignal", ep, !1), x.setTimeout(function() {
            fp();
            Xo = !0
        }, 200))
    }

    function dp() {
        if (!ap) return !1;
        switch ($o) {
            case 1:
            case 0:
                return !0;
            case 2:
                return !1;
            default:
                return !1
        }
    };
    var hp = !1;

    function ip(a, b) {
        var c = Rm(),
            d = Pm();
        if (dp()) {
            var e = jp("INIT");
            e.containerLoadSource = a != null ? a : 0;
            b && (e.parentTargetReference = b);
            e.aliases = c;
            e.destinations = d;
            cp(e)
        }
    }

    function kp(a) {
        var b, c, d, e;
        b = a.targetId;
        c = a.request;
        d = a.Ka;
        e = a.isBatched;
        var f;
        if (f = dp()) {
            var g;
            a: switch (c.endpoint) {
                case 19:
                case 47:
                case 44:
                    g = !0;
                    break a;
                default:
                    g = !1
            }
            f = !g
        }
        if (f) {
            var h = jp("GTAG_HIT", {
                eventId: d.eventId,
                priorityId: d.priorityId
            });
            h.target = b;
            h.url = c.url;
            c.postBody && (h.postBody = c.postBody);
            h.parameterEncoding = c.parameterEncoding;
            h.endpoint = c.endpoint;
            e !== void 0 && (h.isBatched = e);
            cp(h)
        }
    }

    function lp(a) {
        dp() && kp(a())
    }

    function jp(a, b) {
        b = b === void 0 ? {} : b;
        b.groupId = mp;
        var c, d = b,
            e = {
                publicId: np
            };
        d.eventId != null && (e.eventId = d.eventId);
        d.priorityId != null && (e.priorityId = d.priorityId);
        d.eventName && (e.eventName = d.eventName);
        d.groupId && (e.groupId = d.groupId);
        d.tagName && (e.tagName = d.tagName);
        c = {
            containerProduct: "GTM",
            key: e,
            version: '2',
            messageType: a
        };
        c.containerProduct = hp ? "OGT" : "GTM";
        c.key.targetRef = op;
        return c
    }
    var np = "",
        op = {
            ctid: "",
            isDestination: !1
        },
        mp;

    function pp(a) {
        var b = ng.ctid,
            c = Om();
        $o = 0;
        ap = !0;
        gp();
        mp = a;
        np = b;
        hp = pk;
        op = {
            ctid: b,
            isDestination: c
        }
    };
    var qp = [K.m.U, K.m.ia, K.m.V, K.m.Ia],
        rp, sp;

    function tp(a) {
        var b = a[K.m.hc];
        b || (b = [""]);
        for (var c = {
                eg: 0
            }; c.eg < b.length; c = {
                eg: c.eg
            }, ++c.eg) wb(a, function(d) {
            return function(e, f) {
                if (e !== K.m.hc) {
                    var g = So(f),
                        h = b[d.eg],
                        m = wo(),
                        n = xo();
                    ln = !0;
                    kn && ib("TAGGING", 20);
                    fn().declare(e, g, h, m, n)
                }
            }
        }(c))
    }

    function up(a) {
        lo();
        !sp && rp && mo("crc");
        sp = !0;
        var b = a[K.m.tg];
        b && L(41);
        var c = a[K.m.hc];
        c ? L(40) : c = [""];
        for (var d = {
                fg: 0
            }; d.fg < c.length; d = {
                fg: d.fg
            }, ++d.fg) wb(a, function(e) {
            return function(f, g) {
                if (f !== K.m.hc && f !== K.m.tg) {
                    var h = To(g),
                        m = c[e.fg],
                        n = Number(b),
                        p = wo(),
                        q = xo();
                    n = n === void 0 ? 0 : n;
                    kn = !0;
                    ln && ib("TAGGING", 20);
                    fn().default(f, h, m, p, q, n, nn)
                }
            }
        }(d))
    }

    function vp(a) {
        nn.usedContainerScopedDefaults = !0;
        var b = a[K.m.hc];
        if (b) {
            var c = Array.isArray(b) ? b : [b];
            if (!c.includes(xo()) && !c.includes(wo())) return
        }
        wb(a, function(d, e) {
            switch (d) {
                case "ad_storage":
                case "analytics_storage":
                case "ad_user_data":
                case "ad_personalization":
                    break;
                default:
                    return
            }
            nn.usedContainerScopedDefaults = !0;
            nn.containerScopedDefaults[d] = e === "granted" ? 3 : 2
        })
    }

    function wp(a, b) {
        lo();
        rp = !0;
        wb(a, function(c, d) {
            var e = So(d);
            kn = !0;
            ln && ib("TAGGING", 20);
            fn().update(c, e, nn)
        });
        tn(b.eventId, b.priorityId)
    }

    function xp(a) {
        a.hasOwnProperty("all") && (nn.selectedAllCorePlatformServices = !0, wb(Qo, function(b) {
            nn.corePlatformServices[b] = a.all === "granted";
            nn.usedCorePlatformServices = !0
        }));
        wb(a, function(b, c) {
            b !== "all" && (nn.corePlatformServices[b] = c === "granted", nn.usedCorePlatformServices = !0)
        })
    }

    function O(a) {
        Array.isArray(a) || (a = [a]);
        return a.every(function(b) {
            return on(b)
        })
    }

    function yp(a, b) {
        sn(a, b)
    }

    function zp(a, b) {
        vn(a, b)
    }

    function Ap(a, b) {
        un(a, b)
    }

    function Bp() {
        var a = [K.m.U, K.m.Ia, K.m.V];
        fn().waitForUpdate(a, 500, nn)
    }

    function Cp(a) {
        for (var b = l(a), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            fn().clearTimeout(d, void 0, nn)
        }
        tn()
    }

    function Dp() {
        if (!qk)
            for (var a = zo() ? Bk(bk.Pa) : Bk(bk.nb), b = 0; b < qp.length; b++) {
                var c = qp[b],
                    d = c,
                    e = a[c] ? "granted" : "denied";
                fn().implicit(d, e)
            }
    };
    var Ep = !1;
    F(218) && (Ep = Oi(49, Ep));
    var Fp = !1,
        Gp = [];

    function Hp() {
        if (!Fp) {
            Fp = !0;
            for (var a = Gp.length - 1; a >= 0; a--) Gp[a]();
            Gp = []
        }
    };
    var Ip = x.google_tag_manager = x.google_tag_manager || {};

    function Jp(a, b) {
        return Ip[a] = Ip[a] || b()
    }

    function Kp() {
        var a = ng.ctid,
            b = Lp;
        Ip[a] = Ip[a] || b
    }

    function Mp() {
        var a = Ip.sequence || 1;
        Ip.sequence = a + 1;
        return a
    }
    x.google_tag_data = x.google_tag_data || {};

    function Np() {
        if (Ip.pscdl !== void 0) Kn(Gn.X.Mh) === void 0 && Jn(Gn.X.Mh, Ip.pscdl);
        else {
            var a = function(c) {
                    Ip.pscdl = c;
                    Jn(Gn.X.Mh, c)
                },
                b = function() {
                    a("error")
                };
            try {
                wc.cookieDeprecationLabel ? (a("pending"), wc.cookieDeprecationLabel.getValue().then(a).catch(b)) : a("noapi")
            } catch (c) {
                b(c)
            }
        }
    };
    var Op = 0;

    function Pp(a) {
        wl && a === void 0 && Op === 0 && (Wn("mcc", "1"), Op = 1)
    };
    var Qp = {
        Ef: {
            Om: "cd",
            Pm: "ce",
            Qm: "cf",
            Rm: "cpf",
            Sm: "cu"
        }
    };
    var Rp = /^(?:AW|DC|G|GF|GT|HA|MC|UA)$/,
        Sp = /\s/;

    function Tp(a, b) {
        if (pb(a)) {
            a = Bb(a);
            var c = a.indexOf("-");
            if (!(c < 0)) {
                var d = a.substring(0, c);
                if (Rp.test(d)) {
                    var e = a.substring(c + 1),
                        f;
                    if (b) {
                        var g = function(n) {
                            var p = n.indexOf("/");
                            return p < 0 ? [n] : [n.substring(0, p), n.substring(p + 1)]
                        };
                        f = g(e);
                        if (d === "DC" && f.length === 2) {
                            var h = g(f[1]);
                            h.length === 2 && (f[1] = h[0], f.push(h[1]))
                        }
                    } else {
                        f = e.split("/");
                        for (var m = 0; m < f.length; m++)
                            if (!f[m] || Sp.test(f[m]) && (d !== "AW" || m !== 1)) return
                    }
                    return {
                        id: a,
                        prefix: d,
                        destinationId: d + "-" + f[0],
                        ids: f
                    }
                }
            }
        }
    }

    function Up(a, b) {
        for (var c = {}, d = 0; d < a.length; ++d) {
            var e = Tp(a[d], b);
            e && (c[e.id] = e)
        }
        var f = [],
            g;
        for (g in c)
            if (c.hasOwnProperty(g)) {
                var h = c[g];
                h.prefix === "AW" && h.ids[Vp[1]] && f.push(h.destinationId)
            }
        for (var m = 0; m < f.length; ++m) delete c[f[m]];
        for (var n = [], p = l(Object.keys(c)), q = p.next(); !q.done; q = p.next()) n.push(c[q.value]);
        return n
    }
    var Wp = {},
        Vp = (Wp[0] = 0, Wp[1] = 1, Wp[2] = 2, Wp[3] = 0, Wp[4] = 1, Wp[5] = 0, Wp[6] = 0, Wp[7] = 0, Wp);
    var Xp = Number(Si(34, '')) || 500,
        Yp = {},
        Zp = {},
        $p = {
            initialized: 11,
            complete: 12,
            interactive: 13
        },
        aq = {},
        bq = Object.freeze((aq[K.m.mb] = !0, aq)),
        cq = void 0;

    function dq(a, b) {
        if (b.length && wl) {
            var c;
            (c = Yp)[a] != null || (c[a] = []);
            Zp[a] != null || (Zp[a] = []);
            var d = b.filter(function(e) {
                return !Zp[a].includes(e)
            });
            Yp[a].push.apply(Yp[a], ya(d));
            Zp[a].push.apply(Zp[a], ya(d));
            !cq && d.length > 0 && (Xn("tdc", !0), cq = x.setTimeout(function() {
                $n();
                Yp = {};
                cq = void 0
            }, Xp))
        }
    }

    function eq(a, b) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
        for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
        return c
    }

    function fq(a, b, c, d) {
        c = c === void 0 ? {} : c;
        d = d === void 0 ? "" : d;
        if (a === b) return [];
        var e = function(r, t) {
                var u;
                md(t) === "object" ? u = t[r] : md(t) === "array" && (u = t[r]);
                return u === void 0 ? bq[r] : u
            },
            f = eq(a, b),
            g;
        for (g in f)
            if (f.hasOwnProperty(g)) {
                var h = (d ? d + "." : "") + g,
                    m = e(g, a),
                    n = e(g, b),
                    p = md(m) === "object" || md(m) === "array",
                    q = md(n) === "object" || md(n) === "array";
                if (p && q) fq(m, n, c, h);
                else if (p || q || m !== n) c[h] = !0
            }
        return Object.keys(c)
    }

    function gq() {
        Wn("tdc", function() {
            cq && (x.clearTimeout(cq), cq = void 0);
            var a = [],
                b;
            for (b in Yp) Yp.hasOwnProperty(b) && a.push(b + "*" + Yp[b].join("."));
            return a.length ? a.join("!") : void 0
        }, !1)
    };
    var hq = function(a, b, c, d, e, f, g, h, m, n, p) {
            this.eventId = a;
            this.priorityId = b;
            this.C = c;
            this.R = d;
            this.M = e;
            this.P = f;
            this.H = g;
            this.eventMetadata = h;
            this.onSuccess = m;
            this.onFailure = n;
            this.isGtmEvent = p
        },
        iq = function(a, b) {
            var c = [];
            switch (b) {
                case 3:
                    c.push(a.C);
                    c.push(a.R);
                    c.push(a.M);
                    c.push(a.P);
                    c.push(a.H);
                    break;
                case 2:
                    c.push(a.C);
                    break;
                case 1:
                    c.push(a.R);
                    c.push(a.M);
                    c.push(a.P);
                    c.push(a.H);
                    break;
                case 4:
                    c.push(a.C), c.push(a.R), c.push(a.M), c.push(a.P)
            }
            return c
        },
        N = function(a, b, c, d) {
            for (var e = l(iq(a, d === void 0 ? 3 :
                    d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                if (g[b] !== void 0) return g[b]
            }
            return c
        },
        jq = function(a) {
            for (var b = {}, c = iq(a, 4), d = l(c), e = d.next(); !e.done; e = d.next())
                for (var f = Object.keys(e.value), g = l(f), h = g.next(); !h.done; h = g.next()) b[h.value] = 1;
            return Object.keys(b)
        };
    hq.prototype.getMergedValues = function(a, b, c) {
        function d(n) {
            od(n) && wb(n, function(p, q) {
                f = !0;
                e[p] = q
            })
        }
        b = b === void 0 ? 3 : b;
        var e = {},
            f = !1;
        c && d(c);
        var g = iq(this, b);
        g.reverse();
        for (var h = l(g), m = h.next(); !m.done; m = h.next()) d(m.value[a]);
        return f ? e : void 0
    };
    var kq = function(a) {
            for (var b = [K.m.Xe, K.m.Te, K.m.Ue, K.m.Ve, K.m.We, K.m.Ye, K.m.Ze], c = iq(a, 3), d = l(c), e = d.next(); !e.done; e = d.next()) {
                for (var f = e.value, g = {}, h = !1, m = l(b), n = m.next(); !n.done; n = m.next()) {
                    var p = n.value;
                    f[p] !== void 0 && (g[p] = f[p], h = !0)
                }
                var q = h ? g : void 0;
                if (q) return q
            }
            return {}
        },
        lq = function(a, b) {
            this.eventId = a;
            this.priorityId = b;
            this.H = {};
            this.R = {};
            this.C = {};
            this.M = {};
            this.fa = {};
            this.P = {};
            this.eventMetadata = {};
            this.isGtmEvent = !1;
            this.onSuccess = function() {};
            this.onFailure = function() {}
        },
        mq = function(a,
            b) {
            a.H = b;
            return a
        },
        nq = function(a, b) {
            a.R = b;
            return a
        },
        oq = function(a, b) {
            a.C = b;
            return a
        },
        pq = function(a, b) {
            a.M = b;
            return a
        },
        qq = function(a, b) {
            a.fa = b;
            return a
        },
        rq = function(a, b) {
            a.P = b;
            return a
        },
        sq = function(a, b) {
            a.eventMetadata = b || {};
            return a
        },
        tq = function(a, b) {
            a.onSuccess = b;
            return a
        },
        uq = function(a, b) {
            a.onFailure = b;
            return a
        },
        vq = function(a, b) {
            a.isGtmEvent = b;
            return a
        },
        wq = function(a) {
            return new hq(a.eventId, a.priorityId, a.H, a.R, a.C, a.M, a.P, a.eventMetadata, a.onSuccess, a.onFailure, a.isGtmEvent)
        };
    var Q = {
        A: {
            Gj: "accept_by_default",
            sg: "add_tag_timing",
            Ih: "allow_ad_personalization",
            Ij: "batch_on_navigation",
            Kj: "client_id_source",
            Je: "consent_event_id",
            Ke: "consent_priority_id",
            Iq: "consent_state",
            da: "consent_updated",
            Uc: "conversion_linker_enabled",
            sa: "cookie_options",
            vg: "create_dc_join",
            wg: "create_fpm_geo_join",
            xg: "create_fpm_signals_join",
            Td: "create_google_join",
            Me: "em_event",
            Lq: "endpoint_for_debug",
            Wj: "enhanced_client_id_source",
            Oh: "enhanced_match_result",
            me: "euid_mode_enabled",
            ab: "event_start_timestamp_ms",
            Vk: "event_usage",
            Yg: "extra_tag_experiment_ids",
            Sq: "add_parameter",
            ui: "attribution_reporting_experiment",
            wi: "counting_method",
            Zg: "send_as_iframe",
            Tq: "parameter_order",
            ah: "parsed_target",
            Sn: "ga4_collection_subdomain",
            Yk: "gbraid_cookie_marked",
            aa: "hit_type",
            xd: "hit_type_override",
            Xn: "is_config_command",
            Hf: "is_consent_update",
            If: "is_conversion",
            fl: "is_ecommerce",
            yd: "is_external_event",
            Ai: "is_fallback_aw_conversion_ping_allowed",
            Jf: "is_first_visit",
            il: "is_first_visit_conversion",
            bh: "is_fl_fallback_conversion_flow_allowed",
            Kf: "is_fpm_encryption",
            eh: "is_fpm_split",
            oe: "is_gcp_conversion",
            jl: "is_google_signals_allowed",
            zd: "is_merchant_center",
            fh: "is_new_to_site",
            gh: "is_server_side_destination",
            pe: "is_session_start",
            ml: "is_session_start_conversion",
            Wq: "is_sgtm_ga_ads_conversion_study_control_group",
            Xq: "is_sgtm_prehit",
            nl: "is_sgtm_service_worker",
            Bi: "is_split_conversion",
            Yn: "is_syn",
            Lf: "join_id",
            Ci: "join_elapsed",
            Mf: "join_timer_sec",
            te: "tunnel_updated",
            er: "prehit_for_retry",
            hr: "promises",
            ir: "record_aw_latency",
            wc: "redact_ads_data",
            ue: "redact_click_ids",
            jo: "remarketing_only",
            tl: "send_ccm_parallel_ping",
            kh: "send_fledge_experiment",
            kr: "send_ccm_parallel_test_ping",
            Rf: "send_to_destinations",
            Gi: "send_to_targets",
            vl: "send_user_data_hit",
            cb: "source_canonical_id",
            ya: "speculative",
            Al: "speculative_in_message",
            Bl: "suppress_script_load",
            Cl: "syn_or_mod",
            Gl: "transient_ecsid",
            Sf: "transmission_type",
            eb: "user_data",
            nr: "user_data_from_automatic",
            qr: "user_data_from_automatic_getter",
            we: "user_data_from_code",
            oh: "user_data_from_manual",
            Il: "user_data_mode",
            Tf: "user_id_updated"
        }
    };
    var xq = {
            Hm: Number(Si(3, '5')),
            Kr: Number(Si(33, ""))
        },
        yq = [],
        zq = !1;

    function Aq(a) {
        yq.push(a)
    }
    var Bq = "?id=" + ng.ctid,
        Cq = void 0,
        Dq = {},
        Eq = void 0,
        Fq = new function() {
            var a = 5;
            xq.Hm > 0 && (a = xq.Hm);
            this.H = a;
            this.C = 0;
            this.M = []
        },
        Gq = 1E3;

    function Hq(a, b) {
        var c = Cq;
        if (c === void 0)
            if (b) c = Mp();
            else return "";
        for (var d = [pl("https://www.googletagmanager.com"), "/a", Bq], e = l(yq), f = e.next(); !f.done; f = e.next())
            for (var g = f.value, h = g({
                    eventId: c,
                    Sd: !!a
                }), m = l(h), n = m.next(); !n.done; n = m.next()) {
                var p = l(n.value),
                    q = p.next().value,
                    r = p.next().value;
                d.push("&" + q + "=" + r)
            }
        d.push("&z=0");
        return d.join("")
    }

    function Iq() {
        if (bk.fa && (Eq && (x.clearTimeout(Eq), Eq = void 0), Cq !== void 0 && Jq)) {
            var a = Fn(en.W.Lc);
            if (Bn(a)) zq || (zq = !0, Dn(a, Iq));
            else {
                var b;
                if (!(b = Dq[Cq])) {
                    var c = Fq;
                    b = c.C < c.H ? !1 : Db() - c.M[c.C % c.H] < 1E3
                }
                if (b || Gq-- <= 0) L(1), Dq[Cq] = !0;
                else {
                    var d = Fq,
                        e = d.C++ % d.H;
                    d.M[e] = Db();
                    var f = Hq(!0);
                    xm({
                        destinationId: ng.ctid,
                        endpoint: 56,
                        eventId: Cq
                    }, f);
                    zq = Jq = !1
                }
            }
        }
    }

    function Kq() {
        if (vl && bk.fa) {
            var a = Hq(!0, !0);
            xm({
                destinationId: ng.ctid,
                endpoint: 56,
                eventId: Cq
            }, a)
        }
    }
    var Jq = !1;

    function Lq(a) {
        Dq[a] || (a !== Cq && (Iq(), Cq = a), Jq = !0, Eq || (Eq = x.setTimeout(Iq, 500)), Hq().length >= 2022 && Iq())
    }
    var Mq = tb();

    function Nq() {
        Mq = tb()
    }

    function Oq() {
        return [
            ["v", "3"],
            ["t", "t"],
            ["pid", String(Mq)]
        ]
    };
    var Pq = {};

    function Rq(a, b, c) {
        vl && a !== void 0 && (Pq[a] = Pq[a] || [], Pq[a].push(c + b), Lq(a))
    }

    function Sq(a) {
        var b = a.eventId,
            c = a.Sd,
            d = [],
            e = Pq[b] || [];
        e.length && d.push(["epr", e.join(".")]);
        c && delete Pq[b];
        return d
    };

    function Tq(a, b, c, d) {
        var e = Tp(a, !0);
        e && Uq.register(e, b, c, d)
    }

    function Vq(a, b, c, d) {
        var e = Tp(c, d.isGtmEvent);
        e && (nk && (d.deferrable = !0), Uq.push("event", [b, a], e, d))
    }

    function Wq(a, b, c, d) {
        var e = Tp(c, d.isGtmEvent);
        e && Uq.push("get", [a, b], e, d)
    }

    function Xq(a) {
        var b = Tp(a, !0),
            c;
        b ? c = Yq(Uq, b).C : c = {};
        return c
    }

    function Zq(a, b) {
        var c = Tp(a, !0);
        c && $q(Uq, c, b)
    }
    var ar = function() {
            this.R = {};
            this.C = {};
            this.H = {};
            this.fa = null;
            this.P = {};
            this.M = !1;
            this.status = 1
        },
        br = function(a, b, c, d) {
            this.H = Db();
            this.C = b;
            this.args = c;
            this.messageContext = d;
            this.type = a
        },
        cr = function() {
            this.destinations = {};
            this.C = {};
            this.commands = []
        },
        Yq = function(a, b) {
            return a.destinations[b.destinationId] = a.destinations[b.destinationId] || new ar
        },
        dr = function(a, b, c, d) {
            if (d.C) {
                var e = Yq(a, d.C),
                    f = e.fa;
                if (f) {
                    var g = pd(c, null),
                        h = pd(e.R[d.C.id], null),
                        m = pd(e.P, null),
                        n = pd(e.C, null),
                        p = pd(a.C, null),
                        q = {};
                    if (vl) try {
                        q =
                            pd(Dk, null)
                    } catch (w) {
                        L(72)
                    }
                    var r = d.C.prefix,
                        t = function(w) {
                            Rq(d.messageContext.eventId, r, w)
                        },
                        u = wq(vq(uq(tq(sq(qq(pq(rq(oq(nq(mq(new lq(d.messageContext.eventId, d.messageContext.priorityId), g), h), m), n), p), q), d.messageContext.eventMetadata), function() {
                            if (t) {
                                var w = t;
                                t = void 0;
                                w("2");
                                if (d.messageContext.onSuccess) d.messageContext.onSuccess()
                            }
                        }), function() {
                            if (t) {
                                var w = t;
                                t = void 0;
                                w("3");
                                if (d.messageContext.onFailure) d.messageContext.onFailure()
                            }
                        }), !!d.messageContext.isGtmEvent)),
                        v = function() {
                            try {
                                Rq(d.messageContext.eventId,
                                    r, "1");
                                var w = d.type,
                                    y = d.C.id;
                                if (wl && w === "config") {
                                    var z, B = (z = Tp(y)) == null ? void 0 : z.ids;
                                    if (!(B && B.length > 1)) {
                                        var D, G = Ac("google_tag_data", {});
                                        G.td || (G.td = {});
                                        D = G.td;
                                        var I = pd(u.P);
                                        pd(u.C, I);
                                        var M = [],
                                            S;
                                        for (S in D) D.hasOwnProperty(S) && fq(D[S], I).length && M.push(S);
                                        M.length && (dq(y, M), ib("TAGGING", $p[A.readyState] || 14));
                                        D[y] = I
                                    }
                                }
                                f(d.C.id, b, d.H, u)
                            } catch (ea) {
                                Rq(d.messageContext.eventId, r, "4")
                            }
                        };
                    b === "gtag.get" ? v() : Dn(e.la, v)
                }
            }
        };
    cr.prototype.register = function(a, b, c, d) {
        var e = Yq(this, a);
        e.status !== 3 && (e.fa = b, e.status = 3, e.la = Fn(c), $q(this, a, d || {}), this.flush())
    };
    cr.prototype.push = function(a, b, c, d) {
        c !== void 0 && (Yq(this, c).status === 1 && (Yq(this, c).status = 2, this.push("require", [{}], c, {})), Yq(this, c).M && (d.deferrable = !1), d.eventMetadata || (d.eventMetadata = {}), d.eventMetadata[Q.A.Rf] || (d.eventMetadata[Q.A.Rf] = [c.destinationId]), d.eventMetadata[Q.A.Gi] || (d.eventMetadata[Q.A.Gi] = [c.id]));
        this.commands.push(new br(a, c, b, d));
        d.deferrable || this.flush()
    };
    cr.prototype.flush = function(a) {
        for (var b = this, c = [], d = !1, e = {}; this.commands.length; e = {
                Nc: void 0,
                th: void 0
            }) {
            var f = this.commands[0],
                g = f.C;
            if (f.messageContext.deferrable) !g || Yq(this, g).M ? (f.messageContext.deferrable = !1, this.commands.push(f)) : c.push(f), this.commands.shift();
            else {
                switch (f.type) {
                    case "require":
                        if (Yq(this, g).status !== 3 && !a) {
                            this.commands.push.apply(this.commands, c);
                            return
                        }
                        break;
                    case "set":
                        var h = f.args[0];
                        wb(h, function(t, u) {
                            pd(Kb(t, u), b.C)
                        });
                        Zj(h, !0);
                        break;
                    case "config":
                        var m = Yq(this, g);
                        e.Nc = {};
                        wb(f.args[0], function(t) {
                            return function(u, v) {
                                pd(Kb(u, v), t.Nc)
                            }
                        }(e));
                        var n = !!e.Nc[K.m.ud];
                        delete e.Nc[K.m.ud];
                        var p = g.destinationId === g.id;
                        Zj(e.Nc, !0);
                        n || (p ? m.P = {} : m.R[g.id] = {});
                        m.M && n || dr(this, K.m.ra, e.Nc, f);
                        m.M = !0;
                        p ? pd(e.Nc, m.P) : (pd(e.Nc, m.R[g.id]), L(70));
                        d = !0;
                        break;
                    case "event":
                        e.th = {};
                        wb(f.args[0], function(t) {
                            return function(u, v) {
                                pd(Kb(u, v), t.th)
                            }
                        }(e));
                        Zj(e.th);
                        dr(this, f.args[1], e.th, f);
                        break;
                    case "get":
                        var q = {},
                            r = (q[K.m.Fc] = f.args[0], q[K.m.jd] = f.args[1], q);
                        dr(this, K.m.Ob, r, f)
                }
                this.commands.shift();
                er(this, f)
            }
        }
        this.commands.push.apply(this.commands, c);
        d && this.flush()
    };
    var er = function(a, b) {
            if (b.type !== "require")
                if (b.C)
                    for (var c = Yq(a, b.C).H[b.type] || [], d = 0; d < c.length; d++) c[d]();
                else
                    for (var e in a.destinations)
                        if (a.destinations.hasOwnProperty(e)) {
                            var f = a.destinations[e];
                            if (f && f.H)
                                for (var g = f.H[b.type] || [], h = 0; h < g.length; h++) g[h]()
                        }
        },
        $q = function(a, b, c) {
            var d = pd(c, null);
            pd(Yq(a, b).C, d);
            Yq(a, b).C = d
        },
        Uq = new cr;

    function fr(a, b, c) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, !1), !0) : !1
    }

    function gr(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    };

    function hr(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = Xl(a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = tc(g, e);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                gr(e, "load", f);
                gr(e, "error", f)
            };
            fr(e, "load", f);
            fr(e, "error", f)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function ir(a) {
        var b;
        b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
        Ul(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        jr(c, b)
    }

    function jr(a, b) {
        var c = window,
            d;
        b = b === void 0 ? !1 : b;
        d = d === void 0 ? !1 : d;
        if (c.fetch) {
            var e = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            };
            d && (e.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? e.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : e.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            });
            c.fetch(a, e)
        } else hr(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };
    var kr = function() {
        this.fa = this.fa;
        this.P = this.P
    };
    kr.prototype.fa = !1;
    kr.prototype.dispose = function() {
        this.fa || (this.fa = !0, this.M())
    };
    kr.prototype[ia.Symbol.dispose] = function() {
        this.dispose()
    };
    kr.prototype.addOnDisposeCallback = function(a, b) {
        this.fa ? b !== void 0 ? a.call(b) : a() : (this.P || (this.P = []), b && (a = a.bind(b)), this.P.push(a))
    };
    kr.prototype.M = function() {
        if (this.P)
            for (; this.P.length;) this.P.shift()()
    };

    function lr(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }
    var mr = function(a, b) {
        b = b === void 0 ? {} : b;
        kr.call(this);
        this.C = null;
        this.la = {};
        this.nb = 0;
        this.R = null;
        this.H = a;
        var c;
        this.Pa = (c = b.timeoutMs) != null ? c : 500;
        var d;
        this.Da = (d = b.yr) != null ? d : !1
    };
    va(mr, kr);
    mr.prototype.M = function() {
        this.la = {};
        this.R && (gr(this.H, "message", this.R), delete this.R);
        delete this.la;
        delete this.H;
        delete this.C;
        kr.prototype.M.call(this)
    };
    var or = function(a) {
        return typeof a.H.__tcfapi === "function" || nr(a) != null
    };
    mr.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.Da
            },
            d = yl(function() {
                return a(c)
            }),
            e = 0;
        this.Pa !== -1 && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.Pa));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = lr(c), c.internalBlockOnErrors = b.Da, h && c.internalErrorState === 0 || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            pr(this, "addEventListener", f)
        } catch (g) {
            c.tcString =
                "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    mr.prototype.removeEventListener = function(a) {
        a && a.listenerId && pr(this, "removeEventListener", null, a.listenerId)
    };
    var rr = function(a, b, c) {
            var d;
            d = d === void 0 ? "755" : d;
            var e;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var f = a.publisher.restrictions[b];
                    if (f !== void 0) {
                        e = f[d === void 0 ? "755" : d];
                        break a
                    }
                }
                e = void 0
            }
            var g = e;
            if (g === 0) return !1;
            var h = c;
            c === 2 ? (h = 0, g === 2 && (h = 1)) : c === 3 && (h = 1, g === 1 && (h = 0));
            var m;
            if (h === 0)
                if (a.purpose && a.vendor) {
                    var n = qr(a.vendor.consents, d === void 0 ? "755" : d);
                    m = n && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : n && qr(a.purpose.consents, b)
                } else m = !0;
            else m = h === 1 ? a.purpose && a.vendor ? qr(a.purpose.legitimateInterests,
                b) && qr(a.vendor.legitimateInterests, d === void 0 ? "755" : d) : !0 : !0;
            return m
        },
        qr = function(a, b) {
            return !(!a || !a[b])
        },
        pr = function(a, b, c, d) {
            c || (c = function() {});
            var e = a.H;
            if (typeof e.__tcfapi === "function") {
                var f = e.__tcfapi;
                f(b, 2, c, d)
            } else if (nr(a)) {
                sr(a);
                var g = ++a.nb;
                a.la[g] = c;
                if (a.C) {
                    var h = {};
                    a.C.postMessage((h.__tcfapiCall = {
                        command: b,
                        version: 2,
                        callId: g,
                        parameter: d
                    }, h), "*")
                }
            } else c({}, !1)
        },
        nr = function(a) {
            if (a.C) return a.C;
            a.C = Vl(a.H, "__tcfapiLocator");
            return a.C
        },
        sr = function(a) {
            if (!a.R) {
                var b = function(c) {
                    try {
                        var d;
                        d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                        a.la[d.callId](d.returnValue, d.success)
                    } catch (e) {}
                };
                a.R = b;
                fr(a.H, "message", b)
            }
        },
        tr = function(a) {
            if (a.gdprApplies === !1) return !0;
            a.internalErrorState === void 0 && (a.internalErrorState = lr(a));
            return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (ir({
                e: String(a.internalErrorState)
            }), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
        };
    var ur = {
        1: 0,
        3: 0,
        4: 0,
        7: 3,
        9: 3,
        10: 3
    };
    Si(32, '');

    function vr() {
        return Jp("tcf", function() {
            return {}
        })
    }
    var wr = function() {
        return new mr(x, {
            timeoutMs: -1
        })
    };

    function xr() {
        var a = vr(),
            b = wr();
        or(b) && !yr() && !zr() && L(124);
        if (!a.active && or(b)) {
            yr() && (a.active = !0, a.purposes = {}, a.cmpId = 0, a.tcfPolicyVersion = 0, fn().active = !0, a.tcString = "tcunavailable");
            Bp();
            try {
                b.addEventListener(function(c) {
                    if (c.internalErrorState !== 0) Ar(a), Cp([K.m.U, K.m.Ia, K.m.V]), fn().active = !0;
                    else if (a.gdprApplies = c.gdprApplies, a.cmpId = c.cmpId, a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode, zr() && (a.active = !0), !Br(c) || yr() || zr()) {
                        a.tcfPolicyVersion = c.tcfPolicyVersion;
                        var d;
                        if (c.gdprApplies ===
                            !1) {
                            var e = {},
                                f;
                            for (f in ur) ur.hasOwnProperty(f) && (e[f] = !0);
                            d = e;
                            b.removeEventListener(c)
                        } else if (Br(c)) {
                            var g = {},
                                h;
                            for (h in ur)
                                if (ur.hasOwnProperty(h))
                                    if (h === "1") {
                                        var m, n = c,
                                            p = {
                                                hp: !0
                                            };
                                        p = p === void 0 ? {} : p;
                                        m = tr(n) ? n.gdprApplies === !1 ? !0 : n.tcString === "tcunavailable" ? !p.idpcApplies : (p.idpcApplies || n.gdprApplies !== void 0 || p.hp) && (p.idpcApplies || typeof n.tcString === "string" && n.tcString.length) ? rr(n, "1", 0) : !0 : !1;
                                        g["1"] = m
                                    } else g[h] = rr(c, h, ur[h]);
                            d = g
                        }
                        if (d) {
                            a.tcString = c.tcString || "tcempty";
                            a.purposes = d;
                            var q = {},
                                r = (q[K.m.U] = a.purposes["1"] ? "granted" : "denied", q);
                            a.gdprApplies !== !0 ? (Cp([K.m.U, K.m.Ia, K.m.V]), fn().active = !0) : (r[K.m.Ia] = a.purposes["3"] && a.purposes["4"] ? "granted" : "denied", typeof a.tcfPolicyVersion === "number" && a.tcfPolicyVersion >= 4 ? r[K.m.V] = a.purposes["1"] && a.purposes["7"] ? "granted" : "denied" : Cp([K.m.V]), wp(r, {
                                eventId: 0
                            }, {
                                gdprApplies: a ? a.gdprApplies : void 0,
                                tcString: Cr() || ""
                            }))
                        }
                    } else Cp([K.m.U, K.m.Ia, K.m.V])
                })
            } catch (c) {
                Ar(a), Cp([K.m.U, K.m.Ia, K.m.V]), fn().active = !0
            }
        }
    }

    function Ar(a) {
        a.type = "e";
        a.tcString = "tcunavailable"
    }

    function Br(a) {
        return a.eventStatus === "tcloaded" || a.eventStatus === "useractioncomplete" || a.eventStatus === "cmpuishown"
    }

    function yr() {
        return x.gtag_enable_tcf_support === !0
    }

    function zr() {
        return vr().enableAdvertiserConsentMode === !0
    }

    function Cr() {
        var a = vr();
        if (a.active) return a.tcString
    }

    function Dr() {
        var a = vr();
        if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0"
    }

    function Er(a) {
        if (!ur.hasOwnProperty(String(a))) return !0;
        var b = vr();
        return b.active && b.purposes ? !!b.purposes[String(a)] : !0
    };
    var Fr = [K.m.U, K.m.ia, K.m.V, K.m.Ia],
        Gr = {},
        Hr = (Gr[K.m.U] = 1, Gr[K.m.ia] = 2, Gr);

    function Ir(a) {
        if (a === void 0) return 0;
        switch (N(a, K.m.Ga)) {
            case void 0:
                return 1;
            case !1:
                return 3;
            default:
                return 2
        }
    }

    function Jr() {
        return (F(183) ? lj.op : lj.pp).indexOf(xo()) !== -1 && wc.globalPrivacyControl === !0
    }

    function Kr(a) {
        if (Jr()) return !1;
        var b = Ir(a);
        if (b === 3) return !1;
        switch (pn(K.m.Ia)) {
            case 1:
            case 3:
                return !0;
            case 2:
                return !1;
            case 4:
                return b === 2;
            case 0:
                return !0;
            default:
                return !1
        }
    }

    function Lr() {
        return rn() || !on(K.m.U) || !on(K.m.ia)
    }

    function Mr() {
        var a = {},
            b;
        for (b in Hr) Hr.hasOwnProperty(b) && (a[Hr[b]] = pn(b));
        return "G1" + gf(a[1] || 0) + gf(a[2] || 0)
    }
    var Nr = {},
        Or = (Nr[K.m.U] = 0, Nr[K.m.ia] = 1, Nr[K.m.V] = 2, Nr[K.m.Ia] = 3, Nr);

    function Pr(a) {
        switch (a) {
            case void 0:
                return 1;
            case !0:
                return 3;
            case !1:
                return 2;
            default:
                return 0
        }
    }

    function Qr(a) {
        for (var b = "1", c = 0; c < Fr.length; c++) {
            var d = b,
                e, f = Fr[c],
                g = nn.delegatedConsentTypes[f];
            e = g === void 0 ? 0 : Or.hasOwnProperty(g) ? 12 | Or[g] : 8;
            var h = fn();
            h.accessedAny = !0;
            var m = h.entries[f] || {};
            e = e << 2 | Pr(m.implicit);
            b = d + ("" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [e] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [Pr(m.declare) << 4 | Pr(m.default) << 2 | Pr(m.update)])
        }
        var n = b,
            p = (Jr() ? 1 : 0) << 3,
            q = (rn() ? 1 : 0) << 2,
            r = Ir(a);
        b = n + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [p |
            q | r
        ];
        return b += "" + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [nn.containerScopedDefaults.ad_storage << 4 | nn.containerScopedDefaults.analytics_storage << 2 | nn.containerScopedDefaults.ad_user_data] + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [(nn.usedContainerScopedDefaults ? 1 : 0) << 2 | nn.containerScopedDefaults.ad_personalization]
    }

    function Rr() {
        if (!on(K.m.V)) return "-";
        for (var a = Object.keys(Qo), b = {}, c = l(a), d = c.next(); !d.done; d = c.next()) {
            var e = d.value;
            b[e] = nn.corePlatformServices[e] !== !1
        }
        for (var f = "", g = l(a), h = g.next(); !h.done; h = g.next()) {
            var m = h.value;
            b[m] && (f += Qo[m])
        }(nn.usedCorePlatformServices ? nn.selectedAllCorePlatformServices : 1) && (f += "o");
        return f || "-"
    }

    function Sr() {
        return zo() || (yr() || zr()) && Dr() === "1" ? "1" : "0"
    }

    function Tr() {
        return (zo() ? !0 : !(!yr() && !zr()) && Dr() === "1") || !on(K.m.V)
    }

    function Ur() {
        var a = "0",
            b = "0",
            c;
        var d = vr();
        c = d.active ? d.cmpId : void 0;
        typeof c === "number" && c >= 0 && c <= 4095 && (a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c >> 6 & 63], b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [c & 63]);
        var e = "0",
            f;
        var g = vr();
        f = g.active ? g.tcfPolicyVersion : void 0;
        typeof f === "number" && f >= 0 && f <= 63 && (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [f]);
        var h = 0;
        zo() && (h |= 1);
        Dr() === "1" && (h |= 2);
        yr() && (h |= 4);
        var m;
        var n = vr();
        m = n.enableAdvertiserConsentMode !==
            void 0 ? n.enableAdvertiserConsentMode ? "1" : "0" : void 0;
        m === "1" && (h |= 8);
        fn().waitPeriodTimedOut && (h |= 16);
        return "1" + a + b + e + "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_" [h]
    }

    function Vr() {
        return xo() === "US-CO"
    };
    var Wr;

    function Xr() {
        if (zc === null) return 0;
        var a = dd();
        if (!a) return 0;
        var b = a.getEntriesByName(zc, "resource")[0];
        if (!b) return 0;
        switch (b.deliveryType) {
            case "":
                return 1;
            case "cache":
                return 2;
            case "navigational-prefetch":
                return 3;
            default:
                return 0
        }
    }
    var Yr = {
        UA: 1,
        AW: 2,
        DC: 3,
        G: 4,
        GF: 5,
        GT: 12,
        GTM: 14,
        HA: 6,
        MC: 7
    };

    function Zr(a) {
        a = a === void 0 ? {} : a;
        var b = ng.ctid.split("-")[0].toUpperCase(),
            c, d = {
                ctid: ng.ctid,
                wj: hk,
                Aj: gk,
                Zl: Nm.se ? 2 : 1,
                wq: a.zm,
                xe: ng.canonicalContainerId,
                lq: (c = Um()) == null ? void 0 : c.canonicalContainerId
            };
        if (F(204)) {
            var e;
            d.Io = (e = Wr) != null ? e : Wr = Xr()
        }
        d.xe !== a.La && (d.La = a.La);
        var f = Sm();
        d.jm = f ? f.canonicalContainerId : void 0;
        pk ? (d.Sc = Yr[b], d.Sc || (d.Sc = 0)) : d.Sc = qk ? 13 : 10;
        bk.C ? (d.Ch = 0, d.Nl = 2) : d.Ch = bk.M ? 1 : 3;
        var g = {
            6: !1
        };
        bk.H === 2 ? g[7] = !0 : bk.H === 1 && (g[2] = !0);
        if (zc) {
            var h = al(gl(zc), "host");
            h && (g[8] = h.match(/^(www\.)?googletagmanager\.com$/) ===
                null)
        }
        d.Pl = g;
        return kf(d, a.qh)
    }

    function $r() {
        if (!F(192)) return Zr();
        if (F(193)) return kf({
            wj: hk,
            Aj: gk
        });
        var a = ng.ctid.split("-")[0].toUpperCase(),
            b = {
                ctid: ng.ctid,
                wj: hk,
                Aj: gk,
                Zl: Nm.se ? 2 : 1,
                xe: ng.canonicalContainerId
            },
            c = Sm();
        b.jm = c ? c.canonicalContainerId : void 0;
        pk ? (b.Sc = Yr[a], b.Sc || (b.Sc = 0)) : b.Sc = qk ? 13 : 10;
        bk.C ? (b.Ch = 0, b.Nl = 2) : b.Ch = bk.M ? 1 : 3;
        var d = {
            6: !1
        };
        bk.H === 2 ? d[7] = !0 : bk.H === 1 && (d[2] = !0);
        if (zc) {
            var e = al(gl(zc), "host");
            e && (d[8] = e.match(/^(www\.)?googletagmanager\.com$/) === null)
        }
        b.Pl = d;
        return kf(b)
    };

    function as(a, b, c, d) {
        var e, f = Number(a.Qc != null ? a.Qc : void 0);
        f !== 0 && (e = new Date((b || Db()) + 1E3 * (f || 7776E3)));
        return {
            path: a.path,
            domain: a.domain,
            flags: a.flags,
            encode: !!c,
            expires: e,
            Bc: d
        }
    };
    var bs = ["ad_storage", "ad_user_data"];

    function cs(a, b) {
        if (!a) return ib("TAGGING", 32), 10;
        if (b === null || b === void 0 || b === "") return ib("TAGGING", 33), 11;
        var c = ds(!1);
        if (c.error !== 0) return ib("TAGGING", 34), c.error;
        if (!c.value) return ib("TAGGING", 35), 2;
        c.value[a] = b;
        var d = es(c);
        d !== 0 && ib("TAGGING", 36);
        return d
    }

    function fs(a) {
        if (!a) return ib("TAGGING", 27), {
            error: 10
        };
        var b = ds();
        if (b.error !== 0) return ib("TAGGING", 29), b;
        if (!b.value) return ib("TAGGING", 30), {
            error: 2
        };
        if (!(a in b.value)) return ib("TAGGING", 31), {
            value: void 0,
            error: 15
        };
        var c = b.value[a];
        return c === null || c === void 0 || c === "" ? (ib("TAGGING", 28), {
            value: void 0,
            error: 11
        }) : {
            value: c,
            error: 0
        }
    }

    function ds(a) {
        a = a === void 0 ? !0 : a;
        if (!on(bs)) return ib("TAGGING", 43), {
            error: 3
        };
        try {
            if (!x.localStorage) return ib("TAGGING", 44), {
                error: 1
            }
        } catch (f) {
            return ib("TAGGING", 45), {
                error: 14
            }
        }
        var b = {
                schema: "gcl",
                version: 1
            },
            c = void 0;
        try {
            c = x.localStorage.getItem("_gcl_ls")
        } catch (f) {
            return ib("TAGGING", 46), {
                error: 13
            }
        }
        try {
            if (c) {
                var d = JSON.parse(c);
                if (d && typeof d === "object") b = d;
                else return ib("TAGGING", 47), {
                    error: 12
                }
            }
        } catch (f) {
            return ib("TAGGING", 48), {
                error: 8
            }
        }
        if (b.schema !== "gcl") return ib("TAGGING", 49), {
            error: 4
        };
        if (b.version !== 1) return ib("TAGGING", 50), {
            error: 5
        };
        try {
            var e = gs(b);
            a && e && es({
                value: b,
                error: 0
            })
        } catch (f) {
            return ib("TAGGING", 48), {
                error: 8
            }
        }
        return {
            value: b,
            error: 0
        }
    }

    function gs(a) {
        if (!a || typeof a !== "object") return !1;
        if ("expires" in a && "value" in a) {
            var b;
            typeof a.expires === "number" ? b = a.expires : b = typeof a.expires === "string" ? Number(a.expires) : NaN;
            if (isNaN(b) || !(Date.now() <= b)) return a.value = null, a.error = 9, ib("TAGGING", 54), !0
        } else {
            for (var c = !1, d = l(Object.keys(a)), e = d.next(); !e.done; e = d.next()) c = gs(a[e.value]) || c;
            return c
        }
        return !1
    }

    function es(a) {
        if (a.error) return a.error;
        if (!a.value) return ib("TAGGING", 42), 2;
        var b = a.value,
            c;
        try {
            c = JSON.stringify(b)
        } catch (d) {
            return ib("TAGGING", 52), 6
        }
        try {
            x.localStorage.setItem("_gcl_ls", c)
        } catch (d) {
            return ib("TAGGING", 53), 7
        }
        return 0
    };
    var hs = {
            mj: "value",
            pb: "conversionCount"
        },
        is = {
            Yl: 9,
            sm: 10,
            mj: "timeouts",
            pb: "timeouts"
        },
        js = [hs, is];

    function ks(a) {
        if (!ls(a)) return {};
        var b = ms(js),
            c = b[a.pb];
        if (c === void 0 || c === -1) return b;
        var d = {},
            e = ma(Object, "assign").call(Object, {}, b, (d[a.pb] = c + 1, d));
        return ns(e) ? e : b
    }

    function ms(a) {
        var b;
        a: {
            var c = fs("gcl_ctr");
            if (c.error === 0 && c.value && typeof c.value === "object") {
                var d = c.value;
                try {
                    b = "value" in d && typeof d.value === "object" ? d.value : void 0;
                    break a
                } catch (p) {}
            }
            b = void 0
        }
        for (var e = b, f = {}, g = l(a), h = g.next(); !h.done; h = g.next()) {
            var m = h.value;
            if (e && ls(m)) {
                var n = e[m.mj];
                n === void 0 || Number.isNaN(n) ? f[m.pb] = -1 : f[m.pb] = Number(n)
            } else f[m.pb] = -1
        }
        return f
    }

    function os() {
        var a = ks(hs),
            b = a[hs.pb];
        if (b === void 0 || b <= 0) return "";
        var c = a[is.pb];
        return c === void 0 || c < 0 ? b.toString() : [b.toString(), c.toString()].join("~")
    }

    function ns(a, b) {
        b = b || {};
        for (var c = Db(), d = as(b, c, !0), e = {}, f = l(js), g = f.next(); !g.done; g = f.next()) {
            var h = g.value,
                m = a[h.pb];
            m !== void 0 && m !== -1 && (e[h.mj] = m)
        }
        e.creationTimeMs = c;
        return cs("gcl_ctr", {
            value: e,
            expires: Number(d.expires)
        }) === 0 ? !0 : !1
    }

    function ls(a) {
        return on(["ad_storage", "ad_user_data"]) ? !a.sm || Ua(a.sm) : !1
    }

    function ps(a) {
        return on(["ad_storage", "ad_user_data"]) ? !a.Yl || Ua(a.Yl) : !1
    };

    function qs(a) {
        var b = 1,
            c, d, e;
        if (a)
            for (b = 0, d = a.length - 1; d >= 0; d--) e = a.charCodeAt(d), b = (b << 6 & 268435455) + e + (e << 14), c = b & 266338304, b = c !== 0 ? b ^ c >> 21 : b;
        return b
    };
    var rs = {
        N: {
            ko: 0,
            Hj: 1,
            ug: 2,
            Nj: 3,
            Kh: 4,
            Lj: 5,
            Mj: 6,
            Oj: 7,
            Lh: 8,
            Tk: 9,
            Sk: 10,
            si: 11,
            Uk: 12,
            Xg: 13,
            Xk: 14,
            Of: 15,
            io: 16,
            ve: 17,
            Ki: 18,
            Li: 19,
            Mi: 20,
            El: 21,
            Ni: 22,
            Nh: 23,
            Vj: 24
        }
    };
    rs.N[rs.N.ko] = "RESERVED_ZERO";
    rs.N[rs.N.Hj] = "ADS_CONVERSION_HIT";
    rs.N[rs.N.ug] = "CONTAINER_EXECUTE_START";
    rs.N[rs.N.Nj] = "CONTAINER_SETUP_END";
    rs.N[rs.N.Kh] = "CONTAINER_SETUP_START";
    rs.N[rs.N.Lj] = "CONTAINER_BLOCKING_END";
    rs.N[rs.N.Mj] = "CONTAINER_EXECUTE_END";
    rs.N[rs.N.Oj] = "CONTAINER_YIELD_END";
    rs.N[rs.N.Lh] = "CONTAINER_YIELD_START";
    rs.N[rs.N.Tk] = "EVENT_EXECUTE_END";
    rs.N[rs.N.Sk] = "EVENT_EVALUATION_END";
    rs.N[rs.N.si] = "EVENT_EVALUATION_START";
    rs.N[rs.N.Uk] = "EVENT_SETUP_END";
    rs.N[rs.N.Xg] = "EVENT_SETUP_START";
    rs.N[rs.N.Xk] = "GA4_CONVERSION_HIT";
    rs.N[rs.N.Of] = "PAGE_LOAD";
    rs.N[rs.N.io] = "PAGEVIEW";
    rs.N[rs.N.ve] = "SNIPPET_LOAD";
    rs.N[rs.N.Ki] = "TAG_CALLBACK_ERROR";
    rs.N[rs.N.Li] = "TAG_CALLBACK_FAILURE";
    rs.N[rs.N.Mi] = "TAG_CALLBACK_SUCCESS";
    rs.N[rs.N.El] = "TAG_EXECUTE_END";
    rs.N[rs.N.Ni] = "TAG_EXECUTE_START";
    rs.N[rs.N.Nh] = "CUSTOM_PERFORMANCE_START";
    rs.N[rs.N.Vj] = "CUSTOM_PERFORMANCE_END";
    var ss = [],
        ts = {},
        us = {};
    var vs = ["2"];

    function ws(a) {
        return a.origin !== "null"
    };

    function xs(a, b, c) {
        for (var d = {}, e = b.split(";"), f = function(r) {
                return Ua(11) ? r.trim() : r.replace(/^\s*|\s*$/g, "")
            }, g = 0; g < e.length; g++) {
            var h = e[g].split("="),
                m = f(h[0]);
            if (m && a(m)) {
                var n = f(h.slice(1).join("="));
                n && c && (n = decodeURIComponent(n));
                var p = void 0,
                    q = void 0;
                ((p = d)[q = m] || (p[q] = [])).push(n)
            }
        }
        return d
    };
    var ys;

    function zs(a, b, c, d) {
        var e;
        return (e = As(function(f) {
            return f === a
        }, b, c, d)[a]) != null ? e : []
    }

    function As(a, b, c, d) {
        return Bs(d) ? xs(a, String(b || Cs()), c) : {}
    }

    function Ds(a, b, c, d, e) {
        if (Bs(e)) {
            var f = Es(a, d, e);
            if (f.length === 1) return f[0];
            if (f.length !== 0) {
                f = Fs(f, function(g) {
                    return g.To
                }, b);
                if (f.length === 1) return f[0];
                f = Fs(f, function(g) {
                    return g.Vp
                }, c);
                return f[0]
            }
        }
    }

    function Gs(a, b, c, d) {
        var e = Cs(),
            f = window;
        ws(f) && (f.document.cookie = a);
        var g = Cs();
        return e !== g || c !== void 0 && zs(b, g, !1, d).indexOf(c) >= 0
    }

    function Hs(a, b, c, d) {
        function e(w, y, z) {
            if (z == null) return delete h[y], w;
            h[y] = z;
            return w + "; " + y + "=" + z
        }

        function f(w, y) {
            if (y == null) return w;
            h[y] = !0;
            return w + "; " + y
        }
        if (!Bs(c.Bc)) return 2;
        var g;
        b == null ? g = a + "=deleted; expires=" + (new Date(0)).toUTCString() : (c.encode && (b = encodeURIComponent(b)), b = Is(b), g = a + "=" + b);
        var h = {};
        g = e(g, "path", c.path);
        var m;
        c.expires instanceof Date ? m = c.expires.toUTCString() : c.expires != null && (m = "" + c.expires);
        g = e(g, "expires", m);
        g = e(g, "max-age", c.Qp);
        g = e(g, "samesite", c.mq);
        c.secure &&
            (g = f(g, "secure"));
        var n = c.domain;
        if (n && n.toLowerCase() === "auto") {
            for (var p = Js(), q = void 0, r = !1, t = 0; t < p.length; ++t) {
                var u = p[t] !== "none" ? p[t] : void 0,
                    v = e(g, "domain", u);
                v = f(v, c.flags);
                try {
                    d && d(a, h)
                } catch (w) {
                    q = w;
                    continue
                }
                r = !0;
                if (!Ks(u, c.path) && Gs(v, a, b, c.Bc)) return Ua(15) && (ys = u), 0
            }
            if (q && !r) throw q;
            return 1
        }
        n && n.toLowerCase() !== "none" && (g = e(g, "domain", n));
        g = f(g, c.flags);
        d && d(a, h);
        return Ks(n, c.path) ? 1 : Gs(g, a, b, c.Bc) ? 0 : 1
    }

    function Ls(a, b, c) {
        c.path == null && (c.path = "/");
        c.domain || (c.domain = "auto");
        if (ss.includes("2")) {
            var d;
            (d = dd()) == null || d.mark("2-" + rs.N.Nh + "-" + (us["2"] || 0))
        }
        var e = Hs(a, b, c);
        if (ss.includes("2")) {
            var f = "2-" + rs.N.Vj + "-" + (us["2"] || 0),
                g = {
                    start: "2-" + rs.N.Nh + "-" + (us["2"] || 0),
                    end: f
                },
                h;
            (h = dd()) == null || h.mark(f);
            var m, n, p = (n = (m = dd()) == null ? void 0 : m.measure(f, g)) == null ? void 0 : n.duration;
            p !== void 0 && (us["2"] = (us["2"] || 0) + 1, ts["2"] = p + (ts["2"] || 0))
        }
        return e
    }

    function Fs(a, b, c) {
        for (var d = [], e = [], f, g = 0; g < a.length; g++) {
            var h = a[g],
                m = b(h);
            m === c ? d.push(h) : f === void 0 || m < f ? (e = [h], f = m) : m === f && e.push(h)
        }
        return d.length > 0 ? d : e
    }

    function Es(a, b, c) {
        for (var d = [], e = zs(a, void 0, void 0, c), f = 0; f < e.length; f++) {
            var g = e[f].split("."),
                h = g.shift();
            if (!b || !h || b.indexOf(h) !== -1) {
                var m = g.shift();
                if (m) {
                    var n = m.split("-");
                    d.push({
                        Ko: e[f],
                        Lo: g.join("."),
                        To: Number(n[0]) || 1,
                        Vp: Number(n[1]) || 1
                    })
                }
            }
        }
        return d
    }

    function Is(a) {
        a && a.length > 1200 && (a = a.substring(0, 1200));
        return a
    }
    var Ms = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
        Ns = /(^|\.)doubleclick\.net$/i;

    function Ks(a, b) {
        return a !== void 0 && (Ns.test(window.document.location.hostname) || b === "/" && Ms.test(a))
    }

    function Os(a) {
        if (!a) return 1;
        var b = a;
        Ua(6) && a === "none" && (b = window.document.location.hostname);
        b = b.indexOf(".") === 0 ? b.substring(1) : b;
        return b.split(".").length
    }

    function Ps(a) {
        if (!a || a === "/") return 1;
        a[0] !== "/" && (a = "/" + a);
        a[a.length - 1] !== "/" && (a += "/");
        return a.split("/").length - 1
    }

    function Qs(a, b) {
        var c = "" + Os(a),
            d = Ps(b);
        d > 1 && (c += "-" + d);
        return c
    }
    var Cs = function() {
            return ws(window) ? window.document.cookie : ""
        },
        Bs = function(a) {
            return a && Ua(7) ? (Array.isArray(a) ? a : [a]).every(function(b) {
                return qn(b) && on(b)
            }) : !0
        },
        Js = function() {
            var a = ys,
                b = [];
            a && b.push(a);
            var c = window.document.location.hostname.split(".");
            if (c.length === 4) {
                var d = c[c.length - 1];
                if (Number(d).toString() === d) return ["none"]
            }
            for (var e = c.length - 2; e >= 0; e--) {
                var f = c.slice(e).join(".");
                f !== a && b.push(f)
            }
            var g = window.document.location.hostname;
            Ns.test(g) || Ms.test(g) || b.push("none");
            return b
        };

    function Rs(a) {
        var b = Math.round(Math.random() * 2147483647);
        return a ? String(b ^ qs(a) & 2147483647) : String(b)
    }

    function Ss(a) {
        return [Rs(a), Math.round(Db() / 1E3)].join(".")
    }

    function Ts(a, b, c, d, e) {
        var f = Os(b),
            g;
        return (g = Ds(a, f, Ps(c), d, e)) == null ? void 0 : g.Lo
    };
    var Us;

    function Vs() {
        function a(g) {
            c(g.target || g.srcElement || {})
        }

        function b(g) {
            d(g.target || g.srcElement || {})
        }
        var c = Ws,
            d = Xs,
            e = Ys();
        if (!e.init) {
            Oc(A, "mousedown", a);
            Oc(A, "keyup", a);
            Oc(A, "submit", b);
            var f = HTMLFormElement.prototype.submit;
            HTMLFormElement.prototype.submit = function() {
                d(this);
                f.call(this)
            };
            e.init = !0
        }
    }

    function Zs(a, b, c, d, e) {
        var f = {
            callback: a,
            domains: b,
            fragment: c === 2,
            placement: c,
            forms: d,
            sameHost: e
        };
        Ys().decorators.push(f)
    }

    function $s(a, b, c) {
        for (var d = Ys().decorators, e = {}, f = 0; f < d.length; ++f) {
            var g = d[f],
                h;
            if (h = !c || g.forms) a: {
                var m = g.domains,
                    n = a,
                    p = !!g.sameHost;
                if (m && (p || n !== A.location.hostname))
                    for (var q = 0; q < m.length; q++)
                        if (m[q] instanceof RegExp) {
                            if (m[q].test(n)) {
                                h = !0;
                                break a
                            }
                        } else if (n.indexOf(m[q]) >= 0 || p && m[q].indexOf(n) >= 0) {
                    h = !0;
                    break a
                }
                h = !1
            }
            if (h) {
                var r = g.placement;
                r === void 0 && (r = g.fragment ? 2 : 1);
                r === b && Gb(e, g.callback())
            }
        }
        return e
    }

    function Ys() {
        var a = Ac("google_tag_data", {}),
            b = a.gl;
        b && b.decorators || (b = {
            decorators: []
        }, a.gl = b);
        return b
    };
    var at = /(.*?)\*(.*?)\*(.*)/,
        bt = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
        ct = /^(?:www\.|m\.|amp\.)+/,
        dt = /([^?#]+)(\?[^#]*)?(#.*)?/;

    function et(a) {
        var b = dt.exec(a);
        if (b) return {
            sj: b[1],
            query: b[2],
            fragment: b[3]
        }
    }

    function ft(a) {
        return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)")
    }

    function gt(a, b) {
        var c = [wc.userAgent, (new Date).getTimezoneOffset(), wc.userLanguage || wc.language, Math.floor(Db() / 60 / 1E3) - (b === void 0 ? 0 : b), a].join("*"),
            d;
        if (!(d = Us)) {
            for (var e = Array(256), f = 0; f < 256; f++) {
                for (var g = f, h = 0; h < 8; h++) g = g & 1 ? g >>> 1 ^ 3988292384 : g >>> 1;
                e[f] = g
            }
            d = e
        }
        Us = d;
        for (var m = 4294967295, n = 0; n < c.length; n++) m = m >>> 8 ^ Us[(m ^ c.charCodeAt(n)) & 255];
        return ((m ^ -1) >>> 0).toString(36)
    }

    function ht(a) {
        return function(b) {
            var c = gl(x.location.href),
                d = c.search.replace("?", ""),
                e = Yk(d, "_gl", !1, !0) || "";
            b.query = it(e) || {};
            var f = al(c, "fragment"),
                g;
            var h = -1;
            if (Ib(f, "_gl=")) h = 4;
            else {
                var m = f.indexOf("&_gl=");
                m > 0 && (h = m + 3 + 2)
            }
            if (h < 0) g = void 0;
            else {
                var n = f.indexOf("&", h);
                g = n < 0 ? f.substring(h) : f.substring(h, n)
            }
            b.fragment = it(g || "") || {};
            a && jt(c, d, f)
        }
    }

    function kt(a, b) {
        var c = ft(a).exec(b),
            d = b;
        if (c) {
            var e = c[2],
                f = c[4];
            d = c[1];
            f && (d = d + e + f)
        }
        return d
    }

    function jt(a, b, c) {
        function d(g, h) {
            var m = kt("_gl", g);
            m.length && (m = h + m);
            return m
        }
        if (vc && vc.replaceState) {
            var e = ft("_gl");
            if (e.test(b) || e.test(c)) {
                var f = al(a, "path");
                b = d(b, "?");
                c = d(c, "#");
                vc.replaceState({}, "", "" + f + b + c)
            }
        }
    }

    function lt(a, b) {
        var c = ht(!!b),
            d = Ys();
        d.data || (d.data = {
            query: {},
            fragment: {}
        }, c(d.data));
        var e = {},
            f = d.data;
        f && (Gb(e, f.query), a && Gb(e, f.fragment));
        return e
    }
    var it = function(a) {
        try {
            var b = mt(a, 3);
            if (b !== void 0) {
                for (var c = {}, d = b ? b.split("*") : [], e = 0; e + 1 < d.length; e += 2) {
                    var f = d[e],
                        g = gb(d[e + 1]);
                    c[f] = g
                }
                ib("TAGGING", 6);
                return c
            }
        } catch (h) {
            ib("TAGGING", 8)
        }
    };

    function mt(a, b) {
        if (a) {
            var c;
            a: {
                for (var d = a, e = 0; e < 3; ++e) {
                    var f = at.exec(d);
                    if (f) {
                        c = f;
                        break a
                    }
                    d = $k(d) || ""
                }
                c = void 0
            }
            var g = c;
            if (g && g[1] === "1") {
                var h = g[3],
                    m;
                a: {
                    for (var n = g[2], p = 0; p < b; ++p)
                        if (n === gt(h, p)) {
                            m = !0;
                            break a
                        }
                    m = !1
                }
                if (m) return h;
                ib("TAGGING", 7)
            }
        }
    }

    function nt(a, b, c, d, e) {
        function f(p) {
            p = kt(a, p);
            var q = p.charAt(p.length - 1);
            p && q !== "&" && (p += "&");
            return p + n
        }
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var g = et(c);
        if (!g) return "";
        var h = g.query || "",
            m = g.fragment || "",
            n = a + "=" + b;
        d ? m.substring(1).length !== 0 && e || (m = "#" + f(m.substring(1))) : h = "?" + f(h.substring(1));
        return "" + g.sj + h + m
    }

    function ot(a, b) {
        function c(n, p, q) {
            var r;
            a: {
                for (var t in n)
                    if (n.hasOwnProperty(t)) {
                        r = !0;
                        break a
                    }
                r = !1
            }
            if (r) {
                var u, v = [],
                    w;
                for (w in n)
                    if (n.hasOwnProperty(w)) {
                        var y = n[w];
                        y !== void 0 && y === y && y !== null && y.toString() !== "[object Object]" && (v.push(w), v.push(fb(String(y))))
                    }
                var z = v.join("*");
                u = ["1", gt(z), z].join("*");
                d ? (Ua(3) || Ua(1) || !p) && pt("_gl", u, a, p, q) : qt("_gl", u, a, p, q)
            }
        }
        var d = (a.tagName || "").toUpperCase() === "FORM",
            e = $s(b, 1, d),
            f = $s(b, 2, d),
            g = $s(b, 4, d),
            h = $s(b, 3, d);
        c(e, !1, !1);
        c(f, !0, !1);
        Ua(1) && c(g, !0, !0);
        for (var m in h) h.hasOwnProperty(m) &&
            rt(m, h[m], a)
    }

    function rt(a, b, c) {
        c.tagName.toLowerCase() === "a" ? qt(a, b, c) : c.tagName.toLowerCase() === "form" && pt(a, b, c)
    }

    function qt(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        var f;
        if (f = c.href) {
            var g;
            if (!(g = !Ua(4) || d)) {
                var h = x.location.href,
                    m = et(c.href),
                    n = et(h);
                g = !(m && n && m.sj === n.sj && m.query === n.query && m.fragment)
            }
            f = g
        }
        if (f) {
            var p = nt(a, b, c.href, d, e);
            kc.test(p) && (c.href = p)
        }
    }

    function pt(a, b, c, d, e) {
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        if (c) {
            var f = c.getAttribute("action") || "";
            if (f) {
                var g = (c.method || "").toLowerCase();
                if (g !== "get" || d) {
                    if (g === "get" || g === "post") {
                        var h = nt(a, b, f, d, e);
                        kc.test(h) && (c.action = h)
                    }
                } else {
                    for (var m = c.childNodes || [], n = !1, p = 0; p < m.length; p++) {
                        var q = m[p];
                        if (q.name === a) {
                            q.setAttribute("value", b);
                            n = !0;
                            break
                        }
                    }
                    if (!n) {
                        var r = A.createElement("input");
                        r.setAttribute("type", "hidden");
                        r.setAttribute("name", a);
                        r.setAttribute("value", b);
                        c.appendChild(r)
                    }
                }
            }
        }
    }

    function Ws(a) {
        try {
            var b;
            a: {
                for (var c = a, d = 100; c && d > 0;) {
                    if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
                        b = c;
                        break a
                    }
                    c = c.parentNode;
                    d--
                }
                b = null
            }
            var e = b;
            if (e) {
                var f = e.protocol;
                f !== "http:" && f !== "https:" || ot(e, e.hostname)
            }
        } catch (g) {}
    }

    function Xs(a) {
        try {
            var b = a.getAttribute("action");
            if (b) {
                var c = al(gl(b), "host");
                ot(a, c)
            }
        } catch (d) {}
    }

    function st(a, b, c, d) {
        Vs();
        var e = c === "fragment" ? 2 : 1;
        d = !!d;
        Zs(a, b, e, d, !1);
        e === 2 && ib("TAGGING", 23);
        d && ib("TAGGING", 24)
    }

    function tt(a, b) {
        Vs();
        Zs(a, [cl(x.location, "host", !0)], b, !0, !0)
    }

    function ut() {
        var a = A.location.hostname,
            b = bt.exec(A.referrer);
        if (!b) return !1;
        var c = b[2],
            d = b[1],
            e = "";
        if (c) {
            var f = c.split("/"),
                g = f[1];
            e = g === "s" ? $k(f[2]) || "" : $k(g) || ""
        } else if (d) {
            if (d.indexOf("xn--") === 0) return !1;
            e = d.replace(/-/g, ".").replace(/\.\./g, "-")
        }
        var h = a.replace(ct, ""),
            m = e.replace(ct, ""),
            n;
        if (!(n = h === m)) {
            var p = "." + m;
            n = h.length >= p.length && h.substring(h.length - p.length, h.length) === p
        }
        return n
    }

    function vt(a, b) {
        return a === !1 ? !1 : a || b || ut()
    };
    var wt = ["1"],
        xt = {},
        zt = {};

    function At(a, b) {
        b = b === void 0 ? !0 : b;
        var c = Bt(a.prefix);
        if (xt[c]) Ct(a);
        else if (Dt(c, a.path, a.domain)) {
            var d = zt[Bt(a.prefix)] || {
                id: void 0,
                Bh: void 0
            };
            b && Et(a, d.id, d.Bh);
            Ct(a)
        } else {
            var e = il("auiddc");
            if (e) ib("TAGGING", 17), xt[c] = e;
            else if (b) {
                var f = Bt(a.prefix),
                    g = Ss();
                Ft(f, g, a);
                Dt(c, a.path, a.domain);
                Ct(a, !0)
            }
        }
    }

    function Ct(a, b) {
        if ((b === void 0 ? 0 : b) && ls(hs)) {
            var c = ds(!1);
            c.error !== 0 ? ib("TAGGING", 38) : c.value ? "gcl_ctr" in c.value ? (delete c.value.gcl_ctr, es(c) !== 0 && ib("TAGGING", 41)) : ib("TAGGING", 40) : ib("TAGGING", 39)
        }
        if (ps(hs) && ms([hs])[hs.pb] === -1) {
            for (var d = {}, e = (d[hs.pb] = 0, d), f = l(js), g = f.next(); !g.done; g = f.next()) {
                var h = g.value;
                h !== hs && ps(h) && (e[h.pb] = 0)
            }
            ns(e, a)
        }
    }

    function Et(a, b, c) {
        var d = Bt(a.prefix),
            e = xt[d];
        if (e) {
            var f = e.split(".");
            if (f.length === 2) {
                var g = Number(f[1]) || 0;
                if (g) {
                    var h = e;
                    b && (h = e + "." + b + "." + (c ? c : Math.floor(Db() / 1E3)));
                    Ft(d, h, a, g * 1E3)
                }
            }
        }
    }

    function Ft(a, b, c, d) {
        var e;
        e = ["1", Qs(c.domain, c.path), b].join(".");
        var f = as(c, d);
        f.Bc = Gt();
        Ls(a, e, f)
    }

    function Dt(a, b, c) {
        var d = Ts(a, b, c, wt, Gt());
        if (!d) return !1;
        Ht(a, d);
        return !0
    }

    function Ht(a, b) {
        var c = b.split(".");
        c.length === 5 ? (xt[a] = c.slice(0, 2).join("."), zt[a] = {
            id: c.slice(2, 4).join("."),
            Bh: Number(c[4]) || 0
        }) : c.length === 3 ? zt[a] = {
            id: c.slice(0, 2).join("."),
            Bh: Number(c[2]) || 0
        } : xt[a] = b
    }

    function Bt(a) {
        return (a || "_gcl") + "_au"
    }

    function It(a) {
        function b() {
            on(c) && a()
        }
        var c = Gt();
        un(function() {
            b();
            on(c) || vn(b, c)
        }, c)
    }

    function Jt(a) {
        var b = lt(!0),
            c = Bt(a.prefix);
        It(function() {
            var d = b[c];
            if (d) {
                Ht(c, d);
                var e = Number(xt[c].split(".")[1]) * 1E3;
                if (e) {
                    ib("TAGGING", 16);
                    var f = as(a, e);
                    f.Bc = Gt();
                    var g = ["1", Qs(a.domain, a.path), d].join(".");
                    Ls(c, g, f)
                }
            }
        })
    }

    function Kt(a, b, c, d, e) {
        e = e || {};
        var f = function() {
            var g = {},
                h = Ts(a, e.path, e.domain, wt, Gt());
            h && (g[a] = h);
            return g
        };
        It(function() {
            st(f, b, c, d)
        })
    }

    function Gt() {
        return ["ad_storage", "ad_user_data"]
    };

    function Lt(a) {
        for (var b = [], c = A.cookie.split(";"), d = new RegExp("^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"), e = 0; e < c.length; e++) {
            var f = c[e].match(d);
            f && b.push({
                Ej: f[1],
                value: f[2],
                timestamp: Number(f[2].split(".")[1]) || 0
            })
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return b
    }

    function Mt(a, b) {
        var c = Lt(a),
            d = {};
        if (!c || !c.length) return d;
        for (var e = 0; e < c.length; e++) {
            var f = c[e].value.split(".");
            if (!(f[0] !== "1" || b && f.length < 3 || !b && f.length !== 3) && Number(f[1])) {
                d[c[e].Ej] || (d[c[e].Ej] = []);
                var g = {
                    version: f[0],
                    timestamp: Number(f[1]) * 1E3,
                    gclid: f[2]
                };
                b && f.length > 3 && (g.labels = f.slice(3));
                d[c[e].Ej].push(g)
            }
        }
        return d
    };
    var Nt = {},
        Ot = (Nt.k = {
            ba: /^[\w-]+$/
        }, Nt.b = {
            ba: /^[\w-]+$/,
            xj: !0
        }, Nt.i = {
            ba: /^[1-9]\d*$/
        }, Nt.h = {
            ba: /^\d+$/
        }, Nt.t = {
            ba: /^[1-9]\d*$/
        }, Nt.d = {
            ba: /^[A-Za-z0-9_-]+$/
        }, Nt.j = {
            ba: /^\d+$/
        }, Nt.u = {
            ba: /^[1-9]\d*$/
        }, Nt.l = {
            ba: /^[01]$/
        }, Nt.o = {
            ba: /^[1-9]\d*$/
        }, Nt.g = {
            ba: /^[01]$/
        }, Nt.s = {
            ba: /^.+$/
        }, Nt);
    var Pt = {},
        Tt = (Pt[5] = {
            Hh: {
                2: Qt
            },
            lj: "2",
            rh: ["k", "i", "b", "u"]
        }, Pt[4] = {
            Hh: {
                2: Qt,
                GCL: Rt
            },
            lj: "2",
            rh: ["k", "i", "b"]
        }, Pt[2] = {
            Hh: {
                GS2: Qt,
                GS1: St
            },
            lj: "GS2",
            rh: "sogtjlhd".split("")
        }, Pt);

    function Ut(a, b, c) {
        var d = Tt[b];
        if (d) {
            var e = a.split(".")[0];
            c == null || c(e);
            if (e) {
                var f = d.Hh[e];
                if (f) return f(a, b)
            }
        }
    }

    function Qt(a, b) {
        var c = a.split(".");
        if (c.length === 3) {
            var d = c[2];
            if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1) try {
                d = decodeURIComponent(d)
            } catch (t) {}
            var e = {},
                f = Tt[b];
            if (f) {
                for (var g = f.rh, h = l(d.split("$")), m = h.next(); !m.done; m = h.next()) {
                    var n = m.value,
                        p = n[0];
                    if (g.indexOf(p) !== -1) try {
                        var q = decodeURIComponent(n.substring(1)),
                            r = Ot[p];
                        r && (r.xj ? (e[p] = e[p] || [], e[p].push(q)) : e[p] = q)
                    } catch (t) {}
                }
                return e
            }
        }
    }

    function Vt(a, b, c) {
        var d = Tt[b];
        if (d) return [d.lj, c || "1", Wt(a, b)].join(".")
    }

    function Wt(a, b) {
        var c = Tt[b];
        if (c) {
            for (var d = [], e = l(c.rh), f = e.next(); !f.done; f = e.next()) {
                var g = f.value,
                    h = Ot[g];
                if (h) {
                    var m = a[g];
                    if (m !== void 0)
                        if (h.xj && Array.isArray(m))
                            for (var n = l(m), p = n.next(); !p.done; p = n.next()) d.push(encodeURIComponent("" + g + p.value));
                        else d.push(encodeURIComponent("" + g + m))
                }
            }
            return d.join("$")
        }
    }

    function Rt(a) {
        var b = a.split(".");
        b.shift();
        var c = b.shift(),
            d = b.shift(),
            e = {};
        return e.k = d, e.i = c, e.b = b, e
    }

    function St(a) {
        var b = a.split(".").slice(2);
        if (!(b.length < 5 || b.length > 7)) {
            var c = {};
            return c.s = b[0], c.o = b[1], c.g = b[2], c.t = b[3], c.j = b[4], c.l = b[5], c.h = b[6], c
        }
    };
    var Xt = new Map([
        [5, "ad_storage"],
        [4, ["ad_storage", "ad_user_data"]],
        [2, "analytics_storage"]
    ]);

    function Yt(a, b, c) {
        if (Tt[b]) {
            for (var d = [], e = zs(a, void 0, void 0, Xt.get(b)), f = l(e), g = f.next(); !g.done; g = f.next()) {
                var h = Ut(g.value, b, c);
                h && d.push(Zt(h))
            }
            return d
        }
    }

    function $t(a) {
        var b = au;
        if (Tt[2]) {
            for (var c = {}, d = As(a, void 0, void 0, Xt.get(2)), e = Object.keys(d).sort(), f = l(e), g = f.next(); !g.done; g = f.next())
                for (var h = g.value, m = l(d[h]), n = m.next(); !n.done; n = m.next()) {
                    var p = Ut(n.value, 2, b);
                    p && (c[h] || (c[h] = []), c[h].push(Zt(p)))
                }
            return c
        }
    }

    function bu(a, b, c, d, e) {
        d = d || {};
        var f = Qs(d.domain, d.path),
            g = Vt(b, c, f);
        if (!g) return 1;
        var h = as(d, e, void 0, Xt.get(c));
        return Ls(a, g, h)
    }

    function cu(a, b) {
        var c = b.ba;
        return typeof c === "function" ? c(a) : c.test(a)
    }

    function Zt(a) {
        for (var b = l(Object.keys(a)), c = b.next(), d = {}; !c.done; d = {
                Wf: void 0
            }, c = b.next()) {
            var e = c.value,
                f = a[e];
            d.Wf = Ot[e];
            d.Wf ? d.Wf.xj ? a[e] = Array.isArray(f) ? f.filter(function(g) {
                return function(h) {
                    return cu(h, g.Wf)
                }
            }(d)) : void 0 : typeof f === "string" && cu(f, d.Wf) || (a[e] = void 0) : a[e] = void 0
        }
        return a
    };
    var du = function() {
        this.value = 0
    };
    du.prototype.set = function(a) {
        return this.value |= 1 << a
    };
    var eu = function(a, b) {
        b <= 0 || (a.value |= 1 << b - 1)
    };
    du.prototype.get = function() {
        return this.value
    };
    du.prototype.clear = function(a) {
        this.value &= ~(1 << a)
    };
    du.prototype.clearAll = function() {
        this.value = 0
    };
    du.prototype.equals = function(a) {
        return this.value === a.value
    };

    function fu(a) {
        if (a) try {
            return new Uint8Array(atob(a.replace(/-/g, "+").replace(/_/g, "/")).split("").map(function(b) {
                return b.charCodeAt(0)
            }))
        } catch (b) {}
    }

    function gu(a, b) {
        var c = 0,
            d = 0,
            e, f = b;
        do {
            if (f >= a.length) return;
            e = a[f++];
            c |= (e & 127) << d;
            d += 7
        } while (e & 128);
        return [c, f]
    };

    function hu() {
        var a = String,
            b = x.location.hostname,
            c = x.location.pathname,
            d = b = Qb(b);
        d.split(".").length > 2 && (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
        b = d;
        c = Qb(c);
        var e = c.split(";")[0];
        e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
        return a(qs(("" + b + e).toLowerCase()))
    };
    var iu = {},
        ju = (iu.gclid = !0, iu.dclid = !0, iu.gbraid = !0, iu.wbraid = !0, iu),
        ku = /^\w+$/,
        lu = /^[\w-]+$/,
        mu = {},
        nu = (mu.aw = "_aw", mu.dc = "_dc", mu.gf = "_gf", mu.gp = "_gp", mu.gs = "_gs", mu.ha = "_ha", mu.ag = "_ag", mu.gb = "_gb", mu),
        ou = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
        pu = /^www\.googleadservices\.com$/;

    function qu() {
        return ["ad_storage", "ad_user_data"]
    }

    function ru(a) {
        return !Ua(7) || on(a)
    }

    function su(a, b) {
        function c() {
            var d = ru(b);
            d && a();
            return d
        }
        un(function() {
            c() || vn(c, b)
        }, b)
    }

    function tu(a) {
        return uu(a).map(function(b) {
            return b.gclid
        })
    }

    function vu(a) {
        return wu(a).filter(function(b) {
            return b.gclid
        }).map(function(b) {
            return b.gclid
        })
    }

    function wu(a) {
        var b = xu(a.prefix),
            c = yu("gb", b),
            d = yu("ag", b);
        if (!d || !c) return [];
        var e = function(h) {
                return function(m) {
                    m.type = h;
                    return m
                }
            },
            f = uu(c).map(e("gb")),
            g = zu(d).map(e("ag"));
        return f.concat(g).sort(function(h, m) {
            return m.timestamp - h.timestamp
        })
    }

    function Au(a, b, c, d, e) {
        var f = sb(a, function(g) {
            return g.gclid === b
        });
        f ? (f.timestamp < c && (f.timestamp = c, f.Pc = e), f.labels = Bu(f.labels || [], d || [])) : a.push({
            version: "2",
            gclid: b,
            timestamp: c,
            labels: d,
            Pc: e
        })
    }

    function zu(a) {
        for (var b = Yt(a, 5) || [], c = [], d = l(b), e = d.next(); !e.done; e = d.next()) {
            var f = e.value,
                g = f,
                h = Cu(f);
            h && Au(c, g.k, h, g.b || [], f.u)
        }
        return c.sort(function(m, n) {
            return n.timestamp - m.timestamp
        })
    }

    function uu(a) {
        for (var b = [], c = zs(a, A.cookie, void 0, qu()), d = l(c), e = d.next(); !e.done; e = d.next()) {
            var f = Du(e.value);
            f != null && (f.Pc = void 0, f.za = new du, f.ib = [1], Eu(b, f))
        }
        b.sort(function(g, h) {
            return h.timestamp - g.timestamp
        });
        return Fu(b)
    }

    function Gu(a, b) {
        for (var c = [], d = l(a), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.includes(f) || c.push(f)
        }
        for (var g = l(b), h = g.next(); !h.done; h = g.next()) {
            var m = h.value;
            c.includes(m) || c.push(m)
        }
        return c
    }

    function Eu(a, b, c) {
        c = c === void 0 ? !1 : c;
        for (var d, e, f = l(a), g = f.next(); !g.done; g = f.next()) {
            var h = g.value;
            if (h.gclid === b.gclid) {
                d = h;
                break
            }
            h.za && b.za && h.za.equals(b.za) && (e = h)
        }
        if (d) {
            var m, n, p = (m = d.za) != null ? m : new du,
                q = (n = b.za) != null ? n : new du;
            p.value |= q.value;
            d.za = p;
            d.timestamp < b.timestamp && (d.timestamp = b.timestamp, d.Pc = b.Pc);
            d.labels = Gu(d.labels || [], b.labels || []);
            d.ib = Gu(d.ib || [], b.ib || [])
        } else c && e ? ma(Object, "assign").call(Object, e, b) : a.push(b)
    }

    function Hu(a) {
        if (!a) return new du;
        var b = new du;
        if (a === 1) return eu(b, 2), eu(b, 3), b;
        eu(b, a);
        return b
    }

    function Iu() {
        var a = fs("gclid");
        if (!a || a.error || !a.value || typeof a.value !== "object") return null;
        var b = a.value;
        try {
            if (!("value" in b && b.value) || typeof b.value !== "object") return null;
            var c = b.value,
                d = c.value;
            if (!d || !d.match(lu)) return null;
            var e = c.linkDecorationSource,
                f = c.linkDecorationSources,
                g = new du;
            typeof e === "number" ? g = Hu(e) : typeof f === "number" && (g.value = f);
            return {
                version: "",
                gclid: d,
                timestamp: Number(c.creationTimeMs) || 0,
                labels: [],
                za: g,
                ib: [2]
            }
        } catch (h) {
            return null
        }
    }

    function Ju() {
        var a = fs("gcl_aw");
        if (a.error !== 0) return null;
        try {
            return a.value.reduce(function(b, c) {
                if (!c.value || typeof c.value !== "object") return b;
                var d = c.value,
                    e = d.value;
                if (!e || !e.match(lu)) return b;
                var f = new du,
                    g = d.linkDecorationSources;
                typeof g === "number" && (f.value = g);
                b.push({
                    version: "",
                    gclid: e,
                    timestamp: Number(d.creationTimeMs) || 0,
                    expires: Number(c.expires) || 0,
                    labels: [],
                    za: f,
                    ib: [2]
                });
                return b
            }, [])
        } catch (b) {
            return null
        }
    }

    function Ku(a) {
        for (var b = [], c = zs(a, A.cookie, void 0, qu()), d = l(c), e = d.next(); !e.done; e = d.next()) {
            var f = Du(e.value);
            f != null && (f.Pc = void 0, f.za = new du, f.ib = [1], Eu(b, f))
        }
        var g = Iu();
        g && (g.Pc = void 0, g.ib = g.ib || [2], Eu(b, g));
        if (Ua(13)) {
            var h = Ju();
            if (h)
                for (var m = l(h), n = m.next(); !n.done; n = m.next()) {
                    var p = n.value;
                    p.Pc = void 0;
                    p.ib = p.ib || [2];
                    Eu(b, p)
                }
        }
        b.sort(function(q, r) {
            return r.timestamp - q.timestamp
        });
        return Fu(b)
    }

    function Bu(a, b) {
        if (!a.length) return b;
        if (!b.length) return a;
        var c = {};
        return a.concat(b).filter(function(d) {
            return c.hasOwnProperty(d) ? !1 : c[d] = !0
        })
    }

    function xu(a) {
        return a && typeof a === "string" && a.match(ku) ? a : "_gcl"
    }

    function Lu(a, b) {
        if (a) {
            var c = {
                value: a,
                za: new du
            };
            eu(c.za, b);
            return c
        }
    }

    function Mu(a, b, c) {
        var d = gl(a),
            e = al(d, "query", !1, void 0, "gclsrc"),
            f = Lu(al(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
        if (b && (!f || !e)) {
            var g = d.hash.replace("#", "");
            f || (f = Lu(Yk(g, "gclid", !1), 3));
            e || (e = Yk(g, "gclsrc", !1))
        }
        return !f || e !== void 0 && e !== "aw" && e !== "aw.ds" ? [] : [f]
    }

    function Nu(a, b) {
        var c = gl(a),
            d = al(c, "query", !1, void 0, "gclid"),
            e = al(c, "query", !1, void 0, "gclsrc"),
            f = al(c, "query", !1, void 0, "wbraid");
        f = Ob(f);
        var g = al(c, "query", !1, void 0, "gbraid"),
            h = al(c, "query", !1, void 0, "gad_source"),
            m = al(c, "query", !1, void 0, "dclid");
        if (b && !(d && e && f && g)) {
            var n = c.hash.replace("#", "");
            d = d || Yk(n, "gclid", !1);
            e = e || Yk(n, "gclsrc", !1);
            f = f || Yk(n, "wbraid", !1);
            g = g || Yk(n, "gbraid", !1);
            h = h || Yk(n, "gad_source", !1)
        }
        return Ou(d, e, m, f, g, h)
    }

    function Pu() {
        return Nu(x.location.href, !0)
    }

    function Ou(a, b, c, d, e, f) {
        var g = {},
            h = function(m, n) {
                g[n] || (g[n] = []);
                g[n].push(m)
            };
        g.gclid = a;
        g.gclsrc = b;
        g.dclid = c;
        if (a !== void 0 && a.match(lu)) switch (b) {
            case void 0:
                h(a, "aw");
                break;
            case "aw.ds":
                h(a, "aw");
                h(a, "dc");
                break;
            case "ds":
                h(a, "dc");
                break;
            case "3p.ds":
                h(a, "dc");
                break;
            case "gf":
                h(a, "gf");
                break;
            case "ha":
                h(a, "ha")
        }
        c && h(c, "dc");
        d !== void 0 && lu.test(d) && (g.wbraid = d, h(d, "gb"));
        e !== void 0 && lu.test(e) && (g.gbraid = e, h(e, "ag"));
        f !== void 0 && lu.test(f) && (g.gad_source = f, h(f, "gs"));
        return g
    }

    function Qu(a) {
        for (var b = Pu(), c = !0, d = l(Object.keys(b)), e = d.next(); !e.done; e = d.next())
            if (b[e.value] !== void 0) {
                c = !1;
                break
            }
        c && (b = Nu(x.document.referrer, !1), b.gad_source = void 0);
        Ru(b, !1, a)
    }

    function Su(a) {
        Qu(a);
        var b = Mu(x.location.href, !0, !1);
        b.length || (b = Mu(x.document.referrer, !1, !0));
        a = a || {};
        Tu(a);
        if (b.length) {
            var c = b[0],
                d = Db(),
                e = as(a, d, !0),
                f = qu(),
                g = function() {
                    ru(f) && e.expires !== void 0 && cs("gclid", {
                        value: {
                            value: c.value,
                            creationTimeMs: d,
                            linkDecorationSources: c.za.get()
                        },
                        expires: Number(e.expires)
                    })
                };
            un(function() {
                g();
                ru(f) || vn(g, f)
            }, f)
        }
    }

    function Tu(a) {
        var b;
        if (b = Ua(14)) {
            var c = Uu();
            b = ou.test(c) || pu.test(c) || Vu()
        }
        if (b) {
            var d;
            a: {
                for (var e = gl(x.location.href), f = Zk(al(e, "query")), g = l(Object.keys(f)), h = g.next(); !h.done; h = g.next()) {
                    var m = h.value;
                    if (!ju[m]) {
                        var n = f[m][0] || "",
                            p;
                        if (!n || n.length < 50 || n.length > 200) p = !1;
                        else {
                            var q = fu(n),
                                r;
                            if (q) c: {
                                var t = q;
                                if (t && t.length !== 0) {
                                    var u = 0;
                                    try {
                                        for (; u < t.length;) {
                                            var v = gu(t, u);
                                            if (v === void 0) break;
                                            var w = l(v),
                                                y = w.next().value,
                                                z = w.next().value,
                                                B = y,
                                                D = z,
                                                G = B & 7;
                                            if (B >> 3 === 16382) {
                                                if (G !== 0) break;
                                                var I = gu(t, D);
                                                if (I ===
                                                    void 0) break;
                                                r = l(I).next().value === 1;
                                                break c
                                            }
                                            var M;
                                            d: {
                                                var S = void 0,
                                                    ea = t,
                                                    P = D;
                                                switch (G) {
                                                    case 0:
                                                        M = (S = gu(ea, P)) == null ? void 0 : S[1];
                                                        break d;
                                                    case 1:
                                                        M = P + 8;
                                                        break d;
                                                    case 2:
                                                        var V = gu(ea, P);
                                                        if (V === void 0) break;
                                                        var ka = l(V),
                                                            ja = ka.next().value;
                                                        M = ka.next().value + ja;
                                                        break d;
                                                    case 5:
                                                        M = P + 4;
                                                        break d
                                                }
                                                M = void 0
                                            }
                                            if (M === void 0 || M > t.length) break;
                                            u = M
                                        }
                                    } catch (W) {}
                                }
                                r = !1
                            }
                            else r = !1;
                            p = r
                        }
                        if (p) {
                            d = n;
                            break a
                        }
                    }
                }
                d = void 0
            }
            var Y = d;
            Y && Wu(Y, 7, a)
        }
    }

    function Wu(a, b, c) {
        c = c || {};
        var d = Db(),
            e = as(c, d, !0),
            f = qu(),
            g = function() {
                if (ru(f) && e.expires !== void 0) {
                    var h = Ju() || [];
                    Eu(h, {
                        version: "",
                        gclid: a,
                        timestamp: d,
                        expires: Number(e.expires),
                        za: Hu(b)
                    }, !0);
                    cs("gcl_aw", h.map(function(m) {
                        return {
                            value: {
                                value: m.gclid,
                                creationTimeMs: m.timestamp,
                                linkDecorationSources: m.za ? m.za.get() : 0
                            },
                            expires: Number(m.expires)
                        }
                    }))
                }
            };
        un(function() {
            ru(f) ? g() : vn(g, f)
        }, f)
    }

    function Ru(a, b, c, d, e) {
        c = c || {};
        e = e || [];
        var f = xu(c.prefix),
            g = d || Db(),
            h = Math.round(g / 1E3),
            m = qu(),
            n = !1,
            p = !1,
            q = function() {
                if (ru(m)) {
                    var r = as(c, g, !0);
                    r.Bc = m;
                    for (var t = function(S, ea) {
                            var P = yu(S, f);
                            P && (Ls(P, ea, r), S !== "gb" && (n = !0))
                        }, u = function(S) {
                            var ea = ["GCL", h, S];
                            e.length > 0 && ea.push(e.join("."));
                            return ea.join(".")
                        }, v = l(["aw", "dc", "gf", "ha", "gp"]), w = v.next(); !w.done; w = v.next()) {
                        var y = w.value;
                        a[y] && t(y, u(a[y][0]))
                    }
                    if (!n && a.gb) {
                        var z = a.gb[0],
                            B = yu("gb", f);
                        !b && uu(B).some(function(S) {
                            return S.gclid === z && S.labels &&
                                S.labels.length > 0
                        }) || t("gb", u(z))
                    }
                }
                if (!p && a.gbraid && ru("ad_storage") && (p = !0, !n)) {
                    var D = a.gbraid,
                        G = yu("ag", f);
                    if (b || !zu(G).some(function(S) {
                            return S.gclid === D && S.labels && S.labels.length > 0
                        })) {
                        var I = {},
                            M = (I.k = D, I.i = "" + h, I.b = e, I);
                        bu(G, M, 5, c, g)
                    }
                }
                Xu(a, f, g, c)
            };
        un(function() {
            q();
            ru(m) || vn(q, m)
        }, m)
    }

    function Xu(a, b, c, d) {
        if (a.gad_source !== void 0 && ru("ad_storage")) {
            var e = cd();
            if (e !== "r" && e !== "h") {
                var f = a.gad_source,
                    g = yu("gs", b);
                if (g) {
                    var h = Math.floor((Db() - (bd() || 0)) / 1E3),
                        m, n = hu(),
                        p = {};
                    m = (p.k = f, p.i = "" + h, p.u = n, p);
                    bu(g, m, 5, d, c)
                }
            }
        }
    }

    function Yu(a, b) {
        var c = lt(!0);
        su(function() {
            for (var d = xu(b.prefix), e = 0; e < a.length; ++e) {
                var f = a[e];
                if (nu[f] !== void 0) {
                    var g = yu(f, d),
                        h = c[g];
                    if (h) {
                        var m = Math.min(Zu(h), Db()),
                            n;
                        b: {
                            for (var p = m, q = zs(g, A.cookie, void 0, qu()), r = 0; r < q.length; ++r)
                                if (Zu(q[r]) > p) {
                                    n = !0;
                                    break b
                                }
                            n = !1
                        }
                        if (!n) {
                            var t = as(b, m, !0);
                            t.Bc = qu();
                            Ls(g, h, t)
                        }
                    }
                }
            }
            Ru(Ou(c.gclid, c.gclsrc), !1, b)
        }, qu())
    }

    function $u(a) {
        var b = ["ag"],
            c = lt(!0),
            d = xu(a.prefix);
        su(function() {
            for (var e = 0; e < b.length; ++e) {
                var f = yu(b[e], d);
                if (f) {
                    var g = c[f];
                    if (g) {
                        var h = Ut(g, 5);
                        if (h) {
                            var m = Cu(h);
                            m || (m = Db());
                            var n;
                            a: {
                                for (var p = m, q = Yt(f, 5), r = 0; r < q.length; ++r)
                                    if (Cu(q[r]) > p) {
                                        n = !0;
                                        break a
                                    }
                                n = !1
                            }
                            if (n) break;
                            h.i = "" + Math.round(m / 1E3);
                            bu(f, h, 5, a, m)
                        }
                    }
                }
            }
        }, ["ad_storage"])
    }

    function yu(a, b) {
        var c = nu[a];
        if (c !== void 0) return b + c
    }

    function Zu(a) {
        return av(a.split(".")).length !== 0 ? (Number(a.split(".")[1]) || 0) * 1E3 : 0
    }

    function Cu(a) {
        return a ? (Number(a.i) || 0) * 1E3 : 0
    }

    function Du(a) {
        var b = av(a.split("."));
        return b.length === 0 ? null : {
            version: b[0],
            gclid: b[2],
            timestamp: (Number(b[1]) || 0) * 1E3,
            labels: b.slice(3)
        }
    }

    function av(a) {
        return a.length < 3 || a[0] !== "GCL" && a[0] !== "1" || !/^\d+$/.test(a[1]) || !lu.test(a[2]) ? [] : a
    }

    function bv(a, b, c, d, e) {
        if (Array.isArray(b) && ws(x)) {
            var f = xu(e),
                g = function() {
                    for (var h = {}, m = 0; m < a.length; ++m) {
                        var n = yu(a[m], f);
                        if (n) {
                            var p = zs(n, A.cookie, void 0, qu());
                            p.length && (h[n] = p.sort()[p.length - 1])
                        }
                    }
                    return h
                };
            su(function() {
                st(g, b, c, d)
            }, qu())
        }
    }

    function cv(a, b, c, d) {
        if (Array.isArray(a) && ws(x)) {
            var e = ["ag"],
                f = xu(d),
                g = function() {
                    for (var h = {}, m = 0; m < e.length; ++m) {
                        var n = yu(e[m], f);
                        if (!n) return {};
                        var p = Yt(n, 5);
                        if (p.length) {
                            var q = p.sort(function(r, t) {
                                return Cu(t) - Cu(r)
                            })[0];
                            h[n] = Vt(q, 5)
                        }
                    }
                    return h
                };
            su(function() {
                st(g, a, b, c)
            }, ["ad_storage"])
        }
    }

    function Fu(a) {
        return a.filter(function(b) {
            return lu.test(b.gclid)
        })
    }

    function dv(a, b) {
        if (ws(x)) {
            for (var c = xu(b.prefix), d = {}, e = 0; e < a.length; e++) nu[a[e]] && (d[a[e]] = nu[a[e]]);
            su(function() {
                wb(d, function(f, g) {
                    var h = zs(c + g, A.cookie, void 0, qu());
                    h.sort(function(t, u) {
                        return Zu(u) - Zu(t)
                    });
                    if (h.length) {
                        var m = h[0],
                            n = Zu(m),
                            p = av(m.split(".")).length !== 0 ? m.split(".").slice(3) : [],
                            q = {},
                            r;
                        r = av(m.split(".")).length !== 0 ? m.split(".")[2] : void 0;
                        q[f] = [r];
                        Ru(q, !0, b, n, p)
                    }
                })
            }, qu())
        }
    }

    function ev(a) {
        var b = ["ag"],
            c = ["gbraid"];
        su(function() {
            for (var d = xu(a.prefix), e = 0; e < b.length; ++e) {
                var f = yu(b[e], d);
                if (!f) break;
                var g = Yt(f, 5);
                if (g.length) {
                    var h = g.sort(function(q, r) {
                            return Cu(r) - Cu(q)
                        })[0],
                        m = Cu(h),
                        n = h.b,
                        p = {};
                    p[c[e]] = h.k;
                    Ru(p, !0, a, m, n)
                }
            }
        }, ["ad_storage"])
    }

    function fv(a, b) {
        for (var c = 0; c < b.length; ++c)
            if (a[b[c]]) return !0;
        return !1
    }

    function gv(a) {
        function b(h, m, n) {
            n && (h[m] = n)
        }
        if (rn()) {
            var c = Pu(),
                d;
            a.includes("gad_source") && (d = c.gad_source !== void 0 ? c.gad_source : lt(!1)._gs);
            if (fv(c, a) || d) {
                var e = {};
                b(e, "gclid", c.gclid);
                b(e, "dclid", c.dclid);
                b(e, "gclsrc", c.gclsrc);
                b(e, "wbraid", c.wbraid);
                b(e, "gbraid", c.gbraid);
                tt(function() {
                    return e
                }, 3);
                var f = {},
                    g = (f._up = "1", f);
                b(g, "_gs", d);
                tt(function() {
                    return g
                }, 1)
            }
        }
    }

    function Vu() {
        var a = gl(x.location.href);
        return al(a, "query", !1, void 0, "gad_source")
    }

    function hv(a) {
        if (!Ua(1)) return null;
        var b = lt(!0).gad_source;
        if (b != null) return x.location.hash = "", b;
        if (Ua(2)) {
            b = Vu();
            if (b != null) return b;
            var c = Pu();
            if (fv(c, a)) return "0"
        }
        return null
    }

    function iv(a) {
        var b = hv(a);
        b != null && tt(function() {
            var c = {};
            return c.gad_source = b, c
        }, 4)
    }

    function jv(a, b, c) {
        var d = [];
        if (b.length === 0) return d;
        for (var e = {}, f = 0; f < b.length; f++) {
            var g = b[f],
                h = g.type ? g.type : "gcl";
            (g.labels || []).indexOf(c) === -1 ? (a.push(0), e[h] || d.push(g)) : a.push(1);
            e[h] = !0
        }
        return d
    }

    function kv(a, b, c, d) {
        var e = [];
        c = c || {};
        if (!ru(qu())) return e;
        var f = uu(a),
            g = jv(e, f, b);
        if (g.length && !d)
            for (var h = l(g), m = h.next(); !m.done; m = h.next()) {
                var n = m.value,
                    p = n.timestamp,
                    q = [n.version, Math.round(p / 1E3), n.gclid].concat(n.labels || [], [b]).join("."),
                    r = as(c, p, !0);
                r.Bc = qu();
                Ls(a, q, r)
            }
        return e
    }

    function lv(a, b) {
        var c = [];
        b = b || {};
        var d = wu(b),
            e = jv(c, d, a);
        if (e.length)
            for (var f = l(e), g = f.next(); !g.done; g = f.next()) {
                var h = g.value,
                    m = xu(b.prefix),
                    n = yu(h.type, m);
                if (!n) break;
                var p = h,
                    q = p.version,
                    r = p.gclid,
                    t = p.labels,
                    u = p.timestamp,
                    v = Math.round(u / 1E3);
                if (h.type === "ag") {
                    var w = {},
                        y = (w.k = r, w.i = "" + v, w.b = (t || []).concat([a]), w);
                    bu(n, y, 5, b, u)
                } else if (h.type === "gb") {
                    var z = [q, v, r].concat(t || [], [a]).join("."),
                        B = as(b, u, !0);
                    B.Bc = qu();
                    Ls(n, z, B)
                }
            }
        return c
    }

    function mv(a, b) {
        var c = xu(b),
            d = yu(a, c);
        if (!d) return 0;
        var e;
        e = a === "ag" ? zu(d) : uu(d);
        for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
        return f
    }

    function nv(a) {
        for (var b = 0, c = l(Object.keys(a)), d = c.next(); !d.done; d = c.next())
            for (var e = a[d.value], f = 0; f < e.length; f++) b = Math.max(b, Number(e[f].timestamp));
        return b
    }

    function ov(a) {
        var b = Math.max(mv("aw", a), nv(ru(qu()) ? Mt() : {})),
            c = Math.max(mv("gb", a), nv(ru(qu()) ? Mt("_gac_gb", !0) : {}));
        c = Math.max(c, mv("ag", a));
        return c > b
    }

    function Uu() {
        return A.referrer ? al(gl(A.referrer), "host") : ""
    };

    function Dv() {
        return Jp("dedupe_gclid", function() {
            return Ss()
        })
    };
    var Ev = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
        Fv = /^www.googleadservices.com$/;

    function Gv(a) {
        a || (a = Hv());
        return a.Eq ? !1 : a.xp || a.zp || a.Cp || a.Ap || a.cg || a.Xi || a.fp || a.Bp || a.mp ? !0 : !1
    }

    function Hv() {
        var a = {},
            b = lt(!0);
        a.Eq = !!b._up;
        var c = Pu(),
            d = rv();
        a.xp = c.aw !== void 0;
        a.zp = c.dc !== void 0;
        a.Cp = c.wbraid !== void 0;
        a.Ap = c.gbraid !== void 0;
        a.Bp = c.gclsrc === "aw.ds";
        a.cg = d.cg;
        a.Xi = d.Xi;
        var e = A.referrer ? al(gl(A.referrer), "host") : "";
        a.mp = Ev.test(e);
        a.fp = Fv.test(e);
        return a
    };

    function Iv(a) {
        var b = window,
            c = b.webkit;
        delete b.webkit;
        a(b.webkit);
        b.webkit = c
    }

    function Jv(a) {
        var b = {
            action: "gcl_setup"
        };
        if ("CWVWebViewMessage" in a.messageHandlers) return a.messageHandlers.CWVWebViewMessage.postMessage({
            command: "awb",
            payload: b
        }), !0;
        var c = a.messageHandlers.awb;
        return c ? (c.postMessage(b), !0) : !1
    };

    function Kv() {
        return ["ad_storage", "ad_user_data"]
    }

    function Lv(a) {
        if (F(38) && !Kn(Gn.X.ol) && "webkit" in window && window.webkit.messageHandlers) {
            var b = function() {
                try {
                    Iv(function(c) {
                        c && ("CWVWebViewMessage" in c.messageHandlers || "awb" in c.messageHandlers) && (Jn(Gn.X.ol, function(d) {
                            d.gclid && Wu(d.gclid, 5, a)
                        }), Jv(c) || L(178))
                    })
                } catch (c) {
                    L(177)
                }
            };
            un(function() {
                ru(Kv()) ? b() : vn(b, Kv())
            }, Kv())
        }
    };
    var Mv = ["https://www.google.com", "https://www.youtube.com", "https://m.youtube.com"];

    function Nv(a) {
        a.data.action === "gcl_transfer" && a.data.gadSource ? Jn(Gn.X.Qf, {
            gadSource: a.data.gadSource
        }) : L(173)
    }

    function Ov(a, b) {
        if (F(a)) {
            if (Kn(Gn.X.Qf)) return L(176), Gn.X.Qf;
            if (Kn(Gn.X.rl)) return L(170), Gn.X.Qf;
            var c = Yl();
            if (!c) L(171);
            else if (c.opener) {
                var d = function(g) {
                    if (Mv.includes(g.origin)) {
                        a === 119 ? Nv(g) : a === 200 && (Nv(g), g.data.gclid && Wu(String(g.data.gclid), 6, b));
                        var h;
                        (h = g.stopImmediatePropagation) == null || h.call(g);
                        gr(c, "message", d)
                    } else L(172)
                };
                if (fr(c, "message", d)) {
                    Jn(Gn.X.rl, !0);
                    for (var e = l(Mv), f = e.next(); !f.done; f = e.next()) c.opener.postMessage({
                        action: "gcl_setup"
                    }, f.value);
                    L(174);
                    return Gn.X.Qf
                }
                L(175)
            }
        }
    };
    var Pv = function() {
        this.C = this.gppString = void 0
    };
    Pv.prototype.reset = function() {
        this.C = this.gppString = void 0
    };
    var Qv = new Pv;
    var Rv = RegExp("^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"),
        Sv = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
        Tv = /^\d+\.fls\.doubleclick\.net$/,
        Uv = /;gac=([^;?]+)/,
        Vv = /;gacgb=([^;?]+)/;

    function Wv(a, b) {
        if (Tv.test(A.location.host)) {
            var c = A.location.href.match(b);
            return c && c.length === 2 && c[1].match(Rv) ? $k(c[1]) || "" : ""
        }
        for (var d = [], e = l(Object.keys(a)), f = e.next(); !f.done; f = e.next()) {
            for (var g = f.value, h = [], m = a[g], n = 0; n < m.length; n++) h.push(m[n].gclid);
            d.push(g + ":" + h.join(","))
        }
        return d.length > 0 ? d.join(";") : ""
    }

    function Xv(a, b, c) {
        for (var d = ru(qu()) ? Mt("_gac_gb", !0) : {}, e = [], f = !1, g = l(Object.keys(d)), h = g.next(); !h.done; h = g.next()) {
            var m = h.value,
                n = kv("_gac_gb_" + m, a, b, c);
            f = f || n.length !== 0 && n.some(function(p) {
                return p === 1
            });
            e.push(m + ":" + n.join(","))
        }
        return {
            ep: f ? e.join(";") : "",
            cp: Wv(d, Vv)
        }
    }

    function Yv(a) {
        var b = A.location.href.match(new RegExp(";" + a + "=([^;?]+)"));
        return b && b.length === 2 && b[1].match(Sv) ? b[1] : void 0
    }

    function Zv(a) {
        var b = {},
            c, d, e;
        Tv.test(A.location.host) && (c = Yv("gclgs"), d = Yv("gclst"), e = Yv("gcllp"));
        if (c && d && e) b.uh = c, b.xh = d, b.wh = e;
        else {
            var f = Db(),
                g = zu((a || "_gcl") + "_gs"),
                h = g.map(function(p) {
                    return p.gclid
                }),
                m = g.map(function(p) {
                    return f - p.timestamp
                }),
                n = g.map(function(p) {
                    return p.Pc
                });
            h.length > 0 && m.length > 0 && n.length > 0 && (b.uh = h.join("."), b.xh = m.join("."), b.wh = n.join("."))
        }
        return b
    }

    function $v(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (Tv.test(A.location.host)) {
            var e = Yv(c);
            if (e) {
                if (d) {
                    var f = new du;
                    eu(f, 2);
                    eu(f, 3);
                    return e.split(".").map(function(h) {
                        return {
                            gclid: h,
                            za: f,
                            ib: [1]
                        }
                    })
                }
                return e.split(".").map(function(h) {
                    return {
                        gclid: h,
                        za: new du,
                        ib: [1]
                    }
                })
            }
        } else {
            if (b === "gclid") {
                var g = (a || "_gcl") + "_aw";
                return d ? Ku(g) : uu(g)
            }
            if (b === "wbraid") return uu((a || "_gcl") + "_gb");
            if (b === "braids") return wu({
                prefix: a
            })
        }
        return []
    }

    function aw(a) {
        return Tv.test(A.location.host) ? !(Yv("gclaw") || Yv("gac")) : ov(a)
    }

    function bw(a, b, c) {
        var d;
        d = c ? lv(a, b) : kv((b && b.prefix || "_gcl") + "_gb", a, b);
        return d.length === 0 || d.every(function(e) {
            return e === 0
        }) ? "" : d.join(".")
    };

    function cw() {
        var a = x.__uspapi;
        if (ob(a)) {
            var b = "";
            try {
                a("getUSPData", 1, function(c, d) {
                    if (d && c) {
                        var e = c.uspString;
                        e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e)
                    }
                })
            } catch (c) {}
            return b
        }
    };

    function pw(a) {
        var b = N(a.D, K.m.Ic),
            c = N(a.D, K.m.Hc);
        b && !c ? (a.eventName !== K.m.ra && a.eventName !== K.m.Yd && L(131), a.isAborted = !0) : !b && c && (L(132), a.isAborted = !0)
    }

    function qw(a) {
        var b = O(K.m.U) ? Ip.pscdl : "denied";
        b != null && U(a, K.m.Hg, b)
    }

    function rw(a) {
        var b = Wl(!0);
        U(a, K.m.Gc, b)
    }

    function sw(a) {
        Vr() && U(a, K.m.he, 1)
    }

    function gw() {
        var a = A.title;
        if (a === void 0 || a === "") return "";
        a = encodeURIComponent(a);
        for (var b = 256; b > 0 && $k(a.substring(0, b)) === void 0;) b--;
        return $k(a.substring(0, b)) || ""
    }

    function tw(a) {
        uw(a, Qp.Ef.Pm, N(a.D, K.m.yb))
    }

    function uw(a, b, c) {
        fw(a, K.m.wd) || U(a, K.m.wd, {});
        fw(a, K.m.wd)[b] = c
    }

    function vw(a) {
        T(a, Q.A.Sf, en.W.Fa)
    }

    function ww(a) {
        var b = lb("GTAG_EVENT_FEATURE_CHANNEL");
        b && (U(a, K.m.lf, b), jb())
    }

    function xw(a) {
        var b = a.D.getMergedValues(K.m.rc);
        b && a.mergeHitDataForKey(K.m.rc, b)
    }

    function yw(a, b) {
        b = b === void 0 ? !1 : b;
        var c = R(a, Q.A.Rf);
        if (c)
            if (c.indexOf(a.target.destinationId) < 0) {
                if (T(a, Q.A.Gj, !1), b || !zw(a, "custom_event_accept_rules", !1)) a.isAborted = !0
            } else T(a, Q.A.Gj, !0)
    }

    function Aw(a) {
        wl && (ho = !0, a.eventName === K.m.ra ? no(a.D, a.target.id) : (R(a, Q.A.Me) || (ko[a.target.id] = !0), Pp(R(a, Q.A.cb))))
    };

    function Kw(a, b, c, d) {
        var e = Kc(),
            f;
        if (e === 1) a: {
            var g = sk;g = g.toLowerCase();
            for (var h = "https://" + g, m = "http://" + g, n = 1, p = A.getElementsByTagName("script"), q = 0; q < p.length && q < 100; q++) {
                var r = p[q].src;
                if (r) {
                    r = r.toLowerCase();
                    if (r.indexOf(m) === 0) {
                        f = 3;
                        break a
                    }
                    n === 1 && r.indexOf(h) === 0 && (n = 2)
                }
            }
            f = n
        }
        else f = e;
        return (f === 2 || d || "http:" !== x.location.protocol ? a : b) + c
    };
    var Pw = function(a, b) {
            if (a && (pb(a) && (a = Tp(a)), a)) {
                var c = void 0,
                    d = !1,
                    e = N(b, K.m.Jn);
                if (e && Array.isArray(e)) {
                    c = [];
                    for (var f = 0; f < e.length; f++) {
                        var g = Tp(e[f]);
                        g && (c.push(g), (a.id === g.id || a.id === a.destinationId && a.destinationId === g.destinationId) && (d = !0))
                    }
                }
                if (!c || d) {
                    var h = N(b, K.m.Lk),
                        m;
                    if (h) {
                        m = Array.isArray(h) ? h : [h];
                        var n = N(b, K.m.Jk),
                            p = N(b, K.m.Kk),
                            q = N(b, K.m.Mk),
                            r = To(N(b, K.m.In)),
                            t = n || p,
                            u = 1;
                        a.prefix !== "UA" || c || (u = 5);
                        for (var v = 0; v < m.length; v++)
                            if (v < u)
                                if (c) Lw(c, m[v], r, b, {
                                    Ac: t,
                                    options: q
                                });
                                else if (a.prefix ===
                            "AW" && a.ids[Vp[1]]) F(155) ? Lw([a], m[v], r || "US", b, {
                            Ac: t,
                            options: q
                        }) : Mw(a.ids[Vp[0]], a.ids[Vp[1]], m[v], b, {
                            Ac: t,
                            options: q
                        });
                        else if (a.prefix === "UA")
                            if (F(155)) Lw([a], m[v], r || "US", b, {
                                Ac: t
                            });
                            else {
                                var w = a.destinationId,
                                    y = m[v],
                                    z = {
                                        Ac: t
                                    };
                                L(23);
                                if (y) {
                                    z = z || {};
                                    var B = Nw(Ow, z, w),
                                        D = {};
                                    z.Ac !== void 0 ? D.receiver = z.Ac : D.replace = y;
                                    D.ga_wpid = w;
                                    D.destination = y;
                                    B(2, Cb(), D)
                                }
                            }
                    }
                }
            }
        },
        Lw = function(a, b, c, d, e) {
            L(21);
            if (b && c) {
                e = e || {};
                for (var f = {
                        countryNameCode: c,
                        destinationNumber: b,
                        retrievalTime: Cb()
                    }, g = 0; g < a.length; g++) {
                    var h = a[g];
                    Qw[h.id] || (h && h.prefix === "AW" && !f.adData && h.ids.length >= 2 ? (f.adData = {
                        ak: h.ids[Vp[0]],
                        cl: h.ids[Vp[1]]
                    }, Rw(f.adData, d), Qw[h.id] = !0) : h && h.prefix === "UA" && !f.gaData && (f.gaData = {
                        gaWpid: h.destinationId
                    }, Qw[h.id] = !0))
                }(f.gaData || f.adData) && Nw(Sw, e, void 0, d)(e.Ac, f, e.options)
            }
        },
        Mw = function(a, b, c, d, e) {
            L(22);
            if (c) {
                e = e || {};
                var f = Nw(Tw, e, a, d),
                    g = {
                        ak: a,
                        cl: b
                    };
                e.Ac === void 0 && (g.autoreplace = c);
                Rw(g, d);
                f(2, e.Ac, g, c, 0, Cb(), e.options)
            }
        },
        Rw = function(a, b) {
            a.dma = Sr();
            Tr() && (a.dmaCps = Rr());
            Kr(b) ? a.npa = "0" : a.npa = "1"
        },
        Nw = function(a,
            b, c, d) {
            var e = x;
            if (e[a.functionName]) return b.rj && Qc(b.rj), e[a.functionName];
            var f = Uw();
            e[a.functionName] = f;
            if (a.additionalQueues)
                for (var g = 0; g < a.additionalQueues.length; g++) e[a.additionalQueues[g]] = e[a.additionalQueues[g]] || Uw();
            a.idKey && e[a.idKey] === void 0 && (e[a.idKey] = c);
            zm({
                destinationId: ng.ctid,
                endpoint: 0,
                eventId: d == null ? void 0 : d.eventId,
                priorityId: d == null ? void 0 : d.priorityId
            }, Kw("https://", "http://", a.scriptUrl), b.rj, b.Sp);
            return f
        },
        Uw = function() {
            function a() {
                a.q = a.q || [];
                a.q.push(arguments)
            }
            return a
        },
        Tw = {
            functionName: "_googWcmImpl",
            idKey: "_googWcmAk",
            scriptUrl: "www.gstatic.com/wcm/loader.js"
        },
        Ow = {
            functionName: "_gaPhoneImpl",
            idKey: "ga_wpid",
            scriptUrl: "www.gstatic.com/gaphone/loader.js"
        },
        Vw = {
            Lm: Si(2, "9"),
            mo: "5"
        },
        Sw = {
            functionName: "_googCallTrackingImpl",
            additionalQueues: [Ow.functionName, Tw.functionName],
            scriptUrl: "www.gstatic.com/call-tracking/call-tracking_" + (Vw.Lm || Vw.mo) + ".js"
        },
        Qw = {};

    function Ww(a) {
        return {
            getDestinationId: function() {
                return a.target.destinationId
            },
            getEventName: function() {
                return a.eventName
            },
            setEventName: function(b) {
                a.eventName = b
            },
            getHitData: function(b) {
                return fw(a, b)
            },
            setHitData: function(b, c) {
                U(a, b, c)
            },
            setHitDataIfNotDefined: function(b, c) {
                fw(a, b) === void 0 && U(a, b, c)
            },
            copyToHitData: function(b, c) {
                a.copyToHitData(b, c)
            },
            getMetadata: function(b) {
                return R(a, b)
            },
            setMetadata: function(b, c) {
                T(a, b, c)
            },
            isAborted: function() {
                return a.isAborted
            },
            abort: function() {
                a.isAborted = !0
            },
            getFromEventContext: function(b) {
                return N(a.D, b)
            },
            Ab: function() {
                return a
            },
            getHitKeys: function() {
                return Object.keys(a.C)
            },
            getMergedValues: function(b) {
                return a.D.getMergedValues(b, 3)
            },
            mergeHitDataForKey: function(b, c) {
                return od(c) ? a.mergeHitDataForKey(b, c) : !1
            }
        }
    };

    function ax(a, b) {
        return arguments.length === 1 ? bx("set", a) : bx("set", a, b)
    }

    function cx(a, b) {
        return arguments.length === 1 ? bx("config", a) : bx("config", a, b)
    }

    function dx(a, b, c) {
        c = c || {};
        c[K.m.pd] = a;
        return bx("event", b, c)
    }

    function bx() {
        return arguments
    };
    var fx = function() {
        this.messages = [];
        this.C = []
    };
    fx.prototype.enqueue = function(a, b, c) {
        var d = this.messages.length + 1;
        a["gtm.uniqueEventId"] = b;
        a["gtm.priorityId"] = d;
        var e = ma(Object, "assign").call(Object, {}, c, {
                eventId: b,
                priorityId: d,
                fromContainerExecution: !0
            }),
            f = {
                message: a,
                notBeforeEventId: b,
                priorityId: d,
                messageContext: e
            };
        this.messages.push(f);
        for (var g = 0; g < this.C.length; g++) try {
            this.C[g](f)
        } catch (h) {}
    };
    fx.prototype.listen = function(a) {
        this.C.push(a)
    };
    fx.prototype.get = function() {
        for (var a = {}, b = 0; b < this.messages.length; b++) {
            var c = this.messages[b],
                d = a[c.notBeforeEventId];
            d || (d = [], a[c.notBeforeEventId] = d);
            d.push(c)
        }
        return a
    };
    fx.prototype.prune = function(a) {
        for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
            var e = this.messages[d];
            e.notBeforeEventId === a ? b.push(e) : c.push(e)
        }
        this.messages = c;
        return b
    };

    function gx(a, b, c) {
        c.eventMetadata = c.eventMetadata || {};
        c.eventMetadata[Q.A.cb] = ng.canonicalContainerId;
        hx().enqueue(a, b, c)
    }

    function ix() {
        var a = jx;
        hx().listen(a)
    }

    function hx() {
        return Jp("mb", function() {
            return new fx
        })
    };
    var kx, lx = !1;

    function mx() {
        lx = !0;
        kx = kx || {}
    }

    function nx(a) {
        lx || mx();
        return kx[a]
    };

    function ox() {
        var a = x.screen;
        return {
            width: a ? a.width : 0,
            height: a ? a.height : 0
        }
    }

    function px(a) {
        if (A.hidden) return !0;
        var b = a.getBoundingClientRect();
        if (b.top === b.bottom || b.left === b.right || !x.getComputedStyle) return !0;
        var c = x.getComputedStyle(a, null);
        if (c.visibility === "hidden") return !0;
        for (var d = a, e = c; d;) {
            if (e.display === "none") return !0;
            var f = e.opacity,
                g = e.filter;
            if (g) {
                var h = g.indexOf("opacity(");
                h >= 0 && (g = g.substring(h + 8, g.indexOf(")", h)), g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)), f = String(Math.min(Number(g), Number(f))))
            }
            if (f !== void 0 && Number(f) <= 0) return !0;
            (d = d.parentElement) &&
            (e = x.getComputedStyle(d, null))
        }
        return !1
    }
    var jg;
    var By = Number(Si(57, '')) || 5,
        Cy = Number(Si(58, '')) || 50,
        Dy = tb();
    var Fy = function(a, b) {
            a && (Ey("sid", a.targetId, b), Ey("cc", a.clientCount, b), Ey("tl", a.totalLifeMs, b), Ey("hc", a.heartbeatCount, b), Ey("cl", a.clientLifeMs, b))
        },
        Ey = function(a, b, c) {
            b != null && c.push(a + "=" + b)
        },
        Gy = function() {
            var a = A.referrer;
            if (a) {
                var b;
                return al(gl(a), "host") === ((b = x.location) == null ? void 0 : b.host) ? 1 : 2
            }
            return 0
        },
        Hy = "https://" + Pi(21, "www.googletagmanager.com") + "/a?",
        Jy = function() {
            this.R = Iy;
            this.M = 0
        };
    Jy.prototype.H = function(a, b, c, d) {
        var e = Gy(),
            f,
            g = [];
        f = x === x.top && e !== 0 && b ? (b == null ? void 0 : b.clientCount) > 1 ? e === 2 ? 1 : 2 : e === 2 ? 0 : 3 : 4;
        a && Ey("si", a.ig, g);
        Ey("m", 0, g);
        Ey("iss", f, g);
        Ey("if", c, g);
        Fy(b, g);
        d && Ey("fm", encodeURIComponent(d.substring(0, Cy)), g);
        this.P(g);
    };
    Jy.prototype.C = function(a, b, c, d, e) {
        var f = [];
        Ey("m", 1, f);
        Ey("s", a, f);
        Ey("po", Gy(), f);
        b && (Ey("st", b.state, f), Ey("si", b.ig, f), Ey("sm", b.og, f));
        Fy(c, f);
        Ey("c", d, f);
        e && Ey("fm", encodeURIComponent(e.substring(0,
            Cy)), f);
        this.P(f);
    };
    Jy.prototype.P = function(a) {
        a = a === void 0 ? [] : a;
        !vl || this.M >= By || (Ey("pid", Dy, a), Ey("bc", ++this.M, a), a.unshift("ctid=" + ng.ctid + "&t=s"), this.R("" + Hy + a.join("&")))
    };

    function Ky(a) {
        return a.performance && a.performance.now() || Date.now()
    }
    var Ly = function(a, b) {
        var c = x,
            d;
        var e = function(f, g, h) {
            h = h === void 0 ? {
                gm: function() {},
                hm: function() {},
                fm: function() {},
                onFailure: function() {}
            } : h;
            this.qo = f;
            this.C = g;
            this.M = h;
            this.fa = this.la = this.heartbeatCount = this.oo = 0;
            this.ih = !1;
            this.H = {};
            this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
            this.state = 0;
            this.ig = Ky(this.C);
            this.og = Ky(this.C);
            this.R = 10
        };
        e.prototype.init = function() {
            this.P(1);
            this.Da()
        };
        e.prototype.getState = function() {
            return {
                state: this.state,
                ig: Math.round(Ky(this.C) - this.ig),
                og: Math.round(Ky(this.C) - this.og)
            }
        };
        e.prototype.P = function(f) {
            this.state !== f && (this.state = f, this.og = Ky(this.C))
        };
        e.prototype.Dl = function() {
            return String(this.oo++)
        };
        e.prototype.Da = function() {
            var f = this;
            this.heartbeatCount++;
            this.Pa({
                type: 0,
                clientId: this.id,
                requestId: this.Dl(),
                maxDelay: this.jh()
            }, function(g) {
                if (g.type === 0) {
                    var h;
                    if (((h = g.failure) == null ? void 0 : h.failureType) != null)
                        if (g.stats && (f.stats = g.stats), f.fa++, g.isDead || f.fa > 20) {
                            var m = g.isDead && g.failure.failureType;
                            f.R = m || 10;
                            f.P(4);
                            f.no();
                            var n, p;
                            (p = (n = f.M).fm) == null || p.call(n, {
                                failureType: m || 10,
                                data: g.failure.data
                            })
                        } else f.P(3), f.Hl();
                    else {
                        if (f.heartbeatCount > g.stats.heartbeatCount + 20) {
                            f.heartbeatCount = g.stats.heartbeatCount;
                            var q, r;
                            (r = (q = f.M).onFailure) == null || r.call(q, {
                                failureType: 13
                            })
                        }
                        f.stats = g.stats;
                        var t = f.state;
                        f.P(2);
                        if (t !== 2)
                            if (f.ih) {
                                var u, v;
                                (v = (u = f.M).hm) == null || v.call(u)
                            } else {
                                f.ih = !0;
                                var w, y;
                                (y = (w = f.M).gm) == null || y.call(w)
                            }
                        f.fa = 0;
                        f.ro();
                        f.Hl()
                    }
                }
            })
        };
        e.prototype.jh = function() {
            return this.state === 2 ?
                5E3 : 500
        };
        e.prototype.Hl = function() {
            var f = this;
            this.C.setTimeout(function() {
                f.Da()
            }, Math.max(0, this.jh() - (Ky(this.C) - this.la)))
        };
        e.prototype.wo = function(f, g, h) {
            var m = this;
            this.Pa({
                type: 1,
                clientId: this.id,
                requestId: this.Dl(),
                command: f
            }, function(n) {
                if (n.type === 1)
                    if (n.result) g(n.result);
                    else {
                        var p, q, r, t = {
                                failureType: (r = (p = n.failure) == null ? void 0 : p.failureType) != null ? r : 12,
                                data: (q = n.failure) == null ? void 0 : q.data
                            },
                            u, v;
                        (v = (u = m.M).onFailure) == null || v.call(u, t);
                        h(t)
                    }
            })
        };
        e.prototype.Pa = function(f, g) {
            var h = this;
            if (this.state === 4) f.failure = {
                failureType: this.R
            }, g(f);
            else {
                var m = this.state !== 2 && f.type !== 0,
                    n = f.requestId,
                    p, q = this.C.setTimeout(function() {
                        var t = h.H[n];
                        t && h.Nf(t, 7)
                    }, (p = f.maxDelay) != null ? p : 5E3),
                    r = {
                        request: f,
                        xm: g,
                        rm: m,
                        Pp: q
                    };
                this.H[n] = r;
                m || this.sendRequest(r)
            }
        };
        e.prototype.sendRequest = function(f) {
            this.la = Ky(this.C);
            f.rm = !1;
            this.qo(f.request)
        };
        e.prototype.ro = function() {
            for (var f = l(Object.keys(this.H)), g = f.next(); !g.done; g = f.next()) {
                var h = this.H[g.value];
                h.rm && this.sendRequest(h)
            }
        };
        e.prototype.no = function() {
            for (var f =
                    l(Object.keys(this.H)), g = f.next(); !g.done; g = f.next()) this.Nf(this.H[g.value], this.R)
        };
        e.prototype.Nf = function(f, g) {
            this.nb(f);
            var h = f.request;
            h.failure = {
                failureType: g
            };
            f.xm(h)
        };
        e.prototype.nb = function(f) {
            delete this.H[f.request.requestId];
            this.C.clearTimeout(f.Pp)
        };
        e.prototype.vp = function(f) {
            this.la = Ky(this.C);
            var g = this.H[f.requestId];
            if (g) this.nb(g), g.xm(f);
            else {
                var h, m;
                (m = (h = this.M).onFailure) == null || m.call(h, {
                    failureType: 14
                })
            }
        };
        d = new e(a, c, b);
        return d
    };
    var My;
    var Ny = function() {
            My || (My = new Jy);
            return My
        },
        Iy = function(a) {
            Dn(Fn(en.W.Lc), function() {
                Nc(a)
            })
        },
        Oy = function(a) {
            var b = a.substring(0, a.indexOf("/_/service_worker"));
            return "&1p=1" + (b ? "&path=" + encodeURIComponent(b) : "")
        },
        Py = function(a) {
            var b = a,
                c = bk.Da;
            b ? (b.charAt(b.length - 1) !== "/" && (b += "/"), a = b + c) : a = "https://www.googletagmanager.com/static/service_worker/" + c + "/";
            var d;
            try {
                d = new URL(a)
            } catch (e) {
                return null
            }
            return d.protocol !== "https:" ? null : d
        },
        Qy = function(a) {
            var b = Kn(Gn.X.wl);
            return b && b[a]
        },
        Ry = function(a,
            b, c, d, e) {
            var f = this;
            this.H = d;
            this.R = this.P = !1;
            this.fa = null;
            this.initTime = c;
            this.C = 15;
            this.M = this.No(a);
            x.setTimeout(function() {
                f.initialize()
            }, 1E3);
            Qc(function() {
                f.Gp(a, b, e)
            })
        };
    k = Ry.prototype;
    k.delegate = function(a, b, c) {
        this.getState() !== 2 ? (this.H.C(this.C, {
            state: this.getState(),
            ig: this.initTime,
            og: Math.round(Db()) - this.initTime
        }, void 0, a.commandType), c({
            failureType: this.C
        })) : this.M.wo(a, b, c)
    };
    k.getState = function() {
        return this.M.getState().state
    };
    k.Gp = function(a, b, c) {
        var d = x.location.origin,
            e = this,
            f = Lc();
        try {
            var g = f.contentDocument.createElement("iframe"),
                h = a.pathname,
                m = h[h.length - 1] === "/" ? a.toString() : a.toString() + "/",
                n = b ? Oy(h) : "",
                p;
            F(133) && (p = {
                sandbox: "allow-same-origin allow-scripts"
            });
            Lc(m + "sw_iframe.html?origin=" + encodeURIComponent(d) + n + (c ? "&e=1" : ""), void 0, p, void 0, g);
            var q = function() {
                f.contentDocument.body.appendChild(g);
                g.addEventListener("load", function() {
                    e.fa = g.contentWindow;
                    f.contentWindow.addEventListener("message", function(r) {
                        r.origin === a.origin && e.M.vp(r.data)
                    });
                    e.initialize()
                })
            };
            f.contentDocument.readyState === "complete" ? q() : f.contentWindow.addEventListener("load", function() {
                q()
            })
        } catch (r) {
            f.parentElement.removeChild(f), this.C = 11, this.H.H(void 0, void 0, this.C, r.toString())
        }
    };
    k.No = function(a) {
        var b = this,
            c = Ly(function(d) {
                var e;
                (e = b.fa) == null || e.postMessage(d, a.origin)
            }, {
                gm: function() {
                    b.P = !0;
                    b.H.H(c.getState(), c.stats)
                },
                hm: function() {},
                fm: function(d) {
                    b.P ? (b.C = (d == null ? void 0 : d.failureType) || 10, b.H.C(b.C, c.getState(), c.stats, void 0, d == null ? void 0 : d.data)) : (b.C = (d == null ? void 0 :
                        d.failureType) || 4, b.H.H(c.getState(), c.stats, b.C, d == null ? void 0 : d.data))
                },
                onFailure: function(d) {
                    b.C = d.failureType;
                    b.H.C(b.C, c.getState(), c.stats, d.command, d.data)
                }
            });
        return c
    };
    k.initialize = function() {
        this.R || this.M.init();
        this.R = !0
    };

    function Sy() {
        var a = mg(jg.C, "", function() {
            return {}
        });
        try {
            return a("internal_sw_allowed"), !0
        } catch (b) {
            return !1
        }
    }

    function Ty(a, b) {
        var c = Math.round(Db());
        b = b === void 0 ? !1 : b;
        var d = x.location.origin;
        if (!d || !Sy() || F(168)) return;
        Ak() && (a = "" + d + zk() + "/_/service_worker");
        var e = Py(a);
        if (e === null || Qy(e.origin)) return;
        if (!xc()) {
            Ny().H(void 0, void 0, 6);
            return
        }
        var f = new Ry(e, !!a, c || Math.round(Db()), Ny(), b);
        Ln(Gn.X.wl)[e.origin] = f;
    }
    var Uy = function(a, b, c, d) {
        var e;
        if ((e = Qy(a)) == null || !e.delegate) {
            var f = xc() ? 16 : 6;
            Ny().C(f, void 0, void 0, b.commandType);
            d({
                failureType: f
            });
            return
        }
        Qy(a).delegate(b, c, d);
    };

    function Vy(a, b, c, d, e) {
        var f = Py();
        if (f === null) {
            d(xc() ? 16 : 6);
            return
        }
        var g, h = (g = Qy(f.origin)) == null ? void 0 : g.initTime,
            m = Math.round(Db()),
            n = {
                commandType: 0,
                params: {
                    url: a,
                    method: 0,
                    templates: b,
                    body: "",
                    processResponse: !1,
                    sinceInit: h ? m - h : void 0
                }
            };
        e && (n.params.encryptionKeyString = e);
        Uy(f.origin, n, function(p) {
            c(p)
        }, function(p) {
            d(p.failureType)
        });
    }

    function Wy(a, b, c, d) {
        var e = Py(a);
        if (e === null) {
            d("_is_sw=f" + (xc() ? 16 : 6) + "te");
            return
        }
        var f = b ? 1 : 0,
            g = Math.round(Db()),
            h, m = (h = Qy(e.origin)) == null ? void 0 : h.initTime,
            n = m ? g - m : void 0,
            p = !1;
        F(169) && (p = !0);
        Uy(e.origin, {
            commandType: 0,
            params: {
                url: a,
                method: f,
                templates: c,
                body: b || "",
                processResponse: !0,
                suppressSuccessCallback: p,
                sinceInit: n,
                attributionReporting: !0,
                referer: x.location.href
            }
        }, function() {}, function(q) {
            var r = "_is_sw=f" + q.failureType,
                t, u = (t = Qy(e.origin)) ==
                null ? void 0 : t.getState();
            u !== void 0 && (r += "s" + u);
            d(n ? r + ("t" + n) : r + "te")
        });
    };

    function Xy(a) {
        if (F(10) || Ak() || bk.M || ol(a.D) || F(168)) return;
        Ty(void 0, F(131));
    };
    var Yy = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Zy(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function $y(a) {
        var b = a.google_tag_data,
            c;
        if (b != null && b.uach) {
            var d = b.uach,
                e = ma(Object, "assign").call(Object, {}, d);
            d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
            c = e
        } else c = null;
        return c
    }

    function az(a) {
        var b, c;
        return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) != null ? c : null
    }

    function bz(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function cz(a) {
        if (!bz(a)) return null;
        var b = Zy(a);
        if (b.uach_promise) return b.uach_promise;
        var c = a.navigator.userAgentData.getHighEntropyValues(Yy).then(function(d) {
            b.uach != null || (b.uach = d);
            return d
        });
        return b.uach_promise = c
    };

    function iz(a) {
        var b = a.location.href;
        if (a === a.top) return {
            url: b,
            Lp: !0
        };
        var c = !1,
            d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        var e = a.location.ancestorOrigins;
        if (e) {
            var f = e[e.length - 1];
            f && b.indexOf(f) === -1 && (c = !1, b = f)
        }
        return {
            url: b,
            Lp: c
        }
    };

    function Zz(a, b) {
        var c = !!Ak();
        switch (a) {
            case 45:
                return "https://www.google.com/ccm/collect";
            case 46:
                return c ? zk() + "/gs/ccm/collect" : "https://pagead2.googlesyndication.com/ccm/collect";
            case 51:
                return "https://www.google.com/travel/flights/click/conversion";
            case 9:
                return "https://googleads.g.doubleclick.net/pagead/viewthroughconversion";
            case 17:
                return c ? F(90) && Ao() ? Xz() : "" + zk() + "/ag/g/c" : Xz();
            case 16:
                return c ? F(90) && Ao() ? Yz() : "" + zk() + "/ga/g/c" : Yz();
            case 1:
                return "https://ad.doubleclick.net/activity;";
            case 2:
                return c ?
                    zk() + "/ddm/activity/" : "https://ade.googlesyndication.com/ddm/activity/";
            case 33:
                return "https://ad.doubleclick.net/activity;register_conversion=1;";
            case 11:
                return c ? zk() + "/d/pagead/form-data" : F(141) ? "https://www.google.com/pagead/form-data" : "https://google.com/pagead/form-data";
            case 3:
                return "https://" + b.xo + ".fls.doubleclick.net/activityi;";
            case 5:
                return "https://www.googleadservices.com/pagead/conversion";
            case 6:
                return c ? zk() + "/gs/pagead/conversion" : "https://pagead2.googlesyndication.com/pagead/conversion";
            case 8:
                return "https://www.google.com/pagead/1p-conversion";
            case 22:
                return c ? zk() + "/as/d/ccm/conversion" : "https://www.googleadservices.com/ccm/conversion";
            case 60:
                return c ? zk() + "/gs/ccm/conversion" : "https://pagead2.googlesyndication.com/ccm/conversion";
            case 23:
                return c ? zk() + "/g/d/ccm/conversion" : "https://www.google.com/ccm/conversion";
            case 55:
                return c ? zk() + "/gs/measurement/conversion/" : "https://pagead2.googlesyndication.com/measurement/conversion/";
            case 54:
                return F(205) ? "https://www.google.com/measurement/conversion/" :
                    c ? zk() + "/g/measurement/conversion/" : "https://www.google.com/measurement/conversion/";
            case 21:
                return c ? zk() + "/d/ccm/form-data" : F(141) ? "https://www.google.com/ccm/form-data" : "https://google.com/ccm/form-data";
            case 7:
            case 52:
            case 53:
            case 39:
            case 38:
            case 40:
            case 37:
            case 49:
            case 48:
            case 14:
            case 24:
            case 19:
            case 27:
            case 30:
            case 36:
            case 62:
            case 26:
            case 29:
            case 32:
            case 35:
            case 57:
            case 58:
            case 50:
            case 12:
            case 13:
            case 20:
            case 18:
            case 59:
            case 47:
            case 44:
            case 43:
            case 15:
            case 0:
            case 61:
            case 56:
            case 25:
            case 28:
            case 31:
            case 34:
                throw Error("Unsupported endpoint");
            default:
                nc(a, "Unknown endpoint")
        }
    };

    function $z(a) {
        a = a === void 0 ? [] : a;
        return ck(a).join("~")
    }

    function aA() {
        if (!F(118)) return "";
        var a, b;
        return (((a = Tm(Im())) == null ? void 0 : (b = a.context) == null ? void 0 : b.loadExperiments) || []).join("~")
    };

    function bA(a, b) {
        b && wb(b, function(c, d) {
            typeof d !== "object" && d !== void 0 && (a["1p." + c] = String(d))
        })
    };
    var jA = {};
    jA.N = rs.N;
    var kA = {
            Yq: "L",
            lo: "S",
            rr: "Y",
            Hq: "B",
            Rq: "E",
            Vq: "I",
            mr: "TC",
            Uq: "HTC"
        },
        lA = {
            lo: "S",
            Qq: "V",
            Kq: "E",
            lr: "tag"
        },
        mA = {},
        nA = (mA[jA.N.Li] = "6", mA[jA.N.Mi] = "5", mA[jA.N.Ki] = "7", mA);

    function oA() {
        function a(c, d) {
            var e = lb(d);
            e && b.push([c, e])
        }
        var b = [];
        a("u", "GTM");
        a("ut", "TAGGING");
        a("h", "HEALTH");
        return b
    };
    var pA = !1;

    function IA(a) {}

    function JA(a) {}

    function KA() {}

    function LA(a) {}

    function MA(a) {}

    function NA(a) {}

    function OA() {}

    function PA(a, b) {}

    function QA(a, b, c) {}

    function RA() {};
    var SA = Object.freeze({
        cache: "no-store",
        credentials: "include",
        method: "GET",
        keepalive: !0,
        redirect: "follow"
    });

    function TA(a, b, c, d, e, f, g, h) {
        var m = ma(Object, "assign").call(Object, {}, SA);
        c && (m.body = c, m.method = "POST");
        ma(Object, "assign").call(Object, m, e);
        h == null || nm(h);
        x.fetch(b, m).then(function(n) {
            h == null || om(h);
            if (!n.ok) g == null || g();
            else if (n.body) {
                var p = n.body.getReader(),
                    q = new TextDecoder;
                return new Promise(function(r) {
                    function t() {
                        p.read().then(function(u) {
                            var v;
                            v = u.done;
                            var w = q.decode(u.value, {
                                stream: !v
                            });
                            UA(d, w);
                            v ? (f == null || f(), r()) : t()
                        }).catch(function() {
                            r()
                        })
                    }
                    t()
                })
            }
        }).catch(function() {
            h == null || om(h);
            g ? g() : F(128) && (b += "&_z=retryFetch", c ? wm(a, b, c) : vm(a, b))
        })
    };
    var VA = function(a) {
            this.P = a;
            this.C = ""
        },
        WA = function(a, b) {
            a.H = b;
            return a
        },
        XA = function(a, b) {
            a.M = b;
            return a
        },
        UA = function(a, b) {
            b = a.C + b;
            for (var c = b.indexOf("\n\n"); c !== -1;) {
                var d = a,
                    e;
                a: {
                    var f = l(b.substring(0, c).split("\n")),
                        g = f.next().value,
                        h = f.next().value;
                    if (g.indexOf("event: message") === 0 && h.indexOf("data: ") === 0) try {
                        e = JSON.parse(h.substring(h.indexOf(":") + 1));
                        break a
                    } catch (m) {}
                    e = void 0
                }
                YA(d, e);
                b = b.substring(c + 2);
                c = b.indexOf("\n\n")
            }
            a.C = b
        },
        ZA = function(a, b) {
            return function() {
                if (b.fallback_url && b.fallback_url_method) {
                    var c = {};
                    YA(a, (c[b.fallback_url_method] = [b.fallback_url], c.options = {}, c))
                }
            }
        },
        YA = function(a, b) {
            b && ($A(b.send_pixel, b.options, a.P), $A(b.create_iframe, b.options, a.H), $A(b.fetch, b.options, a.M))
        };

    function aB(a) {
        var b = a.search;
        return a.protocol + "//" + a.hostname + a.pathname + (b ? b + "&richsstsse" : "?richsstsse")
    }

    function $A(a, b, c) {
        if (a && c) {
            var d = a || [];
            if (Array.isArray(d))
                for (var e = od(b) ? b : {}, f = l(d), g = f.next(); !g.done; g = f.next()) c(g.value, e)
        }
    };
    var bB = function(a, b) {
            this.Tp = a;
            this.timeoutMs = b;
            this.Sa = void 0
        },
        nm = function(a) {
            a.Sa || (a.Sa = setTimeout(function() {
                a.Tp();
                a.Sa = void 0
            }, a.timeoutMs))
        },
        om = function(a) {
            a.Sa && (clearTimeout(a.Sa), a.Sa = void 0)
        };
    var MB = new RegExp(/^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/),
        NB = {
            cl: ["ecl"],
            customPixels: ["nonGooglePixels"],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            customScripts: ["html", "customPixels", "nonGooglePixels", "nonGoogleScripts", "nonGoogleIframes"],
            nonGooglePixels: [],
            nonGoogleScripts: ["nonGooglePixels"],
            nonGoogleIframes: ["nonGooglePixels"]
        },
        OB = {
            cl: ["ecl"],
            customPixels: ["customScripts",
                "html"
            ],
            ecl: ["cl"],
            ehl: ["hl"],
            gaawc: ["googtag"],
            hl: ["ehl"],
            html: ["customScripts"],
            customScripts: ["html"],
            nonGooglePixels: ["customPixels", "customScripts", "html", "nonGoogleScripts", "nonGoogleIframes"],
            nonGoogleScripts: ["customScripts", "html"],
            nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"]
        },
        PB = "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(" ");

    function QB() {
        var a = Gk("gtm.allowlist") || Gk("gtm.whitelist");
        a && L(9);
        pk && !F(212) ? a = ["google", "gtagfl", "lcl", "zone", "cmpPartners"] : F(212) && (a = void 0);
        MB.test(x.location && x.location.hostname) && (pk ? L(116) : (L(117), RB && (a = [], window.console && window.console.log && window.console.log("GTM blocked. See go/13687728."))));
        var b = a && Hb(Ab(a), NB),
            c = Gk("gtm.blocklist") || Gk("gtm.blacklist");
        c || (c = Gk("tagTypeBlacklist")) && L(3);
        c ? L(8) : c = [];
        MB.test(x.location && x.location.hostname) && (c = Ab(c), c.push("nonGooglePixels", "nonGoogleScripts",
            "sandboxedScripts"));
        Ab(c).indexOf("google") >= 0 && L(2);
        var d = c && Hb(Ab(c), OB),
            e = {};
        return function(f) {
            var g = f && f[lf.Oa];
            if (!g || typeof g !== "string") return !0;
            g = g.replace(/^_*/, "");
            if (e[g] !== void 0) return e[g];
            var h = wk[g] || [],
                m = !0;
            if (a) {
                var n;
                if (n = m) a: {
                    if (b.indexOf(g) < 0) {
                        if (pk && h.indexOf("cmpPartners") >= 0) {
                            n = !0;
                            break a
                        }
                        if (h && h.length > 0)
                            for (var p = 0; p < h.length; p++) {
                                if (b.indexOf(h[p]) < 0) {
                                    L(11);
                                    n = !1;
                                    break a
                                }
                            } else {
                                n = !1;
                                break a
                            }
                    }
                    n = !0
                }
                m = n
            }
            var q = !1;
            if (c) {
                var r = d.indexOf(g) >= 0;
                if (r) q = r;
                else {
                    var t = ub(d, h || []);
                    t &&
                        L(10);
                    q = t
                }
            }
            var u = !m || q;
            !u && (h.indexOf("sandboxedScripts") === -1 ? 0 : pk && h.indexOf("cmpPartners") >= 0 ? !SB() : b && b.indexOf("sandboxedScripts") !== -1 ? 0 : ub(d, PB)) && (u = !0);
            return e[g] = u
        }
    }

    function SB() {
        var a = mg(jg.C, ng.ctid, function() {
            return {}
        });
        try {
            return a("inject_cmp_banner"), !0
        } catch (b) {
            return !1
        }
    }
    var RB = !1;
    RB = !0;
    F(218) && (RB = Oi(48, RB));

    function TB(a, b, c, d, e) {
        if (!Ym(a)) {
            d.loadExperiments = dk();
            Hm(a, d, e);
            var f = UB(a),
                g = function() {
                    Jm().container[a] && (Jm().container[a].state = 3);
                    VB()
                },
                h = {
                    destinationId: a,
                    endpoint: 0
                };
            if (Ak()) zm(h, zk() + "/" + f, void 0, g);
            else {
                var m = Ib(a, "GTM-"),
                    n = nl(),
                    p = c ? "/gtag/js" : "/gtm.js",
                    q = ml(b, p + f);
                if (!q) {
                    var r = fk.yg + p;
                    n && zc && m && (r = zc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0]);
                    q = Kw("https://", "http://", r + f)
                }
                zm(h, q, void 0, g)
            }
        }
    }

    function VB() {
        $m() || wb(an(), function(a, b) {
            WB(a, b.transportUrl, b.context);
            L(92)
        })
    }

    function WB(a, b, c, d) {
        if (!Zm(a))
            if (c.loadExperiments || (c.loadExperiments = dk()), $m()) {
                var e;
                (e = Jm().destination)[a] != null || (e[a] = {
                    state: 0,
                    transportUrl: b,
                    context: c,
                    parent: Im()
                });
                Jm().destination[a].state = 0;
                Km({
                    ctid: a,
                    isDestination: !0
                }, d);
                L(91)
            } else {
                var f;
                (f = Jm().destination)[a] != null || (f[a] = {
                    context: c,
                    state: 1,
                    parent: Im()
                });
                Jm().destination[a].state = 1;
                Km({
                    ctid: a,
                    isDestination: !0
                }, d);
                var g = {
                    destinationId: a,
                    endpoint: 0
                };
                if (Ak()) zm(g, zk() + ("/gtd" + UB(a, !0)));
                else {
                    var h = "/gtag/destination" + UB(a, !0),
                        m = ml(b,
                            h);
                    m || (m = Kw("https://", "http://", fk.yg + h));
                    zm(g, m)
                }
            }
    }

    function UB(a, b) {
        b = b === void 0 ? !1 : b;
        var c = "?id=" + encodeURIComponent(a);
        ik !== "dataLayer" && (c += "&l=" + ik);
        if (!Ib(a, "GTM-") || b) c = F(130) ? c + (Ak() ? "&sc=1" : "&cx=c") : c + "&cx=c";
        c += "&gtm=" + $r();
        nl() && (c += "&sign=" + fk.Ii);
        var d = bk.H;
        d === 1 ? c += "&fps=fc" : d === 2 && (c += "&fps=fe");
        !F(191) && dk().join("~") && (c += "&tag_exp=" + dk().join("~"));
        return c
    };
    var XB = function() {
        this.H = 0;
        this.C = {}
    };
    XB.prototype.addListener = function(a, b, c) {
        var d = ++this.H;
        this.C[a] = this.C[a] || {};
        this.C[a][String(d)] = {
            listener: b,
            He: c
        };
        return d
    };
    XB.prototype.removeListener = function(a, b) {
        var c = this.C[a],
            d = String(b);
        if (!c || !c[d]) return !1;
        delete c[d];
        return !0
    };
    var ZB = function(a, b) {
        var c = [];
        wb(YB.C[a], function(d, e) {
            c.indexOf(e.listener) < 0 && (e.He === void 0 || b.indexOf(e.He) >= 0) && c.push(e.listener)
        });
        return c
    };

    function $B(a, b, c) {
        return {
            entityType: a,
            indexInOriginContainer: b,
            nameInOriginContainer: c,
            originContainerId: ng.ctid
        }
    };

    function aC(a, b) {
        if (data.entities) {
            var c = data.entities[a];
            if (c) return c[b]
        }
    };
    var cC = function(a, b) {
            this.C = !1;
            this.P = [];
            this.eventData = {
                tags: []
            };
            this.R = !1;
            this.H = this.M = 0;
            bC(this, a, b)
        },
        dC = function(a, b, c, d) {
            if (kk.hasOwnProperty(b) || b === "__zone") return -1;
            var e = {};
            od(d) && (e = pd(d, e));
            e.id = c;
            e.status = "timeout";
            return a.eventData.tags.push(e) - 1
        },
        eC = function(a, b, c, d) {
            var e = a.eventData.tags[b];
            e && (e.status = c, e.executionTime = d)
        },
        fC = function(a) {
            if (!a.C) {
                for (var b = a.P, c = 0; c < b.length; c++) b[c]();
                a.C = !0;
                a.P.length = 0
            }
        },
        bC = function(a, b, c) {
            b !== void 0 && a.Uf(b);
            c && x.setTimeout(function() {
                    fC(a)
                },
                Number(c))
        };
    cC.prototype.Uf = function(a) {
        var b = this,
            c = Fb(function() {
                Qc(function() {
                    a(ng.ctid, b.eventData)
                })
            });
        this.C ? c() : this.P.push(c)
    };
    var gC = function(a) {
            a.M++;
            return Fb(function() {
                a.H++;
                a.R && a.H >= a.M && fC(a)
            })
        },
        hC = function(a) {
            a.R = !0;
            a.H >= a.M && fC(a)
        };
    var iC = {};

    function jC() {
        return x[kC()]
    }
    var lC = function(a) {
            if (rn()) {
                var b = jC();
                b(a + "require", "linker");
                b(a + "linker:passthrough", !0)
            }
        },
        mC = function(a) {
            var b = x;
            b.GoogleAnalyticsObject || (b.GoogleAnalyticsObject = a || "ga");
            var c = b.GoogleAnalyticsObject;
            if (b[c]) b.hasOwnProperty(c);
            else {
                var d = function() {
                    var e = Ca.apply(0, arguments);
                    d.q = d.q || [];
                    d.q.push(e)
                };
                d.l = Number(Cb());
                b[c] = d
            }
            return b[c]
        };

    function kC() {
        return x.GoogleAnalyticsObject || "ga"
    }

    function nC() {
        var a = ng.ctid;
    }

    function oC(a, b) {
        return function() {
            var c = jC(),
                d = c && c.getByName && c.getByName(a);
            if (d) {
                var e = d.get("sendHitTask");
                d.set("sendHitTask", function(f) {
                    var g = f.get("hitPayload"),
                        h = f.get("hitCallback"),
                        m = g.indexOf("&tid=" + b) < 0;
                    m && (f.set("hitPayload", g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b), !0), f.set("hitCallback", void 0, !0));
                    e(f);
                    m && (f.set("hitPayload", g, !0), f.set("hitCallback", h, !0), f.set("_x_19", void 0, !0), e(f))
                })
            }
        }
    };
    var uC = ["es", "1"],
        vC = {},
        wC = {};

    function xC(a, b) {
        if (vl) {
            var c;
            c = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
            vC[a] = [
                ["e", c],
                ["eid", a]
            ];
            Lq(a)
        }
    }

    function yC(a) {
        var b = a.eventId,
            c = a.Sd;
        if (!vC[b]) return [];
        var d = [];
        wC[b] || d.push(uC);
        d.push.apply(d, ya(vC[b]));
        c && (wC[b] = !0);
        return d
    };
    var zC = {},
        AC = {},
        BC = {};

    function CC(a, b, c, d) {
        vl && F(120) && ((d === void 0 ? 0 : d) ? (BC[b] = BC[b] || 0, ++BC[b]) : c !== void 0 ? (AC[a] = AC[a] || {}, AC[a][b] = Math.round(c)) : (zC[a] = zC[a] || {}, zC[a][b] = (zC[a][b] || 0) + 1))
    }

    function DC(a) {
        var b = a.eventId,
            c = a.Sd,
            d = zC[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete zC[b];
        return e.length ? [
            ["md", e.join(".")]
        ] : []
    }

    function EC(a) {
        var b = a.eventId,
            c = a.Sd,
            d = AC[b] || {},
            e = [],
            f;
        for (f in d) d.hasOwnProperty(f) && e.push("" + f + d[f]);
        c && delete AC[b];
        return e.length ? [
            ["mtd", e.join(".")]
        ] : []
    }

    function FC() {
        for (var a = [], b = l(Object.keys(BC)), c = b.next(); !c.done; c = b.next()) {
            var d = c.value;
            a.push("" + d + BC[d])
        }
        return a.length ? [
            ["mec", a.join(".")]
        ] : []
    };
    var GC = {},
        HC = {};

    function IC(a, b, c) {
        if (vl && b) {
            var d = rl(b);
            GC[a] = GC[a] || [];
            GC[a].push(c + d);
            var e = b[lf.Oa];
            if (!e) throw Error("Error: No function name given for function call.");
            var f = (Nf[e] ? "1" : "2") + d;
            HC[a] = HC[a] || [];
            HC[a].push(f);
            Lq(a)
        }
    }

    function JC(a) {
        var b = a.eventId,
            c = a.Sd,
            d = [],
            e = GC[b] || [];
        e.length && d.push(["tr", e.join(".")]);
        var f = HC[b] || [];
        f.length && d.push(["ti", f.join(".")]);
        c && (delete GC[b], delete HC[b]);
        return d
    };

    function KC(a, b, c) {
        c = c === void 0 ? !1 : c;
        LC().addRestriction(0, a, b, c)
    }

    function MC(a, b, c) {
        c = c === void 0 ? !1 : c;
        LC().addRestriction(1, a, b, c)
    }

    function NC() {
        var a = Qm();
        return LC().getRestrictions(1, a)
    }
    var OC = function() {
            this.container = {};
            this.C = {}
        },
        PC = function(a, b) {
            var c = a.container[b];
            c || (c = {
                _entity: {
                    internal: [],
                    external: []
                },
                _event: {
                    internal: [],
                    external: []
                }
            }, a.container[b] = c);
            return c
        };
    OC.prototype.addRestriction = function(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        if (!d || !this.C[b]) {
            var e = PC(this, b);
            a === 0 ? d ? e._entity.external.push(c) : e._entity.internal.push(c) : a === 1 && (d ? e._event.external.push(c) : e._event.internal.push(c))
        }
    };
    OC.prototype.getRestrictions = function(a, b) {
        var c = PC(this, b);
        if (a === 0) {
            var d, e;
            return [].concat(ya((c == null ? void 0 : (d = c._entity) == null ? void 0 : d.internal) || []), ya((c == null ? void 0 : (e = c._entity) == null ? void 0 : e.external) || []))
        }
        if (a === 1) {
            var f, g;
            return [].concat(ya((c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) || []), ya((c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) || []))
        }
        return []
    };
    OC.prototype.getExternalRestrictions = function(a, b) {
        var c = PC(this, b),
            d, e;
        return a === 0 ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) || [] : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) || []
    };
    OC.prototype.removeExternalRestrictions = function(a) {
        var b = PC(this, a);
        b._event && (b._event.external = []);
        b._entity && (b._entity.external = []);
        this.C[a] = !0
    };

    function LC() {
        return Jp("r", function() {
            return new OC
        })
    };

    function QC(a, b, c, d) {
        var e = Lf[a],
            f = RC(a, b, c, d);
        if (!f) return null;
        var g = Zf(e[lf.xl], c, []);
        if (g && g.length) {
            var h = g[0];
            f = QC(h.index, {
                onSuccess: f,
                onFailure: h.Tl === 1 ? b.terminate : f,
                terminate: b.terminate
            }, c, d)
        }
        return f
    }

    function RC(a, b, c, d) {
        function e() {
            function w() {
                oo(3);
                var M = Db() - I;
                IC(c.id, f, "7");
                eC(c.Mc, D, "exception", M);
                F(109) && QA(c, f, jA.N.Ki);
                G || (G = !0, h())
            }
            if (f[lf.eo]) h();
            else {
                var y = Yf(f, c, []),
                    z = y[lf.Mm];
                if (z != null)
                    for (var B = 0; B < z.length; B++)
                        if (!O(z[B])) {
                            h();
                            return
                        }
                var D = dC(c.Mc, String(f[lf.Oa]), Number(f[lf.nh]), y[lf.METADATA]),
                    G = !1;
                y.vtp_gtmOnSuccess = function() {
                    if (!G) {
                        G = !0;
                        var M = Db() - I;
                        IC(c.id, Lf[a], "5");
                        eC(c.Mc, D, "success", M);
                        F(109) && QA(c, f, jA.N.Mi);
                        g()
                    }
                };
                y.vtp_gtmOnFailure = function() {
                    if (!G) {
                        G = !0;
                        var M = Db() -
                            I;
                        IC(c.id, Lf[a], "6");
                        eC(c.Mc, D, "failure", M);
                        F(109) && QA(c, f, jA.N.Li);
                        h()
                    }
                };
                y.vtp_gtmTagId = f.tag_id;
                y.vtp_gtmEventId = c.id;
                c.priorityId && (y.vtp_gtmPriorityId = c.priorityId);
                IC(c.id, f, "1");
                F(109) && PA(c, f);
                var I = Db();
                try {
                    $f(y, {
                        event: c,
                        index: a,
                        type: 1
                    })
                } catch (M) {
                    w(M)
                }
                F(109) && QA(c, f, jA.N.El)
            }
        }
        var f = Lf[a],
            g = b.onSuccess,
            h = b.onFailure,
            m = b.terminate;
        if (c.isBlocked(f)) return null;
        var n = Zf(f[lf.Fl], c, []);
        if (n && n.length) {
            var p = n[0],
                q = QC(p.index, {
                    onSuccess: g,
                    onFailure: h,
                    terminate: m
                }, c, d);
            if (!q) return null;
            g = q;
            h = p.Tl ===
                2 ? m : q
        }
        if (f[lf.pl] || f[lf.fo]) {
            var r = f[lf.pl] ? Mf : c.yq,
                t = g,
                u = h;
            if (!r[a]) {
                var v = SC(a, r, Fb(e));
                g = v.onSuccess;
                h = v.onFailure
            }
            return function() {
                r[a](t, u)
            }
        }
        return e
    }

    function SC(a, b, c) {
        var d = [],
            e = [];
        b[a] = TC(d, e, c);
        return {
            onSuccess: function() {
                b[a] = UC;
                for (var f = 0; f < d.length; f++) d[f]()
            },
            onFailure: function() {
                b[a] = VC;
                for (var f = 0; f < e.length; f++) e[f]()
            }
        }
    }

    function TC(a, b, c) {
        return function(d, e) {
            a.push(d);
            b.push(e);
            c()
        }
    }

    function UC(a) {
        a()
    }

    function VC(a, b) {
        b()
    };
    var YC = function(a, b) {
        for (var c = [], d = 0; d < Lf.length; d++)
            if (a[d]) {
                var e = Lf[d];
                var f = gC(b.Mc);
                try {
                    var g = QC(d, {
                        onSuccess: f,
                        onFailure: f,
                        terminate: f
                    }, b, d);
                    if (g) {
                        var h = e[lf.Oa];
                        if (!h) throw Error("Error: No function name given for function call.");
                        var m = Nf[h];
                        c.push({
                            Cm: d,
                            priorityOverride: (m ? m.priorityOverride || 0 : 0) || aC(e[lf.Oa], 1) || 0,
                            execute: g
                        })
                    } else WC(d, b), f()
                } catch (p) {
                    f()
                }
            }
        c.sort(XC);
        for (var n = 0; n < c.length; n++) c[n].execute();
        return c.length > 0
    };

    function ZC(a, b) {
        if (!YB) return !1;
        var c = a["gtm.triggers"] && String(a["gtm.triggers"]),
            d = ZB(a.event, c ? String(c).split(",") : []);
        if (!d.length) return !1;
        for (var e = 0; e < d.length; ++e) {
            var f = gC(b);
            try {
                d[e](a, f)
            } catch (g) {
                f()
            }
        }
        return !0
    }

    function XC(a, b) {
        var c, d = b.priorityOverride,
            e = a.priorityOverride;
        c = d > e ? 1 : d < e ? -1 : 0;
        var f;
        if (c !== 0) f = c;
        else {
            var g = a.Cm,
                h = b.Cm;
            f = g > h ? 1 : g < h ? -1 : 0
        }
        return f
    }

    function WC(a, b) {
        if (vl) {
            var c = function(d) {
                var e = b.isBlocked(Lf[d]) ? "3" : "4",
                    f = Zf(Lf[d][lf.xl], b, []);
                f && f.length && c(f[0].index);
                IC(b.id, Lf[d], e);
                var g = Zf(Lf[d][lf.Fl], b, []);
                g && g.length && c(g[0].index)
            };
            c(a)
        }
    }
    var $C = !1,
        YB;

    function aD() {
        YB || (YB = new XB);
        return YB
    }

    function bD(a) {
        var b = a["gtm.uniqueEventId"],
            c = a["gtm.priorityId"],
            d = a.event;
        if (F(109)) {}
        if (d === "gtm.js") {
            if ($C) return !1;
            $C = !0
        }
        var e = !1,
            f = NC(),
            g = pd(a, null);
        if (!f.every(function(t) {
                return t({
                    originalEventData: g
                })
            })) {
            if (d !== "gtm.js" && d !== "gtm.init" && d !== "gtm.init_consent") return !1;
            e = !0
        }
        xC(b, d);
        var h = a.eventCallback,
            m =
            a.eventTimeout,
            n = {
                id: b,
                priorityId: c,
                name: d,
                isBlocked: cD(g, e),
                yq: [],
                logMacroError: function() {
                    L(6);
                    oo(0)
                },
                cachedModelValues: dD(),
                Mc: new cC(function() {
                    if (F(109)) {}
                    h && h.apply(h, Array.prototype.slice.call(arguments, 0))
                }, m),
                originalEventData: g
            };
        F(120) && vl && (n.reportMacroDiscrepancy = CC);
        F(109) && MA(n.id);
        var p = eg(n);
        F(109) && NA(n.id);
        e && (p = eD(p));
        F(109) && LA(b);
        var q = YC(p, n),
            r = ZC(a, n.Mc);
        hC(n.Mc);
        d !== "gtm.js" && d !== "gtm.sync" || nC();
        return fD(p, q) || r
    }

    function dD() {
        var a = {};
        a.event = Lk("event", 1);
        a.ecommerce = Lk("ecommerce", 1);
        a.gtm = Lk("gtm");
        a.eventModel = Lk("eventModel");
        return a
    }

    function cD(a, b) {
        var c = QB();
        return function(d) {
            if (c(d)) return !0;
            var e = d && d[lf.Oa];
            if (!e || typeof e !== "string") return !0;
            e = e.replace(/^_*/, "");
            var f, g = Qm();
            f = LC().getRestrictions(0, g);
            var h = a;
            b && (h = pd(a, null), h["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER);
            for (var m = wk[e] || [], n = l(f), p = n.next(); !p.done; p = n.next()) {
                var q = p.value;
                try {
                    if (!q({
                            entityId: e,
                            securityGroups: m,
                            originalEventData: h
                        })) return !0
                } catch (r) {
                    return !0
                }
            }
            return !1
        }
    }

    function eD(a) {
        for (var b = [], c = 0; c < a.length; c++)
            if (a[c]) {
                var d = String(Lf[c][lf.Oa]);
                if (jk[d] || Lf[c][lf.ho] !== void 0 || aC(d, 2)) b[c] = !0
            }
        return b
    }

    function fD(a, b) {
        if (!b) return b;
        for (var c = 0; c < a.length; c++)
            if (a[c] && Lf[c] && !kk[String(Lf[c][lf.Oa])]) return !0;
        return !1
    };

    function gD() {
        aD().addListener("gtm.init", function(a, b) {
            bk.fa = !0;
            $n();
            b()
        })
    };
    var hD = !1,
        iD = 0,
        jD = [];

    function kD(a) {
        if (!hD) {
            var b = A.createEventObject,
                c = A.readyState === "complete",
                d = A.readyState === "interactive";
            if (!a || a.type !== "readystatechange" || c || !b && d) {
                hD = !0;
                for (var e = 0; e < jD.length; e++) Qc(jD[e])
            }
            jD.push = function() {
                for (var f = Ca.apply(0, arguments), g = 0; g < f.length; g++) Qc(f[g]);
                return 0
            }
        }
    }

    function lD() {
        if (!hD && iD < 140) {
            iD++;
            try {
                var a, b;
                (b = (a = A.documentElement).doScroll) == null || b.call(a, "left");
                kD()
            } catch (c) {
                x.setTimeout(lD, 50)
            }
        }
    }

    function mD() {
        var a = x;
        hD = !1;
        iD = 0;
        if (A.readyState === "interactive" && !A.createEventObject || A.readyState === "complete") kD();
        else {
            Oc(A, "DOMContentLoaded", kD);
            Oc(A, "readystatechange", kD);
            if (A.createEventObject && A.documentElement.doScroll) {
                var b = !0;
                try {
                    b = !a.frameElement
                } catch (c) {}
                b && lD()
            }
            Oc(a, "load", kD)
        }
    }

    function nD(a) {
        hD ? a() : jD.push(a)
    };
    var oD = {},
        pD = {};

    function qD(a, b) {
        for (var c = [], d = [], e = {}, f = 0; f < a.length; e = {
                uj: void 0,
                aj: void 0
            }, f++) {
            var g = a[f];
            if (g.indexOf("-") >= 0) {
                if (e.uj = Tp(g, b), e.uj) {
                    var h = Pm();
                    sb(h, function(r) {
                        return function(t) {
                            return r.uj.destinationId === t
                        }
                    }(e)) ? c.push(g) : d.push(g)
                }
            } else {
                var m = oD[g] || [];
                e.aj = {};
                m.forEach(function(r) {
                    return function(t) {
                        r.aj[t] = !0
                    }
                }(e));
                for (var n = Rm(), p = 0; p < n.length; p++)
                    if (e.aj[n[p]]) {
                        c = c.concat(Pm());
                        break
                    }
                var q = pD[g] || [];
                q.length && (c = c.concat(q))
            }
        }
        return {
            oj: c,
            Rp: d
        }
    }

    function rD(a) {
        wb(oD, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    }

    function sD(a) {
        wb(pD, function(b, c) {
            var d = c.indexOf(a);
            d >= 0 && c.splice(d, 1)
        })
    };
    var tD = !1,
        uD = !1;

    function vD(a, b) {
        var c = {},
            d = (c.event = a, c);
        b && (d.eventModel = pd(b, null), b[K.m.ff] && (d.eventCallback = b[K.m.ff]), b[K.m.Mg] && (d.eventTimeout = b[K.m.Mg]));
        return d
    }

    function wD(a, b) {
        a.hasOwnProperty("gtm.uniqueEventId") || Object.defineProperty(a, "gtm.uniqueEventId", {
            value: Mp()
        });
        b.eventId = a["gtm.uniqueEventId"];
        b.priorityId = a["gtm.priorityId"];
        return {
            eventId: b.eventId,
            priorityId: b.priorityId
        }
    }

    function xD(a, b) {
        var c = a && a[K.m.pd];
        c === void 0 && (c = Gk(K.m.pd, 2), c === void 0 && (c = "default"));
        if (pb(c) || Array.isArray(c)) {
            var d;
            d = b.isGtmEvent ? pb(c) ? [c] : c : c.toString().replace(/\s+/g, "").split(",");
            var e = qD(d, b.isGtmEvent),
                f = e.oj,
                g = e.Rp;
            if (g.length)
                for (var h = yD(a), m = 0; m < g.length; m++) {
                    var n = Tp(g[m], b.isGtmEvent);
                    if (n) {
                        var p = n.destinationId,
                            q = n.destinationId,
                            r = Jm().destination[q];
                        r && r.state === 0 || WB(p, h, {
                            source: 3,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            var t = f.concat(g);
            return {
                oj: Up(f, b.isGtmEvent),
                Ao: Up(t, b.isGtmEvent)
            }
        }
    }
    var zD = void 0,
        AD = void 0;

    function BD(a, b, c) {
        var d = pd(a, null);
        d.eventId = void 0;
        d.inheritParentConfig = void 0;
        Object.keys(b).some(function(f) {
            return b[f] !== void 0
        }) && L(136);
        var e = pd(b, null);
        pd(c, e);
        gx(cx(Rm()[0], e), a.eventId, d)
    }

    function yD(a) {
        for (var b = l([K.m.rd, K.m.sc]), c = b.next(); !c.done; c = b.next()) {
            var d = c.value,
                e = a && a[d] || Uq.C[d];
            if (e) return e
        }
    }
    var CD = {
            config: function(a, b) {
                var c = wD(a, b);
                if (!(a.length < 2) && pb(a[1])) {
                    var d = {};
                    if (a.length > 2) {
                        if (a[2] !== void 0 && !od(a[2]) || a.length > 3) return;
                        d = a[2]
                    }
                    var e = Tp(a[1], b.isGtmEvent);
                    if (e) {
                        var f, g, h;
                        a: {
                            if (!Nm.se) {
                                var m = Tm(Im());
                                if (bn(m)) {
                                    var n = m.parent,
                                        p = n.isDestination;
                                    h = {
                                        Up: Tm(n),
                                        Np: p
                                    };
                                    break a
                                }
                            }
                            h = void 0
                        }
                        var q = h;
                        q && (f = q.Up, g = q.Np);
                        xC(c.eventId, "gtag.config");
                        var r = e.destinationId,
                            t = e.id !== r;
                        if (t ? Pm().indexOf(r) === -1 : Rm().indexOf(r) === -1) {
                            if (!b.inheritParentConfig && !d[K.m.Ic]) {
                                var u = yD(d);
                                if (t) WB(r, u, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                });
                                else if (f !== void 0 && f.containers.indexOf(r) !== -1) {
                                    var v = d;
                                    zD ? BD(b, v, zD) : AD || (AD = pd(v, null))
                                } else TB(r, u, !0, {
                                    source: 2,
                                    fromContainerExecution: b.fromContainerExecution
                                })
                            }
                        } else {
                            if (f && (L(128), g && L(130), b.inheritParentConfig)) {
                                var w;
                                var y = d;
                                AD ? (BD(b, AD, y), w = !1) : (!y[K.m.ud] && mk && zD || (zD = pd(y, null)), w = !0);
                                w && f.containers && f.containers.join(",");
                                return
                            }
                            wl && (Op === 1 && (Tn.mcc = !1), Op = 2);
                            if (mk && !t && !d[K.m.ud]) {
                                var z = uD;
                                uD = !0;
                                if (z) return
                            }
                            tD || L(43);
                            if (!b.noTargetGroup)
                                if (t) {
                                    sD(e.id);
                                    var B = e.id,
                                        D = d[K.m.Pg] || "default";
                                    D = String(D).split(",");
                                    for (var G = 0; G < D.length; G++) {
                                        var I = pD[D[G]] || [];
                                        pD[D[G]] = I;
                                        I.indexOf(B) < 0 && I.push(B)
                                    }
                                } else {
                                    rD(e.id);
                                    var M = e.id,
                                        S = d[K.m.Pg] || "default";
                                    S = S.toString().split(",");
                                    for (var ea = 0; ea < S.length; ea++) {
                                        var P = oD[S[ea]] || [];
                                        oD[S[ea]] = P;
                                        P.indexOf(M) < 0 && P.push(M)
                                    }
                                }
                            delete d[K.m.Pg];
                            var V = b.eventMetadata || {};
                            V.hasOwnProperty(Q.A.yd) || (V[Q.A.yd] = !b.fromContainerExecution);
                            b.eventMetadata = V;
                            delete d[K.m.ff];
                            for (var ka = t ? [e.id] : Pm(), ja = 0; ja < ka.length; ja++) {
                                var Y =
                                    d,
                                    W = ka[ja],
                                    ha = pd(b, null),
                                    wa = Tp(W, ha.isGtmEvent);
                                wa && Uq.push("config", [Y], wa, ha)
                            }
                        }
                    }
                }
            },
            consent: function(a, b) {
                if (a.length === 3) {
                    L(39);
                    var c = wD(a, b),
                        d = a[1],
                        e = {},
                        f = Ro(a[2]),
                        g;
                    for (g in f)
                        if (f.hasOwnProperty(g)) {
                            var h = f[g];
                            e[g] = g === K.m.tg ? Array.isArray(h) ? NaN : Number(h) : g === K.m.hc ? (Array.isArray(h) ? h : [h]).map(So) : To(h)
                        }
                    b.fromContainerExecution || (e[K.m.V] && L(139), e[K.m.Ia] && L(140));
                    d === "default" ? up(e) : d === "update" ? wp(e, c) : d === "declare" && b.fromContainerExecution && tp(e)
                }
            },
            event: function(a, b) {
                var c = a[1];
                if (!(a.length <
                        2) && pb(c)) {
                    var d = void 0;
                    if (a.length > 2) {
                        if (!od(a[2]) && a[2] !== void 0 || a.length > 3) return;
                        d = a[2]
                    }
                    var e = vD(c, d),
                        f = wD(a, b),
                        g = f.eventId,
                        h = f.priorityId;
                    e["gtm.uniqueEventId"] = g;
                    h && (e["gtm.priorityId"] = h);
                    if (c === "optimize.callback") return e.eventModel = e.eventModel || {}, e;
                    var m = xD(d, b);
                    if (m) {
                        for (var n = m.oj, p = m.Ao, q = p.map(function(M) {
                                return M.id
                            }), r = p.map(function(M) {
                                return M.destinationId
                            }), t = n.map(function(M) {
                                return M.id
                            }), u = l(Pm()), v = u.next(); !v.done; v = u.next()) {
                            var w = v.value;
                            r.indexOf(w) < 0 && t.push(w)
                        }
                        xC(g,
                            c);
                        for (var y = l(t), z = y.next(); !z.done; z = y.next()) {
                            var B = z.value,
                                D = pd(b, null),
                                G = pd(d, null);
                            delete G[K.m.ff];
                            var I = D.eventMetadata || {};
                            I.hasOwnProperty(Q.A.yd) || (I[Q.A.yd] = !D.fromContainerExecution);
                            I[Q.A.Gi] = q.slice();
                            I[Q.A.Rf] = r.slice();
                            D.eventMetadata = I;
                            Vq(c, G, B, D)
                        }
                        e.eventModel = e.eventModel || {};
                        q.length > 0 ? e.eventModel[K.m.pd] = q.join(",") : delete e.eventModel[K.m.pd];
                        tD || L(43);
                        b.noGtmEvent === void 0 && b.eventMetadata && b.eventMetadata[Q.A.Cl] && (b.noGtmEvent = !0);
                        e.eventModel[K.m.Hc] && (b.noGtmEvent = !0);
                        return b.noGtmEvent ? void 0 : e
                    }
                }
            },
            get: function(a, b) {
                L(53);
                if (a.length === 4 && pb(a[1]) && pb(a[2]) && ob(a[3])) {
                    var c = Tp(a[1], b.isGtmEvent),
                        d = String(a[2]),
                        e = a[3];
                    if (c) {
                        tD || L(43);
                        var f = yD();
                        if (sb(Pm(), function(h) {
                                return c.destinationId === h
                            })) {
                            wD(a, b);
                            var g = {};
                            pd((g[K.m.Fc] = d, g[K.m.jd] = e, g), null);
                            Wq(d, function(h) {
                                Qc(function() {
                                    e(h)
                                })
                            }, c.id, b)
                        } else WB(c.destinationId, f, {
                            source: 4,
                            fromContainerExecution: b.fromContainerExecution
                        })
                    }
                }
            },
            js: function(a, b) {
                if (a.length === 2 && a[1].getTime) {
                    tD = !0;
                    var c = wD(a, b),
                        d = c.eventId,
                        e = c.priorityId,
                        f = {};
                    return f.event = "gtm.js", f["gtm.start"] = a[1].getTime(), f["gtm.uniqueEventId"] = d, f["gtm.priorityId"] = e, f
                }
            },
            policy: function(a) {
                if (a.length === 3 && pb(a[1]) && ob(a[2])) {
                    if (kg(a[1], a[2]), L(74), a[1] === "all") {
                        L(75);
                        var b = !1;
                        try {
                            b = a[2](ng.ctid, "unknown", {})
                        } catch (c) {}
                        b || L(76)
                    }
                } else L(73)
            },
            set: function(a, b) {
                var c = void 0;
                a.length === 2 && od(a[1]) ? c = pd(a[1], null) : a.length === 3 && pb(a[1]) && (c = {}, od(a[2]) || Array.isArray(a[2]) ? c[a[1]] = pd(a[2], null) : c[a[1]] = a[2]);
                if (c) {
                    var d = wD(a, b),
                        e = d.eventId,
                        f = d.priorityId;
                    pd(c, null);
                    var g = pd(c, null);
                    Uq.push("set", [g], void 0, b);
                    c["gtm.uniqueEventId"] = e;
                    f && (c["gtm.priorityId"] = f);
                    delete c.event;
                    b.overwriteModelFields = !0;
                    return c
                }
            }
        },
        DD = {
            policy: !0
        };
    var FD = function(a) {
        if (ED(a)) return a;
        this.value = a
    };
    FD.prototype.getUntrustedMessageValue = function() {
        return this.value
    };
    var ED = function(a) {
        return !a || md(a) !== "object" || od(a) ? !1 : "getUntrustedMessageValue" in a
    };
    FD.prototype.getUntrustedMessageValue = FD.prototype.getUntrustedMessageValue;
    var GD = !1,
        HD = [];

    function ID() {
        if (!GD) {
            GD = !0;
            for (var a = 0; a < HD.length; a++) Qc(HD[a])
        }
    }

    function JD(a) {
        GD ? Qc(a) : HD.push(a)
    };
    var KD = 0,
        LD = {},
        MD = [],
        ND = [],
        OD = !1,
        PD = !1;

    function QD(a, b) {
        return a.messageContext.eventId - b.messageContext.eventId || a.messageContext.priorityId - b.messageContext.priorityId
    }

    function RD(a, b, c) {
        a.eventCallback = b;
        c && (a.eventTimeout = c);
        return SD(a)
    }

    function TD(a, b) {
        if (!qb(b) || b < 0) b = 0;
        var c = Ip[ik],
            d = 0,
            e = !1,
            f = void 0;
        f = x.setTimeout(function() {
            e || (e = !0, a());
            f = void 0
        }, b);
        return function() {
            var g = c ? c.subscribers : 1;
            ++d === g && (f && (x.clearTimeout(f), f = void 0), e || (a(), e = !0))
        }
    }

    function UD(a) {
        if (a == null || typeof a !== "object") return !1;
        if (a.event) return !0;
        if (xb(a)) {
            var b = a[0];
            if (b === "config" || b === "event" || b === "js" || b === "get") return !0
        }
        return !1
    }

    function VD() {
        var a;
        if (ND.length) a = ND.shift();
        else if (MD.length) a = MD.shift();
        else return;
        var b;
        var c = a;
        if (OD || !UD(c.message)) b = c;
        else {
            OD = !0;
            var d = c.message["gtm.uniqueEventId"],
                e, f;
            typeof d === "number" ? (e = d - 2, f = d - 1) : (e = Mp(), f = Mp(), c.message["gtm.uniqueEventId"] = Mp());
            var g = {},
                h = {
                    message: (g.event = "gtm.init_consent", g["gtm.uniqueEventId"] = e, g),
                    messageContext: {
                        eventId: e
                    }
                },
                m = {},
                n = {
                    message: (m.event = "gtm.init", m["gtm.uniqueEventId"] = f, m),
                    messageContext: {
                        eventId: f
                    }
                };
            MD.unshift(n, c);
            b = h
        }
        return b
    }

    function WD() {
        for (var a = !1, b; !PD && (b = VD());) {
            PD = !0;
            delete Dk.eventModel;
            Fk();
            var c = b,
                d = c.message,
                e = c.messageContext;
            if (d == null) PD = !1;
            else {
                e.fromContainerExecution && Kk();
                try {
                    if (ob(d)) try {
                        d.call(Hk)
                    } catch (G) {} else if (Array.isArray(d)) {
                        if (pb(d[0])) {
                            var f = d[0].split("."),
                                g = f.pop(),
                                h = d.slice(1),
                                m = Gk(f.join("."), 2);
                            if (m != null) try {
                                m[g].apply(m, h)
                            } catch (G) {}
                        }
                    } else {
                        var n = void 0;
                        if (xb(d)) a: {
                            if (d.length && pb(d[0])) {
                                var p = CD[d[0]];
                                if (p && (!e.fromContainerExecution || !DD[d[0]])) {
                                    n = p(d, e);
                                    break a
                                }
                            }
                            n = void 0
                        }
                        else n =
                            d;
                        if (n) {
                            var q;
                            for (var r = n, t = r._clear || e.overwriteModelFields, u = l(Object.keys(r)), v = u.next(); !v.done; v = u.next()) {
                                var w = v.value;
                                w !== "_clear" && (t && Jk(w), Jk(w, r[w]))
                            }
                            tk || (tk = r["gtm.start"]);
                            var y = r["gtm.uniqueEventId"];
                            r.event ? (typeof y !== "number" && (y = Mp(), r["gtm.uniqueEventId"] = y, Jk("gtm.uniqueEventId", y)), q = bD(r)) : q = !1;
                            a = q || a
                        }
                    }
                } finally {
                    e.fromContainerExecution && Fk(!0);
                    var z = d["gtm.uniqueEventId"];
                    if (typeof z === "number") {
                        for (var B = LD[String(z)] || [], D = 0; D < B.length; D++) ND.push(XD(B[D]));
                        B.length && ND.sort(QD);
                        delete LD[String(z)];
                        z > KD && (KD = z)
                    }
                    PD = !1
                }
            }
        }
        return !a
    }

    function YD() {
        if (F(109)) {
            var a = !bk.la;
        }
        var c = WD();
        if (F(109)) {}
        try {
            var e = ng.ctid,
                f = x[ik].hide;
            if (f && f[e] !== void 0 && f.end) {
                f[e] = !1;
                var g = !0,
                    h;
                for (h in f)
                    if (f.hasOwnProperty(h) && f[h] === !0) {
                        g = !1;
                        break
                    }
                g && (f.end(), f.end = null)
            }
        } catch (m) {}
        return c
    }

    function jx(a) {
        if (KD < a.notBeforeEventId) {
            var b = String(a.notBeforeEventId);
            LD[b] = LD[b] || [];
            LD[b].push(a)
        } else ND.push(XD(a)), ND.sort(QD), Qc(function() {
            PD || WD()
        })
    }

    function XD(a) {
        return {
            message: a.message,
            messageContext: a.messageContext
        }
    }

    function ZD() {
        function a(f) {
            var g = {};
            if (ED(f)) {
                var h = f;
                f = ED(h) ? h.getUntrustedMessageValue() : void 0;
                g.fromContainerExecution = !0
            }
            return {
                message: f,
                messageContext: g
            }
        }
        var b = Ac(ik, []),
            c = Ip[ik] = Ip[ik] || {};
        c.pruned === !0 && L(83);
        LD = hx().get();
        ix();
        nD(function() {
            if (!c.gtmDom) {
                c.gtmDom = !0;
                var f = {};
                b.push((f.event = "gtm.dom", f))
            }
        });
        JD(function() {
            if (!c.gtmLoad) {
                c.gtmLoad = !0;
                var f = {};
                b.push((f.event = "gtm.load", f))
            }
        });
        c.subscribers = (c.subscribers || 0) + 1;
        var d = b.push;
        b.push = function() {
            var f;
            if (Ip.SANDBOXED_JS_SEMAPHORE >
                0) {
                f = [];
                for (var g = 0; g < arguments.length; g++) f[g] = new FD(arguments[g])
            } else f = [].slice.call(arguments, 0);
            var h = f.map(function(q) {
                return a(q)
            });
            MD.push.apply(MD, h);
            var m = d.apply(b, f),
                n = Math.max(100, Number(Si(1, '1000')) || 300);
            if (this.length > n)
                for (L(4), c.pruned = !0; this.length > n;) this.shift();
            var p = typeof m !== "boolean" || m;
            return WD() && p
        };
        var e = b.slice(0).map(function(f) {
            return a(f)
        });
        MD.push.apply(MD, e);
        if (!bk.la) {
            if (F(109)) {}
            Qc(YD)
        }
    }
    var SD = function(a) {
        return x[ik].push(a)
    };

    function $D(a) {
        SD(a)
    };

    function aE() {
        var a, b = gl(x.location.href);
        (a = b.hostname + b.pathname) && Wn("dl", encodeURIComponent(a));
        var c;
        var d = ng.ctid;
        if (d) {
            var e = Nm.se ? 1 : 0,
                f, g = Tm(Im());
            f = g && g.context;
            c = d + ";" + ng.canonicalContainerId + ";" + (f && f.fromContainerExecution ? 1 : 0) + ";" + (f && f.source || 0) + ";" + e
        } else c = void 0;
        var h = c;
        h && Wn("tdp", h);
        var m = Wl(!0);
        m !== void 0 && Wn("frm", String(m))
    };
    var bE = {},
        cE = void 0;

    function dE() {
        if (dp() || wl) Wn("csp", function() {
            return Object.keys(bE).join("~") || void 0
        }, !1), x.addEventListener("securitypolicyviolation", function(a) {
            if (a.disposition === "enforce") {
                L(179);
                var b = um(a.effectiveDirective);
                if (b) {
                    var c;
                    var d = sm(b, a.blockedURI);
                    c = d ? qm[b][d] : void 0;
                    if (c) {
                        var e;
                        a: {
                            try {
                                var f = new URL(a.blockedURI),
                                    g = f.pathname.indexOf(";");
                                e = g >= 0 ? f.origin + f.pathname.substring(0, g) : f.origin + f.pathname;
                                break a
                            } catch (v) {}
                            e = void 0
                        }
                        var h = e;
                        if (h) {
                            for (var m = l(c), n = m.next(); !n.done; n = m.next()) {
                                var p =
                                    n.value;
                                if (!p.wm) {
                                    p.wm = !0;
                                    if (F(59)) {
                                        var q = {
                                            eventId: p.eventId,
                                            priorityId: p.priorityId
                                        };
                                        if (dp()) {
                                            var r = q,
                                                t = {
                                                    type: 1,
                                                    blockedUrl: h,
                                                    endpoint: p.endpoint,
                                                    violation: a.effectiveDirective
                                                };
                                            if (dp()) {
                                                var u = jp("TAG_DIAGNOSTICS", {
                                                    eventId: r == null ? void 0 : r.eventId,
                                                    priorityId: r == null ? void 0 : r.priorityId
                                                });
                                                u.tagDiagnostics = t;
                                                cp(u)
                                            }
                                        }
                                    }
                                    eE(p.endpoint)
                                }
                            }
                            tm(b, a.blockedURI)
                        }
                    }
                }
            }
        })
    }

    function eE(a) {
        var b = String(a);
        bE.hasOwnProperty(b) || (bE[b] = !0, Xn("csp", !0), cE === void 0 && F(171) && (cE = x.setTimeout(function() {
            if (F(171)) {
                var c = Tn.csp;
                Tn.csp = !0;
                Tn.seq = !1;
                var d = Yn(!1);
                Tn.csp = c;
                Tn.seq = !0;
                Jc(d + "&script=1")
            }
            cE = void 0
        }, 500)))
    };

    function fE() {
        var a;
        var b = Sm();
        if (b)
            if (b.canonicalContainerId) a = b.canonicalContainerId;
            else {
                var c, d = b.scriptContainerId || ((c = b.destinations) == null ? void 0 : c[0]);
                a = d ? "_" + d : void 0
            }
        else a = void 0;
        var e = a;
        e && Wn("pcid", e)
    };
    var gE = /^(https?:)?\/\//;

    function hE() {
        var a = Um();
        if (a) {
            var b;
            a: {
                var c, d = (c = a.scriptElement) == null ? void 0 : c.src;
                if (d) {
                    var e;
                    try {
                        var f;
                        e = (f = dd()) == null ? void 0 : f.getEntriesByType("resource")
                    } catch (q) {}
                    if (e) {
                        for (var g = -1, h = l(e), m = h.next(); !m.done; m = h.next()) {
                            var n = m.value;
                            if (n.initiatorType === "script" && (g += 1, n.name.replace(gE, "") === d.replace(gE, ""))) {
                                b = g;
                                break a
                            }
                        }
                        L(146)
                    } else L(145)
                }
                b = void 0
            }
            var p = b;
            p !== void 0 && (a.canonicalContainerId && Wn("rtg", String(a.canonicalContainerId)), Wn("slo", String(p)), Wn("hlo", a.htmlLoadOrder || "-1"),
                Wn("lst", String(a.loadScriptType || "0")))
        } else L(144)
    };

    function iE() {
        var a = [],
            b = Number('') || 0,
            c = Number('0.001') || 0;
        c || (c = b / 100);
        var d = function() {
            var B = !1;
            return B
        }();
        a.push({
            Fe: 21,
            studyId: 21,
            experimentId: 105102050,
            controlId: 105102051,
            controlId2: 105102052,
            probability: c,
            active: d,
            Dd: 0
        });
        var e = Number('') ||
            0,
            f = Number('0.01') || 0;
        f || (f = e / 100);
        var g = function() {
            var B = !1;
            return B
        }();
        a.push({
            Fe: 219,
            studyId: 219,
            experimentId: 104948811,
            controlId: 104948812,
            controlId2: 0,
            probability: f,
            active: g,
            Dd: 0
        });
        var h = Number('') ||
            0,
            m = Number('1') || 0;
        m || (m = h / 100);
        var n = function() {
            var B = !1;
            return B
        }();
        a.push({
            Fe: 220,
            studyId: 220,
            experimentId: 104948813,
            controlId: 104948814,
            controlId2: 0,
            probability: m,
            active: n,
            Dd: 0
        });
        var p =
            Number('') || 0,
            q = Number('0.1') || 0;
        q || (q = p / 100);
        var r = function() {
            var B = !1;
            return B
        }();
        a.push({
            Fe: 197,
            studyId: 197,
            experimentId: 105113532,
            controlId: 105113531,
            controlId2: 0,
            probability: q,
            active: r,
            Dd: 0
        });
        var t = Number('') ||
            0,
            u = Number('0.01') || 0;
        u || (u = t / 100);
        var v = function() {
            var B = !1;
            return B
        }();
        a.push({
            Fe: 195,
            studyId: 195,
            experimentId: 104527906,
            controlId: 104527907,
            controlId2: 104898015,
            probability: u,
            active: v,
            Dd: 1
        });
        var w = Number('') || 0,
            y = Number('0.01') || 0;
        y || (y = w / 100);
        var z =
            function() {
                var B = !1;
                return B
            }();
        a.push({
            Fe: 196,
            studyId: 196,
            experimentId: 104528500,
            controlId: 104528501,
            controlId2: 104898016,
            probability: y,
            active: z,
            Dd: 0
        });
        return a
    };
    var jE = {};

    function kE(a) {
        for (var b = l(Object.keys(a.exp || {})), c = b.next(); !c.done; c = b.next()) bk.R.H.add(Number(c.value))
    }

    function lE(a) {
        var b = Ln(Gn.X.ql);
        return !!ni[a].active || ni[a].probability > .5 || !!(b.exp || {})[ni[a].experimentId] || !!ni[a].active || ni[a].probability > .5 || !!(jE.exp || {})[ni[a].experimentId]
    }

    function mE() {
        for (var a = l(iE()), b = a.next(); !b.done; b = a.next()) {
            var c = b.value,
                d = c.Fe;
            ni[d] = c;
            if (c.Dd === 1) {
                var e = d,
                    f = Ln(Gn.X.ql);
                ri(f, e);
                kE(f);
                lE(e) && E(e)
            } else if (c.Dd === 0) {
                var g = d,
                    h = jE;
                ri(h, g);
                kE(h);
                lE(g) && E(g)
            }
        }
    };

    function HE() {};
    var IE = function() {};
    IE.prototype.toString = function() {
        return "undefined"
    };
    var JE = new IE;
    var LE = function() {
            Jp("rm", function() {
                return {}
            })[Qm()] = function(a) {
                if (KE.hasOwnProperty(a)) return KE[a]
            }
        },
        OE = function(a, b, c) {
            if (a instanceof ME) {
                var d = a,
                    e = d.resolve,
                    f = b,
                    g = String(Mp());
                NE[g] = [f, c];
                a = e.call(d, g);
                b = nb
            }
            return {
                Ep: a,
                onSuccess: b
            }
        },
        PE = function(a) {
            var b = a ? 0 : 1;
            return function(c) {
                L(a ? 134 : 135);
                var d = NE[c];
                if (d && typeof d[b] === "function") d[b]();
                NE[c] = void 0
            }
        },
        ME = function(a) {
            this.valueOf = this.toString;
            this.resolve = function(b) {
                for (var c = [], d = 0; d < a.length; d++) c.push(a[d] === JE ? b : a[d]);
                return c.join("")
            }
        };
    ME.prototype.toString = function() {
        return this.resolve("undefined")
    };
    var KE = {},
        NE = {};

    function QE() {
        F(212) && pk && (kg("all", function(a, b, c) {
            var d = c.options;
            switch (b) {
                case "detect_link_click_events":
                case "detect_form_submit_events":
                    return (d == null ? void 0 : d.waitForTags) !== !0;
                case "detect_youtube_activity_events":
                    return (d == null ? void 0 : d.fixMissingApi) !== !0;
                default:
                    return !0
            }
        }), KC(Qm(), function(a) {
            var b, c;
            b = a.entityId;
            c = a.securityGroups;
            var d = "__" + b;
            return aC(d, 5) || !(!Nf[d] || !Nf[d][5]) || c.includes("cmpPartners")
        }))
    };

    function RE(a, b) {
        function c(g) {
            var h = gl(g),
                m = al(h, "protocol"),
                n = al(h, "host", !0),
                p = al(h, "port"),
                q = al(h, "path").toLowerCase().replace(/\/$/, "");
            if (m === void 0 || m === "http" && p === "80" || m === "https" && p === "443") m = "web", p = "default";
            return [m, n, p, q]
        }
        for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
            if (d[f] !== e[f]) return !1;
        return !0
    }

    function SE(a) {
        return TE(a) ? 1 : 0
    }

    function TE(a) {
        var b = a.arg0,
            c = a.arg1;
        if (a.any_of && Array.isArray(c)) {
            for (var d = 0; d < c.length; d++) {
                var e = pd(a, {});
                pd({
                    arg1: c[d],
                    any_of: void 0
                }, e);
                if (SE(e)) return !0
            }
            return !1
        }
        switch (a["function"]) {
            case "_cn":
                return Sg(b, c);
            case "_css":
                var f;
                a: {
                    if (b) try {
                        for (var g = 0; g < Ng.length; g++) {
                            var h = Ng[g];
                            if (b[h] != null) {
                                f = b[h](c);
                                break a
                            }
                        }
                    } catch (m) {}
                    f = !1
                }
                return f;
            case "_ew":
                return Og(b, c);
            case "_eq":
                return Tg(b, c);
            case "_ge":
                return Ug(b, c);
            case "_gt":
                return Wg(b, c);
            case "_lc":
                return Pg(b, c);
            case "_le":
                return Vg(b,
                    c);
            case "_lt":
                return Xg(b, c);
            case "_re":
                return Rg(b, c, a.ignore_case);
            case "_sw":
                return Yg(b, c);
            case "_um":
                return RE(b, c)
        }
        return !1
    };
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function(a, b) {
        return a + b
    });
    var UE = function(a, b, c, d) {
        kr.call(this);
        this.ih = b;
        this.Nf = c;
        this.nb = d;
        this.Pa = new Map;
        this.jh = 0;
        this.la = new Map;
        this.Da = new Map;
        this.R = void 0;
        this.H = a
    };
    va(UE, kr);
    UE.prototype.M = function() {
        delete this.C;
        this.Pa.clear();
        this.la.clear();
        this.Da.clear();
        this.R && (gr(this.H, "message", this.R), delete this.R);
        delete this.H;
        delete this.nb;
        kr.prototype.M.call(this)
    };
    var VE = function(a) {
            if (a.C) return a.C;
            a.Nf && a.Nf(a.H) ? a.C = a.H : a.C = Vl(a.H, a.ih);
            var b;
            return (b = a.C) != null ? b : null
        },
        XE = function(a, b, c) {
            if (VE(a))
                if (a.C === a.H) {
                    var d = a.Pa.get(b);
                    d && d(a.C, c)
                } else {
                    var e = a.la.get(b);
                    if (e && e.nj) {
                        WE(a);
                        var f = ++a.jh;
                        a.Da.set(f, {
                            Fh: e.Fh,
                            Ro: e.am(c),
                            persistent: b === "addEventListener"
                        });
                        a.C.postMessage(e.nj(c, f), "*")
                    }
                }
        },
        WE = function(a) {
            a.R || (a.R = function(b) {
                try {
                    var c;
                    c = a.nb ? a.nb(b) : void 0;
                    if (c) {
                        var d = c.Xp,
                            e = a.Da.get(d);
                        if (e) {
                            e.persistent || a.Da.delete(d);
                            var f;
                            (f = e.Fh) == null || f.call(e,
                                e.Ro, c.payload)
                        }
                    }
                } catch (g) {}
            }, fr(a.H, "message", a.R))
        };
    var YE = function(a, b) {
            var c = b.listener,
                d = (0, a.__gpp)("addEventListener", c);
            d && c(d, !0)
        },
        ZE = function(a, b) {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        $E = {
            am: function(a) {
                return a.listener
            },
            nj: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }, c
            },
            Fh: function(a, b) {
                var c = b.__gppReturn;
                a(c.returnValue, c.success)
            }
        },
        aF = {
            am: function(a) {
                return a.listener
            },
            nj: function(a, b) {
                var c = {};
                return c.__gppCall = {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }, c
            },
            Fh: function(a, b) {
                var c = b.__gppReturn,
                    d = c.returnValue.data;
                a == null || a(d, c.success)
            }
        };

    function bF(a) {
        var b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Xp: b.__gppReturn.callId
        }
    }
    var cF = function(a, b) {
        var c;
        c = (b === void 0 ? {} : b).timeoutMs;
        kr.call(this);
        this.caller = new UE(a, "__gppLocator", function(d) {
            return typeof d.__gpp === "function"
        }, bF);
        this.caller.Pa.set("addEventListener", YE);
        this.caller.la.set("addEventListener", $E);
        this.caller.Pa.set("removeEventListener", ZE);
        this.caller.la.set("removeEventListener", aF);
        this.timeoutMs = c != null ? c : 500
    };
    va(cF, kr);
    cF.prototype.M = function() {
        this.caller.dispose();
        kr.prototype.M.call(this)
    };
    cF.prototype.addEventListener = function(a) {
        var b = this,
            c = yl(function() {
                a(dF, !0)
            }),
            d = this.timeoutMs === -1 ? void 0 : setTimeout(function() {
                c()
            }, this.timeoutMs);
        XE(this.caller, "addEventListener", {
            listener: function(e, f) {
                clearTimeout(d);
                try {
                    var g;
                    var h;
                    ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 || e.pingData.gppVersion === "1" || e.pingData.gppVersion === "1.0" ? (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 1,
                            gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                            applicableSections: [-1]
                        }
                    }) : Array.isArray(e.pingData.applicableSections) ? g = e : (b.removeEventListener(e.listenerId), g = {
                        eventName: "signalStatus",
                        data: "ready",
                        pingData: {
                            internalErrorState: 2,
                            gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                            applicableSections: [-1]
                        }
                    });
                    a(g, f)
                } catch (m) {
                    if (e == null ? 0 : e.listenerId) try {
                        b.removeEventListener(e.listenerId)
                    } catch (n) {
                        a(eF, !0);
                        return
                    }
                    a(fF, !0)
                }
            }
        })
    };
    cF.prototype.removeEventListener = function(a) {
        XE(this.caller, "removeEventListener", {
            listener: function() {},
            listenerId: a
        })
    };
    var fF = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        dF = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        eF = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function gF(a) {
        var b;
        if (!(b = a.pingData.signalStatus === "ready")) {
            var c = a.pingData.applicableSections;
            b = !c || c.length === 1 && c[0] === -1
        }
        if (b) {
            Qv.gppString = a.pingData.gppString;
            var d = a.pingData.applicableSections.join(",");
            Qv.C = d
        }
    }

    function hF() {
        try {
            var a = new cF(x, {
                timeoutMs: -1
            });
            VE(a.caller) && a.addEventListener(gF)
        } catch (b) {}
    };

    function iF() {
        var a = [
            ["cv", Qi(1)],
            ["rv", gk],
            ["tc", Lf.filter(function(b) {
                return b
            }).length]
        ];
        hk && a.push(["x", hk]);
        yk() && a.push(["tag_exp", yk()]);
        return a
    };
    var jF = {},
        kF = {};

    function Ui(a) {
        jF[a] = (jF[a] || 0) + 1
    }

    function Vi(a) {
        kF[a] = (kF[a] || 0) + 1
    }

    function lF(a, b) {
        for (var c = [], d = l(Object.keys(b)), e = d.next(); !e.done; e = d.next()) {
            var f = e.value;
            c.push(f + "." + b[f])
        }
        return c.length === 0 ? [] : [
            [a, c.join("~")]
        ]
    }

    function mF() {
        return lF("bdm", jF)
    }

    function nF() {
        return lF("vcm", kF)
    };
    var oF = {},
        pF = {};

    function qF(a) {
        var b = a.eventId,
            c = a.Sd,
            d = [],
            e = oF[b] || [];
        e.length && d.push(["hf", e.join(".")]);
        var f = pF[b] || [];
        f.length && d.push(["ht", f.join(".")]);
        c && (delete oF[b], delete pF[b]);
        return d
    };

    function rF() {
        return !1
    }

    function sF() {
        var a = {};
        return function(b, c, d) {}
    };

    function tF() {
        var a = uF;
        return function(b, c, d) {
            var e = d && d.event;
            vF(c);
            var f = Dh(b) ? void 0 : 1,
                g = new ab;
            wb(c, function(r, t) {
                var u = Ed(t, void 0, f);
                u === void 0 && t !== void 0 && L(44);
                g.set(r, u)
            });
            a.Lb(cg());
            var h = {
                Ml: rg(b),
                eventId: e == null ? void 0 : e.id,
                priorityId: e !== void 0 ? e.priorityId : void 0,
                Uf: e !== void 0 ? function(r) {
                    e.Mc.Uf(r)
                } : void 0,
                Hb: function() {
                    return b
                },
                log: function() {},
                Zo: {
                    index: d == null ? void 0 : d.index,
                    type: d == null ? void 0 : d.type,
                    name: d == null ? void 0 : d.name
                },
                iq: !!aC(b, 3),
                originalEventData: e == null ? void 0 : e.originalEventData
            };
            e && e.cachedModelValues && (h.cachedModelValues = {
                gtm: e.cachedModelValues.gtm,
                ecommerce: e.cachedModelValues.ecommerce
            });
            if (rF()) {
                var m = sF(),
                    n, p;
                h.tb = {
                    Dj: [],
                    Vf: {},
                    bc: function(r, t, u) {
                        t === 1 && (n = r);
                        t === 7 && (p = u);
                        m(r, t, u)
                    },
                    Dh: Vh()
                };
                h.log = function(r) {
                    var t = Ca.apply(1, arguments);
                    n && m(n, 4, {
                        level: r,
                        source: p,
                        message: t
                    })
                }
            }
            var q = bf(a, h, [b, g]);
            a.Lb();
            q instanceof Fa && (q.type === "return" ? q = q.data : q = void 0);
            return C(q, void 0, f)
        }
    }

    function vF(a) {
        var b = a.gtmOnSuccess,
            c = a.gtmOnFailure;
        ob(b) && (a.gtmOnSuccess = function() {
            Qc(b)
        });
        ob(c) && (a.gtmOnFailure = function() {
            Qc(c)
        })
    };

    function wF(a) {}
    wF.K = "internal.addAdsClickIds";

    function xF(a, b) {
        var c = this;
    }
    xF.publicName = "addConsentListener";
    var yF = !1;

    function zF(a) {
        for (var b = 0; b < a.length; ++b)
            if (yF) try {
                a[b]()
            } catch (c) {
                L(77)
            } else a[b]()
    }

    function AF(a, b, c) {
        var d = this,
            e;
        return e
    }
    AF.K = "internal.addDataLayerEventListener";

    function BF(a, b, c) {}
    BF.publicName = "addDocumentEventListener";

    function CF(a, b, c, d) {}
    CF.publicName = "addElementEventListener";

    function DF(a) {
        return a.J.rb()
    };

    function EF(a) {}
    EF.publicName = "addEventCallback";

    function TF(a) {}
    TF.K = "internal.addFormAbandonmentListener";

    function UF(a, b, c, d) {}
    UF.K = "internal.addFormData";
    var VF = {},
        WF = [],
        XF = {},
        YF = 0,
        ZF = 0;

    function fG(a, b) {}
    fG.K = "internal.addFormInteractionListener";

    function mG(a, b) {}
    mG.K = "internal.addFormSubmitListener";

    function rG(a) {}
    rG.K = "internal.addGaSendListener";

    function sG(a) {
        if (!a) return {};
        var b = a.Zo;
        return $B(b.type, b.index, b.name)
    }

    function tG(a) {
        return a ? {
            originatingEntity: sG(a)
        } : {}
    };

    function BG(a) {
        var b = Ip.zones;
        return b ? b.getIsAllowedFn(Rm(), a) : function() {
            return !0
        }
    }

    function CG() {
        var a = Ip.zones;
        a && a.unregisterChild(Rm())
    }

    function DG() {
        MC(Qm(), function(a) {
            var b = Ip.zones;
            return b ? b.isActive(Rm(), a.originalEventData["gtm.uniqueEventId"]) : !0
        });
        KC(Qm(), function(a) {
            var b, c;
            b = a.entityId;
            c = a.securityGroups;
            return BG(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c)
        })
    };
    var EG = function(a, b) {
        this.tagId = a;
        this.xe = b
    };

    function FG(a, b) {
        var c = this;
        return a
    }
    FG.K = "internal.loadGoogleTag";

    function GG(a) {
        return new wd("", function(b) {
            var c = this.evaluate(b);
            if (c instanceof wd) return new wd("", function() {
                var d = Ca.apply(0, arguments),
                    e = this,
                    f = pd(DF(this), null);
                f.eventId = a.eventId;
                f.priorityId = a.priorityId;
                f.originalEventData = a.originalEventData;
                var g = d.map(function(m) {
                        return e.evaluate(m)
                    }),
                    h = this.J.qb();
                h.Qd(f);
                return c.Jb.apply(c, [h].concat(ya(g)))
            })
        })
    };

    function HG(a, b, c) {
        var d = this;
    }
    HG.K = "internal.addGoogleTagRestriction";
    var IG = {},
        JG = [];

    function QG(a, b) {}
    QG.K = "internal.addHistoryChangeListener";

    function RG(a, b, c) {}
    RG.publicName = "addWindowEventListener";

    function SG(a, b) {
        return !0
    }
    SG.publicName = "aliasInWindow";

    function TG(a, b, c) {}
    TG.K = "internal.appendRemoteConfigParameter";

    function UG(a) {
        var b;
        return b
    }
    UG.publicName = "callInWindow";

    function VG(a) {}
    VG.publicName = "callLater";

    function WG(a) {}
    WG.K = "callOnDomReady";

    function XG(a) {}
    XG.K = "callOnWindowLoad";

    function YG(a, b) {
        var c;
        return c
    }
    YG.K = "internal.computeGtmParameter";

    function ZG(a, b) {
        var c = this;
    }
    ZG.K = "internal.consentScheduleFirstTry";

    function $G(a, b) {
        var c = this;
    }
    $G.K = "internal.consentScheduleRetry";

    function aH(a) {
        var b;
        return b
    }
    aH.K = "internal.copyFromCrossContainerData";

    function bH(a, b) {
        var c;
        if (!oh(a) || !th(b) && b !== null && !jh(b)) throw H(this.getName(), ["string", "number|undefined"], arguments);
        J(this, "read_data_layer", a);
        c = (b || 2) !== 2 ? Gk(a, 1) : Ik(a, [x, A]);
        var d = Ed(c, this.J, Dh(DF(this).Hb()) ? 2 : 1);
        d === void 0 && c !== void 0 && L(45);
        return d
    }
    bH.publicName = "copyFromDataLayer";

    function cH(a) {
        var b = void 0;
        return b
    }
    cH.K = "internal.copyFromDataLayerCache";

    function dH(a) {
        var b;
        return b
    }
    dH.publicName = "copyFromWindow";

    function eH(a) {
        var b = void 0;
        return Ed(b, this.J, 1)
    }
    eH.K = "internal.copyKeyFromWindow";
    var fH = function(a) {
        return a === en.W.Fa && xn[a] === dn.Ha.qe && !O(K.m.U)
    };
    var gH = function() {
            return "0"
        },
        hH = function(a) {
            if (typeof a !== "string") return "";
            var b = ["gclid", "dclid", "wbraid", "_gl"];
            F(102) && b.push("gbraid");
            return hl(a, b, "0")
        };
    var iH = {},
        jH = {},
        kH = {},
        lH = {},
        mH = {},
        nH = {},
        oH = {},
        pH = {},
        qH = {},
        rH = {},
        sH = {},
        tH = {},
        uH = {},
        vH = {},
        wH = {},
        xH = {},
        yH = {},
        zH = {},
        AH = {},
        BH = {},
        CH = {},
        DH = {},
        EH = {},
        FH = {},
        GH = {},
        HH = {},
        IH = (HH[K.m.Ja] = (iH[2] = [fH], iH), HH[K.m.uf] = (jH[2] = [fH], jH), HH[K.m.hf] = (kH[2] = [fH], kH), HH[K.m.li] = (lH[2] = [fH], lH), HH[K.m.mi] = (mH[2] = [fH], mH), HH[K.m.ni] = (nH[2] = [fH], nH), HH[K.m.oi] = (oH[2] = [fH], oH), HH[K.m.ri] = (pH[2] = [fH], pH), HH[K.m.uc] = (qH[2] = [fH], qH), HH[K.m.vf] = (rH[2] = [fH], rH), HH[K.m.wf] = (sH[2] = [fH], sH), HH[K.m.xf] = (tH[2] = [fH], tH), HH[K.m.yf] = (uH[2] = [fH], uH), HH[K.m.zf] = (vH[2] = [fH], vH), HH[K.m.Af] = (wH[2] = [fH], wH), HH[K.m.Bf] = (xH[2] = [fH], xH), HH[K.m.Cf] = (yH[2] = [fH], yH), HH[K.m.wb] = (zH[1] = [fH], zH), HH[K.m.Xc] = (AH[1] = [fH], AH), HH[K.m.ed] = (BH[1] = [fH], BH), HH[K.m.ce] = (CH[1] = [fH], CH), HH[K.m.Re] = (DH[1] = [function(a) {
            return F(102) && fH(a)
        }], DH), HH[K.m.fd] = (EH[1] = [fH], EH), HH[K.m.Ba] = (FH[1] = [fH], FH), HH[K.m.Va] = (GH[1] = [fH], GH), HH),
        JH = {},
        KH = (JH[K.m.wb] = gH, JH[K.m.Xc] = gH, JH[K.m.ed] = gH, JH[K.m.ce] = gH, JH[K.m.Re] = gH, JH[K.m.fd] = function(a) {
            if (!od(a)) return {};
            var b = pd(a,
                null);
            delete b.match_id;
            return b
        }, JH[K.m.Ba] = hH, JH[K.m.Va] = hH, JH),
        LH = {},
        MH = {},
        NH = (MH[Q.A.eb] = (LH[2] = [fH], LH), MH),
        OH = {};
    var PH = function(a, b, c, d) {
        this.C = a;
        this.M = b;
        this.P = c;
        this.R = d
    };
    PH.prototype.getValue = function(a) {
        a = a === void 0 ? en.W.Fb : a;
        if (!this.M.some(function(b) {
                return b(a)
            })) return this.P.some(function(b) {
            return b(a)
        }) ? this.R(this.C) : this.C
    };
    PH.prototype.H = function() {
        return md(this.C) === "array" || od(this.C) ? pd(this.C, null) : this.C
    };
    var QH = function() {},
        RH = function(a, b) {
            this.conditions = a;
            this.C = b
        },
        SH = function(a, b, c) {
            var d, e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
                f, g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
            return new PH(c, e, g, a.C[b] || QH)
        },
        TH, UH;
    var VH = function(a, b, c) {
            this.eventName = b;
            this.D = c;
            this.C = {};
            this.isAborted = !1;
            this.target = a;
            this.metadata = {};
            for (var d = c.eventMetadata || {}, e = l(Object.keys(d)), f = e.next(); !f.done; f = e.next()) {
                var g = f.value;
                T(this, g, d[g])
            }
        },
        fw = function(a, b) {
            var c, d;
            return (c = a.C[b]) == null ? void 0 : (d = c.getValue) == null ? void 0 : d.call(c, R(a, Q.A.Sf))
        },
        U = function(a, b, c) {
            var d = a.C,
                e;
            c === void 0 ? e = void 0 : (TH != null || (TH = new RH(IH, KH)), e = SH(TH, b, c));
            d[b] = e
        };
    VH.prototype.mergeHitDataForKey = function(a, b) {
        var c, d, e;
        c = (d = this.C[a]) == null ? void 0 : (e = d.H) == null ? void 0 : e.call(d);
        if (!c) return U(this, a, b), !0;
        if (!od(c)) return !1;
        U(this, a, ma(Object, "assign").call(Object, c, b));
        return !0
    };
    var WH = function(a, b) {
        b = b === void 0 ? {} : b;
        for (var c = l(Object.keys(a.C)), d = c.next(); !d.done; d = c.next()) {
            var e = d.value,
                f = void 0,
                g = void 0,
                h = void 0;
            b[e] = (f = a.C[e]) == null ? void 0 : (h = (g = f).H) == null ? void 0 : h.call(g)
        }
        return b
    };
    VH.prototype.copyToHitData = function(a, b, c) {
        var d = N(this.D, a);
        d === void 0 && (d = b);
        if (pb(d) && c !== void 0 && F(92)) try {
            d = c(d)
        } catch (e) {}
        d !== void 0 && U(this, a, d)
    };
    var R = function(a, b) {
            var c = a.metadata[b];
            if (b === Q.A.Sf) {
                var d;
                return c == null ? void 0 : (d = c.H) == null ? void 0 : d.call(c)
            }
            var e;
            return c == null ? void 0 : (e = c.getValue) == null ? void 0 : e.call(c, R(a, Q.A.Sf))
        },
        T = function(a, b, c) {
            var d = a.metadata,
                e;
            c === void 0 ? e = c : (UH != null || (UH = new RH(NH, OH)), e = SH(UH, b, c));
            d[b] = e
        },
        XH = function(a, b) {
            b = b === void 0 ? {} : b;
            for (var c = l(Object.keys(a.metadata)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value,
                    f = void 0,
                    g = void 0,
                    h = void 0;
                b[e] = (f = a.metadata[e]) == null ? void 0 : (h = (g = f).H) == null ? void 0 :
                    h.call(g)
            }
            return b
        },
        zw = function(a, b, c) {
            var d = nx(a.target.destinationId);
            return d && d[b] !== void 0 ? d[b] : c
        };

    function YH(a, b) {
        var c;
        return c
    }
    YH.K = "internal.copyPreHit";

    function ZH(a, b) {
        var c = null;
        return Ed(c, this.J, 2)
    }
    ZH.publicName = "createArgumentsQueue";

    function $H(a) {
        return Ed(function(c) {
            var d = jC();
            if (typeof c === "function") d(function() {
                c(function(f, g, h) {
                    var m =
                        jC(),
                        n = m && m.getByName && m.getByName(f);
                    return (new x.gaplugins.Linker(n)).decorate(g, h)
                })
            });
            else if (Array.isArray(c)) {
                var e = String(c[0]).split(".");
                b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c)
            } else if (c === "isLoaded") return !!d.loaded
        }, this.J, 1)
    }
    $H.K = "internal.createGaCommandQueue";

    function aI(a) {
        return Ed(function() {
                if (!ob(e.push)) throw Error("Object at " + a + " in window is not an array.");
                e.push.apply(e, Array.prototype.slice.call(arguments, 0))
            }, this.J,
            Dh(DF(this).Hb()) ? 2 : 1)
    }
    aI.publicName = "createQueue";

    function bI(a, b) {
        var c = null;
        if (!oh(a) || !ph(b)) throw H(this.getName(), ["string", "string|undefined"], arguments);
        try {
            var d = (b || "").split("").filter(function(e) {
                return "ig".indexOf(e) >= 0
            }).join("");
            c = new Bd(new RegExp(a, d))
        } catch (e) {}
        return c
    }
    bI.K = "internal.createRegex";

    function cI(a) {}
    cI.K = "internal.declareConsentState";

    function dI(a) {
        var b = "";
        return b
    }
    dI.K = "internal.decodeUrlHtmlEntities";

    function eI(a, b, c) {
        var d;
        return d
    }
    eI.K = "internal.decorateUrlWithGaCookies";

    function fI() {}
    fI.K = "internal.deferCustomEvents";

    function gI(a) {
        var b;
        return b
    }
    gI.K = "internal.detectUserProvidedData";

    function lI(a, b) {
        return f
    }
    lI.K = "internal.enableAutoEventOnClick";

    function tI(a, b) {
        return p
    }
    tI.K = "internal.enableAutoEventOnElementVisibility";

    function uI() {}
    uI.K = "internal.enableAutoEventOnError";
    var vI = {},
        wI = [],
        xI = {},
        yI = 0,
        zI = 0;

    function FI(a, b) {
        var c = this;
        return d
    }
    FI.K = "internal.enableAutoEventOnFormInteraction";

    function KI(a, b) {
        var c = this;
        return f
    }
    KI.K = "internal.enableAutoEventOnFormSubmit";

    function PI() {
        var a = this;
    }
    PI.K = "internal.enableAutoEventOnGaSend";
    var QI = {},
        RI = [];

    function YI(a, b) {
        var c = this;
        return f
    }
    YI.K = "internal.enableAutoEventOnHistoryChange";
    var ZI = ["http://", "https://", "javascript:", "file://"];

    function cJ(a, b) {
        var c = this;
        return h
    }
    cJ.K = "internal.enableAutoEventOnLinkClick";
    var dJ, eJ;

    function pJ(a, b) {
        var c = this;
        return d
    }
    pJ.K = "internal.enableAutoEventOnScroll";

    function qJ(a) {
        return function() {
            if (a.limit && a.qj >= a.limit) a.Ah && x.clearInterval(a.Ah);
            else {
                a.qj++;
                var b = Db();
                SD({
                    event: a.eventName,
                    "gtm.timerId": a.Ah,
                    "gtm.timerEventNumber": a.qj,
                    "gtm.timerInterval": a.interval,
                    "gtm.timerLimit": a.limit,
                    "gtm.timerStartTime": a.Bm,
                    "gtm.timerCurrentTime": b,
                    "gtm.timerElapsedTime": b - a.Bm,
                    "gtm.triggers": a.Dq
                })
            }
        }
    }

    function rJ(a, b) {
        return f
    }
    rJ.K = "internal.enableAutoEventOnTimer";
    var pc = Aa(["data-gtm-yt-inspected-"]),
        tJ = ["www.youtube.com", "www.youtube-nocookie.com"],
        uJ, vJ = !1;

    function FJ(a, b) {
        var c = this;
        return e
    }
    FJ.K = "internal.enableAutoEventOnYouTubeActivity";
    vJ = !1;

    function GJ(a, b) {
        if (!oh(a) || !ih(b)) throw H(this.getName(), ["string", "Object|undefined"], arguments);
        var c = b ? C(b) : {},
            d = a,
            e = !1;
        return e
    }
    GJ.K = "internal.evaluateBooleanExpression";
    var HJ;

    function IJ(a) {
        var b = !1;
        return b
    }
    IJ.K = "internal.evaluateMatchingRules";

    function kK() {
        return Er(7) && Er(9) && Er(10)
    };
    var oK = function(a, b) {
            if (!b.isGtmEvent) {
                var c = N(b, K.m.Fc),
                    d = N(b, K.m.jd),
                    e = N(b, c);
                if (e === void 0) {
                    var f = void 0;
                    lK.hasOwnProperty(c) ? f = lK[c] : mK.hasOwnProperty(c) && (f = mK[c]);
                    f === 1 && (f = nK(c));
                    pb(f) ? jC()(function() {
                        var g, h, m, n = (m = (g = jC()) == null ? void 0 : (h = g.getByName) == null ? void 0 : h.call(g, a)) == null ? void 0 : m.get(f);
                        d(n)
                    }) : d(void 0)
                } else d(e)
            }
        },
        pK = function(a, b) {
            var c = a[K.m.ld],
                d = b + ".",
                e = a[K.m.na] || "",
                f = c === void 0 ? !!a.use_anchor : c === "fragment",
                g = !!a[K.m.Jc];
            e = String(e).replace(/\s+/g, "").split(",");
            var h = jC();
            h(d + "require", "linker");
            h(d + "linker:autoLink", e, f, g)
        },
        tK = function(a, b, c) {
            if (!c.isGtmEvent || !qK[a]) {
                var d = !O(K.m.ia),
                    e = function(f) {
                        var g = "gtm" + String(Mp()),
                            h, m = jC(),
                            n = rK(b, "", c),
                            p, q = n.createOnlyFields._useUp;
                        if (c.isGtmEvent || sK(b, n.createOnlyFields)) {
                            c.isGtmEvent && (h = n.createOnlyFields, n.gtmTrackerName && (h.name = g));
                            m(function() {
                                var t, u = m == null ? void 0 : (t = m.getByName) == null ? void 0 : t.call(m, b);
                                u && (p = u.get("clientId"));
                                if (!c.isGtmEvent) {
                                    var v;
                                    m == null || (v = m.remove) == null || v.call(m, b)
                                }
                            });
                            m("create", a, c.isGtmEvent ?
                                h : n.createOnlyFields);
                            d && O(K.m.ia) && (d = !1, m(function() {
                                var t, u, v = (t = jC()) == null ? void 0 : (u = t.getByName) == null ? void 0 : u.call(t, c.isGtmEvent ? g : b);
                                !v || v.get("clientId") == p && q || (c.isGtmEvent ? (n.fieldsToSet["&gcu"] = "1", n.fieldsToSet["&sst.gcut"] = Oo[f]) : (n.fieldsToSend["&gcu"] = "1", n.fieldsToSend["&sst.gcut"] = Oo[f]), v.set(n.fieldsToSet),
                                    c.isGtmEvent ? v.send("pageview") : v.send("pageview", n.fieldsToSend))
                            }));
                            c.isGtmEvent && m(function() {
                                var t;
                                m == null || (t = m.remove) == null || t.call(m, g)
                            })
                        }
                    };
                zp(function() {
                    return void e(K.m.ia)
                }, K.m.ia);
                zp(function() {
                    return void e(K.m.U)
                }, K.m.U);
                zp(function() {
                    return void e(K.m.V)
                }, K.m.V);
                c.isGtmEvent && (qK[a] = !0)
            }
        },
        uK = function(a, b) {
            nl() && b && (a[K.m.qc] = b)
        },
        DK = function(a, b, c) {
            function d() {
                var V = Ca.apply(0, arguments);
                V[0] = w ? w + "." + V[0] : "" + V[0];
                u.apply(window, V)
            }

            function e(V) {
                function ka(ua, Va) {
                    for (var $a = 0; Va &&
                        $a < Va.length; $a++) d(ua, Va[$a])
                }
                var ja = c.isGtmEvent,
                    Y = ja ? vK(y) : wK(b, c);
                if (Y) {
                    var W = {};
                    uK(W, V);
                    d("require", "ec", "ec.js", W);
                    ja && Y.Ri && d("set", "&cu", Y.Ri);
                    var ha = Y.action;
                    if (ja || ha === "impressions")
                        if (ka("ec:addImpression", Y.Xl), !ja) return;
                    if (ha === "promo_click" || ha === "promo_view" || ja && Y.ng) {
                        var wa = Y.ng;
                        ka("ec:addPromo", wa);
                        if (wa && wa.length > 0 && ha === "promo_click") {
                            ja ? d("ec:setAction", ha, Y.Yb) : d("ec:setAction", ha);
                            return
                        }
                        if (!ja) return
                    }
                    ha !== "promo_view" && ha !== "impressions" && (ka("ec:addProduct", Y.Od), d("ec:setAction",
                        ha, Y.Yb))
                }
            }

            function f(V) {
                if (V) {
                    var ka = {};
                    if (od(V))
                        for (var ja in xK) xK.hasOwnProperty(ja) && yK(xK[ja], ja, V[ja], ka);
                    uK(ka, D);
                    d("require", "linkid", ka)
                }
            }

            function g() {
                var V = N(c, K.m.Hn);
                V && (d("require", V, {
                    dataLayer: ik
                }), d("require", "render"))
            }

            function h() {
                var V = N(c, K.m.cf);
                u(function() {
                    if (!c.isGtmEvent && od(V)) {
                        var ka = y.fieldsToSend,
                            ja, Y, W = (ja = v()) == null ? void 0 : (Y = ja.getByName) == null ? void 0 : Y.call(ja, w),
                            ha;
                        for (ha in V)
                            if (V[ha] != null && /^(dimension|metric)\d+$/.test(ha)) {
                                var wa = void 0,
                                    ua = (wa = W) == null ? void 0 :
                                    wa.get(nK(V[ha]));
                                zK(ka, ha, ua)
                            }
                    }
                })
            }

            function m(V, ka, ja) {
                ja && (ka = String(ka));
                y.fieldsToSend[V] = ka
            }

            function n() {
                if (y.displayfeatures) {
                    var V = "_dc_gtm_" + p.replace(/[^A-Za-z0-9-]/g, "");
                    d("require", "displayfeatures", void 0, {
                        cookieName: V
                    })
                }
            }
            var p = a,
                q = Tp(a),
                r = c.eventMetadata[Q.A.Rf];
            if (!(q && r && r.indexOf(q.destinationId) < 0)) {
                wl && (ho = !0, b === K.m.ra ? no(c, a) : (c.eventMetadata[Q.A.Me] || (ko[a] = !0), Pp(c.eventMetadata[Q.A.cb])));
                var t, u = c.isGtmEvent ? mC(N(c, "gaFunctionName")) : mC();
                if (ob(u)) {
                    var v = jC,
                        w;
                    w = c.isGtmEvent ?
                        N(c, "name") || N(c, "gtmTrackerName") : "gtag_" + p.split("-").join("_");
                    var y = rK(w, b, c);
                    !c.isGtmEvent && sK(w, y.createOnlyFields) && (u(function() {
                        var V, ka;
                        v() && ((V = v()) == null || (ka = V.remove) == null || ka.call(V, w))
                    }), AK[w] = !1);
                    u("create", p, y.createOnlyFields);
                    var z = c.isGtmEvent && y.fieldsToSet[K.m.qc];
                    if (!c.isGtmEvent && y.createOnlyFields[K.m.qc] || z) {
                        var B = ml(c.isGtmEvent ? y.fieldsToSet[K.m.qc] : y.createOnlyFields[K.m.qc], "/analytics.js");
                        B && (t = B)
                    }
                    var D = c.isGtmEvent ? y.fieldsToSet[K.m.qc] : y.createOnlyFields[K.m.qc];
                    if (D) {
                        var G = c.isGtmEvent ? y.fieldsToSet[K.m.Ng] : y.createOnlyFields[K.m.Ng];
                        G && !AK[w] && (AK[w] = !0, u(oC(w, G)))
                    }
                    c.isGtmEvent ? y.enableRecaptcha && d("require", "recaptcha", "recaptcha.js") : (h(), f(y.linkAttribution));
                    var I = y[K.m.Ua];
                    I && I[K.m.na] && pK(I, w);
                    d("set", y.fieldsToSet);
                    if (c.isGtmEvent) {
                        if (y.enableLinkId) {
                            var M = {};
                            uK(M, D);
                            d("require", "linkid", "linkid.js", M)
                        }
                        tK(p, w, c)
                    }
                    if (b === K.m.Wc)
                        if (c.isGtmEvent) {
                            n();
                            if (y.remarketingLists) {
                                var S = "_dc_gtm_" + p.replace(/[^A-Za-z0-9-]/g, "");
                                d("require", "adfeatures", {
                                    cookieName: S
                                })
                            }
                            e(D);
                            d("send", "pageview");
                            y.createOnlyFields._useUp && lC(w + ".")
                        } else g(), d("send", "pageview", y.fieldsToSend);
                    else b === K.m.ra ? (g(), Pw(p, c), N(c, K.m.Eb) && (gv(["aw", "dc"]), lC(w + ".")), iv(["aw", "dc"]), y.sendPageView != 0 && d("send", "pageview", y.fieldsToSend), tK(p, w, c)) : b === K.m.Ob ? oK(w, c) : b === "screen_view" ? d("send", "screenview", y.fieldsToSend) : b === "timing_complete" ? (y.fieldsToSend.hitType = "timing", m("timingCategory", y.eventCategory, !0), c.isGtmEvent ? m("timingVar", y.timingVar, !0) : m("timingVar", y.name, !0), m("timingValue",
                        yb(y.value)), y.eventLabel !== void 0 && m("timingLabel", y.eventLabel, !0), d("send", y.fieldsToSend)) : b === "exception" ? d("send", "exception", y.fieldsToSend) : b === "" && c.isGtmEvent || (b === "track_social" && c.isGtmEvent ? (y.fieldsToSend.hitType = "social", m("socialNetwork", y.socialNetwork, !0), m("socialAction", y.socialAction, !0), m("socialTarget", y.socialTarget, !0)) : ((c.isGtmEvent || BK[b]) && e(D), c.isGtmEvent && n(), y.fieldsToSend.hitType = "event", m("eventCategory", y.eventCategory, !0), m("eventAction", y.eventAction || b, !0),
                        y.eventLabel !== void 0 && m("eventLabel", y.eventLabel, !0), y.value !== void 0 && m("eventValue", yb(y.value))), d("send", y.fieldsToSend));
                    var ea = t && !c.eventMetadata[Q.A.Bl];
                    if (!CK && (!c.isGtmEvent || ea)) {
                        CK = !0;
                        var P = function() {
                            c.onFailure()
                        };
                        Jc(t || "https://www.google-analytics.com/analytics.js", function() {
                            var V;
                            ((V = v()) == null ? 0 : V.loaded) || P()
                        }, P)
                    }
                } else Qc(c.onFailure)
            }
        },
        EK = function(a, b, c, d) {
            Ap(function() {
                DK(a, b, d)
            }, [K.m.ia, K.m.U])
        },
        sK = function(a, b) {
            var c = FK[a];
            FK[a] = pd(b, null);
            if (!c) return !1;
            for (var d in b)
                if (b.hasOwnProperty(d) &&
                    b[d] !== c[d]) return !0;
            for (var e in c)
                if (c.hasOwnProperty(e) && c[e] !== b[e]) return !0;
            return !1
        },
        wK = function(a, b) {
            function c(u) {
                return {
                    id: d(K.m.Na),
                    affiliation: d(K.m.jk),
                    revenue: d(K.m.Ca),
                    tax: d(K.m.lk),
                    shipping: d(K.m.de),
                    coupon: d(K.m.kk),
                    list: d(K.m.Xh) || d(K.m.df) || u
                }
            }
            for (var d = function(u) {
                    return N(b, u)
                }, e = d(K.m.wa), f, g = 0; e && g < e.length && !(f = e[g][K.m.Xh] || e[g][K.m.df]); g++);
            var h = d(K.m.cf);
            if (od(h))
                for (var m = 0; e && m < e.length; ++m) {
                    var n = e[m],
                        p;
                    for (p in h) h.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) &&
                        h[p] != null && zK(n, p, n[h[p]])
                }
            var q = null,
                r = d(K.m.yn);
            if (a === K.m.ub || a === K.m.Xd) q = {
                action: a,
                Yb: c(),
                Od: GK(e)
            };
            else if (a === K.m.Ud) q = {
                action: "add",
                Yb: c(),
                Od: GK(e)
            };
            else if (a === K.m.Vd) q = {
                action: "remove",
                Yb: c(),
                Od: GK(e)
            };
            else if (a === K.m.Nb) q = {
                action: "detail",
                Yb: c(f),
                Od: GK(e)
            };
            else if (a === K.m.jc) q = {
                action: "impressions",
                Xl: GK(e)
            };
            else if (a === K.m.kc) q = {
                action: "promo_view",
                ng: GK(r) || GK(e)
            };
            else if (a === "select_content" && r && r.length > 0 || a === K.m.Dc) q = {
                action: "promo_click",
                ng: GK(r) || GK(e)
            };
            else if (a === "select_content" ||
                a === K.m.Wd) q = {
                action: "click",
                Yb: {
                    list: d(K.m.Xh) || d(K.m.df) || f
                },
                Od: GK(e)
            };
            else if (a === K.m.Vc || a === "checkout_progress") {
                var t = {
                    step: a === K.m.Vc ? 1 : d(K.m.Wh),
                    option: d(K.m.Ig)
                };
                q = {
                    action: "checkout",
                    Od: GK(e),
                    Yb: pd(c(), t)
                }
            } else a === "set_checkout_option" && (q = {
                action: "checkout_option",
                Yb: {
                    step: d(K.m.Wh),
                    option: d(K.m.Ig)
                }
            });
            q && (q.Ri = d(K.m.Ya));
            return q
        },
        vK = function(a) {
            var b = a.gtmEcommerceData;
            if (!b) return null;
            var c = {};
            b.currencyCode && (c.Ri = b.currencyCode);
            if (b.impressions) {
                c.action = "impressions";
                var d = b.impressions;
                c.Xl = b.translateIfKeyEquals === "impressions" ? GK(d) : d
            }
            if (b.promoView) {
                c.action = "promo_view";
                var e = b.promoView.promotions;
                c.ng = b.translateIfKeyEquals === "promoView" ? GK(e) : e
            }
            if (b.promoClick) {
                var f = b.promoClick;
                c.action = "promo_click";
                var g = f.promotions;
                c.ng = b.translateIfKeyEquals === "promoClick" ? GK(g) : g;
                c.Yb = f.actionField;
                return c
            }
            for (var h in b)
                if (b[h] !== void 0 && h !== "translateIfKeyEquals" && h !== "impressions" && h !== "promoView" && h !== "promoClick" && h !== "currencyCode") {
                    c.action = h;
                    var m = b[h].products;
                    c.Od = b.translateIfKeyEquals ===
                        "products" ? GK(m) : m;
                    c.Yb = b[h].actionField;
                    break
                }
            return Object.keys(c).length ? c : null
        },
        GK = function(a) {
            function b(e) {
                function f(h, m) {
                    for (var n = 0; n < m.length; n++) {
                        var p = m[n];
                        if (e[p]) {
                            g[h] = e[p];
                            break
                        }
                    }
                }
                var g = pd(e, null);
                f("id", ["id", "item_id", "promotion_id"]);
                f("name", ["name", "item_name", "promotion_name"]);
                f("brand", ["brand", "item_brand"]);
                f("variant", ["variant", "item_variant"]);
                f("list", ["list_name", "item_list_name"]);
                f("position", ["list_position", "creative_slot", "index"]);
                (function() {
                    if (e.category) g.category =
                        e.category;
                    else {
                        for (var h = "", m = 0; m < HK.length; m++) e[HK[m]] !== void 0 && (h && (h += "/"), h += e[HK[m]]);
                        h && (g.category = h)
                    }
                })();
                f("listPosition", ["list_position"]);
                f("creative", ["creative_name"]);
                f("list", ["list_name"]);
                f("position", ["list_position", "creative_slot"]);
                return g
            }
            for (var c = [], d = 0; a && d < a.length; d++) a[d] && od(a[d]) && c.push(b(a[d]));
            return c.length ? c : void 0
        },
        rK = function(a, b, c) {
            var d = function(P) {
                    return N(c, P)
                },
                e = {},
                f = {},
                g = {},
                h = {},
                m = IK(d(K.m.Dn));
            !c.isGtmEvent && m && zK(f, "exp", m);
            g["&gtm"] = Zr({
                La: c.eventMetadata[Q.A.cb],
                qh: !0
            });
            c.isGtmEvent || (g._no_slc = !0);
            rn() && (h._cs = JK);
            var n = d(K.m.cf);
            if (!c.isGtmEvent && od(n))
                for (var p in n)
                    if (n.hasOwnProperty(p) && /^(dimension|metric)\d+$/.test(p) && n[p] != null) {
                        var q = d(String(n[p]));
                        q !== void 0 && zK(f, p, q)
                    }
            for (var r = !c.isGtmEvent, t = jq(c), u = 0; u < t.length; ++u) {
                var v = t[u];
                if (c.isGtmEvent) {
                    var w = d(v);
                    KK.hasOwnProperty(v) ? e[v] = w : LK.hasOwnProperty(v) ? h[v] = w : g[v] = w
                } else {
                    var y = void 0;
                    v !== K.m.ma ? y = d(v) : y = c.getMergedValues(v);
                    if (MK.hasOwnProperty(v)) yK(MK[v], v, y, e);
                    else if (NK.hasOwnProperty(v)) yK(NK[v],
                        v, y, g);
                    else if (mK.hasOwnProperty(v)) yK(mK[v], v, y, f);
                    else if (lK.hasOwnProperty(v)) yK(lK[v], v, y, h);
                    else if (/^(dimension|metric|content_group)\d+$/.test(v)) yK(1, v, y, f);
                    else if (v === K.m.ma) {
                        if (!OK) {
                            var z = Mb(y);
                            z && (f["&did"] = z)
                        }
                        var B = void 0,
                            D = void 0;
                        b === K.m.ra ? B = Mb(c.getMergedValues(v), ".") : (B = Mb(c.getMergedValues(v, 1), "."), D = Mb(c.getMergedValues(v, 2), "."));
                        B && (f["&gdid"] = B);
                        D && (f["&edid"] = D)
                    } else v === K.m.lb && t.indexOf(K.m.bd) < 0 && (h.cookieName = String(y) + "_ga");
                    F(153) && PK[v] && (c.M.hasOwnProperty(v) || b ===
                        K.m.ra && c.C.hasOwnProperty(v)) && (r = !1)
                }
            }
            F(153) && r && (f["&jsscut"] = "1");
            d(K.m.Bg) !== !1 && d(K.m.Pb) !== !1 && kK() || (g.allowAdFeatures = !1);
            g.allowAdPersonalizationSignals = Kr(c);
            !c.isGtmEvent && d(K.m.Eb) && (h._useUp = !0);
            if (c.isGtmEvent) {
                h.name = h.name || e.gtmTrackerName;
                var G = g.hitCallback;
                g.hitCallback = function() {
                    ob(G) && G();
                    c.onSuccess()
                }
            } else {
                zK(h, "cookieDomain", "auto");
                zK(g, "forceSSL", !0);
                zK(e, "eventCategory", QK(b));
                RK[b] && zK(f, "nonInteraction", !0);
                b === "login" || b === "sign_up" || b === "share" ? zK(e, "eventLabel",
                    d(K.m.Fk)) : b === "search" || b === "view_search_results" ? zK(e, "eventLabel", d(K.m.On)) : b === "select_content" && zK(e, "eventLabel", d(K.m.vn));
                var I = e[K.m.Ua] || {},
                    M = I[K.m.pf];
                M || M != 0 && I[K.m.na] ? h.allowLinker = !0 : M === !1 && zK(h, "useAmpClientId", !1);
                f.hitCallback = c.onSuccess;
                h.name = a
            }
            Lr() && (g["&gcs"] = Mr());
            g["&gcd"] = Qr(c);
            rn() && (O(K.m.ia) || (h.storage = "none"), O([K.m.U, K.m.V]) || (g.allowAdFeatures = !1, h.storeGac = !1));
            Tr() && (g["&dma_cps"] = Rr());
            g["&dma"] = Sr();
            or(wr()) && (g["&tcfd"] = Ur());
            yk() && (g["&tag_exp"] = yk());
            var S =
                ol(c) || d(K.m.qc),
                ea = d(K.m.Ng);
            S && (c.isGtmEvent || (h[K.m.qc] = S), h._cd2l = !0);
            ea && !c.isGtmEvent && (h[K.m.Ng] = ea);
            e.fieldsToSend = f;
            e.fieldsToSet = g;
            e.createOnlyFields = h;
            return e
        },
        JK = function(a) {
            return O(a)
        },
        IK = function(a) {
            if (Array.isArray(a)) {
                for (var b = [], c = 0; c < a.length; c++) {
                    var d = a[c];
                    if (d != null) {
                        var e = d.id,
                            f = d.variant;
                        e != null && f != null && b.push(String(e) + "." + String(f))
                    }
                }
                return b.length > 0 ? b.join("!") : void 0
            }
        },
        zK = function(a, b, c) {
            a.hasOwnProperty(b) || (a[b] = c)
        },
        QK = function(a) {
            var b = "general";
            SK[a] ? b = "ecommerce" :
                TK[a] ? b = "engagement" : a === "exception" && (b = "error");
            return b
        },
        nK = function(a) {
            return a && pb(a) ? a.replace(/(_[a-z])/g, function(b) {
                return b[1].toUpperCase()
            }) : a
        },
        yK = function(a, b, c, d) {
            if (c !== void 0)
                if (UK[b] && (c = zb(c)), b !== "anonymize_ip" || c || (c = void 0), a === 1) d[nK(b)] = c;
                else if (pb(a)) d[a] = c;
            else
                for (var e in a) a.hasOwnProperty(e) && c[e] !== void 0 && (d[a[e]] = c[e])
        },
        OK = !1;
    var CK = !1,
        AK = {},
        qK = {},
        VK = {},
        PK = (VK[K.m.Ga] =
            1, VK[K.m.Pb] = 1, VK[K.m.xb] = 1, VK[K.m.yb] = 1, VK[K.m.Cb] = 1, VK[K.m.bd] = 1, VK[K.m.Rb] = 1, VK[K.m.lb] = 1, VK[K.m.Ec] = 1, VK[K.m.Hk] = 1, VK[K.m.Ba] = 1, VK[K.m.rf] = 1, VK[K.m.Va] = 1, VK[K.m.Db] = 1, VK),
        WK = {},
        lK = (WK.client_storage = "storage", WK.sample_rate = 1, WK.site_speed_sample_rate = 1, WK.store_gac = 1, WK.use_amp_client_id = 1, WK[K.m.Qb] = 1, WK[K.m.Ta] = "storeGac", WK[K.m.xb] = 1, WK[K.m.yb] = 1, WK[K.m.Cb] = 1, WK[K.m.bd] = 1, WK[K.m.Rb] = 1, WK[K.m.Ec] = 1, WK),
        XK = {},
        LK = (XK._cs = 1, XK._useUp = 1, XK.allowAnchor = 1, XK.allowLinker = 1, XK.alwaysSendReferrer = 1,
            XK.clientId = 1, XK.cookieDomain = 1, XK.cookieExpires = 1, XK.cookieFlags = 1, XK.cookieName = 1, XK.cookiePath = 1, XK.cookieUpdate = 1, XK.legacyCookieDomain = 1, XK.legacyHistoryImport = 1, XK.name = 1, XK.sampleRate = 1, XK.siteSpeedSampleRate = 1, XK.storage = 1, XK.storeGac = 1, XK.useAmpClientId = 1, XK._cd2l = 1, XK),
        NK = {
            anonymize_ip: 1
        },
        YK = {},
        mK = (YK.campaign = {
                content: "campaignContent",
                id: "campaignId",
                medium: "campaignMedium",
                name: "campaignName",
                source: "campaignSource",
                term: "campaignKeyword"
            }, YK.app_id = 1, YK.app_installer_id = 1, YK.app_name =
            1, YK.app_version = 1, YK.description = "exDescription", YK.fatal = "exFatal", YK.language = 1, YK.page_hostname = "hostname", YK.transport_type = "transport", YK[K.m.Ya] = "currencyCode", YK[K.m.Sg] = 1, YK[K.m.Ba] = "location", YK[K.m.rf] = "page", YK[K.m.Va] = "referrer", YK[K.m.Db] = "title", YK[K.m.gi] = 1, YK[K.m.Ja] = 1, YK),
        ZK = {},
        MK = (ZK.content_id = 1, ZK.event_action = 1, ZK.event_category = 1, ZK.event_label = 1, ZK.link_attribution = 1, ZK.name = 1, ZK[K.m.Ua] = 1, ZK[K.m.Fk] = 1, ZK[K.m.mb] = 1, ZK[K.m.Ca] = 1, ZK),
        KK = {
            displayfeatures: 1,
            enableLinkId: 1,
            enableRecaptcha: 1,
            eventAction: 1,
            eventCategory: 1,
            eventLabel: 1,
            gaFunctionName: 1,
            gtmEcommerceData: 1,
            gtmTrackerName: 1,
            linker: 1,
            remarketingLists: 1,
            socialAction: 1,
            socialNetwork: 1,
            socialTarget: 1,
            timingVar: 1,
            value: 1
        },
        HK = ["item_category", "item_category2", "item_category3", "item_category4", "item_category5"],
        $K = {},
        xK = ($K.levels = 1, $K[K.m.yb] = "duration", $K[K.m.bd] = 1, $K),
        aL = {},
        UK = (aL.anonymize_ip = 1, aL.fatal = 1, aL.send_page_view = 1, aL.store_gac = 1, aL.use_amp_client_id = 1, aL[K.m.Ta] = 1, aL[K.m.Sg] = 1, aL),
        bL = {},
        BK = (bL.checkout_progress = 1,
            bL.select_content = 1, bL.set_checkout_option = 1, bL[K.m.Ud] = 1, bL[K.m.Vd] = 1, bL[K.m.Vc] = 1, bL[K.m.Wd] = 1, bL[K.m.jc] = 1, bL[K.m.Dc] = 1, bL[K.m.kc] = 1, bL[K.m.ub] = 1, bL[K.m.Xd] = 1, bL[K.m.Nb] = 1, bL),
        cL = {},
        SK = (cL.checkout_progress = 1, cL.set_checkout_option = 1, cL[K.m.Xj] = 1, cL[K.m.Yj] = 1, cL[K.m.Ud] = 1, cL[K.m.Vd] = 1, cL[K.m.Zj] = 1, cL[K.m.Vc] = 1, cL[K.m.ub] = 1, cL[K.m.Xd] = 1, cL[K.m.bk] = 1, cL),
        dL = {},
        TK = (dL.generate_lead = 1, dL.login = 1, dL.search = 1, dL.select_content = 1, dL.share = 1, dL.sign_up = 1, dL.view_search_results = 1, dL[K.m.Wd] = 1, dL[K.m.jc] =
            1, dL[K.m.Dc] = 1, dL[K.m.kc] = 1, dL[K.m.Nb] = 1, dL),
        eL = {},
        RK = (eL.view_search_results = 1, eL[K.m.jc] = 1, eL[K.m.kc] = 1, eL[K.m.Nb] = 1, eL),
        FK = {};

    function fL(a, b, c, d) {}
    fL.K = "internal.executeEventProcessor";

    function gL(a) {
        var b;
        return Ed(b, this.J, 1)
    }
    gL.K = "internal.executeJavascriptString";

    function hL(a) {
        var b;
        return b
    };

    function iL(a) {
        var b = "";
        return b
    }
    iL.K = "internal.generateClientId";

    function jL(a) {
        var b = {};
        return Ed(b)
    }
    jL.K = "internal.getAdsCookieWritingOptions";

    function kL(a, b) {
        var c = !1;
        return c
    }
    kL.K = "internal.getAllowAdPersonalization";

    function lL() {
        var a;
        return a
    }
    lL.K = "internal.getAndResetEventUsage";

    function mL(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    mL.K = "internal.getAuid";
    var nL = null;

    function oL() {
        var a = new ab;
        return a
    }
    oL.publicName = "getContainerVersion";

    function pL(a, b) {
        b = b === void 0 ? !0 : b;
        var c;
        return c
    }
    pL.publicName = "getCookieValues";

    function qL() {
        var a = "";
        return a
    }
    qL.K = "internal.getCorePlatformServicesParam";

    function rL() {
        return wo()
    }
    rL.K = "internal.getCountryCode";

    function sL() {
        var a = [];
        return Ed(a)
    }
    sL.K = "internal.getDestinationIds";

    function tL(a) {
        var b = new ab;
        return b
    }
    tL.K = "internal.getDeveloperIds";

    function uL(a) {
        var b;
        return b
    }
    uL.K = "internal.getEcsidCookieValue";

    function vL(a, b) {
        var c = null;
        return c
    }
    vL.K = "internal.getElementAttribute";

    function wL(a) {
        var b = null;
        return b
    }
    wL.K = "internal.getElementById";

    function xL(a) {
        var b = "";
        return b
    }
    xL.K = "internal.getElementInnerText";

    function yL(a, b) {
        var c = null;
        return Ed(c)
    }
    yL.K = "internal.getElementProperty";

    function zL(a) {
        var b;
        return b
    }
    zL.K = "internal.getElementValue";

    function AL(a) {
        var b = 0;
        return b
    }
    AL.K = "internal.getElementVisibilityRatio";

    function BL(a) {
        var b = null;
        return b
    }
    BL.K = "internal.getElementsByCssSelector";

    function CL(a) {
        var b;
        if (!oh(a)) throw H(this.getName(), ["string"], arguments);
        J(this, "read_event_data", a);
        var c;
        a: {
            var d = a,
                e = DF(this).originalEventData;
            if (e) {
                for (var f = e, g = {}, h = {}, m = {}, n = [], p = d.split("\\\\"), q = 0; q < p.length; q++) {
                    for (var r = p[q].split("\\."), t = 0; t < r.length; t++) {
                        for (var u = r[t].split("."), v = 0; v < u.length; v++) n.push(u[v]), v !== u.length - 1 && n.push(m);
                        t !== r.length - 1 && n.push(h)
                    }
                    q !== p.length - 1 && n.push(g)
                }
                for (var w = [], y = "", z = l(n), B = z.next(); !B.done; B =
                    z.next()) {
                    var D = B.value;
                    D === m ? (w.push(y), y = "") : y = D === g ? y + "\\" : D === h ? y + "." : y + D
                }
                y && w.push(y);
                for (var G = l(w), I = G.next(); !I.done; I = G.next()) {
                    if (f == null) {
                        c = void 0;
                        break a
                    }
                    f = f[I.value]
                }
                c = f
            } else c = void 0
        }
        b = Ed(c, this.J, 1);
        return b
    }
    CL.K = "internal.getEventData";
    var DL = {};
    DL.disableUserDataWithoutCcd = F(223);
    DL.enableDecodeUri = F(92);
    DL.enableGaAdsConversions = F(122);
    DL.enableGaAdsConversionsClientId = F(121);
    DL.enableOverrideAdsCps = F(170);
    DL.enableUrlDecodeEventUsage = F(139);

    function EL() {
        return Ed(DL)
    }
    EL.K = "internal.getFlags";

    function FL() {
        var a;
        return a
    }
    FL.K = "internal.getGsaExperimentId";

    function GL() {
        return new Bd(JE)
    }
    GL.K = "internal.getHtmlId";

    function HL(a) {
        var b;
        return b
    }
    HL.K = "internal.getIframingState";

    function IL(a, b) {
        var c = {};
        return Ed(c)
    }
    IL.K = "internal.getLinkerValueFromLocation";

    function JL() {
        var a = new ab;
        return a
    }
    JL.K = "internal.getPrivacyStrings";

    function KL(a, b) {
        var c;
        return c
    }
    KL.K = "internal.getProductSettingsParameter";

    function LL(a, b) {
        var c;
        return c
    }
    LL.publicName = "getQueryParameters";

    function ML(a, b) {
        var c;
        return c
    }
    ML.publicName = "getReferrerQueryParameters";

    function NL(a) {
        var b = "";
        if (!ph(a)) throw H(this.getName(), ["string|undefined"], arguments);
        J(this, "get_referrer", a);
        b = cl(gl(A.referrer), a);
        return b
    }
    NL.publicName = "getReferrerUrl";

    function OL() {
        return xo()
    }
    OL.K = "internal.getRegionCode";

    function PL(a, b) {
        var c;
        return c
    }
    PL.K = "internal.getRemoteConfigParameter";

    function QL() {
        var a = new ab;
        a.set("width", 0);
        a.set("height", 0);
        return a
    }
    QL.K = "internal.getScreenDimensions";

    function RL() {
        var a = "";
        return a
    }
    RL.K = "internal.getTopSameDomainUrl";

    function SL() {
        var a = "";
        return a
    }
    SL.K = "internal.getTopWindowUrl";

    function TL(a) {
        var b = "";
        if (!ph(a)) throw H(this.getName(), ["string|undefined"], arguments);
        J(this, "get_url", a);
        b = al(gl(x.location.href), a);
        return b
    }
    TL.publicName = "getUrl";

    function UL() {
        J(this, "get_user_agent");
        return wc.userAgent
    }
    UL.K = "internal.getUserAgent";

    function VL() {
        var a;
        return a ? Ed(dz(a)) : a
    }
    VL.K = "internal.getUserAgentClientHints";

    function cM() {
        var a = x;
        return a.gaGlobal = a.gaGlobal || {}
    }

    function dM() {
        var a = cM();
        a.hid = a.hid || tb();
        return a.hid
    }

    function eM(a, b) {
        var c = cM();
        if (c.vid === void 0 || b && !c.from_cookie) c.vid = a, c.from_cookie = b
    };

    function CM(a) {
        (zy(a) || Ak()) && U(a, K.m.Qk, xo() || wo());
        !zy(a) && Ak() && U(a, K.m.bl, "::")
    }

    function DM(a) {
        if (Ak() && !zy(a) && (Ao() || U(a, K.m.Ek, !0), F(78))) {
            tw(a);
            uw(a, Qp.Ef.Rm, Uo(N(a.D, K.m.lb)));
            var b = Qp.Ef.Sm;
            var c = N(a.D, K.m.Ec);
            uw(a, b, c === !0 ? 1 : c === !1 ? 0 : void 0);
            uw(a, Qp.Ef.Qm, Uo(N(a.D, K.m.Cb)));
            uw(a, Qp.Ef.Om, Qs(To(N(a.D, K.m.xb)), To(N(a.D, K.m.Rb))))
        }
    };
    var YM = {
        AW: Gn.X.Im,
        G: Gn.X.Tn,
        DC: Gn.X.Rn
    };

    function ZM(a) {
        var b = qj(a);
        return "" + qs(b.map(function(c) {
            return c.value
        }).join("!"))
    }

    function $M(a) {
        var b = Tp(a);
        return b && YM[b.prefix]
    }

    function aN(a, b) {
        var c = a[b];
        c && (c.clearTimerId && x.clearTimeout(c.clearTimerId), c.clearTimerId = x.setTimeout(function() {
            delete a[b]
        }, 36E5))
    };
    var GN = function(a) {
            for (var b = {}, c = String(FN.cookie).split(";"), d = 0; d < c.length; d++) {
                var e = c[d].split("="),
                    f = e[0].replace(/^\s*|\s*$/g, "");
                if (f && a(f)) {
                    var g = e.slice(1).join("=").replace(/^\s*|\s*$/g, "");
                    g && (g = decodeURIComponent(g));
                    var h = void 0,
                        m = void 0;
                    ((h = b)[m = f] || (h[m] = [])).push(g)
                }
            }
            return b
        },
        HN = function() {
            return GN(function(a) {
                return a === "AMP_TOKEN"
            }).AMP_TOKEN || []
        };
    var IN = window,
        FN = document,
        JN = function(a) {
            var b = IN._gaUserPrefs;
            if (b && b.ioo && b.ioo() || FN.documentElement.hasAttribute("data-google-analytics-opt-out") || a && IN["ga-disable-" + a] === !0) return !0;
            try {
                var c = IN.external;
                if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0
            } catch (f) {}
            for (var d = HN(), e = 0; e < d.length; e++)
                if (d[e] == "$OPT_OUT") return !0;
            return FN.getElementById("__gaOptOutExtension") ? !0 : !1
        };

    function VN(a) {
        wb(a, function(c) {
            c.charAt(0) === "_" && delete a[c]
        });
        var b = a[K.m.Wb] || {};
        wb(b, function(c) {
            c.charAt(0) === "_" && delete b[c]
        })
    };

    function DO(a, b) {}

    function EO(a, b) {
        var c = function() {};
        return c
    }

    function FO(a, b, c) {};
    var GO = EO;

    function IO(a, b, c) {
        var d = this;
    }
    IO.K = "internal.gtagConfig";

    function KO(a, b) {}
    KO.publicName = "gtagSet";

    function LO() {
        var a = {};
        return a
    };

    function MO(a) {}
    MO.K = "internal.initializeServiceWorker";

    function NO(a, b) {}
    NO.publicName = "injectHiddenIframe";
    var OO = function() {
        var a = 0;
        return function(b) {
            switch (b) {
                case 1:
                    a |= 1;
                    break;
                case 2:
                    a |= 2;
                    break;
                case 3:
                    a |= 4
            }
            return a
        }
    }();

    function PO(a, b, c, d, e) {
        if (!((oh(a) || nh(a)) && kh(b) && kh(c) && sh(d) && sh(e))) throw H(this.getName(), ["string|OpaqueValue", "function", "function", "boolean|undefined", "boolean|undefined"], arguments);
        var f = DF(this);
        d && OO(3);
        e && (OO(1), OO(2));
        var g = f.eventId,
            h = f.Hb(),
            m = OO(void 0);
        if (vl) {
            var n = String(m) + h;
            oF[g] = oF[g] || [];
            oF[g].push(n);
            pF[g] = pF[g] || [];
            pF[g].push("p" + h)
        }
        if (d && e) throw Error("useIframe and supportDocumentWrite cannot both be true.");
        J(this, "unsafe_inject_arbitrary_html", d, e);
        var p = C(b, this.J),
            q = C(c, this.J),
            r = C(a, this.J, 1);
        QO(r, p, q, !!d, !!e, f);
    }
    var RO = function(a, b, c, d) {
            return function() {
                try {
                    if (b.length > 0) {
                        var e = b.shift(),
                            f = RO(a, b, c, d),
                            g = e;
                        if (String(g.nodeName).toUpperCase() === "SCRIPT" && g.type === "text/gtmscript") {
                            var h = g.text || g.textContent || g.innerHTML || "",
                                m = g.getAttribute("data-gtmsrc"),
                                n = g.charset || "";
                            m ? Jc(m, f, d, {
                                async: !1,
                                id: e.id,
                                text: h,
                                charset: n
                            }, a) : (g = A.createElement("script"), g.async = !1, g.type = "text/javascript", g.id = e.id, g.text = h, g.charset = n, f && (g.onload = f), a.insertBefore(g, null));
                            m || f()
                        } else if (e.innerHTML && e.innerHTML.toLowerCase().indexOf("<script") >=
                            0) {
                            for (var p = []; e.firstChild;) p.push(e.removeChild(e.firstChild));
                            a.insertBefore(e, null);
                            RO(e, p, f, d)()
                        } else a.insertBefore(e, null), f()
                    } else c()
                } catch (q) {
                    d()
                }
            }
        },
        QO = function(a, b, c, d, e, f) {
            if (A.body) {
                var g = OE(a, b, c);
                a = g.Ep;
                b = g.onSuccess;
                if (d) {} else e ?
                    SO(a, b, c) : RO(A.body, Tc(a), b, c)()
            } else x.setTimeout(function() {
                QO(a, b, c, d, e, f)
            })
        };
    PO.K = "internal.injectHtml";
    var TO = {};

    function VO(a, b, c, d) {}
    var WO = {
            dl: 1,
            id: 1
        },
        XO = {};

    function YO(a, b, c, d) {}
    F(160) ? YO.publicName = "injectScript" : VO.publicName = "injectScript";
    YO.K = "internal.injectScript";

    function ZO() {
        return Bo()
    }
    ZO.K = "internal.isAutoPiiEligible";

    function $O(a) {
        var b = !0;
        return b
    }
    $O.publicName = "isConsentGranted";

    function aP(a) {
        var b = !1;
        return b
    }
    aP.K = "internal.isDebugMode";

    function bP() {
        return zo()
    }
    bP.K = "internal.isDmaRegion";

    function cP(a) {
        var b = !1;
        return b
    }
    cP.K = "internal.isEntityInfrastructure";

    function dP(a) {
        var b = !1;
        return b
    }
    dP.K = "internal.isFeatureEnabled";

    function eP() {
        var a = !1;
        return a
    }
    eP.K = "internal.isFpfe";

    function fP() {
        var a = !1;
        return a
    }
    fP.K = "internal.isGcpConversion";

    function gP() {
        var a = !1;
        return a
    }
    gP.K = "internal.isLandingPage";

    function hP() {
        var a = !1;
        return a
    }
    hP.K = "internal.isOgt";

    function iP() {
        var a;
        return a
    }
    iP.K = "internal.isSafariPcmEligibleBrowser";

    function jP() {
        var a = Qh(function(b) {
            DF(this).log("error", b)
        });
        a.publicName = "JSON";
        return a
    };

    function kP(a) {
        var b = void 0;
        if (!oh(a)) throw H(this.getName(), ["string"], arguments);
        b = gl(a);
        return Ed(b)
    }
    kP.K = "internal.legacyParseUrl";

    function lP() {
        return !1
    }
    var mP = {
        getItem: function(a) {
            var b = null;
            return b
        },
        setItem: function(a, b) {
            return !1
        },
        removeItem: function(a) {}
    };

    function nP() {}
    nP.publicName = "logToConsole";

    function oP(a, b) {}
    oP.K = "internal.mergeRemoteConfig";

    function pP(a, b, c) {
        c = c === void 0 ? !0 : c;
        var d = [];
        return Ed(d)
    }
    pP.K = "internal.parseCookieValuesFromString";

    function qP(a) {
        var b = void 0;
        if (typeof a !== "string") return;
        a && Ib(a, "//") && (a = A.location.protocol + a);
        if (typeof URL === "function") {
            var c;
            a: {
                var d;
                try {
                    d = new URL(a)
                } catch (w) {
                    c = void 0;
                    break a
                }
                for (var e = {}, f = Array.from(d.searchParams), g = 0; g < f.length; g++) {
                    var h = f[g][0],
                        m = f[g][1];
                    e.hasOwnProperty(h) ? typeof e[h] === "string" ? e[h] = [e[h], m] : e[h].push(m) : e[h] = m
                }
                c = Ed({
                    href: d.href,
                    origin: d.origin,
                    protocol: d.protocol,
                    username: d.username,
                    password: d.password,
                    host: d.host,
                    hostname: d.hostname,
                    port: d.port,
                    pathname: d.pathname,
                    search: d.search,
                    searchParams: e,
                    hash: d.hash
                })
            }
            return c
        }
        var n;
        try {
            n = gl(a)
        } catch (w) {
            return
        }
        if (!n.protocol || !n.host) return;
        var p = {};
        if (n.search)
            for (var q = n.search.replace("?", "").split("&"), r = 0; r < q.length; r++) {
                var t = q[r].split("="),
                    u = t[0],
                    v = $k(t.splice(1).join("=")) || "";
                v = v.replace(/\+/g, " ");
                p.hasOwnProperty(u) ? typeof p[u] === "string" ? p[u] = [p[u], v] : p[u].push(v) : p[u] = v
            }
        n.searchParams = p;
        n.origin = n.protocol + "//" + n.host;
        n.username = "";
        n.password = "";
        b = Ed(n);
        return b
    }
    qP.publicName = "parseUrl";

    function rP(a) {}
    rP.K = "internal.processAsNewEvent";

    function sP(a, b, c) {
        var d;
        return d
    }
    sP.K = "internal.pushToDataLayer";

    function tP(a) {
        var b = Ca.apply(1, arguments),
            c = !1;
        return c
    }
    tP.publicName = "queryPermission";

    function uP(a) {
        var b = this;
    }
    uP.K = "internal.queueAdsTransmission";

    function vP(a) {
        var b = void 0;
        return b
    }
    vP.publicName = "readAnalyticsStorage";

    function wP() {
        var a = "";
        return a
    }
    wP.publicName = "readCharacterSet";

    function xP() {
        return ik
    }
    xP.K = "internal.readDataLayerName";

    function yP() {
        var a = "";
        return a
    }
    yP.publicName = "readTitle";

    function zP(a, b) {
        var c = this;
    }
    zP.K = "internal.registerCcdCallback";

    function AP(a, b) {
        return !0
    }
    AP.K = "internal.registerDestination";
    var BP = ["config", "event", "get", "set"];

    function CP(a, b, c) {}
    CP.K = "internal.registerGtagCommandListener";

    function DP(a, b) {
        var c = !1;
        return c
    }
    DP.K = "internal.removeDataLayerEventListener";

    function EP(a, b) {}
    EP.K = "internal.removeFormData";

    function FP() {}
    FP.publicName = "resetDataLayer";

    function GP(a, b, c) {
        var d = void 0;
        return d
    }
    GP.K = "internal.scrubUrlParams";

    function HP(a) {}
    HP.K = "internal.sendAdsHit";

    function IP(a, b, c, d) {}
    IP.K = "internal.sendGtagEvent";

    function JP(a, b, c) {}
    JP.publicName = "sendPixel";

    function KP(a, b) {}
    KP.K = "internal.setAnchorHref";

    function LP(a) {}
    LP.K = "internal.setContainerConsentDefaults";

    function MP(a, b, c, d) {
        var e = this;
        d = d === void 0 ? !0 : d;
        var f = !1;
        return f
    }
    MP.publicName = "setCookie";

    function NP(a) {}
    NP.K = "internal.setCorePlatformServices";

    function OP(a, b) {}
    OP.K = "internal.setDataLayerValue";

    function PP(a) {}
    PP.publicName = "setDefaultConsentState";

    function QP(a, b) {}
    QP.K = "internal.setDelegatedConsentType";

    function RP(a, b) {}
    RP.K = "internal.setFormAction";

    function SP(a, b, c) {
        c = c === void 0 ? !1 : c;
    }
    SP.K = "internal.setInCrossContainerData";

    function TP(a, b, c) {
        return !1
    }
    TP.publicName = "setInWindow";

    function UP(a, b, c) {}
    UP.K = "internal.setProductSettingsParameter";

    function VP(a, b, c) {}
    VP.K = "internal.setRemoteConfigParameter";

    function WP(a, b) {}
    WP.K = "internal.setTransmissionMode";

    function XP(a, b, c, d) {
        var e = this;
    }
    XP.publicName = "sha256";

    function YP(a, b, c) {}
    YP.K = "internal.sortRemoteConfigParameters";

    function ZP(a) {}
    ZP.K = "internal.storeAdsBraidLabels";

    function $P(a, b) {
        var c = void 0;
        return c
    }
    $P.K = "internal.subscribeToCrossContainerData";
    var aQ = {},
        bQ = {};
    aQ.getItem = function(a) {
        var b = null;
        return b
    };
    aQ.setItem = function(a, b) {};
    aQ.removeItem = function(a) {};
    aQ.clear = function() {};
    aQ.publicName = "templateStorage";

    function cQ(a, b) {
        var c = !1;
        return c
    }
    cQ.K = "internal.testRegex";

    function dQ(a) {
        var b;
        return b
    };

    function eQ(a, b) {
        var c;
        return c
    }
    eQ.K = "internal.unsubscribeFromCrossContainerData";

    function fQ(a) {}
    fQ.publicName = "updateConsentState";

    function gQ(a) {
        var b = !1;
        return b
    }
    gQ.K = "internal.userDataNeedsEncryption";
    var hQ;

    function iQ(a, b, c) {
        hQ = hQ || new ai;
        hQ.add(a, b, c)
    }

    function jQ(a, b) {
        var c = hQ = hQ || new ai;
        if (c.C.hasOwnProperty(a)) throw Error("Attempting to add a private function which already exists: " + a + ".");
        if (c.contains(a)) throw Error("Attempting to add a private function with an existing API name: " + a + ".");
        c.C[a] = ob(b) ? wh(a, b) : xh(a, b)
    }

    function kQ() {
        return function(a) {
            var b;
            var c = hQ;
            if (c.contains(a)) b = c.get(a, this);
            else {
                var d;
                if (d = c.C.hasOwnProperty(a)) {
                    var e = this.J.rb();
                    if (e) {
                        var f = !1,
                            g = e.Hb();
                        if (g) {
                            Dh(g) || (f = !0);
                        }
                        d = f
                    } else d = !0
                }
                if (d) {
                    var h = c.C.hasOwnProperty(a) ? c.C[a] : void 0;
                    b = h
                } else throw Error(a + " is not a valid API name.");
            }
            return b
        }
    };

    function lQ() {
        var a = function(c) {
                return void jQ(c.K, c)
            },
            b = function(c) {
                return void iQ(c.publicName, c)
            };
        b(xF);
        b(EF);
        b(SG);
        b(UG);
        b(VG);
        b(bH);
        b(dH);
        b(ZH);
        b(jP());
        b(aI);
        b(oL);
        b(pL);
        b(LL);
        b(ML);
        b(NL);
        b(TL);
        b(KO);
        b(NO);
        b($O);
        b(nP);
        b(qP);
        b(tP);
        b(wP);
        b(yP);
        b(JP);
        b(MP);
        b(PP);
        b(TP);
        b(XP);
        b(aQ);
        b(fQ);
        iQ("Math", Bh());
        iQ("Object", Zh);
        iQ("TestHelper", ci());
        iQ("assertApi", yh);
        iQ("assertThat", zh);
        iQ("decodeUri", Eh);
        iQ("decodeUriComponent", Fh);
        iQ("encodeUri", Gh);
        iQ("encodeUriComponent", Hh);
        iQ("fail", Mh);
        iQ("generateRandom",
            Nh);
        iQ("getTimestamp", Oh);
        iQ("getTimestampMillis", Oh);
        iQ("getType", Ph);
        iQ("makeInteger", Rh);
        iQ("makeNumber", Sh);
        iQ("makeString", Th);
        iQ("makeTableMap", Uh);
        iQ("mock", Xh);
        iQ("mockObject", Yh);
        iQ("fromBase64", hL, !("atob" in x));
        iQ("localStorage", mP, !lP());
        iQ("toBase64", dQ, !("btoa" in x));
        a(wF);
        a(AF);
        a(UF);
        a(fG);
        a(mG);
        a(rG);
        a(HG);
        a(QG);
        a(TG);
        a(WG);
        a(XG);
        a(YG);
        a(ZG);
        a($G);
        a(aH);
        a(cH);
        a(eH);
        a(YH);
        a($H);
        a(bI);
        a(cI);
        a(dI);
        a(eI);
        a(fI);
        a(gI);
        a(lI);
        a(tI);
        a(uI);
        a(FI);
        a(KI);
        a(PI);
        a(YI);
        a(cJ);
        a(pJ);
        a(rJ);
        a(FJ);
        a(GJ);
        a(IJ);
        a(fL);
        a(gL);
        a(iL);
        a(jL);
        a(kL);
        a(lL);
        a(mL);
        a(rL);
        a(sL);
        a(tL);
        a(uL);
        a(vL);
        a(wL);
        a(xL);
        a(yL);
        a(zL);
        a(AL);
        a(BL);
        a(CL);
        a(EL);
        a(FL);
        a(GL);
        a(HL);
        a(IL);
        a(JL);
        a(KL);
        a(OL);
        a(PL);
        a(QL);
        a(RL);
        a(SL);
        a(VL);
        a(IO);
        a(MO);
        a(PO);
        a(YO);
        a(ZO);
        a(aP);
        a(bP);
        a(cP);
        a(dP);
        a(eP);
        a(fP);
        a(gP);
        a(hP);
        a(iP);
        a(kP);
        a(FG);
        a(oP);
        a(pP);
        a(rP);
        a(sP);
        a(uP);
        a(xP);
        a(zP);
        a(AP);
        a(CP);
        a(DP);
        a(EP);
        a(GP);
        a(HP);
        a(IP);
        a(KP);
        a(LP);
        a(NP);
        a(OP);
        a(QP);
        a(RP);
        a(SP);
        a(UP);
        a(VP);
        a(WP);
        a(YP);
        a(ZP);
        a($P);
        a(cQ);
        a(eQ);
        a(gQ);
        jQ("internal.IframingStateSchema",
            LO());
        F(104) && a(qL);
        F(160) ? b(YO) : b(VO);
        F(177) && b(vP);
        return kQ()
    };
    var uF;

    function mQ() {
        var a = data.sandboxed_scripts,
            b = data.security_groups;
        a: {
            var c = data.runtime || [],
                d = data.runtime_lines;uF = new $e;nQ();Hf = tF();
            var e = uF,
                f = lQ(),
                g = new xd("require", f);g.Ra();e.C.C.set("require", g);Wa.set("require", g);
            for (var h = [], m = 0; m < c.length; m++) {
                var n = c[m];
                if (!Array.isArray(n) || n.length < 3) {
                    if (n.length === 0) continue;
                    break a
                }
                d && d[m] && d[m].length && bg(n, d[m]);
                try {
                    uF.execute(n), F(120) && vl && n[0] === 50 && h.push(n[1])
                } catch (r) {}
            }
            F(120) && (Uf = h)
        }
        if (a && a.length)
            for (var p = 0; p < a.length; p++) {
                var q = a[p].replace(/^_*/,
                    "");
                wk[q] = ["sandboxedScripts"]
            }
        oQ(b)
    }

    function nQ() {
        uF.Tc(function(a, b, c) {
            Ip.SANDBOXED_JS_SEMAPHORE = Ip.SANDBOXED_JS_SEMAPHORE || 0;
            Ip.SANDBOXED_JS_SEMAPHORE++;
            try {
                return a.apply(b, c)
            } finally {
                Ip.SANDBOXED_JS_SEMAPHORE--
            }
        })
    }

    function oQ(a) {
        a && wb(a, function(b, c) {
            for (var d = 0; d < c.length; d++) {
                var e = c[d].replace(/^_*/, "");
                wk[e] = wk[e] || [];
                wk[e].push(b)
            }
        })
    };

    function pQ(a) {
        gx(ax("developer_id." + a, !0), 0, {})
    };
    var qQ = Array.isArray;

    function rQ(a, b) {
        return pd(a, b || null)
    }

    function X(a) {
        return window.encodeURIComponent(a)
    }

    function sQ(a, b, c) {
        Nc(a, b, c)
    }

    function tQ(a) {
        var b = ["veinteractive.com", "ve-interactive.cn"];
        if (!a) return !1;
        var c = al(gl(a), "host");
        if (!c) return !1;
        for (var d = 0; b && d < b.length; d++) {
            var e = b[d] && b[d].toLowerCase();
            if (e) {
                var f = c.length - e.length;
                f > 0 && e.charAt(0) !== "." && (f--, e = "." + e);
                if (f >= 0 && c.indexOf(e, f) === f) return !0
            }
        }
        return !1
    }

    function uQ(a, b, c) {
        for (var d = {}, e = !1, f = 0; a && f < a.length; f++) a[f] && a[f].hasOwnProperty(b) && a[f].hasOwnProperty(c) && (d[a[f][b]] = a[f][c], e = !0);
        return e ? d : null
    }

    function vQ(a, b) {
        var c = {};
        if (a)
            for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
        if (b) {
            var e = uQ(b, "parameter", "parameterValue");
            e && (c = rQ(e, c))
        }
        return c
    }

    function wQ(a, b, c) {
        return a === void 0 || a === c ? b : a
    }

    function xQ(a, b, c) {
        return Jc(a, b, c, void 0)
    }

    function yQ() {
        return x.location.href
    }

    function zQ(a, b) {
        return Gk(a, b || 2)
    }

    function AQ(a, b) {
        x[a] = b
    }

    function BQ(a, b, c) {
        var d = x;
        b && (d[a] === void 0 || c && !d[a]) && (d[a] = b);
        return d[a]
    }

    var CQ = {};
    var Z = {
        securityGroups: {}
    };

    Z.securityGroups.get_referrer = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Z.__get_referrer = b;
                Z.__get_referrer.F = "get_referrer";
                Z.__get_referrer.isVendorTemplate = !0;
                Z.__get_referrer.priorityOverride = 0;
                Z.__get_referrer.isInfrastructure = !1;
                Z.__get_referrer["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"),
                    b.vtp_query && c.push("query"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!pb(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!pb(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " +
                                    h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    T: a
                }
            })
        }();
    Z.securityGroups.read_event_data = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Z.__read_event_data = b;
                Z.__read_event_data.F = "read_event_data";
                Z.__read_event_data.isVendorTemplate = !0;
                Z.__read_event_data.priorityOverride = 0;
                Z.__read_event_data.isInfrastructure = !1;
                Z.__read_event_data["5"] = !1
            })(function(b) {
                var c = b.vtp_eventDataAccess,
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (g != null && !pb(g)) throw e(f, {
                            key: g
                        }, "Key must be a string.");
                        if (c !== "any") {
                            try {
                                if (c ===
                                    "specific" && g != null && Mg(g, d)) return
                            } catch (h) {
                                throw e(f, {
                                    key: g
                                }, "Invalid key filter.");
                            }
                            throw e(f, {
                                key: g
                            }, "Prohibited read from event data.");
                        }
                    },
                    T: a
                }
            })
        }();

    Z.securityGroups.read_data_layer = ["google"],
        function() {
            function a(b, c) {
                return {
                    key: c
                }
            }(function(b) {
                Z.__read_data_layer = b;
                Z.__read_data_layer.F = "read_data_layer";
                Z.__read_data_layer.isVendorTemplate = !0;
                Z.__read_data_layer.priorityOverride = 0;
                Z.__read_data_layer.isInfrastructure = !1;
                Z.__read_data_layer["5"] = !1
            })(function(b) {
                var c = b.vtp_allowedKeys || "specific",
                    d = b.vtp_keyPatterns || [],
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g) {
                        if (!pb(g)) throw e(f, {}, "Keys must be strings.");
                        if (c !== "any") {
                            try {
                                if (Mg(g,
                                        d)) return
                            } catch (h) {
                                throw e(f, {}, "Invalid key filter.");
                            }
                            throw e(f, {}, "Prohibited read from data layer variable: " + g + ".");
                        }
                    },
                    T: a
                }
            })
        }();









    Z.securityGroups.ua = ["google"],
        function() {
            function a(n, p) {
                for (var q in n)
                    if (!h[q] && n.hasOwnProperty(q)) {
                        var r = g[q] ? zb(n[q]) : n[q];
                        q != "anonymizeIp" || r || (r = void 0);
                        p[q] = r
                    }
            }

            function b(n) {
                var p = {};
                n.vtp_gaSettings && rQ(uQ(n.vtp_gaSettings.vtp_fieldsToSet, "fieldName", "value"), p);
                rQ(uQ(n.vtp_fieldsToSet, "fieldName", "value"), p);
                zb(p.urlPassthrough) && (p._useUp = !0);
                n.vtp_transportUrl && (p._x_19 = n.vtp_transportUrl);
                return p
            }

            function c(n, p) {
                return p === void 0 ? p : n(p)
            }

            function d(n, p, q) {}

            function e(n, p) {
                if (!f && (!Ak() && !bk.M || !p._x_19 || n.vtp_useDebugVersion || n.vtp_useInternalVersion)) {
                    var q = n.vtp_useDebugVersion ? "u/analytics_debug.js" : "analytics.js";
                    n.vtp_useInternalVersion && !n.vtp_useDebugVersion && (q = "internal/" + q);
                    f = !0;
                    var r = n.vtp_gtmOnFailure,
                        t = ml(p._x_19, "/analytics.js"),
                        u = Kw("https:", "http:", "//www.google-analytics.com/" + q, p && !!p.forceSSL);
                    xQ(q === "analytics.js" && t ? t : u, function() {
                        var v = jC();
                        v && v.loaded ||
                            r();
                    }, r)
                }
            }
            var f, g = {
                    allowAnchor: !0,
                    allowLinker: !0,
                    alwaysSendReferrer: !0,
                    anonymizeIp: !0,
                    cookieUpdate: !0,
                    exFatal: !0,
                    forceSSL: !0,
                    javaEnabled: !0,
                    legacyHistoryImport: !0,
                    nonInteraction: !0,
                    useAmpClientId: !0,
                    useBeacon: !0,
                    storeGac: !0,
                    allowAdFeatures: !0,
                    allowAdPersonalizationSignals: !0,
                    _cd2l: !0
                },
                h = {
                    urlPassthrough: !0
                },
                m = function(n) {
                    function p() {
                        if (n.vtp_doubleClick || n.vtp_advertisingFeaturesType == "DISPLAY_FEATURES") w.displayfeatures = !0
                    }
                    var q = {},
                        r = {},
                        t = {};
                    if (n.vtp_gaSettings) {
                        var u = n.vtp_gaSettings;
                        rQ(uQ(u.vtp_contentGroup, "index", "group"), q);
                        rQ(uQ(u.vtp_dimension, "index", "dimension"), r);
                        rQ(uQ(u.vtp_metric, "index", "metric"), t);
                        var v = rQ(u);
                        v.vtp_fieldsToSet = void 0;
                        v.vtp_contentGroup = void 0;
                        v.vtp_dimension = void 0;
                        v.vtp_metric = void 0;
                        n = rQ(n, v)
                    }
                    rQ(uQ(n.vtp_contentGroup, "index", "group"), q);
                    rQ(uQ(n.vtp_dimension, "index", "dimension"), r);
                    rQ(uQ(n.vtp_metric, "index", "metric"), t);
                    var w = b(n),
                        y = String(n.vtp_trackingId || ""),
                        z = "",
                        B = "",
                        D = "";
                    n.vtp_setTrackerName &&
                        typeof n.vtp_trackerName == "string" ? n.vtp_trackerName !== "" && (D = n.vtp_trackerName, B = D + ".") : (D = "gtm" + String(Mp()), B = D + ".");
                    var G = function(wa, ua) {
                        for (var Va in ua) ua.hasOwnProperty(Va) && (w[wa + Va] = ua[Va])
                    };
                    G("contentGroup", q);
                    G("dimension", r);
                    G("metric", t);
                    n.vtp_enableEcommerce && (z = n.vtp_gtmCachedValues.event, w.gtmEcommerceData = d(n, w, z));
                    if (n.vtp_trackType === "TRACK_EVENT") z = "track_event", p(), w.eventCategory = String(n.vtp_eventCategory), w.eventAction = String(n.vtp_eventAction), w.eventLabel = c(String, n.vtp_eventLabel),
                        w.value = c(yb, n.vtp_eventValue);
                    else if (n.vtp_trackType == "TRACK_PAGEVIEW") {
                        if (z = K.m.Wc, p(), n.vtp_advertisingFeaturesType == "DISPLAY_FEATURES_WITH_REMARKETING_LISTS" && (w.remarketingLists = !0), n.vtp_autoLinkDomains) {
                            var I = {};
                            I[K.m.na] = n.vtp_autoLinkDomains;
                            I.use_anchor = n.vtp_useHashAutoLink;
                            I[K.m.Jc] = n.vtp_decorateFormsAutoLink;
                            w[K.m.Ua] = I
                        }
                    } else n.vtp_trackType === "TRACK_SOCIAL" ? (z = "track_social", w.socialNetwork = String(n.vtp_socialNetwork), w.socialAction = String(n.vtp_socialAction), w.socialTarget = String(n.vtp_socialActionTarget)) :
                        n.vtp_trackType == "TRACK_TIMING" && (z = "timing_complete", w.eventCategory = String(n.vtp_timingCategory), w.timingVar = String(n.vtp_timingVar), w.value = yb(n.vtp_timingValue), w.eventLabel = c(String, n.vtp_timingLabel));
                    n.vtp_enableRecaptcha && (w.enableRecaptcha = !0);
                    n.vtp_enableLinkId && (w.enableLinkId = !0);
                    var M = {};
                    a(w, M);
                    w.name || (M.gtmTrackerName = D);
                    M.gaFunctionName = n.vtp_functionName;
                    n.vtp_nonInteraction !== void 0 && (M.nonInteraction = n.vtp_nonInteraction);
                    var S = wq(vq(uq(tq(mq(new lq(n.vtp_gtmEventId, n.vtp_gtmPriorityId),
                        M), n.vtp_gtmOnSuccess), n.vtp_gtmOnFailure), !0));
                    n.vtp_useDebugVersion && n.vtp_useInternalVersion && (S.eventMetadata[Q.A.Bl] = !0);
                    EK(y, z, Date.now(), S);
                    var ea = mC(n.vtp_functionName);
                    if (ob(ea)) {
                        var P = function(wa) {
                            var ua = [].slice.call(arguments, 0);
                            ua[0] = B + ua[0];
                            ea.apply(window, ua)
                        };
                        if (n.vtp_trackType == "TRACK_TRANSACTION") {} else if (n.vtp_trackType == "DECORATE_LINK") {} else if (n.vtp_trackType == "DECORATE_FORM") {} else if (n.vtp_trackType == "TRACK_DATA") {}
                        e(n, w)
                    } else Qc(n.vtp_gtmOnFailure)
                };
            Z.__ua = m;
            Z.__ua.F = "ua";
            Z.__ua.isVendorTemplate = !0;
            Z.__ua.priorityOverride = 0;
            Z.__ua.isInfrastructure = !1;
            Z.__ua["5"] = !1
        }();
    Z.securityGroups.get_url = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    component: c,
                    queryKey: d
                }
            }(function(b) {
                Z.__get_url = b;
                Z.__get_url.F = "get_url";
                Z.__get_url.isVendorTemplate = !0;
                Z.__get_url.priorityOverride = 0;
                Z.__get_url.isInfrastructure = !1;
                Z.__get_url["5"] = !1
            })(function(b) {
                var c = b.vtp_urlParts === "any" ? null : [];
                c && (b.vtp_protocol && c.push("protocol"), b.vtp_host && c.push("host"), b.vtp_port && c.push("port"), b.vtp_path && c.push("path"), b.vtp_extension && c.push("extension"), b.vtp_query && c.push("query"), b.vtp_fragment &&
                    c.push("fragment"));
                var d = c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
                    e = b.vtp_createPermissionError;
                return {
                    assert: function(f, g, h) {
                        if (g) {
                            if (!pb(g)) throw e(f, {}, "URL component must be a string.");
                            if (c && c.indexOf(g) < 0) throw e(f, {}, "Prohibited URL component: " + g);
                            if (g === "query" && d) {
                                if (!h) throw e(f, {}, "Prohibited from getting entire URL query when query keys are specified.");
                                if (!pb(h)) throw e(f, {}, "Query key must be a string.");
                                if (d.indexOf(h) < 0) throw e(f, {}, "Prohibited query key: " + h);
                            }
                        } else if (c) throw e(f, {}, "Prohibited from getting entire URL when components are specified.");
                    },
                    T: a
                }
            })
        }();


    Z.securityGroups.gas = ["google"], Z.__gas = function(a) {
        var b = rQ(a),
            c = b;
        c[lf.Oa] = null;
        c[lf.yi] = null;
        var d = b = c;
        d.vtp_fieldsToSet = d.vtp_fieldsToSet || [];
        var e = d.vtp_cookieDomain;
        e !== void 0 && (d.vtp_fieldsToSet.push({
            fieldName: "cookieDomain",
            value: e
        }), delete d.vtp_cookieDomain);
        return b
    }, Z.__gas.F = "gas", Z.__gas.isVendorTemplate = !0, Z.__gas.priorityOverride = 0, Z.__gas.isInfrastructure = !1, Z.__gas["5"] = !0;


    Z.securityGroups.unsafe_inject_arbitrary_html = ["google"],
        function() {
            function a(b, c, d) {
                return {
                    useIframe: c,
                    supportDocumentWrite: d
                }
            }(function(b) {
                Z.__unsafe_inject_arbitrary_html = b;
                Z.__unsafe_inject_arbitrary_html.F = "unsafe_inject_arbitrary_html";
                Z.__unsafe_inject_arbitrary_html.isVendorTemplate = !0;
                Z.__unsafe_inject_arbitrary_html.priorityOverride = 0;
                Z.__unsafe_inject_arbitrary_html.isInfrastructure = !1;
                Z.__unsafe_inject_arbitrary_html["5"] = !1
            })(function(b) {
                var c = b.vtp_createPermissionError;
                return {
                    assert: function(d,
                        e, f) {
                        if (e && f) throw c(d, {}, "Only one of useIframe and supportDocumentWrite can be true.");
                        if (e !== void 0 && typeof e !== "boolean") throw c(d, {}, "useIframe must be a boolean.");
                        if (f !== void 0 && typeof f !== "boolean") throw c(d, {}, "supportDocumentWrite must be a boolean.");
                    },
                    T: a
                }
            })
        }();






    var Lp = {
        dataLayer: Hk,
        callback: function(a) {
            vk.hasOwnProperty(a) && ob(vk[a]) && vk[a]();
            delete vk[a]
        },
        bootstrap: 0
    };
    Lp.onHtmlSuccess = PE(!0), Lp.onHtmlFailure = PE(!1);

    function DQ() {
        Kp();
        Wm();
        VB();
        Gb(wk, Z.securityGroups);
        var a = Tm(Im()),
            b, c = a == null ? void 0 : (b = a.context) == null ? void 0 : b.source;
        ip(c, a == null ? void 0 : a.parent);
        c !== 2 && c !== 4 && c !== 3 || L(142);
        LE(), Qf({
            Jp: function(d) {
                return d === JE
            },
            Oo: function(d) {
                return new ME(d)
            },
            Kp: function(d) {
                for (var e = !1, f = !1, g = 2; g < d.length; g++) e = e || d[g] === 8, f = f || d[g] === 16;
                return e && f
            },
            Zp: function(d) {
                var e;
                if (d === JE) e = d;
                else {
                    var f = Mp();
                    KE[f] = d;
                    e = 'google_tag_manager["rm"]["' + Qm() + '"](' + f + ")"
                }
                return e
            }
        });
        Tf = {
            Jo: hg
        }
    }
    var EQ = !1;
    F(218) && (EQ = Oi(47, EQ));

    function to() {
        try {
            if (EQ || !cn()) {
                ek();
                bk.P = Pi(18, "");
                bk.nb = Si(4, 'ad_storage|analytics_storage|ad_user_data|ad_personalization');
                bk.Pa = Si(5, 'ad_storage|analytics_storage|ad_user_data');
                bk.Da = Si(11, '57f0');
                bk.Da = Si(10, '57v0');
                if (F(109)) {}
                Sa[7] = !0;
                var a = Jp("debugGroupId", function() {
                    return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
                });
                pp(a);
                Hp();
                hF();
                xr();
                Np();
                if (Xm()) {
                    CG();
                    LC().removeExternalRestrictions(Qm());
                } else {
                    Rf();
                    Nf = Z;
                    Of = SE;
                    jg = new qg;
                    mQ();
                    DQ();
                    QE();
                    ro || (qo = vo());
                    Dp();
                    ZD();
                    Wi();
                    mD();
                    GD = !1;
                    A.readyState === "complete" ? ID() : Oc(x, "load", ID);
                    gD();
                    vl && (Aq(Oq), x.setInterval(Nq, 864E5), Aq(iF), Aq(yC), Aq(oA), Aq(Sq), Aq(qF), Aq(JC), F(120) && (Aq(DC), Aq(EC), Aq(FC)), jF = {}, kF = {}, Aq(mF), Aq(nF), Ti());
                    wl && (eo(), gq(), aE(), hE(), fE(), Wn("bt", String(bk.C ? 2 : bk.M ? 1 : 0)), Wn("ct", String(bk.C ? 0 : bk.M ? 1 : 3)), dE());
                    HE();
                    oo(1);
                    DG();
                    mE();
                    uk = Db();
                    Lp.bootstrap = uk;
                    bk.la && YD();
                    F(109) && KA();
                    F(134) && (typeof x.name === "string" && Ib(x.name, "web-pixel-sandbox-CUSTOM") && ed() ? pQ("dMDg0Yz") : x.Shopify && (pQ("dN2ZkMj"), ed() && pQ("dNTU0Yz")))
                }
            }
        } catch (b) {
            oo(4), Kq()
        }
    }
    (function(a) {
        function b() {
            n = A.documentElement.getAttribute("data-tag-assistant-present");
            Wo(n) && (m = h.Wk)
        }

        function c() {
            m && zc ? g(m) : a()
        }
        if (!x[Pi(37, "__TAGGY_INSTALLED")]) {
            var d = !1;
            if (A.referrer) {
                var e = gl(A.referrer);
                d = cl(e, "host") === Pi(38, "cct.google")
            }
            if (!d) {
                var f = zs(Pi(39, "googTaggyReferrer"));
                d = !(!f.length || !f[0].length)
            }
            d && (x[Pi(37, "__TAGGY_INSTALLED")] = !0, Jc(Pi(40, "https://cct.google/taggy/agent.js")))
        }
        var g = function(u) {
                var v = "GTM",
                    w = "GTM";
                pk && (v = "OGT", w = "GTAG");
                var y = Pi(23, "google.tagmanager.debugui2.queue"),
                    z = x[y];
                z || (z = [], x[y] = z, Jc("https://" + fk.yg + "/debug/bootstrap?id=" + ng.ctid + "&src=" + w + "&cond=" + String(u) + "&gtm=" + Zr()));
                var B = {
                    messageType: "CONTAINER_STARTING",
                    data: {
                        scriptSource: zc,
                        containerProduct: v,
                        debug: !1,
                        id: ng.ctid,
                        targetRef: {
                            ctid: ng.ctid,
                            isDestination: Om()
                        },
                        aliases: Rm(),
                        destinations: Pm()
                    }
                };
                B.data.resume = function() {
                    a()
                };
                fk.Nm && (B.data.initialPublish = !0);
                z.push(B)
            },
            h = {
                Wn: 1,
                Zk: 2,
                sl: 3,
                Uj: 4,
                Wk: 5
            };
        h[h.Wn] = "GTM_DEBUG_LEGACY_PARAM";
        h[h.Zk] = "GTM_DEBUG_PARAM";
        h[h.sl] = "REFERRER";
        h[h.Uj] = "COOKIE";
        h[h.Wk] = "EXTENSION_PARAM";
        var m = void 0,
            n = void 0,
            p = al(x.location, "query", !1, void 0, "gtm_debug");
        Wo(p) && (m = h.Zk);
        if (!m && A.referrer) {
            var q = gl(A.referrer);
            cl(q, "host") === Pi(24, "tagassistant.google.com") && (m = h.sl)
        }
        if (!m) {
            var r = zs("__TAG_ASSISTANT");
            r.length && r[0].length && (m = h.Uj)
        }
        m || b();
        if (!m && Vo(n)) {
            var t = !1;
            Oc(A, "TADebugSignal", function() {
                t || (t = !0, b(), c())
            }, !1);
            x.setTimeout(function() {
                t || (t = !0, b(), c())
            }, 200)
        } else c()
    })(function() {
        F(83) && EQ && !vo()["0"] ? so() : to()
    });

})()