(function() {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis;

    function ha(a, b) {
        if (b) a: {
            var c = ba;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && aa(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    ha("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var m = this || self;

    function ia(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = m, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    }

    function ja(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function t(a, b, c) {
        t = ja;
        return t.apply(null, arguments)
    }

    function ka(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.N = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.O = function(d, e, g) {
            for (var f = Array(arguments.length - 2), k = 2; k < arguments.length; k++) f[k - 2] = arguments[k];
            return b.prototype[e].apply(d, f)
        }
    };

    function la(a) {
        m.setTimeout(() => {
            throw a;
        }, 0)
    };
    var ma = ia(748402147, ia(1, !0));

    function u(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    let na = void 0;

    function oa(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var pa = oa(),
        v = oa("m_m", !0);
    const w = oa("jas", !0);
    var qa;
    const ra = [];
    ra[w] = 7;
    qa = Object.freeze(ra);
    var y = {};

    function z(a, b) {
        return b === void 0 ? a.h !== A && !!(2 & (a.g[w] | 0)) : !!(2 & b) && a.h !== A
    }
    const A = {};
    var sa = Object.freeze({});
    const ta = BigInt(Number.MIN_SAFE_INTEGER),
        ua = BigInt(Number.MAX_SAFE_INTEGER);
    const va = Number.isFinite;

    function ya(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return va(a) ? a | 0 : void 0
    }

    function za(a, b, c) {
        if (a != null && a[v] === y) return a;
        if (Array.isArray(a)) {
            var d = a[w] | 0;
            c = d | c & 32 | c & 2;
            c !== d && (a[w] = c);
            return new b(a)
        }
    };

    function Aa(a) {
        return a
    };

    function Ba(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        const g = [];
        var f = a.length;
        let k, h = 4294967295,
            l = !1;
        const n = !!(b & 64),
            p = n ? b & 128 ? 0 : -1 : void 0;
        b & 1 || (k = f && a[f - 1], k != null && typeof k === "object" && k.constructor === Object ? (f--, h = f) : k = void 0, !n || b & 128 || e || (l = !0, h = (Ca ? ? Aa)(h - p, p, a, k, void 0) + p));
        b = void 0;
        for (e = 0; e < f; e++) {
            let r = a[e];
            if (r != null && (r = c(r, d)) != null)
                if (n && e >= h) {
                    const q = e - p;
                    (b ? ? (b = {}))[q] = r
                } else g[e] = r
        }
        if (k)
            for (let r in k) {
                a = k[r];
                if (a == null || (a = c(a, d)) == null) continue;
                f = +r;
                let q;
                n && !Number.isNaN(f) && (q = f + p) <
                    h ? g[q] = a : (b ? ? (b = {}))[r] = a
            }
        b && (l ? g.push(b) : g[h] = b);
        return g
    }

    function Da(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return a >= ta && a <= ua ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    const b = a[w] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Ba(a, b, Da)
                }
                if (a != null && a[v] === y) return Ea(a);
                return
        }
        return a
    }
    let Ca;

    function Ea(a) {
        a = a.g;
        return Ba(a, a[w] | 0, Da)
    };

    function Fa(a) {
        if (a == null) {
            var b = 32;
            a = []
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            b = a[w] | 0;
            if (ma && 1 & b) throw Error("rfarr");
            2048 & b && !(2 & b) && Ga();
            if (b & 256) throw Error("farr");
            if (b & 64) return b & 2048 || (a[w] = b | 2048), a;
            var c = a;
            b |= 64;
            var d = c.length;
            if (d) {
                var e = d - 1;
                d = c[e];
                if (d != null && typeof d === "object" && d.constructor === Object) {
                    const g = b & 128 ? 0 : -1;
                    e -= g;
                    if (e >= 1024) throw Error("pvtlmt");
                    for (const f in d) {
                        const k = +f;
                        if (k < e) c[k + g] = d[f], delete d[f];
                        else break
                    }
                    b = b & -8380417 | (e & 1023) << 13
                }
            }
        }
        a[w] = b | 2112;
        return a
    }

    function Ga() {
        if (ma) throw Error("carr");
        if (pa != null) {
            var a = na ? ? (na = {});
            var b = a[pa] || 0;
            b >= 5 || (a[pa] = b + 1, a = Error(), a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {}), a.__closure__error__context__984382.severity = "incident", la(a))
        }
    };

    function Ha(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[w] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = B(a, c, !1, b && !(c & 16)) : (a[w] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[v] === y) return b = a.g, c = b[w] | 0, z(a, c) ? a : Ia(a, b, c) ? Ja(a, b) : B(b, c)
    }

    function Ja(a, b, c) {
        a = new a.constructor(b);
        c && (a.h = A);
        a.i = A;
        return a
    }

    function B(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = Ba(a, b, Ha, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        a[w] = b;
        return a
    }

    function Ka(a) {
        const b = a.g,
            c = b[w] | 0;
        if (z(a, c)) {
            var d;
            Ia(a, b, c) ? d = Ja(a, b, !0) : d = new a.constructor(B(b, c, !1));
            a = d
        }
        return a
    }

    function La(a) {
        if (a.h !== A) return !1;
        var b = a.g;
        b = B(b, b[w] | 0);
        b[w] |= 2048;
        a.g = b;
        a.h = void 0;
        a.i = void 0;
        return !0
    }

    function Ma(a, b) {
        b === void 0 && (b = a[w] | 0);
        b & 32 && !(b & 4096) && (a[w] = b | 4096)
    }

    function Ia(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[w] = c | 2, a.h = A, !0) : !1
    };

    function E(a, b) {
        a = Na(a.g, b);
        if (a !== null) return a
    }

    function Na(a, b, c, d) {
        if (b === -1) return null;
        const e = b + (c ? 0 : -1),
            g = a.length - 1;
        let f, k;
        if (!(g < 1 + (c ? 0 : -1))) {
            if (e >= g)
                if (f = a[g], f != null && typeof f === "object" && f.constructor === Object) c = f[b], k = !0;
                else if (e === g) c = f;
            else return;
            else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return k ? f[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function F(a, b, c) {
        var d = a.length - 1;
        if (d >= 0 && 0 >= d) {
            const e = a[d];
            if (e != null && typeof e === "object" && e.constructor === Object) return e[1] = c, b
        }
        if (0 <= d) return a[0] = c, b;
        c !== void 0 && (d = (b ? ? (b = a[w] | 0)) >> 13 & 1023 || 536870912, 1 >= d ? c != null && (a[d + -1] = {
            [1]: c
        }) : a[0] = c);
        return b
    }

    function G(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Oa(a, b) {
        var c = Pa;
        let d = !1;
        const e = Na(a, 1, void 0, g => {
            const f = za(g, c, b);
            d = f !== g && f != null;
            return f
        });
        if (e != null) return d && !z(e) && Ma(a, b), e
    }

    function Qa(a) {
        let b = a.g,
            c = b[w] | 0,
            d = Oa(b, c);
        if (d == null) return d;
        c = b[w] | 0;
        if (!z(a, c)) {
            const e = Ka(d);
            e !== d && (La(a) && (b = a.g, c = b[w] | 0), d = e, c = F(b, c, d), Ma(b, c))
        }
        return d
    }

    function Ra(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function H(a) {
        a = E(a, 1);
        return a == null || typeof a === "string" ? a : void 0
    }

    function I(a, b) {
        a = E(a, b);
        return (a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0) ? ? !1
    }

    function J(a, b) {
        return ya(E(a, b)) ? ? 0
    }

    function K(a, b) {
        a = E(a, b);
        return (a == null ? a : va(a) ? a | 0 : void 0) ? ? 1
    };
    var L = class {
        constructor(a) {
            this.g = Fa(a)
        }
        toJSON() {
            return Ea(this)
        }
    };
    L.prototype[v] = y;
    L.prototype.toString = function() {
        return this.g.toString()
    };
    var Sa = class extends L {};

    function Ta(a) {
        var b = a.g,
            c = b,
            d = b[w] | 0;
        b = void 0 === sa ? 2 : 4;
        var e = z(a, d);
        const g = e ? 1 : b;
        b = g === 3;
        var f = !e;
        (g === 2 || f) && La(a) && (c = a.g, d = c[w] | 0);
        a = Na(c, 1);
        e = Array.isArray(a) ? a : qa;
        var k = e === qa ? 7 : e[w] | 0;
        a = k;
        2 & d && (a |= 2);
        var h = a | 1;
        if (a = !(4 & h)) {
            var l = e,
                n = d;
            const p = !!(2 & h);
            p && (n |= 2);
            let r = !p,
                q = !0,
                C = 0,
                x = 0;
            for (; C < l.length; C++) {
                const D = za(l[C], Sa, n);
                if (D instanceof Sa) {
                    if (!p) {
                        const X = z(D);
                        r && (r = !X);
                        q && (q = X)
                    }
                    l[x++] = D
                }
            }
            x < C && (l.length = x);
            h |= 4;
            h = q ? h & -4097 : h | 4096;
            h = r ? h | 8 : h & -9
        }
        h !== k && (e[w] = h, 2 & h && Object.freeze(e));
        if (f &&
            !(8 & h || !e.length && (g === 1 || (g !== 4 ? 0 : 2 & h || !(16 & h) && 32 & d)))) {
            G(h) && (e = [...e], h = Ra(h, d), d = F(c, d, e));
            f = e;
            k = h;
            for (l = 0; l < f.length; l++) h = f[l], n = Ka(h), h !== n && (f[l] = n);
            k |= 8;
            h = k = f.length ? k | 4096 : k & -4097;
            e[w] = h
        }
        k = f = h;
        g === 1 || (g !== 4 ? 0 : 2 & f || !(16 & f) && 32 & d) ? G(f) || (f |= !e.length || a && !(4096 & f) || 32 & d && !(4096 & f || 16 & f) ? 2 : 256, f !== k && (e[w] = f), Object.freeze(e)) : (g === 2 && G(f) && (e = [...e], k = 0, f = Ra(f, d), d = F(c, d, e)), G(f) || (b || (f |= 16), f !== k && (e[w] = f)));
        2 & f || !(4096 & f || 16 & f) || Ma(c, d);
        return e
    }
    var Pa = class extends L {};
    var Ua = class extends L {};

    function Va() {}

    function Wa(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var M = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g
            }
        },
        Xa = new M("about:invalid#zClosurez");
    class Ya {
        constructor(a) {
            this.M = a
        }
    }

    function N(a) {
        return new Ya(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const Za = new Ya(a => /^[^:]*([/?#]|$)/.test(a));
    var $a = N("http"),
        ab = N("https"),
        bb = N("ftp"),
        cb = N("mailto");
    const db = [N("data"), $a, ab, cb, bb, Za];

    function eb(a = db) {
        for (let b = 0; b < a.length; ++b) {
            const c = a[b];
            if (c instanceof Ya && c.M("#")) return new M("#")
        }
    }

    function fb(a = db) {
        return eb(a) || Xa
    }
    var gb = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function hb(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function ib(a = document) {
        return a.createElement("img")
    };
    let O = [];

    function jb() {
        const a = O;
        O = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var kb = {
            capture: !0
        },
        lb = {
            passive: !0
        },
        mb = Wa(() => {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                m.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function nb(a) {
        return a ? a.passive && mb() ? a : a.capture || !1 : !1
    }

    function P(a, b, c, d) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, nb(d))
    }

    function ob(a) {
        var b = Q;
        b.readyState === "complete" || b.readyState === "interactive" ? (O.push(a), O.length === 1 && (window.Promise ? Promise.resolve().then(jb) : (a = window.setImmediate, typeof a === "function" ? a(jb) : setTimeout(jb, 0)))) : b.addEventListener("DOMContentLoaded", a)
    };

    function pb(a, b, c = null, d = !1) {
        qb(a, b, c, d)
    }

    function qb(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const e = ib(a.document);
        if (c || d) {
            const g = f => {
                c && c(f);
                if (d) {
                    f = a.google_image_requests;
                    var k = Array.prototype.indexOf.call(f, e, void 0);
                    k >= 0 && Array.prototype.splice.call(f, k, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", g, nb());
                typeof e.removeEventListener === "function" && e.removeEventListener("error", g, nb())
            };
            P(e, "load", g);
            P(e, "error", g)
        }
        e.src = b;
        a.google_image_requests.push(e)
    };

    function rb(a = null) {
        return a && a.getAttribute("data-jc") === "23" ? a : document.querySelector('[data-jc="23"]')
    }

    function sb() {
        if (!(Math.random() > .01)) {
            var a = rb(document.currentScript);
            a = a && a.getAttribute("data-jc-rcd") === "true" ? "pagead2.googlesyndication-cn.com" : "pagead2.googlesyndication.com";
            var b = (b = rb(document.currentScript)) && b.getAttribute("data-jc-version") || "unknown";
            a = `https://${a}/pagead/gen_204?id=jca&jc=${23}&version=${b}&sample=${.01}`;
            b = window;
            var c;
            if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
            c && typeof b.navigator.sendBeacon === "function" ? b.navigator.sendBeacon(a) :
                pb(b, a, void 0, !1)
        }
    };
    var Q = document,
        R = window;
    var tb = (a = []) => {
        m.google_logging_queue || (m.google_logging_queue = []);
        m.google_logging_queue.push([12, a])
    };
    var ub = () => {
            var a = Q;
            try {
                return a.querySelectorAll("*[data-ifc]")
            } catch (b) {
                return []
            }
        },
        vb = (a, b) => {
            a && hb(b, (c, d) => {
                a.style[d] = c
            })
        },
        wb = a => {
            var b = Q.body;
            const c = document.createDocumentFragment(),
                d = a.length;
            for (let e = 0; e < d; ++e) c.appendChild(a[e]);
            b.appendChild(c)
        };
    let xb = null;

    function yb() {
        const a = m.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function zb() {
        const a = m.performance;
        return a && a.now ? a.now() : null
    };
    var Ab = class {
        constructor(a, b) {
            var c = zb() || yb();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const S = m.performance,
        Bb = !!(S && S.mark && S.measure && S.clearMarks),
        T = Wa(() => {
            var a;
            if (a = Bb) {
                var b;
                a = window;
                if (xb === null) {
                    xb = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (xb = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = xb;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function Cb(a) {
        a && S && T() && (S.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), S.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function Db(a, b, c, d, e) {
        const g = [];
        hb(a, (f, k) => {
            (f = Eb(f, b, c, d, e)) && g.push(`${k}=${f}`)
        });
        return g.join(b)
    }

    function Eb(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const g = [];
                for (let f = 0; f < a.length; f++) g.push(Eb(a[f], b, c, d + 1, e));
                return g.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Db(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Fb(a) {
        let b = 1;
        for (const c in a.h) c.length > b && (b = c.length);
        return 3997 - b - a.i.length - 1
    }

    function Gb(a) {
        let b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=fccs&",
            c = Fb(a) - 24;
        if (c < 0) return "";
        a.g.sort((g, f) => g - f);
        let d = null,
            e = "";
        for (let g = 0; g < a.g.length; g++) {
            const f = a.g[g],
                k = a.h[f];
            for (let h = 0; h < k.length; h++) {
                if (!c) {
                    d = d == null ? f : d;
                    break
                }
                let l = Db(k[h], a.i, ",$");
                if (l) {
                    l = e + l;
                    if (c >= l.length) {
                        c -= l.length;
                        b += l;
                        e = a.i;
                        break
                    }
                    d = d == null ? f : d
                }
            }
        }
        a = "";
        d != null && (a = `${e}${"trn"}=${d}`);
        return b + a
    }
    var Hb = class {
        constructor() {
            this.i = "&";
            this.h = {};
            this.l = 0;
            this.g = []
        }
    };

    function Ib(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) Ib(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    };
    class Jb {};

    function Kb() {
        var a = Lb,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.g = b)
    }

    function Mb(a) {
        if (Lb.g < 1) try {
            let b;
            a instanceof Hb ? b = a : (b = new Hb, hb(a, (d, e) => {
                var g = b;
                const f = g.l++,
                    k = {};
                k[e] = d;
                d = [k];
                g.g.push(f);
                g.h[f] = d
            }));
            const c = Gb(b);
            c && pb(m, c)
        } catch (b) {}
    }
    var Nb = class {
        constructor() {
            this.g = Math.random()
        }
    };
    const Ob = [$a, ab, cb, bb, Za, N("market"), N("itms"), N("intent"), N("itms-appss")];

    function Pb() {
        var a = `${R.location.protocol==="http:"?"http:":"https:"}//${"pagead2.googlesyndication.com"}/pagead/gen_204`;
        return b => {
            b = {
                id: "unsafeurl",
                ctx: 625,
                url: b
            };
            var c = [];
            for (d in b) Ib(d, b[d], c);
            var d = c.join("&");
            if (d) {
                b = a.indexOf("#");
                b < 0 && (b = a.length);
                c = a.indexOf("?");
                let e;
                c < 0 || c > b ? (c = b, e = "") : e = a.substring(c + 1, b);
                b = [a.slice(0, c), e, a.slice(b)];
                c = b[1];
                b[1] = d ? c ? c + "&" + d : d : c;
                d = b[0] + (b[1] ? "?" + b[1] : "") + b[2]
            } else d = a;
            navigator.sendBeacon && navigator.sendBeacon(d, "")
        }
    };
    let Lb;
    const U = new class {
        constructor(a, b) {
            this.g = [];
            this.i = b || m;
            let c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.g = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.h = T() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.h) return null;
            a = new Ab(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            S && T() && S.mark(b);
            return a
        }
        end(a) {
            if (this.h && typeof a.value === "number") {
                a.duration = (zb() || yb()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                S && T() && S.mark(b);
                !this.h || this.g.length >
                    2048 || this.g.push(a)
            }
        }
    }(1, window);

    function Qb() {
        window.google_measure_js_timing || (U.h = !1, U.g !== U.i.google_js_reporting_queue && (T() && u(U.g, Cb), U.g.length = 0))
    }(function(a) {
        Lb = a ? ? new Nb;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Kb();
        window.document.readyState === "complete" ? Qb() : U.h && P(window, "load", () => {
            Qb()
        })
    })();

    function Rb(a) {
        P(R, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || c.googMsgType !== "ig" || a(c, b)
        })
    };

    function V() {
        this.h = this.h;
        this.i = this.i
    }
    V.prototype.h = !1;
    V.prototype.dispose = function() {
        this.h || (this.h = !0, this.l())
    };
    V.prototype[Symbol.dispose] = function() {
        this.dispose()
    };
    V.prototype.l = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function W(a, b, c) {
        V.call(this);
        this.m = a;
        this.C = b || 0;
        this.o = c;
        this.v = t(this.A, this)
    }
    ka(W, V);
    W.prototype.g = 0;
    W.prototype.l = function() {
        W.N.l.call(this);
        this.isActive() && m.clearTimeout(this.g);
        this.g = 0;
        delete this.m;
        delete this.o
    };
    W.prototype.start = function(a) {
        this.isActive() && m.clearTimeout(this.g);
        this.g = 0;
        var b = this.v;
        a = a !== void 0 ? a : this.C;
        if (typeof b !== "function")
            if (b && typeof b.handleEvent == "function") b = t(b.handleEvent, b);
            else throw Error("Invalid listener argument");
        this.g = Number(a) > 2147483647 ? -1 : m.setTimeout(b, a || 0)
    };
    W.prototype.isActive = function() {
        return this.g != 0
    };
    W.prototype.A = function() {
        this.g = 0;
        this.m && this.m.call(this.o)
    };
    const Sb = {
            display: "inline-block",
            position: "absolute"
        },
        Tb = {
            display: "none",
            width: "100%",
            height: "100%",
            top: "0",
            left: "0"
        };

    function Y(a, b) {
        a && (a.style.display = b ? "inline-block" : "none")
    }

    function Ub(a, b) {
        if (a) return R.getComputedStyle(a).getPropertyValue(b)
    }

    function Vb({
        width: a,
        height: b
    }, {
        x: c,
        y: d,
        width: e,
        height: g
    }, {
        top: f,
        right: k,
        bottom: h,
        left: l
    }) {
        return {
            top: Math.max(0, f - d),
            right: Math.max(0, c + e - (a - k)),
            bottom: Math.max(0, d + g - (b - h)),
            left: Math.max(0, l - c)
        }
    }

    function Wb(a = "") {
        const b = {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        };
        a && (a = a.split(","), a.length === 4 && a.reduce((c, d) => c && !isNaN(+d), !0) && ([b.top, b.right, b.bottom, b.left] = a.map(c => +c)));
        return b
    }

    function Xb(a, b, c = 2147483647) {
        const d = Q.createElement("div");
        vb(d, { ...Sb,
            "z-index": String(c),
            ...b
        });
        I(a.data, 10) && P(d, "click", Va);
        if (I(a.data, 11)) {
            a = Q.createElement("a");
            b = Pb();
            c = fb(Ob);
            c === Xa && b("#");
            if (c instanceof M)
                if (c instanceof M) b = c.g;
                else throw Error("");
            else b = gb.test(c) ? c : void 0;
            b !== void 0 && (a.href = b);
            a.appendChild(d);
            return a
        }
        return d
    }

    function Yb(a, b) {
        switch (K(b.j, 5)) {
            case 2:
                R.AFMA_Communicator ? .addEventListener ? .("onshow", () => {
                    Z(a, b)
                });
                break;
            case 10:
                P(R, "i-creative-view", () => {
                    Z(a, b)
                });
                break;
            case 4:
                P(Q, "DOMContentLoaded", () => {
                    Z(a, b)
                });
                break;
            case 8:
                Rb(c => {
                    c.rr && Z(a, b)
                });
                break;
            case 9:
                if ("IntersectionObserver" in R) {
                    const c = new IntersectionObserver(d => {
                        for (const e of d)
                            if (e.intersectionRatio > 0) {
                                Z(a, b);
                                break
                            }
                    });
                    c.observe(Q.body);
                    a.L.push(c)
                }
                break;
            case 11:
                R.AFMA_Communicator ? .addEventListener ? .("onAdVisibilityChanged", () => {
                    Z(a, b)
                })
        }
    }

    function Zb(a, b) {
        b = Wb(b);
        const c = J(a.data, 9);
        a.l = [{
            width: "100%",
            height: b.top + c + "px",
            top: -c + "px",
            left: "0"
        }, {
            width: b.right + c + "px",
            height: "100%",
            top: "0",
            right: -c + "px"
        }, {
            width: "100%",
            height: b.bottom + c + "px",
            bottom: -c + "px",
            left: "0"
        }, {
            width: b.left + c + "px",
            height: "100%",
            top: "0",
            left: -c + "px"
        }].map(d => Xb(a, d, 9019))
    }

    function $b(a) {
        const b = m.oneAfmaInstance;
        b && b.getNativeClickMeta().then(c => {
            if (c) {
                var d = c.adViewRectangle;
                c = c.mediaViewRectangle;
                if (d && c && (d = JSON.parse(d), c = JSON.parse(c), d && c)) {
                    c = Vb(d, c, Wb(H(a.j) ? ? ""));
                    d = a.j;
                    c = `${c.top},${c.right},${c.bottom},${c.left}`;
                    if (c != null && typeof c !== "string") throw Error();
                    if (!La(d) && z(d, d.g[w] | 0)) throw Error();
                    d = d.g;
                    F(d, d[w] | 0, c)
                }
            }
        })
    }

    function ac(a) {
        var b = 0;
        for (const d of a.G) {
            const e = d.j,
                g = a.A[K(e, 5)];
            d.u || g === void 0 || (b = Math.max(b, g + J(e, 2)))
        }
        a.m && a.m.dispose();
        b -= Date.now();
        const c = a.h;
        b > 0 ? (Y(c, !0), a.m = new W(() => {
            Y(c, !1)
        }, b), a.m.start()) : Y(c, !1)
    }

    function Z(a, b) {
        if (!b.u) {
            var c = K(b.j, 5);
            a.A[c] = Date.now();
            I(b.j, 9) && (a.G.push(b), ac(a))
        }
    }

    function bc(a, b, c) {
        if (!a.g || !a.v || b.timeStamp - a.g.timeStamp >= 300) return !1;
        const d = new Map;
        u(a.v.changedTouches, e => {
            d.set(e.identifier, {
                x: e.clientX,
                y: e.clientY
            })
        });
        b = J(c.j, 11) || 10;
        for (const e of a.g.changedTouches)
            if (a = d.get(e.identifier), !a || Math.abs(a.x - e.clientX) > b || Math.abs(a.y - e.clientY) > b) return !0;
        return !1
    }
    var dc = class {
        constructor() {
            var a = cc;
            this.l = [];
            this.m = this.h = null;
            this.G = [];
            this.data = null;
            this.C = [];
            this.i = [];
            this.o = [];
            this.A = {};
            this.L = [];
            this.v = this.g = null;
            this.I = "";
            this.H = !1;
            this.J = a["send-fccs"] === "true";
            this.I = a.qid || "";
            this.H = a["is-fsn"] === "true"
        }
        init(a) {
            tb([a]);
            this.data = new Ua(a);
            a = Qa(this.data);
            u(Ta(a), g => {
                this.o.push({
                    D: 0,
                    u: !1,
                    F: 0,
                    j: g,
                    B: -1
                })
            });
            this.i = ub();
            let b = !1;
            a = this.i.length;
            for (let g = 0; g < a; ++g) {
                var c = new Pa(JSON.parse(this.i[g].getAttribute("data-ifc") || "[]"));
                u(Ta(c), f => {
                    this.o.push({
                        D: 0,
                        u: !1,
                        F: 0,
                        j: f,
                        B: g
                    });
                    K(f, 4) === 1 && (b = !0)
                })
            }
            c = a = !1;
            let d = I(this.data, 12);
            for (var e of this.o) {
                const g = e.j;
                J(g, 2) > 0 && K(g, 5) > 0 ? (!this.h && I(g, 9) && (this.h = Xb(this, Tb)), Yb(this, e)) : (H(g) ? ? "") && I(g, 9) && Zb(this, H(g) ? ? "");
                (H(g) ? ? "") && (a = !0, this.H && I(g, 13) && $b(e));
                J(g, 11) > 0 && (c = !0);
                I(g, 12) && (d = !0)
            }
            e = [];
            this.h && e.push(this.h);
            !b && e.push(...this.l);
            Q.body && wb(e);
            I(this.data, 13) && ob(() => {
                const g = Q.body.querySelectorAll(".amp-fcp, .amp-bcp");
                for (let f = 0; f < g.length; ++f) Ub(g[f], "position") === "absolute" && Y(g[f], !1)
            });
            P(Q, "click", g => {
                if (this.J) {
                    var f = {
                        cx: g.clientX,
                        cy: g.clientY,
                        et: Date.now(),
                        qid: this.I
                    };
                    var k = Jb;
                    var h = "K";
                    k.K && k.hasOwnProperty(h) || (h = new k, k.K = h);
                    k = [];
                    !f.eid && k.length && (f.eid = k.toString());
                    Mb(f);
                    this.J = !1
                }
                f = J(this.data, 15);
                if (f > 0 && (g.isTrusted === !1 && f & 1 || navigator.userActivation.hasBeenActive === !1 && f & 2 || navigator.userActivation.isActive === !1 && f & 4)) g.preventDefault ? g.preventDefault() : g.returnValue = !1, g.stopImmediatePropagation(), sb();
                else {
                    f = -1;
                    k = [];
                    for (var l of this.o) {
                        h = l.B;
                        var n = h !== -1;
                        if (!(J(l.j,
                                3) <= f || l.u || n && k[h] === !1)) {
                            var p = !n || k[h] || this.i[h].contains(g.target);
                            n && p && (k[h] = !0);
                            if (h = p)
                                if (h = g, n = l.j, J(n, 2) > 0 && K(n, 5) > 0) h = this.A[K(n, 5)], h = h !== void 0 && Date.now() < h + J(n, 2);
                                else if (H(n) ? ? "") {
                                {
                                    const x = (l.B >= 0 ? this.i[l.B] : Q.body).getBoundingClientRect(),
                                        D = Number(Ub(Q.body, "zoom") || "1"),
                                        [X, ic] = [h.clientX, h.clientY],
                                        [ca, da, wa, xa] = [X / D - x.left, ic / D - x.top, x.width, x.height];
                                    if (!(wa > 0 && xa > 0) || isNaN(ca) || isNaN(da) || ca < 0 || da < 0) h = !1;
                                    else {
                                        n = Wb(H(l.j) ? ? "");
                                        p = !(ca >= n.left && wa - ca > n.right && da >= n.top && xa - da > n.bottom);
                                        var r = I(l.j, 12);
                                        if (this.g && (I(this.data, 12) || r) && h.timeStamp - this.g.timeStamp < 300) {
                                            h = this.g.changedTouches[0];
                                            const [ea, fa] = [h.clientX / D - x.left, h.clientY / D - x.top];
                                            !isNaN(ea) && !isNaN(fa) && ea >= 0 && fa >= 0 && (p = (p = I(this.data, 16) || r ? p : !1) || !(ea >= n.left && wa - ea > n.right && fa >= n.top && xa - fa > n.bottom))
                                        }
                                        h = p
                                    }
                                }
                            } else h = J(n, 11) > 0 ? bc(this, h, l) : !0;
                            if (h) {
                                var q = l;
                                f = J(l.j, 3)
                            }
                        }
                    }
                    if (q) switch (l = q.j, K(l, 4)) {
                        case 2:
                        case 3:
                            g.preventDefault ? g.preventDefault() : g.returnValue = !1;
                            f = Date.now();
                            f - q.F > 500 && (q.F = f, ++q.D);
                            f = q.j;
                            if (J(f, 8) &&
                                q.D >= J(f, 8))
                                if (q.u = !0, this.h && J(f, 2) > 0) ac(this);
                                else if (this.l.length > 0 && (H(f) ? ? ""))
                                for (var C of this.l) Y(C, !1);
                            sb();
                            C = Ea(l);
                            for (const x of this.C) x(g, C)
                    }
                }
            }, kb);
            c && P(Q, "touchstart", g => {
                this.v = g
            }, lb);
            (a && d || c) && P(Q, "touchend", g => {
                this.g = g
            }, lb)
        }
        registerCallback(a) {
            this.C.push(a)
        }
    };
    const ec = rb(document.currentScript);
    if (ec == null) throw Error("JSC not found 23");
    var cc;
    const fc = {},
        hc = ec.attributes;
    for (let a = hc.length - 1; a >= 0; a--) {
        const b = hc[a].name;
        b.indexOf("data-jcp-") === 0 && (fc[b.substring(9)] = hc[a].value)
    }
    cc = fc;
    const jc = window;
    jc.googqscp = new dc;
    cc["init-data"] && jc.googqscp.init(JSON.parse(cc["init-data"]));
}).call(this);