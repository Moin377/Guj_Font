(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var k = this || self;

    function aa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = k, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    };

    function ca(a) {
        k.setTimeout(() => {
            throw a;
        }, 0)
    };
    var da = aa(748402147, aa(1, !0));

    function ea(a) {
        ea[" "](a);
        return a
    }
    ea[" "] = function() {};
    let fa = void 0;

    function ha(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var ia = ha(),
        q = ha("m_m", !0);
    const r = ha("jas", !0);
    var t = {};

    function v(a, b) {
        return b === void 0 ? a.g !== x && !!(2 & (a.l[r] | 0)) : !!(2 & b) && a.g !== x
    }
    const x = {};
    const ja = BigInt(Number.MIN_SAFE_INTEGER),
        ka = BigInt(Number.MAX_SAFE_INTEGER);
    const la = Number.isFinite;

    function A(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return la(a) ? a | 0 : void 0
    };

    function ma(a) {
        return a
    };

    function na(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        const f = [];
        var g = a.length;
        let h, l = 4294967295,
            n = !1;
        const m = !!(b & 64),
            w = m ? b & 128 ? 0 : -1 : void 0;
        b & 1 || (h = g && a[g - 1], h != null && typeof h === "object" && h.constructor === Object ? (g--, l = g) : h = void 0, !m || b & 128 || e || (n = !0, l = (oa ? ? ma)(l - w, w, a, h, void 0) + w));
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (m && e >= l) {
                    const u = e - w;
                    (b ? ? (b = {}))[u] = p
                } else f[e] = p
        }
        if (h)
            for (let p in h) {
                a = h[p];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +p;
                let u;
                m && !Number.isNaN(g) && (u = g + w) <
                    l ? f[u] = a : (b ? ? (b = {}))[p] = a
            }
        b && (n ? f.push(b) : f[l] = b);
        return f
    }

    function pa(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return a >= ja && a <= ka ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    const b = a[r] | 0;
                    return a.length === 0 && b & 1 ? void 0 : na(a, b, pa)
                }
                if (a != null && a[q] === t) return B(a);
                return
        }
        return a
    }
    let oa;

    function B(a) {
        a = a.l;
        return na(a, a[r] | 0, pa)
    };

    function qa(a) {
        if (a == null) {
            var b = 32;
            a = []
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            b = a[r] | 0;
            if (da && 1 & b) throw Error("rfarr");
            2048 & b && !(2 & b) && ra();
            if (b & 256) throw Error("farr");
            if (b & 64) return b & 2048 || (a[r] = b | 2048), a;
            var c = a;
            b |= 64;
            var d = c.length;
            if (d) {
                var e = d - 1;
                d = c[e];
                if (d != null && typeof d === "object" && d.constructor === Object) {
                    const f = b & 128 ? 0 : -1;
                    e -= f;
                    if (e >= 1024) throw Error("pvtlmt");
                    for (const g in d) {
                        const h = +g;
                        if (h < e) c[h + f] = d[g], delete d[g];
                        else break
                    }
                    b = b & -8380417 | (e & 1023) << 13
                }
            }
        }
        a[r] = b | 2112;
        return a
    }

    function ra() {
        if (da) throw Error("carr");
        if (ia != null) {
            var a = fa ? ? (fa = {});
            var b = a[ia] || 0;
            b >= 5 || (a[ia] = b + 1, a = Error(), a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {}), a.__closure__error__context__984382.severity = "incident", ca(a))
        }
    };

    function ua(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[r] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = E(a, c, !1, b && !(c & 16)) : (a[r] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[q] === t) return b = a.l, c = b[r] | 0, v(a, c) ? a : va(a, b, c) ? wa(a, b) : E(b, c)
    }

    function wa(a, b, c) {
        a = new a.constructor(b);
        c && (a.g = x);
        a.h = x;
        return a
    }

    function E(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = na(a, b, ua, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        a[r] = b;
        return a
    }

    function xa(a) {
        if (a.g !== x) return !1;
        var b = a.l;
        b = E(b, b[r] | 0);
        b[r] |= 2048;
        a.l = b;
        a.g = void 0;
        a.h = void 0;
        return !0
    }

    function ya(a, b) {
        b === void 0 && (b = a[r] | 0);
        b & 32 && !(b & 4096) && (a[r] = b | 4096)
    }

    function va(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[r] = c | 2, a.g = x, !0) : !1
    };

    function G(a, b) {
        a = za(a.l, b);
        if (a !== null) return a
    }

    function za(a, b, c) {
        if (b === -1) return null;
        const d = b + -1;
        var e = a.length - 1;
        let f, g;
        if (!(e < 0)) {
            if (d >= e)
                if (f = a[e], f != null && typeof f === "object" && f.constructor === Object) e = f[b], g = !0;
                else if (d === e) e = f;
            else return;
            else e = a[d];
            if (c && e != null) {
                c = c(e);
                if (c == null) return c;
                if (!Object.is(c, e)) return g ? f[b] = c : a[d] = c, c
            }
            return e
        }
    }

    function Aa(a, b, c, d) {
        const e = c + -1;
        var f = a.length - 1;
        if (f >= 0 && e >= f) {
            const g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        d !== void 0 && (f = (b ? ? (b = a[r] | 0)) >> 13 & 1023 || 536870912, c >= f ? d != null && (a[f + -1] = {
            [c]: d
        }) : a[e] = d);
        return b
    }

    function Ba(a) {
        a = a.l;
        return Ca(a, a[r] | 0) !== void 0
    }

    function Ca(a, b) {
        var c = Da;
        let d = !1;
        const e = za(a, 1, f => {
            if (f != null && f[q] === t) var g = f;
            else if (Array.isArray(f)) {
                g = f[r] | 0;
                let h;
                h = g | b & 32;
                h |= b & 2;
                h !== g && (f[r] = h);
                g = new c(f)
            } else g = void 0;
            d = g !== f && g != null;
            return g
        });
        if (e != null) return d && !v(e) && ya(a, b), e
    }

    function Ea(a) {
        let b = a.l,
            c = b[r] | 0,
            d = Ca(b, c);
        if (d == null) return d;
        c = b[r] | 0;
        if (!v(a, c)) {
            var e = d;
            const f = e.l,
                g = f[r] | 0;
            e = v(e, g) ? va(e, f, g) ? wa(e, f, !0) : new e.constructor(E(f, g, !1)) : e;
            e !== d && (xa(a) && (b = a.l, c = b[r] | 0), d = e, c = Aa(b, c, 1, d), ya(b, c))
        }
        return d
    }

    function H(a, b) {
        a = G(a, b);
        return a == null || typeof a === "string" ? a : void 0
    }

    function I(a, b) {
        a = G(a, b);
        return (a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0) ? ? !1
    }

    function J(a, b, c) {
        if (c != null && typeof c !== "string") throw Error();
        if (!xa(a) && v(a, a.l[r] | 0)) throw Error();
        a = a.l;
        Aa(a, a[r] | 0, b, c)
    };
    var K = class {
        constructor(a) {
            this.l = qa(a)
        }
        toJSON() {
            return B(this)
        }
    };
    K.prototype[q] = t;
    var Da = class extends K {};
    var Fa = function(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b[r] |= 32;
                b = new a(b)
            }
            return b
        }
    }(class extends K {});
    var Ga = class extends K {};

    function Ha(a = window) {
        return a
    };

    function Ia(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let Ja = globalThis.trustedTypes,
        Ka;

    function La() {
        let a = null;
        if (!Ja) return a;
        try {
            const b = c => c;
            a = Ja.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    };
    var Ma = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Na(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function Oa(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Pa(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function L(a) {
        var b = document;
        return typeof a === "string" ? b.getElementById(a) : a
    }

    function Qa(a) {
        var b = document;
        if (b.getElementsByClassName) a = b.getElementsByClassName(a)[0];
        else {
            b = document;
            var c;
            a ? c = b.querySelector(a ? "." + a : "") : c = (a ? b.querySelectorAll(a ? "." + a : "") : b.getElementsByTagName("*"))[0] || null;
            a = c
        }
        return a || null
    }

    function Ra(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    };
    var Sa = {
            passive: !0
        },
        Ta = Ia(() => {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                k.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Ua(a) {
        return a ? a.passive && Ta() ? a : a.capture || !1 : !1
    }

    function M(a, b, c, d) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, Ua(d))
    }

    function N(a) {
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };

    function Va(a, b, c = null, d = !1) {
        Wa(a, b, c, d)
    }

    function Wa(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        const e = Pa("IMG", a.document);
        if (c || d) {
            const f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    const h = Array.prototype.indexOf.call(g, e, void 0);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, Ua());
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, Ua())
            };
            M(e, "load", f);
            M(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    };
    let Xa = 0;

    function Ya(a) {
        return (a = Za(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function Za(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[${"data-jc"}="${a}"]`)
    }

    function $a() {
        if (!(Math.random() > .01)) {
            var a = Za(60, document.currentScript);
            a = `https://${a&&a.getAttribute("data-jc-rcd")==="true"?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=${60}&version=${Ya(60)}&sample=${.01}`;
            var b = window,
                c;
            if (c = b.navigator) c = b.navigator.userAgent, c = /Chrome/.test(c) && !/Edge/.test(c) ? !0 : !1;
            c && typeof b.navigator.sendBeacon === "function" ? b.navigator.sendBeacon(a) : Va(b, a, void 0, !1)
        }
    };
    var ab = document,
        O = window;

    function fb(a) {
        return typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || ""
    }

    function gb(a, b) {
        a.classList ? b = a.classList.contains(b) : (a = a.classList ? a.classList : fb(a).match(/\S+/g) || [], b = Array.prototype.indexOf.call(a, b, void 0) >= 0);
        return b
    }

    function P(a, b) {
        if (a.classList) a.classList.add(b);
        else if (!gb(a, b)) {
            const c = fb(a);
            b = c + (c.length > 0 ? " " + b : b);
            typeof a.className == "string" ? a.className = b : a.setAttribute && a.setAttribute("class", b)
        }
    };
    var hb = class {
        constructor(a) {
            this.serializedAttributionData = B(a);
            var b = a.l,
                c = b[r] | 0;
            this.g = va(a, b, c) ? wa(a, b, !0) : new a.constructor(E(b, c, !1));
            if (a = Ba(this.g)) a = Ea(this.g), a = !!I(a, 33);
            this.isMutableImpression = a;
            H(this.g, 30);
            this.V = !!I(this.g, 11);
            this.hasUserFeedbackData = !!this.g && Ba(this.g);
            this.O = !!I(this.g, 4);
            this.S = !!I(this.g, 6);
            this.N = !!I(this.g, 13);
            A(G(this.g, 8));
            this.creativeIndexSuffix = (A(G(this.g, 8)) ? ? 0) > 1 ? (A(G(this.g, 7)) ? ? 0).toString() : "";
            H(this.g, 34) != null && (this.creativeIndexSuffix = (H(this.g,
                34) ? ? "") + "_" + this.creativeIndexSuffix);
            this.W = !!I(this.g, 17);
            this.U = !!I(this.g, 18);
            this.M = !!I(this.g, 14);
            this.F = !!I(this.g, 15);
            this.X = !!I(this.g, 31);
            this.T = I(this.g, 9) == 1;
            this.openAttributionInline = I(this.g, 10) == 1;
            this.isMobileDevice = !!I(this.g, 12);
            this.A = null;
            this.R = (a = ab.querySelector("[data-slide]")) ? a.getAttribute("data-slide") === "true" : !1;
            (this.H = (A(G(this.g, 8)) ? ? 0) > 1) && O.goog_multislot_cache === void 0 && (O.goog_multislot_cache = {});
            this.H && !this.R ? (a = O.goog_multislot_cache.hd, a === void 0 && (a = !1,
                (b = ab.querySelector("[data-dim]")) ? (b = b.getBoundingClientRect(), b.right - b.left >= 150 && b.bottom - b.top >= 150 ? a = !1 : (c = document.body.getBoundingClientRect(), (Math.abs(c.left - b.left) <= 1 && Math.abs(c.right - b.right) <= 1 ? b.bottom - b.top : b.right - b.left) < 150 && (a = !0))) : a = !1, window.goog_multislot_cache.hd = a)) : a = !1;
            this.G = a;
            this.C = L("abgcp" + this.creativeIndexSuffix);
            this.B = L("abgc" + this.creativeIndexSuffix);
            this.h = L("abgs" + this.creativeIndexSuffix);
            L("abgl" + this.creativeIndexSuffix);
            this.u = L("abgb" + this.creativeIndexSuffix);
            this.D = L("abgac" + this.creativeIndexSuffix);
            L("mute_panel" + this.creativeIndexSuffix);
            this.v = Qa("goog_delegate_attribution" + this.creativeIndexSuffix);
            this.isDelegateAttributionActive = !!this.v && !!this.M && !Qa("goog_delegate_disabled") && !this.F;
            if (this.h) a: for (a = this.h, b = a.childNodes, c = 0; c < b.length; c++) {
                const d = b.item(c);
                if (typeof d.tagName != "undefined" && d.tagName.toUpperCase() == "A") {
                    a = d;
                    break a
                }
            } else a = null;
            this.m = a;
            this.j = this.isDelegateAttributionActive ? this.v : L("cbb" + this.creativeIndexSuffix);
            this.P =
                this.G ? this.creativeIndexSuffix === "0" : !0;
            this.enableDelegateDismissableMenu = !!this.j && gb(this.j, "goog_dismissable_menu");
            this.o = null;
            this.I = 0;
            this.i = this.isDelegateAttributionActive ? this.v : this.S && this.C ? this.C : this.B;
            this.autoExpandOnLoad = !!I(this.g, 19);
            this.adbadgeEnabled = !!I(this.g, 24);
            this.enableNativeJakeUi = !!I(this.g, 27);
            H(this.g, 33)
        }
    };
    var ib = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        jb = /#|$/;
    var kb = class {
        constructor(a, b, c) {
            if (!a) throw Error("bad conv util ctor args");
            this.g = a;
            this.h = c
        }
    };
    var Q = (a, b) => {
        a && Oa(b, (c, d) => {
            a.style[d] = c
        })
    };
    var lb = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function mb(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    const nb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var ob = class {
            constructor(a, b) {
                this.g = a;
                this.h = b
            }
        },
        pb = class {
            constructor(a, b) {
                this.url = a;
                this.g = !!b;
                this.depth = null
            }
        };
    let R = null;

    function qb() {
        const a = k.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function rb() {
        const a = k.performance;
        return a && a.now ? a.now() : null
    };
    var sb = class {
        constructor(a, b) {
            var c = rb() || qb();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const S = k.performance,
        tb = !!(S && S.mark && S.measure && S.clearMarks),
        U = Ia(() => {
            var a;
            if (a = tb) {
                var b;
                a = window;
                if (R === null) {
                    R = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (R = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = R;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function ub(a) {
        a && S && U() && (S.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), S.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function vb(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function wb(a, b, c, d, e) {
        const f = [];
        Oa(a, (g, h) => {
            (g = xb(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function xb(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(xb(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(wb(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function yb(a) {
        let b = 1;
        for (const c in a.h) c.length > b && (b = c.length);
        return 3997 - b - a.i.length - 1
    }

    function zb(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = yb(a) - b.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.h[g];
            for (let l = 0; l < h.length; l++) {
                if (!d) {
                    b = b == null ? g : b;
                    break
                }
                let n = wb(h[l], a.i, ",$");
                if (n) {
                    n = e + n;
                    if (d >= n.length) {
                        d -= n.length;
                        c += n;
                        e = a.i;
                        break
                    }
                    b = b == null ? g : b
                }
            }
        }
        a = "";
        b != null && (a = `${e}${"trn"}=${b}`);
        return c + a
    }
    var Ab = class {
        constructor() {
            this.i = "&";
            this.h = {};
            this.j = 0;
            this.g = []
        }
    };

    function Bb(a, b, c) {
        let d, e;
        try {
            a.g && a.g.g ? (e = a.g.start(b.toString(), 3), d = c(), a.g.end(e)) : d = c()
        } catch (f) {
            c = !0;
            try {
                ub(e), c = a.m(b, new lb(f, {
                    message: mb(f)
                }), void 0, void 0)
            } catch (g) {
                a.j(217, g)
            }
            if (c) window.console ? .error ? .(f);
            else throw f;
        }
        return d
    }

    function Cb(a, b) {
        var c = V;
        return (...d) => Bb(c, a, () => b.apply(void 0, d))
    }
    var Fb = class {
        constructor(a = null) {
            this.pinger = Db;
            this.g = a;
            this.h = null;
            this.i = !1;
            this.m = this.j
        }
        j(a, b, c, d, e) {
            e = e || "jserror";
            let f = void 0;
            try {
                const C = new Ab;
                var g = C;
                g.g.push(1);
                g.h[1] = vb("context", a);
                b.error && b.meta && b.id || (b = new lb(b, {
                    message: mb(b)
                }));
                g = b;
                if (g.msg) {
                    b = C;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.h[2] = vb("msg", h)
                }
                var l = g.meta || {};
                h = l;
                if (this.h) try {
                    this.h(h)
                } catch (z) {}
                if (d) try {
                    d(h)
                } catch (z) {}
                d = C;
                l = [l];
                d.g.push(3);
                d.h[3] = l;
                var n;
                if (!(n = u)) {
                    d = k;
                    l = [];
                    let z;
                    h = null;
                    do {
                        var m = d;
                        try {
                            var w;
                            if (w = !!m && m.location.href != null) b: {
                                try {
                                    ea(m.foo);
                                    w = !0;
                                    break b
                                } catch (y) {}
                                w = !1
                            }
                            var p = w
                        } catch {
                            p = !1
                        }
                        p ? (z = m.location.href, h = m.document && m.document.referrer || null) : (z = h, h = null);
                        l.push(new pb(z || ""));
                        try {
                            d = m.parent
                        } catch (y) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let y = 0, bb = l.length - 1; y <= bb; ++y) l[y].depth = bb - y;
                    m = k;
                    if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length === l.length - 1)
                        for (p = 1; p < l.length; ++p) {
                            const y = l[p];
                            y.url || (y.url = m.location.ancestorOrigins[p - 1] || "", y.g = !0)
                        }
                    n = l
                }
                var u = n;
                let ba = new pb(k.location.href, !1);
                n = null;
                const sa = u.length - 1;
                for (m = sa; m >= 0; --m) {
                    var D = u[m];
                    !n && nb.test(D.url) && (n = D);
                    if (D.url && !D.g) {
                        ba = D;
                        break
                    }
                }
                D = null;
                const Pb = u.length && u[sa].url;
                ba.depth !== 0 && Pb && (D = u[sa]);
                f = new ob(ba, D);
                if (f.h) {
                    u = C;
                    var F = f.h.url || "";
                    u.g.push(4);
                    u.h[4] = vb("top", F)
                }
                var ta = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    const z = f.g.url.match(ib);
                    var T = z[1],
                        cb = z[3],
                        db = z[4];
                    F = "";
                    T && (F += T + ":");
                    cb && (F += "//", F += cb, db && (F += ":" + db));
                    var eb = F
                } else eb = "";
                T = C;
                ta = [ta, {
                    url: eb
                }];
                T.g.push(5);
                T.h[5] = ta;
                Eb(this.pinger, e, C, this.i, c)
            } catch (C) {
                try {
                    Eb(this.pinger,
                        e, {
                            context: "ecmserr",
                            rctx: a,
                            msg: mb(C),
                            url: f ? .g.url ? ? ""
                        }, this.i, c)
                } catch (ba) {}
            }
            return !0
        }
    };

    function Eb(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ab ? f = c : (f = new Ab, Oa(c, (h, l) => {
                var n = f;
                const m = n.j++;
                h = vb(l, h);
                n.g.push(m);
                n.h[m] = h
            }));
            const g = zb(f, "/pagead/gen_204?id=" + b + "&");
            g && Va(k, g)
        } catch (f) {}
    }

    function Gb() {
        var a = Db,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.g = b)
    }
    var Hb = class {
        constructor() {
            this.g = Math.random()
        }
    };
    let Db, V;
    const W = new class {
        constructor(a, b) {
            this.h = [];
            this.i = b || k;
            let c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.h = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.g = U() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new sb(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            S && U() && S.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (rb() || qb()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                S && U() && S.mark(b);
                !this.g || this.h.length >
                    2048 || this.h.push(a)
            }
        }
    }(1, window);

    function Ib() {
        window.google_measure_js_timing || (W.g = !1, W.h !== W.i.google_js_reporting_queue && (U() && Array.prototype.forEach.call(W.h, ub, void 0), W.h.length = 0))
    }(function(a) {
        Db = a ? ? new Hb;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Gb();
        V = new Fb(W);
        V.h = b => {
            const c = Xa;
            c !== 0 && (b.jc = String(c), b.shv = Ya(c))
        };
        V.i = !0;
        window.document.readyState === "complete" ? Ib() : W.g && M(window, "load", () => {
            Ib()
        })
    })();

    function X(a, b) {
        return Cb(a, b)
    };

    function Jb(a) {
        if (a.g.m && a.g.U) {
            const b = Ea(a.g.g);
            b && H(b, 5) != null && H(b, 6) != null && (a.i = new kb(H(b, 5) ? ? "", H(b, 6) ? ? "", H(b, 19) ? ? ""));
            M(a.g.m, "click", X(452, () => {
                if (!a.j && (a.j = !0, a.i)) {
                    var c = a.i; {
                        var d = c.g;
                        const g = d.search(jb);
                        var e;
                        b: {
                            for (e = 0;
                                (e = d.indexOf("ad_signals", e)) >= 0 && e < g;) {
                                var f = d.charCodeAt(e - 1);
                                if (f == 38 || f == 63)
                                    if (f = d.charCodeAt(e + 10), !f || f == 61 || f == 38 || f == 35) break b;
                                e += 11
                            }
                            e = -1
                        }
                        f = e;
                        if (f < 0) d = null;
                        else {
                            e = d.indexOf("&", f);
                            if (e < 0 || e > g) e = g;
                            d = decodeURIComponent(d.slice(f + 11, e !== -1 ? e : 0).replace(/\+/g,
                                " "))
                        }
                    }
                    d ? (c = {
                        J: d,
                        label: "closebutton_whythisad_click",
                        L: "1",
                        K: ""
                    }, d = new Ga, c != null && (c.J != null && J(d, 1, c.J), c.Z != null && J(d, 3, c.Z), c.label != null && J(d, 6, c.label), c.L != null && J(d, 7, c.L), c.K != null && J(d, 8, c.K), c.Y != null && J(d, 11, c.Y)), Ha(k).fence ? .reportEvent({
                        eventType: "interaction",
                        eventData: JSON.stringify(B(d)),
                        destination: ["buyer"]
                    })) : (d = c.g + "&label=closebutton_whythisad_click", d += "&label_instance=1", c.h && (d += "&cid=" + c.h), Va(window, d))
                }
            }))
        }
    }

    function Kb(a) {
        if (a.g.V) M(a.g.i, "click", X(365, b => {
            const c = O.goog_interstitial_display;
            c && (c(b), b && (b.stopPropagation(), b.preventDefault()))
        }));
        else if (a.g.isMutableImpression && a.g.isMobileDevice) M(a.g.i, "click", () => a.h());
        else if (a.g.isMutableImpression && !a.g.isMobileDevice && (a.g.j && (M(a.g.j, "click", () => a.h()), M(a.g.j, "keydown", b => {
                b.code !== "Enter" && b.code !== "Space" || a.h()
            })), a.g.X && a.g.h && M(a.g.h, "click", () => a.h())), a.g.O) Lb(a);
        else {
            M(a.g.i, "mouseover", X(367, () => Lb(a)));
            M(a.g.i, "mouseout", X(369,
                () => Mb(a, 500)));
            M(a.g.i, "touchstart", X(368, () => Lb(a)), Sa);
            const b = X(370, () => Mb(a, 4E3));
            M(a.g.i, "mouseup", b);
            M(a.g.i, "touchend", b);
            M(a.g.i, "touchcancel", b);
            a.g.m && M(a.g.m, "click", X(371, c => a.preventDefault(c)))
        }
    }

    function Lb(a) {
        window.clearTimeout(a.g.o);
        a.g.o = null;
        a.g.h && a.g.h.style.display == "block" || (a.g.I = Date.now(), a.g.u && a.g.h && (a.g.u.style.display = "none", a.g.h.style.display = "block"))
    }

    function Mb(a, b) {
        window.clearTimeout(a.g.o);
        a.g.o = window.setTimeout(() => Nb(a), b)
    }

    function Ob(a) {
        const b = a.g.D;
        b !== void 0 && (b.style.display = "block", a.g.enableNativeJakeUi && window.requestAnimationFrame(() => {
            P(b, "abgacfo")
        }))
    }

    function Nb(a) {
        window.clearTimeout(a.g.o);
        a.g.o = null;
        a.g.u && a.g.h && (a.g.u.style.display = "block", a.g.h.style.display = "none")
    }
    class Qb {
        constructor(a, b) {
            this.g = a;
            this.h = b;
            this.g.W || (this.j = !1, this.i = null, !this.g.G || this.g.adbadgeEnabled || this.g.P ? Jb(this) : (a = {
                display: "none"
            }, b = {
                width: "15px",
                height: "15px"
            }, this.g.isMobileDevice ? (Q(this.g.u, a), Q(this.g.h, a), Q(this.g.C, b), Q(this.g.B, b)) : Q(this.g.B, a)), Kb(this), this.g.enableNativeJakeUi && P(this.g.D, "abgnac"), this.g.isDelegateAttributionActive ? (P(document.body, "goog_delegate_active"), P(document.body, "jaa")) : (!this.g.isMutableImpression && this.g.j && Ra(this.g.j), setTimeout(() => {
                P(document.body,
                    "jar")
            }, this.g.N ? 750 : 100)), this.g.F && P(document.body, "goog_delegate_disabled"), this.g.autoExpandOnLoad && O.addEventListener("load", () => this.h()))
        }
        preventDefault(a) {
            if (this.g.h && this.g.h.style.display == "block" && Date.now() - this.g.I < 500) N(a);
            else if (this.g.openAttributionInline) {
                var b = this.g.m.getAttribute("href");
                window.adSlot ? window.adSlot.openAttribution(b) && N(a) : window.openAttribution && (window.openAttribution(b), N(a))
            } else this.g.T && (b = this.g.m.getAttribute("href"), window.adSlot ? window.adSlot.openSystemBrowser(b) &&
                N(a) : window.openSystemBrowser && (window.openSystemBrowser(b), N(a)))
        }
    };

    function Rb(a) {
        if (!a.g && (a.g = !0, O.goog_delegate_deferred_token = void 0, a.h)) {
            var b = a.i;
            a = Fa(JSON.stringify(a.h));
            if (!a) throw Error("bad attrdata");
            a = new hb(a);
            new b(a)
        }
    }
    class Sb {
        constructor(a) {
            var b = Tb;
            if (!b) throw Error("bad ctor");
            this.i = b;
            this.h = a;
            this.g = !1;
            Qa("goog_delegate_deferred") ? O.goog_delegate_deferred_token !== void 0 ? Rb(this) : (a = () => {
                Rb(this)
            }, O.goog_delegate_deferred_token = a, setTimeout(a, 5E3)) : Rb(this)
        }
    };
    var Ub = (a = []) => {
        k.google_logging_queue || (k.google_logging_queue = []);
        k.google_logging_queue.push([11, a])
    };
    class Vb {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function Wb() {
        const {
            promise: a,
            resolve: b
        } = new Vb;
        return {
            promise: a,
            resolve: b
        }
    };

    function Xb(a, b = () => {}) {
        a.google_llp || (a.google_llp = {});
        a = a.google_llp;
        let c = a[5];
        if (c) return c;
        c = Wb();
        a[5] = c;
        b();
        return c
    }

    function Yb(a, b) {
        return Xb(a, () => {
            var c = a.document;
            const d = Pa("SCRIPT", c);
            if (b instanceof Ma) var e = b.g;
            else throw Error("");
            d.src = e;
            (e = Na(d.ownerDocument)) && d.setAttribute("nonce", e);
            (c = c.getElementsByTagName("script")[0]) && c.parentNode && c.parentNode.insertBefore(d, c)
        }).promise
    };

    function Zb(a) {
        a = a === null ? "null" : a === void 0 ? "undefined" : a;
        var b;
        Ka === void 0 && (Ka = La());
        a = (b = Ka) ? b.createScriptURL(a) : a;
        return new Ma(a)
    };

    function $b(a) {
        Ub([a]);
        new Sb(a)
    }

    function ac(a) {
        a.g.A ? a.g.A.expandAttributionCard() : (Bb(V, 373, () => {
            Nb(a.h);
            Ob(a.h)
        }), Yb(window, Zb(`https://${"pagead2.googlesyndication.com"}${"/pagead/js/"+(H(a.g.g,33)??"")+"/abg_survey.js"}`)).then(b => {
            b.createAttributionCard(a.g);
            a.g.A = b;
            b.expandAttributionCard()
        }), $a())
    }
    var Tb = class {
        constructor(a) {
            this.g = a;
            this.h = new Qb(this.g, X(359, () => ac(this)))
        }
    };
    Xa = 60;
    const bc = Za(60, document.currentScript);
    if (bc == null) throw Error("JSC not found 60");
    const cc = {},
        dc = bc.attributes;
    for (let a = dc.length - 1; a >= 0; a--) {
        const b = dc[a].name;
        b.indexOf("data-jcp-") === 0 && (cc[b.substring(9)] = dc[a].value)
    }
    if (cc["attribution-data"]) $b(JSON.parse(cc["attribution-data"]));
    else
        for (var ec = ["buildAttribution"], Y = k, Z; ec.length && (Z = ec.shift());) ec.length || $b === void 0 ? Y[Z] && Y[Z] !== Object.prototype[Z] ? Y = Y[Z] : Y = Y[Z] = {} : Y[Z] = $b;
}).call(this);