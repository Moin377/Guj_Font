(window.tawkJsonp = window.tawkJsonp || []).push([
    ["chunk-2d224aff"], {
        e0ca: function(t, i, e) {
            "use strict";
            e.r(i);
            var o = e("2f62"),
                n = e("f0b0"),
                s = e("5a60");

            function a(t) {
                return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function r(t, i) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    i && (o = o.filter((function(i) {
                        return Object.getOwnPropertyDescriptor(t, i).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function c(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var e = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? r(Object(e), !0).forEach((function(i) {
                        h(t, i, e[i])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : r(Object(e)).forEach((function(i) {
                        Object.defineProperty(t, i, Object.getOwnPropertyDescriptor(e, i))
                    }))
                }
                return t
            }

            function h(t, i, e) {
                return (i = function(t) {
                    var i = function(t, i) {
                        if ("object" != a(t) || !t) return t;
                        var e = t[Symbol.toPrimitive];
                        if (void 0 !== e) {
                            var o = e.call(t, i || "default");
                            if ("object" != a(o)) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === i ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == a(i) ? i : i + ""
                }(i)) in t ? Object.defineProperty(t, i, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[i] = e, t
            }
            var l = {
                    name: "min-content",
                    components: {
                        TawkImage: n.TawkImage
                    },
                    props: {
                        minDesktop: {
                            type: Object,
                            required: !0
                        }
                    },
                    computed: c(c({}, Object(o.c)({
                        activeProfiles: "chat/activeProfiles",
                        chatWindowState: "session/chatWindowState",
                        pageStatus: "session/pageStatus",
                        states: "widget/states",
                        isRoundWidget: "widget/isRoundWidget",
                        hasLiveChat: "widget/hasLiveChat",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        hasChatStarted: "chat/hasChatStarted",
                        agentsCount: "chat/agentsCount",
                        isBottom: "widget/isBottom",
                        isCenter: "widget/isCenter",
                        isRight: "widget/isRight"
                    })), {}, {
                        firstActiveProfile: function() {
                            return this.activeProfiles.length ? this.activeProfiles[0] : ""
                        },
                        minimizeText: function() {
                            if (this.mobileBrowserName) return "offline" === this.pageStatus ? this.$i18n("form", "message") : this.$i18n("chat", "chat_text");
                            var t = this.states[this.pageStatus];
                            return t ? t.minimizedText : ""
                        },
                        isLiveChatFeatureEnabled: function() {
                            return !!(this.hasLiveChat || this.hasChatStarted && this.agentsCount > 0)
                        },
                        getModifierClass: function() {
                            return this.isBottom || this.isCenter ? this.isCenter ? this.isRight ? "tawk-min-chat-icon-right" : "tawk-min-chat-icon-left" : "tawk-min-chat-icon-down" : "tawk-min-chat-icon-up"
                        }
                    }),
                    watch: {
                        minimizeText: function() {
                            this.$emit("contentChange")
                        },
                        firstActiveProfile: function() {
                            this.$emit("contentChange")
                        }
                    },
                    mounted: function() {
                        this.$emit("contentChange")
                    }
                },
                m = e("2877"),
                d = Object(m.a)(l, (function() {
                    var t = this,
                        i = t._self._c;
                    return i("div", [t.isRoundWidget ? [t.firstActiveProfile ? i("tawk-image", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "min" === t.chatWindowState && t.isLiveChatFeatureEnabled,
                            expression: "chatWindowState === 'min' &&\n\t\t\t\tisLiveChatFeatureEnabled"
                        }],
                        staticClass: "tawk-min-chat-icon",
                        attrs: {
                            src: t.firstActiveProfile.profileImage,
                            alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                        }
                    }) : t._e(), i("div", [t.firstActiveProfile || "min" !== t.chatWindowState ? "max" === t.chatWindowState ? i("svg", {
                        key: "close",
                        staticClass: "tawk-min-chat-icon",
                        class: t.getModifierClass,
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            height: "24px",
                            width: "24px",
                            role: "img",
                            alt: t.$i18n("chat", "close_icon"),
                            "aria-labelledby": "closeIconTitle closeIconDesc"
                        }
                    }, [i("title", {
                        attrs: {
                            id: "closeIconTitle"
                        }
                    }, [t._v("Close Chat")]), i("desc", {
                        attrs: {
                            id: "closeIconDesc"
                        }
                    }, [t._v("This icon closes the chat window.")]), i("path", {
                        attrs: {
                            fill: "currentColor",
                            transform: "scale(1.2) translate(-2, -2)",
                            d: "M2.00009 6.99988C2.00012 6.79765 2.06147 6.60018 2.17604 6.43353C2.29061 6.26688 2.45301 6.13889 2.64181 6.06643C2.83062 5.99398 3.03695 5.98047 3.23359 6.02769C3.43023 6.07491 3.60794 6.18064 3.74325 6.33093L12.0001 15.5048L20.2569 6.33093C20.4344 6.13383 20.6828 6.01529 20.9476 6.00138C21.2125 5.98747 21.472 6.07933 21.6691 6.25675C21.8662 6.43417 21.9847 6.68263 21.9986 6.94745C22.0125 7.21228 21.9207 7.47179 21.7433 7.66888L12.7433 17.6689C12.6495 17.7731 12.5349 17.8564 12.4069 17.9134C12.2788 17.9705 12.1402 17.9999 12.0001 17.9999C11.8599 17.9999 11.7213 17.9705 11.5933 17.9134C11.4653 17.8564 11.3507 17.7731 11.2569 17.6689L2.25693 7.66888C2.09149 7.48535 1.99998 7.24698 2.00009 6.99988Z"
                        }
                    })]) : t._e() : i("svg", {
                        key: "chat",
                        staticClass: "tawk-min-chat-icon",
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 800 800",
                            height: "32px",
                            width: "32px",
                            role: "img",
                            alt: t.$i18n("chat", "chat_icon"),
                            "aria-labelledby": "openIconTitle openIconDesc"
                        }
                    }, [i("title", {
                        attrs: {
                            id: "openIconTitle"
                        }
                    }, [t._v("Opens Chat")]), i("desc", {
                        attrs: {
                            id: "openIconDesc"
                        }
                    }, [t._v("This icon Opens the chat window.")]), i("path", {
                        attrs: {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M400 26.2c-193.3 0-350 156.7-350 350 0 136.2 77.9 254.3 191.5 312.1 15.4 8.1 31.4 15.1 48.1 20.8l-16.5 63.5c-2 7.8 5.4 14.7 13 12.1l229.8-77.6c14.6-5.3 28.8-11.6 42.4-18.7C672 630.6 750 512.5 750 376.2c0-193.3-156.7-350-350-350zm211.1 510.7c-10.8 26.5-41.9 77.2-121.5 77.2-79.9 0-110.9-51-121.6-77.4-2.8-6.8 5-13.4 13.8-11.8 76.2 13.7 147.7 13 215.3.3 8.9-1.8 16.8 4.8 14 11.7z"
                        }
                    })])])] : [i("div", {
                        ref: "full-content",
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle"
                    }, [t.mobileBrowserName ? [i("div", {
                        ref: "content-icon"
                    }, [t.firstActiveProfile ? i("div", {
                        staticClass: "tawk-flex tawk-flex-middle tawk-flex-none"
                    }, [t.firstActiveProfile.profileImage && t.firstActiveProfile.profileImage.length > 0 ? i("tawk-image", {
                        staticClass: "tawk-min-agent-image tawk-flex-none",
                        attrs: {
                            src: t.firstActiveProfile.profileImage,
                            alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                        }
                    }) : t._e()], 1) : i("svg", {
                        key: "chat",
                        staticClass: "tawk-min-chat-icon",
                        attrs: {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 800 800",
                            height: "22px",
                            width: "22px",
                            role: "img",
                            alt: "".concat(t.$i18n("chat", "chat_icon")),
                            "aria-labelledby": "closeIconTitle closeIconDesc"
                        }
                    }, [i("title", {
                        attrs: {
                            id: "closeIconTitle"
                        }
                    }, [t._v("Close Chat")]), i("desc", {
                        attrs: {
                            id: "closeIconDesc"
                        }
                    }, [t._v("This icon closes the chat window.")]), i("path", {
                        attrs: {
                            "fill-rule": "evenodd",
                            "clip-rule": "evenodd",
                            d: "M400 26.2c-193.3 0-350 156.7-350 350 0 136.2 77.9 254.3 191.5 312.1 15.4 8.1 31.4 15.1 48.1 20.8l-16.5 63.5c-2 7.8 5.4 14.7 13 12.1l229.8-77.6c14.6-5.3 28.8-11.6 42.4-18.7C672 630.6 750 512.5 750 376.2c0-193.3-156.7-350-350-350zm211.1 510.7c-10.8 26.5-41.9 77.2-121.5 77.2-79.9 0-110.9-51-121.6-77.4-2.8-6.8 5-13.4 13.8-11.8 76.2 13.7 147.7 13 215.3.3 8.9-1.8 16.8 4.8 14 11.7z"
                        }
                    })])]), i("span", {
                        ref: "content-text",
                        staticClass: "tawk-text-bold-3 tawk-margin-xsmall-left tawk-text-truncate",
                        staticStyle: {
                            color: "inherit",
                            "white-space": "nowrap"
                        }
                    }, [t._v(" " + t._s(t.minimizeText) + " ")])] : [i("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "min" === t.chatWindowState && !t.firstActiveProfile,
                            expression: "chatWindowState === 'min' &&\n\t\t\t\t\t\t!firstActiveProfile"
                        }],
                        staticClass: "tawk-text-truncate",
                        style: {
                            width: "100%",
                            flex: "0 0 auto"
                        }
                    }, [t._v(" " + t._s(t.minimizeText) + " ")]), i("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "min" === t.chatWindowState && t.firstActiveProfile && t.isLiveChatFeatureEnabled,
                            expression: "chatWindowState === 'min' &&\n\t\t\t\t\tfirstActiveProfile &&\n\t\t\t\t\tisLiveChatFeatureEnabled"
                        }],
                        staticClass: "tawk-flex tawk-flex-middle",
                        style: {
                            width: "100%"
                        }
                    }, [t.firstActiveProfile.profileImage && t.firstActiveProfile.profileImage.length > 0 ? i("tawk-image", {
                        staticClass: "tawk-min-agent-image tawk-flex-none",
                        attrs: {
                            src: t.firstActiveProfile.profileImage,
                            alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                        }
                    }) : t._e(), i("div", {
                        staticClass: "tawk-margin-xsmall-left",
                        style: {
                            overflow: "hidden",
                            width: "100%"
                        }
                    }, [t.firstActiveProfile.displayName && t.firstActiveProfile.displayName.length > 0 ? i("p", {
                        staticClass: "tawk-min-agent-label tawk-text-bold tawk-text-truncate"
                    }, [t._v(" " + t._s(t.firstActiveProfile.displayName) + " ")]) : t._e(), t.firstActiveProfile.profileTitle && t.firstActiveProfile.profileTitle.length > 0 ? i("p", {
                        staticClass: "tawk-min-agent-label tawk-text-regular-2 tawk-text-truncate"
                    }, [t._v(" " + t._s(t.firstActiveProfile.profileTitle) + " ")]) : t._e()])], 1)]], 2)]], 2)
                }), [], !1, null, null, null).exports,
                f = e("87dd");

            function p(t) {
                return (p = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function u(t, i) {
                var e = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    i && (o = o.filter((function(i) {
                        return Object.getOwnPropertyDescriptor(t, i).enumerable
                    }))), e.push.apply(e, o)
                }
                return e
            }

            function g(t) {
                for (var i = 1; i < arguments.length; i++) {
                    var e = null != arguments[i] ? arguments[i] : {};
                    i % 2 ? u(Object(e), !0).forEach((function(i) {
                        w(t, i, e[i])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : u(Object(e)).forEach((function(i) {
                        Object.defineProperty(t, i, Object.getOwnPropertyDescriptor(e, i))
                    }))
                }
                return t
            }

            function w(t, i, e) {
                return (i = function(t) {
                    var i = function(t, i) {
                        if ("object" != p(t) || !t) return t;
                        var e = t[Symbol.toPrimitive];
                        if (void 0 !== e) {
                            var o = e.call(t, i || "default");
                            if ("object" != p(o)) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === i ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == p(i) ? i : i + ""
                }(i)) in t ? Object.defineProperty(t, i, {
                    value: e,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[i] = e, t
            }
            var b = {
                    name: "MinimizeWidget",
                    components: {
                        IFrame: s.a,
                        TawkBadge: n.TawkBadge,
                        TawkButton: n.TawkButton,
                        MinContent: d
                    },
                    mixins: [f.a],
                    data: function() {
                        return {
                            cssLink: "".concat("https://embed.tawk.to/_s/v4/app/6880b98ef42", "/css/min-widget.css"),
                            isLoaded: !1,
                            clickEvent: "touchend",
                            resizeWidth: 0,
                            key: n.Helper.generateUUID()
                        }
                    },
                    mounted: function() {
                        var t = this;
                        this.$eventBus.$on("switchWidget", (function() {
                            t.key = n.Helper.generateUUID()
                        }))
                    },
                    computed: g(g({}, Object(o.c)({
                        chatWindowState: "session/chatWindowState",
                        isRight: "widget/isRight",
                        isBottom: "widget/isBottom",
                        isCenter: "widget/isCenter",
                        isRTL: "widget/isRTL",
                        isRoundWidget: "widget/isRoundWidget",
                        minDesktop: "widget/minDesktop",
                        minMobile: "widget/minMobile",
                        unreadMessageCount: "chat/unreadMessageCount",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        pageStatus: "session/pageStatus",
                        zoomRatio: "widget/zoomRatio",
                        hasLiveChat: "widget/hasLiveChat",
                        hasChatStarted: "chat/hasChatStarted",
                        agentsCount: "chat/agentsCount",
                        isMobileLandscape: "widget/isMobileLandscape",
                        os: "browserData/os",
                        onClick: "widget/onClick"
                    })), {}, {
                        xOffset: function() {
                            return this.$TawkWidgetSettings.xOffset()
                        },
                        yOffset: function() {
                            return this.$TawkWidgetSettings.yOffset()
                        },
                        xOffsetMobile: function() {
                            return this.$TawkWidgetSettings.xOffsetMobile()
                        },
                        yOffsetMobile: function() {
                            return this.$TawkWidgetSettings.yOffsetMobile()
                        },
                        buttonStyles: function() {
                            var t = {};
                            return this.isRoundWidget || (this.mobileBrowserName ? (t.borderRadius = "3px", t.width = this.resizeWidth ? "".concat(this.resizeWidth, "px") : "".concat(this.minMobile.width, "px"), t.height = "".concat(this.minMobile.height, "px"), t.padding = "0 8px") : (t.borderRadius = "".concat(this.minDesktop.borderRadiusTop, "px ").concat(this.minDesktop.borderRadiusTop, "px\n\t\t\t\t\t").concat(this.minDesktop.borderRadiusBottom, "px ").concat(this.minDesktop.borderRadiusBottom, "px"), t.width = "".concat(this.minDesktop.width, "px"), t.height = "".concat(this.minDesktop.height, "px"), t.padding = "0 15px")), this.isBottom || this.isCenter ? t.bottom = "0" : t.top = "0", this.isRTL ? t.right = "0" : t.left = "0", t.position = "absolute", t.zIndex = "1000", t.border = "0", t
                        },
                        iFrameHeight: function() {
                            return this.mobileBrowserName ? this.isRoundWidget ? this.isMobileLandscape ? "safari" !== this.mobileBrowserName || "iphone" !== this.os.identity && "mac" !== this.os.identity ? "safari" === this.mobileBrowserName || "iphone" !== this.os.identity && "mac" !== this.os.identity ? "".concat((this.minMobile.height + 4) * this.zoomRatio, "px") : "".concat((this.minMobile.height + 4) * (this.zoomRatio / 1.7), "px") : "".concat((this.minMobile.height + 4) * this.zoomRatio * 1.2, "px") : "".concat((this.minMobile.height + 4) * this.zoomRatio, "px") : "".concat((this.minMobile.height + 6) * this.zoomRatio, "px") : this.isRoundWidget ? "".concat(this.minDesktop.height, "px") : "".concat(this.minDesktop.height + 4, "px")
                        },
                        iFrameWidth: function() {
                            if (this.mobileBrowserName) {
                                var t = this.resizeWidth || this.minMobile.width;
                                return !this.isMobileLandscape || "iphone" !== this.os.identity && "mac" !== this.os.identity ? "".concat((t + 7) * this.zoomRatio, "px") : "safari" === this.mobileBrowserName ? "".concat((t + 7) * (1.2 * this.zoomRatio), "px") : "".concat((t + 7) * (this.zoomRatio / 1.7), "px")
                            }
                            return "".concat(this.minDesktop.width + 4, "px")
                        },
                        styleObject: function() {
                            var t, i, e = this.mobileBrowserName ? this.minMobile : this.minDesktop,
                                o = {
                                    "position:": "fixed !important;",
                                    "z-index:": "1000003 !important;",
                                    "width:": "".concat(this.iFrameWidth, " !important;"),
                                    "height:": "".concat(this.iFrameHeight, " !important;"),
                                    "min-width:": "".concat(this.iFrameWidth, " !important;"),
                                    "min-height:": "".concat(this.iFrameHeight, " !important;"),
                                    "max-width:": "".concat(this.iFrameWidth, " !important;"),
                                    "max-height:": "".concat(this.iFrameHeight, " !important;")
                                };
                            this.mobileBrowserName ? this.isMobileLandscape ? "safari" === this.mobileBrowserName ? (t = this.xOffsetMobile, i = this.yOffsetMobile) : (t = this.xOffsetMobile / 1.7, i = this.yOffsetMobile / 1.7) : (t = this.xOffsetMobile, i = this.yOffsetMobile) : (t = this.xOffset, i = this.yOffset);
                            var n = t * this.zoomRatio;
                            if (this.isRight ? o["right:"] = "".concat(n, "px !important;") : o["left:"] = "".concat(n, "px !important;"), this.isCenter) {
                                if (o["top:"] = "calc((50% - ".concat(.5 * e.height, "px) + ").concat(i, "px) !important;"), !this.isRoundWidget) {
                                    var s = .5 * e.height - .5 * e.width + t,
                                        a = "49% !important",
                                        r = "rotate(".concat(this.isRight ? "-90deg" : "90deg", ") !important");
                                    this.mobileBrowserName ? (a = "0 0 !important", this.isRight ? (o["left:"] = "calc(100% - ".concat(this.iFrameHeight, " - ").concat(this.xOffsetMobile * this.zoomRatio, "px) !important;"), r = "rotate(-90deg) translateX(-50%) !important") : (o["right:"] = "85% !important;", o["left:"] = "calc(".concat(this.iFrameHeight, " + ").concat(this.xOffsetMobile * this.zoomRatio, "px) !important;"), r = "rotate(90deg) translateX(-50%) !important")) : this.isRight ? o["right:"] = "".concat(s, "px !important;") : o["left:"] = "".concat(s, "px !important;"), o["transform-origin:"] = a, o["-webkit-transform:"] = "".concat(r, ";"), o["-ms-transform:"] = "".concat(r, ";"), o["transform:"] = "".concat(r, ";")
                                }
                            } else this.isBottom ? o["bottom:"] = "".concat(i * this.zoomRatio, "px !important;") : o["top:"] = "".concat(i * this.zoomRatio, "px !important;");
                            return "max" !== this.chatWindowState || this.isRoundWidget && !this.mobileBrowserName ? this.mobileBrowserName ? o["display:"] = "block !important;" : setTimeout((function() {
                                o["display:"] = "block !important;"
                            }), 250) : o["display:"] = "none !important;", g(g({}, this.genericStyles), o)
                        },
                        badgePosition: function() {
                            var t, i, e = this.mobileBrowserName ? this.minMobile : this.minDesktop,
                                o = {};
                            return this.mobileBrowserName && this.resizeWidth && (e.width = this.resizeWidth + 5), this.isRoundWidget ? (t = "".concat(e.width - 20, "px"), i = "".concat(e.height - 20, "px")) : (t = "".concat(e.width - 16, "px"), i = "".concat(e.height - 16, "px")), this.isBottom || this.isCenter ? (o.left = t, o.bottom = i, o.right = "auto", o.top = "auto") : (o.left = t, o.top = "0px", o.right = "auto", o.bottom = "auto"), o
                        },
                        isLiveChatFeatureEnabled: function() {
                            return !!(this.hasLiveChat || this.hasChatStarted && this.agentsCount > 0)
                        },
                        hideMinimizeWidget: function() {
                            return "slide" === this.onClick && "max" === this.chatWindowState
                        }
                    }),
                    watch: {
                        zoomRatio: function() {
                            this.mobileBrowserName && this.isLoaded && this.scaleContent()
                        },
                        isMobileLandscape: function() {
                            this.mobileBrowserName && this.scaleContent()
                        }
                    },
                    methods: g(g({}, Object(o.b)({
                        toggleWidget: "session/toggleWidget"
                    })), {}, {
                        loaded: function() {
                            var t = this;
                            this.isLoaded = !0, this.$nextTick((function() {
                                t.contentChange()
                            })), this.mobileBrowserName && this.scaleContent()
                        },
                        scaleContent: function() {
                            var t, i = this.isRTL ? "right" : "left",
                                e = "scale(".concat(this.zoomRatio, ")");
                            t = this.isBottom || this.isCenter ? "bottom" : "top", this.mobileBrowserName && this.isMobileLandscape && ("safari" !== this.mobileBrowserName || "iphone" !== this.os.identity && "mac" !== this.os.identity ? "safari" === this.mobileBrowserName || "iphone" !== this.os.identity && "mac" !== this.os.identity || (e = "scale(".concat(this.zoomRatio / 1.7, ")")) : e = "scale(".concat(1.2 * this.zoomRatio, ")"));
                            var o = "-moz-transform: ".concat(e, ";\n\t\t\t\t\t\t\t-webkit-transform: ").concat(e, ";\n\t\t\t\t\t\t\t-o-transform: ").concat(e, ";\n\t\t\t\t\t\t\t-ms-transform: ").concat(e, ";\n\t\t\t\t\t\t\ttransform: ").concat(e, ";"),
                                n = "-moz-transform-origin: ".concat(t, " ").concat(i, ";\n\t\t\t\t\t\t\t\t-webkit-transform-origin: ").concat(t, "  ").concat(i, ";\n\t\t\t\t\t\t\t\t-o-transform-orgin: ").concat(t, "  ").concat(i, ";\n\t\t\t\t\t\t\t\t-ms-transform-origin: ").concat(t, "  ").concat(i, ";\n\t\t\t\t\t\t\t\ttransform-origin: ").concat(t, "  ").concat(i);
                            this.$refs.container.style.cssText += o + n
                        },
                        contentChange: function() {
                            var t = this;
                            this.mobileBrowserName && !this.isRoundWidget && setTimeout((function() {
                                if (t.$refs && t.$refs["min-content"] && t.$refs["min-content"].$refs) {
                                    var i = t.$refs["min-content"].$refs["content-icon"],
                                        e = t.$refs["min-content"].$refs["content-text"];
                                    if (i && e) {
                                        e.className = e.className.replace(/tawk-text-truncate/g, "").trim();
                                        var o = i.clientWidth + e.clientWidth + 8;
                                        o && o + 16 > t.minMobile.width ? t.resizeWidth = o + 16 : t.resizeWidth = 0
                                    }
                                    t.resizeWidth > screen.width && (t.resizeWidth = screen.width - 2 * t.xOffsetMobile, e.className += " tawk-text-truncate")
                                }
                            }), 1e3 / 66)
                        }
                    })
                },
                v = Object(m.a)(b, (function() {
                    var t = this,
                        i = t._self._c;
                    return i("i-frame", {
                        key: t.key,
                        ref: "iframe",
                        attrs: {
                            width: t.iFrameWidth,
                            height: t.iFrameHeight,
                            cssLink: t.cssLink,
                            styleObject: t.styleObject
                        }
                    }, [i("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isLoaded && !t.hideMinimizeWidget,
                            expression: "isLoaded && !hideMinimizeWidget"
                        }],
                        ref: "container",
                        staticClass: "tawk-min-container"
                    }, [t.unreadMessageCount > 0 && "offline" !== t.pageStatus && "min" === t.chatWindowState && t.isLiveChatFeatureEnabled ? i("tawk-badge", {
                        staticClass: "tawk-min-badge",
                        style: t.badgePosition,
                        attrs: {
                            count: t.unreadMessageCount
                        }
                    }) : t._e(), i("tawk-button", {
                        staticClass: "tawk-custom-color tawk-custom-border-color tawk-outline",
                        style: t.buttonStyles,
                        attrs: {
                            label: "$i18n('chat', 'chat_widget')",
                            isCircle: t.isRoundWidget,
                            size: t.isRoundWidget ? "large" : "",
                            tabindex: "0"
                        },
                        on: {
                            click: t.toggleWidget
                        }
                    }, [i("min-content", {
                        ref: "min-content",
                        attrs: {
                            minDesktop: t.minDesktop,
                            isRoundWidget: t.isRoundWidget
                        },
                        on: {
                            contentChange: t.contentChange
                        }
                    })], 1)], 1)])
                }), [], !1, null, null, null);
            i.default = v.exports
        }
    }
]);