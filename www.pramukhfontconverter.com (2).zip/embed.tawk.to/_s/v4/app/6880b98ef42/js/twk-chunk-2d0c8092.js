(window.tawkJsonp = window.tawkJsonp || []).push([
    ["chunk-2d0c8092"], {
        "52ba": function(t, e, i) {
            "use strict";
            i.r(e);
            var n = i("2f62"),
                r = i("f0b0"),
                o = i("5a60"),
                s = i("87dd"),
                a = i("7f46");

            function c(t) {
                return (c = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function d(t, e) {
                var i = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), i.push.apply(i, n)
                }
                return i
            }

            function h(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? d(Object(i), !0).forEach((function(e) {
                        m(t, e, i[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : d(Object(i)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e))
                    }))
                }
                return t
            }

            function m(t, e, i) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != c(t) || !t) return t;
                        var i = t[Symbol.toPrimitive];
                        if (void 0 !== i) {
                            var n = i.call(t, e || "default");
                            if ("object" != c(n)) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == c(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = i, t
            }
            var g = {
                    name: "BrandingWidget",
                    components: {
                        IFrame: o.a,
                        TawkBranding: r.TawkBranding
                    },
                    mixins: [s.a],
                    data: function() {
                        return {
                            cssLink: "".concat("https://embed.tawk.to/_s/v4/app/6880b98ef42", "/css/branding-widget.css"),
                            imageUrl: "".concat("https://embed.tawk.to/_s/v4/assets", "/images/Tawky_16x16.svg"),
                            powerImageURL: "".concat("https://embed.tawk.to/_s/v4/assets", "/images/power.svg"),
                            iframe: {
                                height: "",
                                width: ""
                            },
                            key: r.Helper.generateUUID(),
                            showBranding: !1
                        }
                    },
                    mounted: function() {
                        var t = this;
                        "max" === this.chatWindowState && setTimeout((function() {
                            t.$refs["branding-widget"].$el.style.setProperty("display", "block", "important"), t.showBranding = !0
                        }), 250), this.$eventBus.$on("switchWidget", (function() {
                            t.key = r.Helper.generateUUID()
                        }))
                    },
                    watch: {
                        chatWindowState: function(t) {
                            var e = this;
                            "max" === this.onClick && !this.mobileBrowserName && this.isRoundWidget && this.$refs && this.$refs["branding-widget"] && ("max" === t ? setTimeout((function() {
                                e.$refs["branding-widget"].$el.style.setProperty("display", "block", "important"), e.showBranding = !0
                            }), 250) : setTimeout((function() {
                                e.$refs["branding-widget"].$el.style.setProperty("display", "none", "important"), e.showBranding = !1
                            }), 250))
                        }
                    },
                    computed: h(h({}, Object(n.c)({
                        isRight: "widget/isRight",
                        isBottom: "widget/isBottom",
                        isCenter: "widget/isCenter",
                        branding: "widget/branding",
                        chatWindowState: "session/chatWindowState",
                        isWindowed: "widget/isWindowed",
                        isEmbedded: "widget/isEmbedded",
                        minDesktop: "widget/minDesktop",
                        maxDesktop: "widget/maxDesktop",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        onClick: "widget/onClick",
                        isRoundWidget: "widget/isRoundWidget"
                    })), {}, {
                        xOffset: function() {
                            return this.$TawkWidgetSettings.xOffset()
                        },
                        yOffset: function() {
                            return this.$TawkWidgetSettings.yOffset()
                        },
                        iFrameHeight: function() {
                            return 30
                        },
                        iFrameWidth: function() {
                            return 175
                        },
                        styleObject: function() {
                            var t, e = {
                                "z-index:": "1000002 !important;",
                                "height:": "".concat(this.iFrameHeight + 15, "px !important;"),
                                "width:": "".concat(this.maxDesktop.width, "px !important;"),
                                "min-height:": "".concat(this.iFrameHeight + 15, "px !important;"),
                                "min-width:": "".concat(this.maxDesktop.width, "px !important;"),
                                "max-height:": "".concat(this.iFrameHeight + 15, "px !important;"),
                                "max-width:": "".concat(this.maxDesktop.width, "px !important;"),
                                "position:": "fixed !important;"
                            };
                            t = this.isCenter ? this.minDesktop.width + this.xOffset + 10 : this.xOffset, this.isRight ? e["right:"] = "".concat(t, "px !important;") : e["left:"] = "".concat(t, "px !important;"), "max" === this.chatWindowState || this.isEmbedded ? e["display:"] = "block !important;" : e["display:"] = "none !important;";
                            return this.isBottom ? e["bottom:"] = "".concat(this.minDesktop.height + this.yOffset - 50, "px !important;") : (e["top:"] = "".concat(this.maxDesktop.height + this.minDesktop.height + this.yOffset + 30, "px !important;"), e["bottom:"] = "auto !important;"), h(h({}, this.genericStyles), e)
                        },
                        whitelabel: function() {
                            if (this.branding.whitelabeled) {
                                var t = a.a.markdownToHtml(this.branding.text);
                                return t && "Chat U+26A1 by <b>tawk.to</b>" === t && (t = t.replace("U+26A1", '<img src="'.concat(this.powerImageURL, '" style="max-width: 8px;" />'))), t && ":tawky: Add free <b>live chat</b> to your site" === t && (t = t.replace(":tawky:", '<img src="'.concat(this.imageUrl, '" />'))), {
                                    label: t,
                                    url: this.branding.url,
                                    textColor: this.branding.textColor
                                }
                            }
                        },
                        isShow: function() {
                            return "slide" !== this.onClick && !!this.isRoundWidget && !this.isEmbedded && (this.branding.whitelabeled && !this.mobileBrowserName ? this.branding.text.length : "max" === this.onClick && !this.mobileBrowserName)
                        }
                    })
                },
                l = i("2877"),
                p = Object(l.a)(g, (function() {
                    var t = this,
                        e = t._self._c;
                    return t.isShow ? e("i-frame", {
                        key: t.key,
                        ref: "branding-widget",
                        attrs: {
                            height: "".concat(t.iFrameHeight, "px"),
                            cssLink: t.cssLink,
                            styleObject: t.styleObject
                        }
                    }, [e("div", [t.showBranding ? e("tawk-branding", {
                        ref: "branding",
                        attrs: {
                            whitelabel: t.whitelabel,
                            imageUrl: t.imageUrl,
                            tawkToUrl: t.branding.url,
                            isFloating: !0
                        }
                    }) : t._e()], 1)]) : t._e()
                }), [], !1, null, null, null);
            e.default = p.exports
        }
    }
]);