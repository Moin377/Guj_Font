(window.tawkJsonp = window.tawkJsonp || []).push([
    ["chunk-6289ff8e", "chunk-2d0e4a7c"], {
        "06d5": function(t, e, a) {
            (e = a("24fb")(!1)).push([t.i, ".tawk-button-hover[data-v-2fc2d95d]:focus,.tawk-button-hover[data-v-2fc2d95d]:hover{background-color:hsla(0,0%,100%,.2)!important;border-radius:5px!important}", ""]), t.exports = e
        },
        "24fb": function(t, e, a) {
            "use strict";

            function i(t, e) {
                var a = t[1] || "",
                    i = t[3];
                if (!i) return a;
                if (e && "function" == typeof btoa) {
                    var s = function(t) {
                            var e = btoa(unescape(encodeURIComponent(JSON.stringify(t)))),
                                a = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(e);
                            return "/*# ".concat(a, " */")
                        }(i),
                        n = i.sources.map((function(t) {
                            return "/*# sourceURL=".concat(i.sourceRoot || "").concat(t, " */")
                        }));
                    return [a].concat(n).concat([s]).join("\n")
                }
                return [a].join("\n")
            }
            t.exports = function(t) {
                var e = [];
                return e.toString = function() {
                    return this.map((function(e) {
                        var a = i(e, t);
                        return e[2] ? "@media ".concat(e[2], " {").concat(a, "}") : a
                    })).join("")
                }, e.i = function(t, a, i) {
                    "string" == typeof t && (t = [
                        [null, t, ""]
                    ]);
                    var s = {};
                    if (i)
                        for (var n = 0; n < this.length; n++) {
                            var r = this[n][0];
                            null != r && (s[r] = !0)
                        }
                    for (var o = 0; o < t.length; o++) {
                        var c = [].concat(t[o]);
                        i && s[c[0]] || (a && (c[2] ? c[2] = "".concat(a, " and ").concat(c[2]) : c[2] = a), e.push(c))
                    }
                }, e
            }
        },
        "499e": function(t, e, a) {
            "use strict";

            function i(t, e) {
                for (var a = [], i = {}, s = 0; s < e.length; s++) {
                    var n = e[s],
                        r = n[0],
                        o = {
                            id: t + ":" + s,
                            css: n[1],
                            media: n[2],
                            sourceMap: n[3]
                        };
                    i[r] ? i[r].parts.push(o) : a.push(i[r] = {
                        id: r,
                        parts: [o]
                    })
                }
                return a
            }
            a.r(e), a.d(e, "default", (function() {
                return f
            }));
            var s = "undefined" != typeof document;
            if ("undefined" != typeof DEBUG && DEBUG && !s) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
            var n = {},
                r = s && (document.head || document.getElementsByTagName("head")[0]),
                o = null,
                c = 0,
                l = !1,
                u = function() {},
                h = null,
                d = "data-vue-ssr-id",
                m = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

            function f(t, e, a, s) {
                l = a, h = s || {};
                var r = i(t, e);
                return p(r),
                    function(e) {
                        for (var a = [], s = 0; s < r.length; s++) {
                            var o = r[s],
                                c = n[o.id];
                            c.refs--, a.push(c)
                        }
                        for (e ? p(r = i(t, e)) : r = [], s = 0; s < a.length; s++)
                            if (0 === (c = a[s]).refs) {
                                for (var l = 0; l < c.parts.length; l++) c.parts[l]();
                                delete n[c.id]
                            }
                    }
            }

            function p(t) {
                for (var e = 0; e < t.length; e++) {
                    var a = t[e],
                        i = n[a.id];
                    if (i) {
                        i.refs++;
                        for (var s = 0; s < i.parts.length; s++) i.parts[s](a.parts[s]);
                        for (; s < a.parts.length; s++) i.parts.push(w(a.parts[s]));
                        i.parts.length > a.parts.length && (i.parts.length = a.parts.length)
                    } else {
                        var r = [];
                        for (s = 0; s < a.parts.length; s++) r.push(w(a.parts[s]));
                        n[a.id] = {
                            id: a.id,
                            refs: 1,
                            parts: r
                        }
                    }
                }
            }

            function g() {
                var t = document.createElement("style");
                return t.type = "text/css", r.appendChild(t), t
            }

            function w(t) {
                var e, a, i = document.querySelector("style[" + d + '~="' + t.id + '"]');
                if (i) {
                    if (l) return u;
                    i.parentNode.removeChild(i)
                }
                if (m) {
                    var s = c++;
                    i = o || (o = g()), e = v.bind(null, i, s, !1), a = v.bind(null, i, s, !0)
                } else i = g(), e = y.bind(null, i), a = function() {
                    i.parentNode.removeChild(i)
                };
                return e(t),
                    function(i) {
                        if (i) {
                            if (i.css === t.css && i.media === t.media && i.sourceMap === t.sourceMap) return;
                            e(t = i)
                        } else a()
                    }
            }
            var b = function() {
                var t = [];
                return function(e, a) {
                    return t[e] = a, t.filter(Boolean).join("\n")
                }
            }();

            function v(t, e, a, i) {
                var s = a ? "" : i.css;
                if (t.styleSheet) t.styleSheet.cssText = b(e, s);
                else {
                    var n = document.createTextNode(s),
                        r = t.childNodes;
                    r[e] && t.removeChild(r[e]), r.length ? t.insertBefore(n, r[e]) : t.appendChild(n)
                }
            }

            function y(t, e) {
                var a = e.css,
                    i = e.media,
                    s = e.sourceMap;
                if (i && t.setAttribute("media", i), h.ssrId && t.setAttribute(d, e.id), s && (a += "\n/*# sourceURL=" + s.sources[0] + " */", a += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(s)))) + " */"), t.styleSheet) t.styleSheet.cssText = a;
                else {
                    for (; t.firstChild;) t.removeChild(t.firstChild);
                    t.appendChild(document.createTextNode(a))
                }
            }
        },
        "4b3e": function(t, e, a) {
            "use strict";
            a.d(e, "a", (function() {
                return o
            }));
            var i = a("2f62");

            function s(t) {
                return (s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function n(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function r(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != s(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != s(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == s(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var o = {
                data: function() {
                    return {
                        offVideo: !0
                    }
                },
                computed: function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var a = null != arguments[e] ? arguments[e] : {};
                        e % 2 ? n(Object(a), !0).forEach((function(e) {
                            r(t, e, a[e])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : n(Object(a)).forEach((function(e) {
                            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                        }))
                    }
                    return t
                }({}, Object(i.c)({
                    chatWindowState: "session/chatWindowState",
                    currentRoute: "router/current"
                })),
                watch: {
                    chatWindowState: function(t) {
                        "min" === t || "/" !== this.currentRoute && "kb-article" !== this.currentRoute ? this.offVideo = !1 : this.offVideo = !0
                    },
                    currentRoute: function(t) {
                        this.offVideo = "/" === t || "kb-article" === t
                    }
                }
            }
        },
        "5af8": function(t, e, a) {
            var i = a("06d5");
            i.__esModule && (i = i.default), "string" == typeof i && (i = [
                [t.i, i, ""]
            ]), i.locals && (t.exports = i.locals), (0, a("499e").default)("38c258ea", i, !0, {
                sourceMap: !1,
                shadowMode: !1
            })
        },
        "90c2": function(t, e, a) {
            "use strict";
            a.r(e);
            var i = a("2f62"),
                s = a("9f3e"),
                n = a("dbd1"),
                r = a("f0b0");

            function o(t) {
                return (o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function c(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function l(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(a), !0).forEach((function(e) {
                        u(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : c(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function u(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != o(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != o(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == o(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var h = {
                    name: "start-chat",
                    components: {
                        TawkCard: r.TawkCard,
                        TawkIcon: r.TawkIcon
                    },
                    computed: l(l({}, Object(i.c)({
                        isPrechatEnabled: "widget/isPrechatEnabled",
                        prechatFormSubmitted: "session/prechatFormSubmitted",
                        states: "widget/states",
                        pageStatus: "session/pageStatus"
                    })), {}, {
                        stateBody: function() {
                            var t = this.pageStatus || "online";
                            return t && this.states[t] && this.states[t].body || []
                        },
                        chatCard: function() {
                            var t = this.stateBody.find((function(t) {
                                return "chat" === t.type
                            }));
                            return t && t.content ? t.content : {}
                        }
                    }),
                    methods: l(l({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        showOverlay: "overlay/showOverlay",
                        clearHistory: "router/clearHistory"
                    })), {}, {
                        startChat: function() {
                            this.showOverlay(!1), this.clearHistory(), this.isPrechatEnabled && !this.prechatFormSubmitted ? this.routerPush("prechat") : this.routerPush("chat")
                        }
                    })
                },
                d = a("2877"),
                m = Object(d.a)(h, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", {
                        staticClass: "tawk-message-section"
                    }, [e("div", {
                        staticClass: "tawk-message-header"
                    }, [e("p", {
                        staticClass: "tawk-message-title"
                    }, [t._v(t._s(t.$i18n("chat", "start_new_chat")))])]), e("tawk-card", {
                        staticClass: "tawk-home-card-chat tawk-box-shadow-xsmall tawk-message-tile",
                        attrs: {
                            color: "inverse"
                        },
                        on: {
                            click: t.startChat
                        }
                    }, [e("div", {
                        staticClass: "tawk-flex-1 tawk-message-tile-content"
                    }, [e("p", {
                        staticClass: "tawk-message-tile-title"
                    }, [t._v(" " + t._s(t.chatCard.buttonText || "Chat with us") + " ")]), e("p", {
                        staticClass: "tawk-message-tile-subtitle"
                    }, [t._v(" " + t._s(t.chatCard.hasOwnProperty("buttonSubtitle") ? t.chatCard.buttonSubtitle : t.$i18n("home", "chat_button_subtitle")) + " ")])]), e("div", [e("tawk-icon", {
                        attrs: {
                            type: "send",
                            size: "24"
                        }
                    })], 1)])], 1)
                }), [], !1, null, null, null).exports,
                f = a("7f46");

            function p(t) {
                return (p = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function g(t) {
                return function(t) {
                    if (Array.isArray(t)) return w(t)
                }(t) || function(t) {
                    if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
                }(t) || function(t, e) {
                    if (t) {
                        if ("string" == typeof t) return w(t, e);
                        var a = {}.toString.call(t).slice(8, -1);
                        return "Object" === a && t.constructor && (a = t.constructor.name), "Map" === a || "Set" === a ? Array.from(t) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? w(t, e) : void 0
                    }
                }(t) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function w(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var a = 0, i = Array(e); a < e; a++) i[a] = t[a];
                return i
            }

            function b(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function v(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? b(Object(a), !0).forEach((function(e) {
                        y(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : b(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function y(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != p(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != p(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == p(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var k = {
                    name: "recents",
                    components: {
                        TawkLoader: r.TawkLoader,
                        TawkButton: r.TawkButton,
                        TawkEmoji: r.TawkEmoji,
                        TawkIcon: r.TawkIcon
                    },
                    data: function() {
                        return {
                            localConversations: []
                        }
                    },
                    computed: v(v({}, Object(i.c)({
                        emojiEnabled: "widget/emojiEnabled",
                        historyConversations: "history/items",
                        nextListHash: "history/nextListHash",
                        agents: "chat/agents",
                        incomingMessage: "chat/incomingMessage",
                        lastMessage: "chat/lastMessage",
                        unreadMessageCount: "chat/unreadMessageCount",
                        components: "widget/components"
                    })), {}, {
                        isLoading: function() {
                            return this.$store.getters["history/isLoading"]("index")
                        },
                        isRecentConversation: function() {
                            return function(t) {
                                return !t.isRead
                            }
                        },
                        hasUnreadMessage: function() {
                            return this.unreadMessageCount > 0 && ("c" === this.lastMessage.senderType || "a" === this.lastMessage.senderType || "s" === this.lastMessage.senderType)
                        }
                    }),
                    created: function() {
                        this.updateConversations()
                    },
                    mounted: function() {
                        this.loadHistory()
                    },
                    watch: {
                        historyConversations: {
                            handler: "updateConversations",
                            deep: !0
                        },
                        lastMessage: {
                            handler: "updateConversations",
                            deep: !0
                        },
                        incomingMessage: {
                            handler: "updateConversations",
                            deep: !0
                        }
                    },
                    methods: v(v({}, Object(i.b)({
                        loadHistory: "history/load",
                        routerPush: "router/routerPush",
                        showOverlay: "overlay/showOverlay"
                    })), {}, {
                        updateConversations: function() {
                            var t = g(this.historyConversations);
                            if (this.lastMessage && Object.keys(this.lastMessage).length > 0 && this.lastMessage.message) {
                                var e = this.lastMessage.message || "";
                                t.unshift({
                                    id: "active-chat",
                                    isActive: !0,
                                    snippet: e
                                })
                            }
                            this.localConversations = t
                        },
                        loadMoreConversations: function() {
                            this.loadHistory({
                                loadNext: !0,
                                limit: 5
                            })
                        },
                        getConversationName: function(t) {
                            return t.isActive ? this.lastMessage && this.lastMessage.name ? this.lastMessage.name : this.$i18n("chat", "mobile_name") : t.agentAliases && t.agentAliases.length > 0 ? t.agentAliases[0].displayName : "Unknown"
                        },
                        getConversationTime: function(t) {
                            if (t.isActive) return this.$i18n("chat", "now");
                            if (!t.endedOn) return this.$i18n("chat", "now");
                            var e = new Date(t.endedOn),
                                a = new Date;
                            return e.toDateString() === a.toDateString() ? e.toLocaleTimeString("en-GB", {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: !1
                            }) : e.toLocaleDateString("en-GB", {
                                day: "2-digit",
                                month: "2-digit",
                                year: "numeric"
                            })
                        },
                        messageTextOnly: function(t) {
                            return f.a.removeHTMLTags(f.a.removeAnchorTags(this.$TawkWindow.makeHtml(t)))
                        },
                        selectConversation: function(t) {
                            if (t && t.isActive) {
                                var e = this.$store.getters["widget/isPrechatEnabled"],
                                    a = this.$store.getters["session/prechatFormSubmitted"];
                                e && !a ? this.routerPush("prechat") : this.routerPush("chat"), this.showOverlay(!1)
                            } else this.$store.commit("history/setSelectedChat", t), this.routerPush("history-chat"), this.showOverlay(!0)
                        }
                    })
                },
                C = Object(d.a)(k, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", {
                        staticClass: "tawk-recents-message-section"
                    }, [e("p", {
                        staticClass: "tawk-message-title"
                    }, [t._v(t._s(t.$i18n("chat", "recent")))]), t.isLoading ? e("div", {
                        staticClass: "tawk-margin-small tawk-margin-top",
                        staticStyle: {
                            width: "100%"
                        },
                        attrs: {
                            role: "progressbar",
                            "aria-busy": "true"
                        }
                    }, [e("tawk-loader", {
                        staticClass: "tawk-margin-xsmall",
                        attrs: {
                            type: "bar",
                            size: "large"
                        }
                    }), e("tawk-loader", {
                        staticClass: "tawk-margin-xsmall",
                        attrs: {
                            type: "bar",
                            size: "large"
                        }
                    }), e("tawk-loader", {
                        staticClass: "tawk-margin-xsmall",
                        attrs: {
                            type: "bar",
                            size: "large"
                        }
                    })], 1) : [t.localConversations.length > 0 ? t._l(t.localConversations, (function(a, i) {
                        return e("div", {
                            key: a.id || i,
                            staticClass: "tawk-message-item",
                            attrs: {
                                role: "button",
                                tabindex: "0"
                            },
                            on: {
                                click: function(e) {
                                    return t.selectConversation(a)
                                },
                                keyup: function(e) {
                                    return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.selectConversation(a)
                                }
                            }
                        }, [e("div", {
                            staticClass: "tawk-message-item-content"
                        }, [e("div", {
                            staticClass: "tawk-message-item-header"
                        }, [e("div", {
                            staticClass: "tawk-message-item-info"
                        }, [e("span", {
                            staticClass: "tawk-message-item-name"
                        }, [t._v(t._s(t.getConversationName(a)))])]), e("span", {
                            staticClass: "tawk-message-item-time"
                        }, [t._v(t._s(t.getConversationTime(a)))])]), e("div", {
                            staticClass: "tawk-message-item-body"
                        }, [t.hasUnreadMessage && a.isActive ? e("p", {
                            staticClass: "tawk-message-item-text tawk-message-item-text-unread"
                        }, [e("span", {
                            staticClass: "tawk-emoji-container"
                        }, [e("tawk-emoji", {
                            key: t.lastMessage.messageId,
                            attrs: {
                                emoji: t.messageTextOnly(a.snippet),
                                enabled: t.emojiEnabled
                            }
                        })], 1)]) : e("p", {
                            class: ["tawk-message-item-text", t.isRecentConversation(a) ? "" : "tawk-message-item-text-secondary"]
                        }, [e("span", {
                            staticClass: "tawk-emoji-container"
                        }, [null != a && a.snippet && 0 !== a.snippet.length ? e("tawk-emoji", {
                            key: t.lastMessage.messageId,
                            attrs: {
                                emoji: t.messageTextOnly(a.snippet),
                                enabled: t.emojiEnabled
                            }
                        }) : e("p", {
                            staticClass: "tawk-text-italic"
                        }, [e("tawk-icon", {
                            attrs: {
                                type: "attachment",
                                size: "small"
                            }
                        }), t._v(" " + t._s(t.$i18n("chat", "sent_file")) + " ")], 1)], 1)]), a.isActive && t.unreadMessageCount > 0 ? e("div", {
                            staticClass: "tawk-message-item-badge"
                        }, [t._v(t._s(t.unreadMessageCount))]) : t._e(), e("tawk-icon", {
                            staticClass: "tawk-message-chevron",
                            attrs: {
                                type: "chevron-right"
                            }
                        })], 1)]), e("div", {
                            staticClass: "tawk-message-divider"
                        })])
                    })) : [e("div", {
                        staticClass: "tawk-margin-auto tawk-padding"
                    }, [e("p", {
                        staticClass: "tawk-text-regular-4 tawk-text-grey-3"
                    }, [t._v(t._s(t.$i18n("home", "no_recent_conversations")))])])]], t.nextListHash && !t.isLoading ? e("div", {
                        staticClass: "tawk-text-center tawk-margin-top-small"
                    }, [e("tawk-button", {
                        staticClass: "tawk-message-load-more-button",
                        attrs: {
                            label: t.$i18n("routes", "load_more"),
                            isText: !0
                        },
                        on: {
                            click: t.loadMoreConversations
                        }
                    }, [t._v(" " + t._s(t.$i18n("routes", "load_more")) + " ")])], 1) : t._e()], 2)
                }), [], !1, null, null, null).exports;

            function O(t) {
                return (O = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function S(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function x(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != O(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != O(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == O(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var T = {
                    name: "messages",
                    components: {
                        BaseFrame: s.a,
                        BaseBody: n.a,
                        StartChat: m,
                        Recents: C
                    },
                    computed: function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var a = null != arguments[e] ? arguments[e] : {};
                            e % 2 ? S(Object(a), !0).forEach((function(e) {
                                x(t, e, a[e])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : S(Object(a)).forEach((function(e) {
                                Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                            }))
                        }
                        return t
                    }({}, Object(i.c)({
                        hasLiveChat: "widget/hasLiveChat",
                        pageStatus: "session/pageStatus"
                    }))
                },
                $ = Object(d.a)(T, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("base-frame", {
                        staticClass: "tawk-message-view"
                    }, [e("base-body", {
                        staticClass: "tawk-margin-top"
                    }, [t.hasLiveChat && "offline" !== t.pageStatus ? e("start-chat") : t._e(), e("recents")], 1)], 1)
                }), [], !1, null, null, null);
            e.default = $.exports
        },
        a36a: function(t, e, a) {
            "use strict";
            a("5af8")
        },
        d6a3: function(t, e, a) {
            "use strict";
            a.r(e);
            var i = a("2f62"),
                s = a("f0b0"),
                n = a("5a60"),
                r = {
                    methods: {
                        convertToAvatarLink: function(t) {
                            return t ? 0 === t.indexOf("https://s3.amazonaws.com/tawk-to-pi") || 0 === t.indexOf("https://embed.tawk.to/_s/v4/assets") ? t : "".concat("https://s3.amazonaws.com/tawk-to-pi", "/").concat(t) : "".concat("https://embed.tawk.to/_s/v4/assets", "/images/default-profile.svg")
                        }
                    }
                },
                o = {
                    name: "AvatarGroup",
                    components: {
                        TawkAvatar: s.TawkAvatar
                    },
                    directives: {
                        TawkTooltip: s.TawkTooltip
                    },
                    mixins: [r],
                    props: {
                        agents: {
                            type: Array,
                            required: !0,
                            default: function() {
                                return []
                            }
                        },
                        showWebrtcOptions: {
                            type: Boolean,
                            default: !1
                        },
                        toolbarWidth: {
                            type: Number,
                            required: !0,
                            default: 0
                        }
                    },
                    computed: {
                        isDesktopView: function() {
                            return this.toolbarWidth >= 350
                        },
                        shouldShowAgentDetails: function() {
                            return this.isDesktopView || !this.isDesktopView && !this.showWebrtcOptions
                        },
                        isSingleAgent: function() {
                            return 1 === this.agents.length
                        },
                        firstAgent: function() {
                            return this.agents[0] || {}
                        },
                        visibleAgents: function() {
                            return this.agents.slice(0, 3)
                        },
                        hasOverflow: function() {
                            return this.agents.length > 3
                        },
                        overflowCount: function() {
                            return this.agents.length - 3
                        }
                    },
                    methods: {
                        getAvatarStackStyle: function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                                e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                            return {
                                display: "inline-block",
                                marginLeft: t > 0 || e ? "-".concat(8, "px") : "0",
                                zIndex: e ? 1 : this.visibleAgents.length - t
                            }
                        }
                    }
                },
                c = a("2877"),
                l = Object(c.a)(o, (function() {
                    var t = this,
                        e = t._self._c;
                    return t.isSingleAgent ? e("div", {
                        staticStyle: {
                            display: "contents"
                        }
                    }, [e("div", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        staticStyle: {
                            display: "inline-block"
                        },
                        attrs: {
                            "data-text": t.firstAgent.displayName || "agent",
                            "aria-label": t.firstAgent.displayName || "agent"
                        }
                    }, [e("tawk-avatar", {
                        attrs: {
                            src: t.convertToAvatarLink(t.firstAgent.profileImage),
                            alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                        }
                    })], 1), t.shouldShowAgentDetails ? e("div", {
                        staticClass: "tawk-toolbar-agent-details"
                    }, [e("p", {
                        staticClass: "tawk-toolbar-agent-name tawk-text-truncate"
                    }, [t._v(" " + t._s(t.firstAgent.displayName) + " ")]), e("p", {
                        staticClass: "tawk-toolbar-agent-title tawk-text-truncate"
                    }, [t._v(" " + t._s(t.firstAgent.profileTitle) + " ")])]) : t._e()]) : e("div", {
                        staticClass: "tawk-avatar-group"
                    }, [t.isDesktopView ? e("div", [t._l(t.visibleAgents, (function(a, i) {
                        return e("div", {
                            directives: [{
                                name: "tawk-tooltip",
                                rawName: "v-tawk-tooltip"
                            }],
                            key: a.id,
                            style: t.getAvatarStackStyle(i),
                            attrs: {
                                "data-text": a.displayName || "agent",
                                "aria-label": a.displayName || "agent"
                            }
                        }, [e("tawk-avatar", {
                            attrs: {
                                src: t.convertToAvatarLink(a.profileImage),
                                alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                            }
                        })], 1)
                    })), t.hasOverflow ? e("div", {
                        style: t.getAvatarStackStyle(0, !0)
                    }, [e("tawk-avatar", {
                        attrs: {
                            count: t.overflowCount
                        }
                    })], 1) : t._e()], 2) : e("div", [e("tawk-avatar", {
                        attrs: {
                            count: t.agents.length
                        }
                    })], 1)])
                }), [], !1, null, null, null).exports;

            function u(t) {
                return (u = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function h(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function d(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? h(Object(a), !0).forEach((function(e) {
                        m(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : h(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function m(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != u(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != u(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == u(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var f = {
                    name: "toolbar",
                    components: {
                        TawkIcon: s.TawkIcon,
                        TawkButton: s.TawkButton,
                        TawkDropdown: s.TawkDropdown,
                        TawkAvatar: s.TawkAvatar,
                        AvatarGroup: l
                    },
                    directives: {
                        TawkTooltip: s.TawkTooltip
                    },
                    mixins: [r],
                    data: function() {
                        return {
                            isOpen: !1,
                            isActive: !1
                        }
                    },
                    props: {
                        currentView: {
                            type: Object,
                            default: function() {
                                return {}
                            }
                        },
                        borderRadiusTop: {
                            type: String,
                            default: "0px"
                        },
                        hasBackground: {
                            type: Boolean,
                            default: !0
                        },
                        showBackButton: {
                            default: !1
                        },
                        showWebRtcButtons: {
                            type: Boolean,
                            default: !1
                        },
                        showAgentAvatars: {
                            default: !1
                        }
                    },
                    computed: d(d({}, Object(i.c)({
                        isSoundEnabled: "widget/isSoundEnabled",
                        localSoundEnabled: "widget/localSoundEnabled",
                        isRoundWidget: "widget/isRoundWidget",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        hasChatStarted: "chat/hasChatStarted",
                        isWindowed: "widget/isWindowed",
                        prechatFormSubmitted: "session/prechatFormSubmitted",
                        isPrechatEnabled: "widget/isPrechatEnabled",
                        pageStatus: "session/pageStatus",
                        isRTL: "widget/isRTL",
                        webrtcOptions: "widget/webrtcOptions",
                        hasLiveChat: "widget/hasLiveChat",
                        agentsCount: "chat/agentsCount",
                        needConsent: "session/needConsent",
                        currentRoute: "router/current",
                        components: "widget/components",
                        emailTranscriptEnabled: "widget/emailTranscriptEnabled",
                        activeProfiles: "chat/activeProfiles",
                        toolbarOptions: "widget/toolbarOptions",
                        branding: "widget/branding",
                        calls: "chat/calls",
                        messageBlocks: "chat/messageBlocks",
                        ongoingCall: "chat/ongoingCall",
                        onClick: "widget/onClick",
                        isHome: "router/isHome",
                        getLogoContent: "widget/getLogoContent",
                        chatMessages: "chat/chatMessages",
                        selectedChat: "history/selectedChat",
                        maxDesktop: "widget/maxDesktop"
                    })), {}, {
                        showWebrtcOptions: function() {
                            return this.components.webrtc && "offline" !== this.pageStatus && this.webrtcOptions && this.webrtcOptions.enabled && (!this.isPrechatEnabled || this.isPrechatEnabled && this.prechatFormSubmitted) && this.showWebRtcButtons && !this.isBotOnly
                        },
                        isBotOnly: function() {
                            if (0 === this.activeProfiles.length) return !1;
                            var t = !1;
                            return this.activeProfiles[0].isBot && (t = !0), t
                        },
                        wrapperClasses: function() {
                            return ["tawk-toolbar", "tawk-flex", "tawk-card-small", "tawk-flex-none", "tawk-flex-middle", "tawk-custom-color", (this.isHome || "prechat" === this.currentRoute) && this.isActive ? "tawk-active" : "", this.isHome || "prechat" === this.currentRoute ? "" : "tawk-active"]
                        },
                        isLiveChatFeatureEnabled: function() {
                            return !!(this.hasLiveChat || this.hasChatStarted && this.agentsCount > 0)
                        },
                        isHamburgerMenuVisible: function() {
                            return "offline" !== this.pageStatus && ("chat" === this.currentRoute || "agents" === this.currentRoute && !this.selectedChat)
                        },
                        isAgentAvatarsVisible: function() {
                            return !(!this.showAgentAvatars || "chat" !== this.currentRoute && "agents" !== this.currentRoute || !(this.activeProfiles.length > 0))
                        },
                        logoUrl: function() {
                            return "https://tawk.link"
                        }
                    }),
                    methods: d(d({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        routerBack: "router/routerBack",
                        toggleLocalSound: "widget/toggleLocalSound",
                        toggleWidget: "session/toggleWidget",
                        showOverlay: "overlay/showOverlay"
                    })), {}, {
                        initiateCall: function(t, e) {
                            this.$TawkChatManager.initiateCall(t, e)
                        },
                        popoutWidget: function() {
                            this.$TawkWindow.popoutWidget()
                        },
                        toggleDropdown: function() {
                            this.isOpen = !this.isOpen
                        },
                        nameForm: function() {
                            this.isOpen = !1, this.routerPush("name-form"), this.showOverlay(!0)
                        },
                        emailTranscriptForm: function() {
                            this.isOpen = !1, this.routerPush("email-transcript-form"), this.showOverlay(!0)
                        },
                        toggleAgentsList: function() {
                            this.routerPush("agents"), this.showOverlay(!0)
                        }
                    }),
                    mounted: function() {
                        var t = this;
                        this.$eventBus.$on("widgetOnFocus", (function(e) {
                            t.$refs["toolbar-button"] && !t.$refs["toolbar-button"].$el.contains(e.target) && (t.isOpen = !1)
                        })), this.$eventBus.$on("chatPanelScroll", (function(e) {
                            e.scrollTop > 5 ? t.isActive = !0 : t.isActive = !1
                        }))
                    }
                },
                p = (a("a36a"), Object(c.a)(f, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", {
                        ref: "toolbar",
                        class: t.wrapperClasses,
                        style: {
                            borderRadius: t.borderRadiusTop
                        }
                    }, [e("div", {
                        staticClass: "tawk-toolbar-nav",
                        attrs: {
                            role: "navigation",
                            "aria-label": "primary"
                        }
                    }, [t.showBackButton ? e("div", {
                        staticClass: "tawk-route-back tawk-flex tawk-flex-middle tawk-margin-xsmall-right"
                    }, [e("tawk-button", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        staticClass: "tawk-header-text tawk-button-hover",
                        attrs: {
                            isText: !0,
                            inverse: !0,
                            "data-text": t.$i18n("rollover", "back"),
                            "aria-label": t.$i18n("rollover", "back"),
                            tabindex: "0"
                        },
                        on: {
                            click: t.routerBack
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "chevron-left"
                        }
                    })], 1), t.currentView.title && "agents" !== t.currentRoute ? e("span", {
                        staticClass: "tawk-toolbar-title tawk-text-regular-3 tawk-header-text tawk-margin-xsmall-left tawk-custom-text-color-inverse"
                    }, [t._v(" " + t._s(t.currentView.title()) + " ")]) : t.chatMessages && Object.keys(t.chatMessages).length > 0 && !t.isAgentAvatarsVisible && "prechat" !== this.currentView.path ? e("p", {
                        staticClass: "tawk-toolbar-agent-name tawk-text-truncate"
                    }, [t._v(" " + t._s(t.chatMessages[Object.keys(t.chatMessages)[0]].name) + " ")]) : t._e()], 1) : t._e(), "history-chat" === t.currentRoute ? [e("div", {
                        class: ["tawk-toolbar-agent-avatars", {
                            "tawk-margin-remove-left": 1 === t.selectedChat.agentAliases
                        }],
                        on: {
                            click: t.toggleAgentsList
                        }
                    }, [t.selectedChat.agentAliases.length > 1 ? e("div", t._l(t.selectedChat.agentAliases, (function(a, i) {
                        return e("tawk-avatar", {
                            key: i,
                            attrs: {
                                src: t.convertToAvatarLink(a.profileImage),
                                alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                            }
                        })
                    })), 1) : t._e(), t.selectedChat.agentAliases.length ? e("div", {
                        staticClass: "tawk-toolbar-agent-details"
                    }, [t.selectedChat.agentAliases[0].displayName ? e("p", {
                        staticClass: "tawk-toolbar-agent-name tawk-text-truncate"
                    }, [t._v(" " + t._s(t.selectedChat.agentAliases[0].displayName) + " ")]) : t._e(), t.selectedChat.agentAliases[0].profileTitle ? e("p", {
                        staticClass: "tawk-toolbar-agent-title tawk-text-truncate"
                    }, [t._v(" " + t._s(t.selectedChat.agentAliases[0].profileTitle) + " ")]) : t._e()]) : t._e(), t.selectedChat.agentAliases.length > 1 ? e("div", {
                        staticClass: "tawk-margin-xsmall-left"
                    }, [e("tawk-avatar", {
                        attrs: {
                            count: t.selectedChat.agentAliases.length - 1
                        }
                    })], 1) : t._e()])] : t._e(), t.isHome && t.getLogoContent ? e("div", {
                        staticClass: "tawk-flex-1 tawk-padding-small",
                        class: ["tawk-text-".concat(t.getLogoContent.alignment), "right" === t.getLogoContent.alignment ? "tawk-margin-xsmall-right" : ""]
                    }, [e("img", {
                        staticClass: "tawk-toolbar-logo",
                        attrs: {
                            src: "".concat(t.logoUrl, "/").concat(t.getLogoContent.image.content),
                            alt: "'Logo'"
                        }
                    })]) : t._e(), e("transition", {
                        attrs: {
                            name: "fade",
                            mode: "out-in"
                        }
                    }, [t.isAgentAvatarsVisible ? e("div", {
                        class: ["tawk-toolbar-agent-avatars", {
                            "tawk-margin-remove-left": 1 === t.activeProfiles.length
                        }],
                        attrs: {
                            role: "button",
                            tabindex: "0"
                        },
                        on: {
                            click: t.toggleAgentsList
                        }
                    }, [e("avatar-group", {
                        attrs: {
                            agents: t.activeProfiles,
                            showWebrtcOptions: t.showWebrtcOptions,
                            toolbarWidth: t.maxDesktop.width
                        }
                    })], 1) : t._e()])], 2), e("div", {
                        staticClass: "tawk-margin-auto-left tawk-flex-none tawk-flex tawk-flex-middle",
                        attrs: {
                            role: "navigation",
                            "aria-label": "secondary"
                        }
                    }, [t.showWebrtcOptions && !t.needConsent ? e("div", [e("tawk-button", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        staticClass: "tawk-header-text tawk-button-hover",
                        attrs: {
                            isText: !0,
                            inverse: !0,
                            disabled: t.ongoingCall,
                            "aria-label": t.$i18n("rollover", "voice_call"),
                            "data-text": t.$i18n("rollover", "voice_call"),
                            tabindex: "0"
                        },
                        on: {
                            click: t.initiateCall
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "call"
                        }
                    })], 1), t.webrtcOptions.video ? e("tawk-button", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        staticClass: "tawk-header-text tawk-button-hover",
                        attrs: {
                            isText: !0,
                            inverse: !0,
                            disabled: t.ongoingCall,
                            "aria-label": t.$i18n("rollover", "video_call"),
                            "data-text": t.$i18n("rollover", "video_call"),
                            tabindex: "0"
                        },
                        on: {
                            click: function(e) {
                                return t.initiateCall(!0, !1)
                            }
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "video-call-on"
                        }
                    })], 1) : t._e(), t.webrtcOptions.screen ? e("tawk-button", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        staticClass: "tawk-header-text tawk-button-hover",
                        attrs: {
                            isText: !0,
                            inverse: !0,
                            disabled: t.ongoingCall,
                            "aria-label": t.$i18n("rollover", "screen_share"),
                            "data-text": t.$i18n("rollover", "screen_share"),
                            tabindex: "0"
                        },
                        on: {
                            click: function(e) {
                                return t.initiateCall(!1, !0)
                            }
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "share-screen"
                        }
                    })], 1) : t._e()], 1) : t._e(), t.isHamburgerMenuVisible && !t.needConsent ? e("tawk-dropdown", {
                        ref: "toolbar-menu",
                        staticClass: "tawk-toolbar-menu",
                        attrs: {
                            isOpen: t.isOpen,
                            position: t.isRTL ? "left" : "right",
                            role: "menu"
                        },
                        on: {
                            "update:isOpen": function(e) {
                                t.isOpen = e
                            },
                            "update:is-open": function(e) {
                                t.isOpen = e
                            }
                        }
                    }, [e("tawk-button", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        ref: "toolbar-button",
                        staticClass: "tawk-header-text tawk-margin-auto-left tawk-flex-none tawk-button-hover",
                        attrs: {
                            isText: !0,
                            inverse: !0,
                            "aria-label": t.$i18n("rollover", "chat_menu"),
                            "data-text": t.$i18n("rollover", "chat_menu"),
                            tabindex: "0"
                        },
                        nativeOn: {
                            click: function(e) {
                                return t.toggleDropdown.apply(null, arguments)
                            }
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "menu"
                        }
                    })], 1), e("div", {
                        attrs: {
                            slot: "menu"
                        },
                        slot: "menu"
                    }, [e("tawk-button", {
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle",
                        attrs: {
                            isText: !0,
                            size: "small",
                            role: "button",
                            tabindex: t.isOpen ? 0 : -1
                        },
                        on: {
                            click: t.nameForm
                        }
                    }, [e("span", {
                        staticStyle: {
                            width: "25px"
                        }
                    }, [e("tawk-icon", {
                        staticStyle: {
                            width: "20px"
                        },
                        attrs: {
                            type: "edit",
                            size: "small"
                        }
                    })], 1), t._v(" " + t._s(t.$i18n("menu", "change_name")) + " ")]), t.emailTranscriptEnabled ? e("tawk-button", {
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle",
                        attrs: {
                            isText: !0,
                            size: "small",
                            role: "button",
                            tabindex: t.isOpen ? 0 : -1
                        },
                        on: {
                            click: t.emailTranscriptForm
                        }
                    }, [e("span", {
                        staticStyle: {
                            width: "25px"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "envelope",
                            size: "small"
                        }
                    })], 1), t._v(" " + t._s(t.$i18n("menu", "email_transcript")) + " ")]) : t._e(), e("tawk-button", {
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle",
                        attrs: {
                            isText: !0,
                            size: "small",
                            role: "button",
                            tabindex: t.isOpen ? 0 : -1
                        },
                        on: {
                            click: t.toggleLocalSound
                        }
                    }, [t.isSoundEnabled && t.localSoundEnabled ? e("div", [e("span", {
                        staticStyle: {
                            width: "1.6rem",
                            "vertical-align": "middle"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "volume-up",
                            size: "medium"
                        }
                    })], 1), t._v(" " + t._s(t.$i18n("menu", "sound_on")) + " ")]) : e("div", [e("span", {
                        staticStyle: {
                            width: "1.6rem",
                            "vertical-align": "middle"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "mute",
                            size: "medium"
                        }
                    })], 1), t._v(" " + t._s(t.$i18n("menu", "sound_off")) + " ")])]), t.isWindowed ? t._e() : e("tawk-button", {
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle",
                        attrs: {
                            isText: !0,
                            size: "small",
                            role: "button",
                            tabindex: t.isOpen ? 0 : -1
                        },
                        on: {
                            click: t.popoutWidget
                        }
                    }, [e("span", {
                        staticStyle: {
                            width: "1.6rem"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "popout",
                            size: "medium"
                        }
                    })], 1), t._v(t._s(t.$i18n("menu", "popout_widget")) + " ")]), t.hasChatStarted ? e("tawk-button", {
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle",
                        attrs: {
                            isText: !0,
                            size: "small",
                            role: "button",
                            tabindex: t.isOpen ? 0 : -1
                        },
                        on: {
                            click: function(e) {
                                return t.$emit("showEndChat")
                            }
                        }
                    }, [e("span", {
                        staticStyle: {
                            width: "1.6rem"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "close-circle",
                            size: "small"
                        }
                    })], 1), t._v(" " + t._s(t.$i18n("menu", "end_chat_session")) + " ")]) : t._e(), t.branding && !t.branding.whitelabeled ? e("tawk-button", {
                        staticClass: "tawk-text-left tawk-flex tawk-flex-middle",
                        attrs: {
                            href: t.branding.url,
                            target: "blank",
                            isText: !0,
                            size: "small",
                            role: "button",
                            tabindex: t.isOpen ? 0 : -1
                        }
                    }, [e("span", {
                        staticStyle: {
                            width: "1.6rem"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "chat-bubble",
                            size: "small"
                        }
                    })], 1), t._v(" " + t._s(t.$i18n("menu", "add_chat_to_your_website")) + " ")]) : t._e()], 1)], 1) : t._e(), t.isWindowed || t.isRoundWidget && !t.mobileBrowserName && "slide" !== this.onClick ? t._e() : e("tawk-button", {
                        directives: [{
                            name: "tawk-tooltip",
                            rawName: "v-tawk-tooltip"
                        }],
                        staticClass: "tawk-header-text tawk-flex-none tawk-button-hover tawk-custom-color",
                        attrs: {
                            isText: !0,
                            "data-text": t.$i18n("rollover", "minimize"),
                            "aria-label": t.$i18n("rollover", "minimize")
                        },
                        nativeOn: {
                            click: function(e) {
                                return t.toggleWidget.apply(null, arguments)
                            }
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "x"
                        }
                    })], 1)], 1)])
                }), [], !1, null, "2fc2d95d", null)).exports,
                g = a("7f46");

            function w(t) {
                return (w = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function b(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function v(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? b(Object(a), !0).forEach((function(e) {
                        y(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : b(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function y(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != w(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != w(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == w(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var k = {
                    name: "TawkMaximizeFooter",
                    components: {
                        TawkChatInput: s.TawkChatInput,
                        TawkBranding: s.TawkBranding,
                        TawkIcon: s.TawkIcon,
                        TawkButton: s.TawkButton
                    },
                    data: function() {
                        return {
                            isDraggedOver: !1,
                            imageUrl: "".concat("https://embed.tawk.to/_s/v4/assets", "/images/Tawky_16x16.svg"),
                            powerImageURL: "".concat("https://embed.tawk.to/_s/v4/assets", "/images/power.svg")
                        }
                    },
                    computed: v(v({}, Object(i.c)({
                        isWindowed: "widget/isWindowed",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        isEmbedded: "widget/isEmbedded",
                        hasLiveChat: "widget/hasLiveChat",
                        branding: "widget/branding",
                        needConsent: "session/needConsent",
                        pageStatus: "session/pageStatus",
                        prechatFormSubmitted: "session/prechatFormSubmitted",
                        isPrechatEnabled: "widget/isPrechatEnabled",
                        getHistory: "router/getHistory",
                        currentView: "router/getCurrentView",
                        features: "widget/features",
                        states: "widget/states",
                        hasChatStarted: "chat/hasChatStarted",
                        hasChatEnded: "chat/hasChatEnded",
                        kbSelected: "knowledgeBase/selected",
                        onClick: "widget/onClick",
                        isRoundWidget: "widget/isRoundWidget"
                    })), {}, {
                        borderRadiusBottom: function() {
                            return this.isWindowed || this.mobileBrowserName || this.isEmbedded ? "0px" : this.isRoundWidget ? "0 0 5px 5px" : "0px"
                        },
                        whitelabel: function() {
                            if (this.branding.whitelabeled) {
                                var t = g.a.markdownToHtml(this.branding.text);
                                return t && "Chat U+26A1 by <b>tawk.to</b>" === t && (t = t.replace("U+26A1", '<img src="'.concat(this.powerImageURL, '" style="max-width: 8px;" />'))), t && ":tawky: Add free <b>live chat</b> to your site" === t && (t = t.replace(":tawky:", '<img src="'.concat(this.imageUrl, '" />'))), {
                                    label: t,
                                    url: this.branding.url,
                                    textColor: this.branding.textColor
                                }
                            }
                        },
                        isChatInputBottom: function() {
                            var t = !1,
                                e = this.states[this.pageStatus];
                            return e && e.body.length && (t = "chat" === e.body[e.body.length - 1].type), t
                        },
                        isLiveChatFeatureEnabled: function() {
                            return !!(this.hasLiveChat || this.hasChatStarted && this.agentsCount > 0)
                        },
                        inputPlaceholder: function() {
                            var t, e = this.states[this.pageStatus];
                            if (e && e.body && e.body.length)
                                for (var a = 0; a < e.body.length; a++) {
                                    var i = e.body[a];
                                    if ("chat" === i.type) {
                                        t = i.content.inputPlaceholder;
                                        break
                                    }
                                }
                            return t
                        },
                        mainFooterClasses: function() {
                            return ["tawk-card", "tawk-card-inverse", "tawk-card-xsmall", "tawk-footer", "tawk-flex-none", this.isDraggedOver ? "has-dragover" : ""]
                        },
                        showChatInput: function() {
                            return this.currentView && "chat" === this.currentView.path
                        },
                        showStartChatButton: function() {
                            return "offline" !== this.pageStatus && this.hasLiveChat && "history-chat" === this.currentView.path && (!this.hasChatStarted || this.hasChatEnded)
                        },
                        showReturnToLiveChatBtton: function() {
                            return this.hasLiveChat && "history-chat" === this.currentView.path && this.hasChatStarted && !this.hasChatEnded
                        },
                        isShowBranding: function() {
                            return this.branding.whitelabeled && this.mobileBrowserName || !this.isRoundWidget && this.branding.whitelabeled ? this.branding.text.length : !!this.isEmbedded || "max" !== this.onClick || this.mobileBrowserName || !this.isRoundWidget
                        }
                    }),
                    methods: v(v({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        showOverlay: "overlay/showOverlay",
                        clearHistory: "router/clearHistory"
                    })), {}, {
                        dragover: function(t) {
                            t.preventDefault(), this.features.upload && (this.isDraggedOver = !0)
                        },
                        dragleave: function(t) {
                            t.preventDefault(), this.features.upload && (t.currentTarget.contains(t.relatedTarget) || (this.isDraggedOver = !1))
                        },
                        drop: function(t) {
                            this.hasLiveChat && this.features.upload && (t.preventDefault(), this.isDraggedOver = !1, this.$refs["tawk-chatinput"] && this.$refs["tawk-chatinput"].$refs && this.$refs["tawk-chatinput"].$refs.fileupload && (this.$refs["tawk-chatinput"].$refs.fileupload.files = t.dataTransfer.files, this.$refs["tawk-chatinput"].onFileUpload()))
                        },
                        messageTyping: function(t) {
                            this.$TawkChatManager.sendMessagePreview(t)
                        },
                        sendMessage: function(t) {
                            var e = t.message,
                                a = t.attachments,
                                i = void 0 === a ? [] : a;
                            this.$TawkChatManager.sendMessage({
                                message: e,
                                attachments: i
                            }), this.routerPush("chat"), this.showOverlay(!1)
                        },
                        ratingClicked: function(t) {
                            this.$TawkChatManager.changeRating(t), this.routerPush("chat"), this.showOverlay(!1)
                        },
                        chatFocus: function() {
                            this.$refs["main-footer"].style.boxShadow = "0px -2px 8px rgba(0,0,0,.1)"
                        },
                        chatBlur: function() {
                            this.$refs["main-footer"].style.boxShadow = "0 0 0 transparent"
                        },
                        paste: function(t) {
                            var e, a = (t.originalEvent || t).clipboardData;
                            a && ((e = a.files).length && !this.features.uploads || e && e.length && (this.$refs["tawk-chatinput"].$refs.fileupload.files = e, this.$refs["tawk-chatinput"].onFileUpload()))
                        },
                        startChat: function() {
                            this.showOverlay(!1), this.clearHistory(), this.isPrechatEnabled && !this.prechatFormSubmitted ? this.routerPush("prechat") : this.routerPush("chat")
                        },
                        returnToLiveChat: function() {
                            this.showOverlay(!1), this.clearHistory(), this.routerPush("chat")
                        },
                        autoFocusChatInput: function() {
                            this.$refs["tawk-chatinput"].$refs.chatinput.focus()
                        },
                        goToHomeView: function() {
                            this.routerPush("/"), this.showOverlay(!1)
                        },
                        goToMessageView: function() {
                            this.routerPush("messages"), this.showOverlay(!1)
                        }
                    }),
                    watch: {
                        currentView: function(t) {
                            "chat" == t.path && this.autoFocusChatInput()
                        },
                        hasChatStarted: function() {
                            var t = this;
                            setTimeout((function() {
                                t.autoFocusChatInput()
                            }), 500)
                        }
                    }
                },
                C = Object(c.a)(k, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", {
                        ref: "main-footer",
                        class: t.mainFooterClasses,
                        style: {
                            borderRadius: t.borderRadiusBottom
                        },
                        on: {
                            dragover: t.dragover,
                            dragleave: t.dragleave,
                            drop: t.drop,
                            paste: t.paste
                        }
                    }, [t.showStartChatButton ? e("div", {
                        staticClass: "tawk-max-footer-actions"
                    }, [e("tawk-button", {
                        staticClass: "tawk-max-footer-actions-button",
                        attrs: {
                            label: t.$i18n("home", "chat_button"),
                            isOutline: !0
                        },
                        on: {
                            click: t.startChat
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "send"
                        }
                    }), t._v(" " + t._s(t.$i18n("home", "chat_button")) + " ")], 1)], 1) : t._e(), t.showReturnToLiveChatBtton ? e("div", {
                        staticClass: "tawk-max-footer-actions"
                    }, [e("tawk-button", {
                        staticClass: "tawk-max-footer-actions-button",
                        attrs: {
                            label: t.$i18n("chat", "return_to_live_chat"),
                            isOutline: !0
                        },
                        on: {
                            click: t.returnToLiveChat
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "chat-bubble"
                        }
                    }), t._v(" " + t._s(t.$i18n("chat", "return_to_live_chat")) + " ")], 1)], 1) : t._e(), t.isShowBranding ? e("tawk-branding", {
                        staticClass: "tawk-text-center tawk-padding-small",
                        attrs: {
                            whitelabel: t.whitelabel,
                            imageUrl: t.imageUrl,
                            tawkToUrl: t.branding.url
                        }
                    }) : t._e(), "/" !== t.currentView.path && "messages" !== t.currentView.path || t.needConsent ? t._e() : e("div", {
                        staticClass: "tawk-bottom-navbar",
                        class: t.isShowBranding ? "tawk-bottom-navbar-offset" : ""
                    }, [e("div", [e("tawk-button", {
                        class: {
                            "tawk-nav-active": "/" === t.currentView.path
                        },
                        attrs: {
                            label: t.$i18n("home", "home"),
                            isText: !0
                        },
                        on: {
                            click: t.goToHomeView
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "home"
                        }
                    })], 1)], 1), e("div", [e("tawk-button", {
                        class: {
                            "tawk-nav-active": "messages" === t.currentView.path
                        },
                        attrs: {
                            label: t.$i18n("home", "messages"),
                            isText: !0
                        },
                        on: {
                            click: t.goToMessageView
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "chat-bubble"
                        }
                    })], 1)], 1)]), t.isDraggedOver ? e("div", {
                        staticClass: "tawk-flex tawk-flex-column tawk-flex-center tawk-flex-middle",
                        attrs: {
                            id: "tawk-dragover-container"
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "attachment",
                            size: "xlarge"
                        }
                    }), e("p", [t._v(t._s(t.$i18n("rollover", "upload_file")))])], 1) : t._e(), t.needConsent || "offline" === t.pageStatus || t.isPrechatEnabled && !t.prechatFormSubmitted || !t.isLiveChatFeatureEnabled ? t._e() : e("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.showChatInput,
                            expression: "showChatInput"
                        }],
                        ref: "tawk-chatinput-container",
                        attrs: {
                            id: "tawk-chatinput-container"
                        }
                    }, [e("tawk-chat-input", {
                        ref: "tawk-chatinput",
                        attrs: {
                            placeholder: t.inputPlaceholder,
                            features: t.features
                        },
                        on: {
                            messageTyping: t.messageTyping,
                            sendMessage: t.sendMessage,
                            ratingClicked: t.ratingClicked,
                            focus: t.chatFocus,
                            blur: t.chatBlur
                        }
                    })], 1)], 1)
                }), [], !1, null, null, null).exports;

            function O(t) {
                return (O = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function S(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function x(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? S(Object(a), !0).forEach((function(e) {
                        T(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : S(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function T(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != O(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != O(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == O(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var $ = {
                    name: "home-header",
                    components: {
                        TawkImage: s.TawkImage,
                        TawkVideo: s.TawkVideo,
                        KnowledgeBaseSearch: function() {
                            return a.e("chunk-2d0e5f34").then(a.bind(null, "9755"))
                        },
                        AgentCard: function() {
                            return a.e("chunk-2d0c8894").then(a.bind(null, "54fe"))
                        },
                        TawkEmoji: s.TawkEmoji
                    },
                    props: {
                        state: {
                            type: String,
                            default: "online"
                        }
                    },
                    data: function() {
                        return {
                            header: {},
                            refreshHeader: !0
                        }
                    },
                    mounted: function() {
                        this.state && this.states[this.state] && (this.header = this.states[this.state].header)
                    },
                    computed: x(x({}, Object(i.c)({
                        states: "widget/states",
                        pageStatus: "session/pageStatus",
                        chatVersion: "chat/chatVersion",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        emojiEnabled: "widget/emojiEnabled"
                    })), {}, {
                        logoUrl: function() {
                            return "https://tawk.link"
                        }
                    }),
                    watch: {
                        state: function() {
                            var t = this;
                            this.refreshHeader = !1, this.header = {}, this.$nextTick((function() {
                                t.refreshHeader = !0, t.state && t.states[t.state] && (t.header = t.states[t.state].header)
                            }))
                        }
                    },
                    methods: {
                        convertToHTML: function(t) {
                            return g.a.markdownToHtml(t)
                        }
                    }
                },
                P = Object(c.a)($, (function() {
                    var t = this,
                        e = t._self._c;
                    return t.refreshHeader ? e("div", {
                        staticClass: "tawk-form-width-100 tawk-flex tawk-flex-column"
                    }, t._l(t.header, (function(a, i) {
                        return e("div", {
                            key: i
                        }, [(a.type, t._e()), "heading" === a.type ? e("div", {
                            staticClass: "tawk-margin-xsmall-top",
                            class: "header-card card--" + a.type
                        }, [e("p", {
                            staticClass: "tawk-text-bold-4 tawk-header-text tawk-custom-color",
                            class: [a.content.alignment && "card--alignment-".concat(a.content.alignment)],
                            attrs: {
                                role: "heading"
                            }
                        }, [e("tawk-emoji", {
                            attrs: {
                                emoji: t.convertToHTML(a.content.value),
                                enabled: t.emojiEnabled
                            }
                        })], 1)]) : t._e(), "text" === a.type ? e("div", {
                            staticClass: "tawk-margin-xsmall-top",
                            class: "header-card card--" + a.type
                        }, [e("p", {
                            staticClass: "tawk-text-regular-4 tawk-header-text tawk-custom-color",
                            class: [a.content.alignment && "card--alignment-".concat(a.content.alignment)]
                        }, [e("tawk-emoji", {
                            attrs: {
                                emoji: t.convertToHTML(a.content.value),
                                enabled: t.emojiEnabled
                            }
                        })], 1)]) : t._e(), "agents" === a.type ? e("div", {
                            staticClass: "tawk-margin-xsmall-top",
                            class: ["tawk-flex card--" + a.type, a.content.alignment && "card--flex-".concat(a.content.alignment)]
                        }, [e("agent-card", {
                            attrs: {
                                agentIds: a.content.agentIds
                            }
                        })], 1) : t._e(), "image" === a.type ? e("div", {
                            staticClass: "tawk-margin-xsmall-top",
                            class: "header-card card--" + a.type
                        }, [e(a.content.link ? "a" : "div", {
                            tag: "component",
                            attrs: {
                                href: a.content.link ? a.content.link.ref : null,
                                target: a.content.link && "blank" === a.content.link.target ? "_blank" : "_top"
                            }
                        }, [e("tawk-image", {
                            staticClass: "tawk-custom-image",
                            attrs: {
                                position: a.content.alignment,
                                src: a.content.image.content,
                                alt: a.content.image.content
                            }
                        })], 1)], 1) : t._e(), "video" === a.type ? e("div", {
                            staticClass: "tawk-margin-xsmall-top",
                            class: "header-card card--" + a.type
                        }, [e("tawk-video", {
                            attrs: {
                                content: {
                                    source: a.content.source,
                                    url: a.content.url,
                                    options: a.content.config
                                },
                                isMobile: !!t.mobileBrowserName
                            }
                        })], 1) : t._e(), "kb-search" === a.type ? e("knowledge-base-search", {
                            attrs: {
                                content: a.content
                            }
                        }) : t._e()], 1)
                    })), 0) : t._e()
                }), [], !1, null, null, null).exports;

            function j(t) {
                return (j = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function B(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function _(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? B(Object(a), !0).forEach((function(e) {
                        E(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : B(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function E(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != j(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != j(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == j(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var M = {
                    name: "Item",
                    mixins: [a("4b3e").a],
                    data: function() {
                        return {
                            isConversationCard: !1,
                            totalHistoryItems: 0,
                            isLoadingHistory: !0,
                            offVideo: !0
                        }
                    },
                    props: {
                        card: {
                            type: Object,
                            required: !0
                        },
                        isSubmitting: {
                            type: Boolean,
                            required: !0
                        },
                        isSubmitButtonLock: {
                            type: Boolean,
                            required: !0
                        },
                        submissionError: {
                            type: Boolean,
                            required: !1
                        },
                        body: {
                            type: Array,
                            required: !0
                        },
                        state: {
                            type: String,
                            required: !0
                        },
                        hasConversationCard: {
                            type: Boolean,
                            required: !0
                        }
                    },
                    components: {
                        TawkCard: s.TawkCard,
                        TawkIcon: s.TawkIcon,
                        TawkImage: s.TawkImage,
                        TawkVideo: s.TawkVideo,
                        TawkButton: s.TawkButton,
                        KnowledgeBase: function() {
                            return Promise.all([a.e("chunk-2d221830"), a.e("chunk-2d0c02e2")]).then(a.bind(null, "414c"))
                        },
                        TawkAlert: s.TawkAlert,
                        KnowledgeBaseSearch: function() {
                            return a.e("chunk-2d0e5f34").then(a.bind(null, "9755"))
                        },
                        Conversations: function() {
                            return a.e("chunk-18f22878").then(a.bind(null, "30be"))
                        },
                        KbFeaturedArticle: function() {
                            return a.e("chunk-2d207f48").then(a.bind(null, "a377"))
                        },
                        TawkEmoji: s.TawkEmoji,
                        TawkForm: function() {
                            return a.e("chunk-2d0b345a").then(a.bind(null, "2853"))
                        }
                    },
                    mounted: function() {
                        this.hasLiveChat && "previous-conversations" === this.card.type && (this.$emit("update:hasConversationCard", !0), this.isConversationCard = !0), this.$emit("contentCardLoaded")
                    },
                    computed: _(_({}, Object(i.c)({
                        hasLiveChat: "widget/hasLiveChat",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        hasChatStarted: "chat/hasChatStarted",
                        isPrechatEnabled: "widget/isPrechatEnabled",
                        prechatFormSubmitted: "session/prechatFormSubmitted",
                        historyItems: "history/items",
                        hasChatEnded: "chat/hasChatEnded",
                        emojiEnabled: "widget/emojiEnabled",
                        chatOrder: "chat/chatOrder",
                        isNotValidEmail: "session/isNotValidEmail",
                        isNotValidPhone: "session/isNotValidPhone",
                        isHome: "router/isHome"
                    })), {}, {
                        isChatInputBottom: function() {
                            var t = !1;
                            return this.body && this.body.length && (t = "chat" === this.body[this.body.length - 1].type), t
                        },
                        showStartChatButton: function() {
                            return !this.hasChatStarted && !this.hasChatEnded && this.hasLiveChat
                        },
                        showConversationCard: function() {
                            return this.isLoadingHistory || this.totalHistoryItems || this.chatOrder
                        }
                    }),
                    methods: _(_({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        showOverlay: "overlay/showOverlay"
                    })), {}, {
                        startChat: function() {
                            this.isPrechatEnabled && !this.prechatFormSubmitted ? this.routerPush("prechat") : (this.routerPush("chat"), this.showOverlay(!1))
                        },
                        submitForm: function(t) {
                            this.$emit("submitForm", t)
                        },
                        convertToHTML: function(t) {
                            return g.a.markdownToHtml(t)
                        },
                        historyItemsLoaded: function(t) {
                            this.totalHistoryItems = t, this.isLoadingHistory = !1
                        }
                    }),
                    watch: {
                        isNotValidEmail: function(t) {
                            t && (this.$emit("update:isSubmitting", !1), this.$emit("update:isSubmitButtonLock", !1))
                        },
                        isNotValidPhone: function(t) {
                            t && (this.$emit("update:isSubmitting", !1), this.$emit("update:isSubmitButtonLock", !1))
                        }
                    }
                },
                L = Object(c.a)(M, (function() {
                    var t = this,
                        e = t._self._c;
                    return !t.isConversationCard || t.isConversationCard && t.showConversationCard ? e("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !t.isConversationCard || t.isConversationCard && !t.isLoadingHistory,
                            expression: "!isConversationCard || (isConversationCard && !isLoadingHistory)"
                        }],
                        staticClass: "card-container",
                        class: t.isConversationCard && t.chatOrder ? "tawk-flex-first" : ""
                    }, ["heading" === t.card.type ? e("tawk-card", {
                        staticClass: "tawk-box-shadow-xsmall",
                        class: "card--" + t.card.type,
                        attrs: {
                            color: "inverse"
                        }
                    }, [e("p", {
                        staticClass: "tawk-text-bold-4",
                        class: [t.card.content.alignment && "card--alignment-".concat(t.card.content.alignment)],
                        attrs: {
                            role: "heading"
                        }
                    }, [e("tawk-emoji", {
                        attrs: {
                            emoji: t.convertToHTML(t.card.content.value),
                            enabled: t.emojiEnabled
                        }
                    })], 1)]) : "text" === t.card.type ? e("tawk-card", {
                        staticClass: "tawk-box-shadow-xsmall",
                        class: "card--" + t.card.type,
                        attrs: {
                            color: "inverse"
                        }
                    }, [e("p", {
                        staticClass: "tawk-text-regular-4",
                        class: [t.card.content.alignment && "card--alignment-".concat(t.card.content.alignment)]
                    }, [e("tawk-emoji", {
                        attrs: {
                            emoji: t.convertToHTML(t.card.content.value),
                            enabled: t.emojiEnabled
                        }
                    })], 1)]) : "image" === t.card.type ? e("tawk-card", {
                        staticClass: "tawk-box-shadow-xsmall",
                        class: "card--" + t.card.type,
                        attrs: {
                            color: "inverse"
                        }
                    }, [e(t.card.content.link ? "a" : "div", {
                        tag: "component",
                        attrs: {
                            href: t.card.content.link ? t.card.content.link.ref : null,
                            target: t.card.content.link && "blank" === t.card.content.link.target ? "_blank" : "_top"
                        }
                    }, [e("tawk-image", {
                        staticClass: "tawk-custom-image",
                        attrs: {
                            position: t.card.content.alignment,
                            src: t.card.content.image.content,
                            alt: "".concat(t.$i18n("home", "banner_image")),
                            role: "banner"
                        }
                    })], 1)], 1) : "video" === t.card.type ? e("tawk-card", {
                        staticClass: "tawk-box-shadow-xsmall",
                        class: "card--" + t.card.type,
                        attrs: {
                            color: "inverse"
                        }
                    }, [t.offVideo ? e("tawk-video", {
                        attrs: {
                            content: {
                                source: t.card.content.source,
                                url: t.card.content.url,
                                options: t.card.content.config
                            },
                            isMobile: !!t.mobileBrowserName
                        }
                    }) : t._e()], 1) : "chat" === t.card.type ? [t.showStartChatButton ? e("tawk-card", {
                        staticClass: "tawk-home-card-chat tawk-box-shadow-xsmall",
                        class: "card--" + t.card.type,
                        attrs: {
                            id: t.card.id,
                            color: "inverse"
                        },
                        on: {
                            click: t.startChat
                        }
                    }, [e("div", {
                        staticClass: "tawk-flex-1"
                    }, [e("p", [t._v(" " + t._s(t.card.content.buttonText) + " ")]), e("p", [t._v(" " + t._s(t.card.content.hasOwnProperty("buttonSubtitle") ? t.card.content.buttonSubtitle : t.$i18n("home", "chat_button_subtitle")) + " ")])]), e("div", [e("tawk-icon", {
                        attrs: {
                            type: "send"
                        }
                    })], 1)]) : t._e()] : "kb-featured-articles" === t.card.type ? e("tawk-card", {
                        staticClass: "tawk-home-kb-card",
                        attrs: {
                            id: t.card.id,
                            color: "inverse"
                        }
                    }, [e("knowledge-base", {
                        attrs: {
                            state: t.state,
                            content: t.card.content
                        }
                    })], 1) : "kb-search" === t.card.type ? e("tawk-card", {
                        staticClass: "tawk-home-kb-card tawk-box-shadow-xsmall",
                        attrs: {
                            id: t.card.id,
                            color: "inverse"
                        }
                    }, [e("knowledge-base-search", {
                        attrs: {
                            content: t.card.content
                        }
                    })], 1) : "kb-featured-article" == t.card.type ? e("kb-featured-article", {
                        class: "card--" + t.card.type,
                        attrs: {
                            content: t.card.content
                        }
                    }) : "form" === t.card.type ? e("div", {
                        staticClass: "card--form",
                        class: t.isSubmitting && "submitting"
                    }, [e("tawk-form", {
                        attrs: {
                            state: t.state,
                            submissionError: t.submissionError,
                            isSubmitting: t.isSubmitting,
                            isSubmitButtonLock: t.isSubmitButtonLock
                        },
                        on: {
                            "update:isSubmitting": [function(e) {
                                t.isSubmitting = e
                            }, t.isSubmitting],
                            "update:is-submitting": function(e) {
                                t.isSubmitting = e
                            },
                            "update:isSubmitButtonLock": function(e) {
                                t.isSubmitButtonLock = e
                            },
                            "update:is-submit-button-lock": function(e) {
                                t.isSubmitButtonLock = e
                            },
                            onFormSubmit: t.submitForm
                        }
                    }), e("transition", {
                        attrs: {
                            name: "slide-fade"
                        }
                    }, [t.submissionError ? e("tawk-alert", {
                        staticClass: "tawk-form-error-alert",
                        staticStyle: {
                            width: "100%"
                        },
                        attrs: {
                            status: "danger",
                            icon: "error",
                            title: t.$i18n("form", "errorSaving"),
                            description: "",
                            isDismissable: !0,
                            isAutoDismissable: !0
                        }
                    }) : t._e()], 1)], 1) : t._e()], 2) : t._e()
                }), [], !1, null, null, null).exports;

            function V(t) {
                return (V = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function D(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function A(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? D(Object(a), !0).forEach((function(e) {
                        R(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : D(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function R(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != V(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != V(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == V(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var H = {
                    name: "HomeBody",
                    mixins: [a("e49c").a],
                    props: {
                        state: {
                            type: String,
                            default: "online"
                        },
                        overwriteSubmit: {
                            type: Boolean,
                            default: !1
                        },
                        isSubmitting: {
                            type: Boolean,
                            default: !1
                        }
                    },
                    components: {
                        TawkCard: s.TawkCard,
                        TawkIcon: s.TawkIcon,
                        TawkButton: s.TawkButton,
                        ContentCard: L,
                        Conversations: function() {
                            return a.e("chunk-18f22878").then(a.bind(null, "30be"))
                        },
                        RestartChat: function() {
                            return a.e("chunk-2d20848d").then(a.bind(null, "a3af"))
                        }
                    },
                    data: function() {
                        return {
                            submissionError: !1,
                            submissionSuccess: !1,
                            hasConversationCard: !1,
                            submittingValue: !1,
                            isSubmitButtonLock: !1
                        }
                    },
                    computed: A(A({}, Object(i.c)({
                        states: "widget/states",
                        hasLiveChat: "widget/hasLiveChat",
                        hasChatEnded: "chat/hasChatEnded",
                        chatEndVersion: "chat/chatEndVersion",
                        pageStatus: "session/pageStatus",
                        kbIsLoading: "knowledgeBase/isLoading",
                        kbSelected: "knowledgeBase/selected",
                        hasChatStarted: "chat/hasChatStarted"
                    })), {}, {
                        body: function() {
                            return this.state && this.states[this.state] ? this.states[this.state].body : []
                        },
                        noPrechatForm: function() {
                            var t = !0;
                            if ("prechat" === this.state) {
                                for (var e = 0; e < this.body.length; e++)
                                    if ("form" === this.body[e].type) {
                                        t = !1;
                                        break
                                    }
                            } else t = !1;
                            return t
                        },
                        isHistoryCardEnabled: function() {
                            for (var t = !1, e = 0; e < this.body.length; e++) {
                                if ("previous-conversations" === this.body[e].type) {
                                    t = !0;
                                    break
                                }
                            }
                            return t
                        },
                        hasChatCardEnabled: function() {
                            for (var t = !1, e = 0; e < this.body.length; e++) {
                                if ("chat" === this.body[e].type) {
                                    t = !0;
                                    break
                                }
                            }
                            return t
                        }
                    }),
                    methods: A(A({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        showOverlay: "overlay/showOverlay",
                        loadHistory: "history/load",
                        updateShowChat: "chat/updateShowChat"
                    })), {}, {
                        submitForm: function(t) {
                            var e = this;
                            if (!t.hasError) {
                                if (this.submittingValue = !0, this.$emit("update:isSubmitting", this.submittingValue), this.submissionError = !1, this.submissionSuccess = !1, this.$store.commit("session/setIsNotValidEmail", null), this.overwriteSubmit) return this.$emit("submitForm", t);
                                t.formData.submittedFrom = window.location.href, this.$socket.publish("notifyOfflineMessage", t.formData, (function(a) {
                                    if (e.submittingValue = !1, e.$emit("update:isSubmitting", e.submittingValue), e.isSubmitButtonLock = !0, e.$emit("update:isSubmitButtonLock", e.isSubmitButtonLock), a) return "InvalidArgument" === a.code && "email" === a.message ? void e.$store.commit("session/setIsNotValidEmail", "email") : (e.isSubmitButtonLock = !1, e.$emit("update:isSubmitButtonLock", e.isSubmitButtonLock), void(e.submissionError = !0));
                                    setTimeout((function() {
                                        e.isSubmitButtonLock = !1, e.$emit("update:isSubmitButtonLock", e.isSubmitButtonLock)
                                    }), 3e4), e.routerPush("offline-success"), e.showOverlay(!0), e.$store.dispatch("visitor/updateVisitorInformation", {
                                        n: t.formData.name,
                                        e: t.formData.email
                                    }), e.$TawkJSAPI.triggerApiHandlers("onOfflineSubmit", t.formData)
                                }))
                            }
                        }
                    })
                },
                W = Object(c.a)(H, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", {
                        staticClass: "tawk-form-width-100 tawk-flex tawk-flex-column"
                    }, [t.hasChatEnded && "prechat" !== t.state && "offline" !== t.state && t.chatEndVersion ? e("div", {
                        staticClass: "card-container"
                    }, [e("restart-chat")], 1) : t._e(), t.hasChatCardEnabled && t.hasChatStarted && t.hasLiveChat && "offline" !== t.pageStatus && "online" === t.state || "away" === t.state ? e("div", {
                        staticClass: "card-container tawk-flex-first"
                    }, [e("tawk-card", {
                        staticClass: "tawk-home-kb-card",
                        attrs: {
                            color: "inverse"
                        }
                    }, [e("conversations", {
                        attrs: {
                            state: t.state
                        }
                    })], 1)], 1) : t._e(), t._l(t.body, (function(a, i) {
                        return e("content-card", {
                            key: i,
                            attrs: {
                                card: a,
                                isSubmitting: t.submittingValue,
                                isSubmitButtonLock: t.isSubmitButtonLock,
                                submissionError: t.submissionError,
                                body: t.body,
                                state: t.state,
                                hasConversationCard: t.hasConversationCard
                            },
                            on: {
                                "update:isSubmitting": function(e) {
                                    t.submittingValue = e
                                },
                                "update:is-submitting": function(e) {
                                    t.submittingValue = e
                                },
                                "update:isSubmitButtonLock": function(e) {
                                    t.isSubmitButtonLock = e
                                },
                                "update:is-submit-button-lock": function(e) {
                                    t.isSubmitButtonLock = e
                                },
                                "update:hasConversationCard": function(e) {
                                    t.hasConversationCard = e
                                },
                                "update:has-conversation-card": function(e) {
                                    t.hasConversationCard = e
                                },
                                submitForm: t.submitForm,
                                contentCardLoaded: function(e) {
                                    return t.$emit("homeLoaded")
                                }
                            }
                        })
                    })), t.noPrechatForm ? e("div", {
                        staticClass: "card-container"
                    }, [e("tawk-card", {
                        staticClass: "tawk-box-shadow-xsmall",
                        attrs: {
                            color: "inverse",
                            size: "small"
                        }
                    }, [e("tawk-button", {
                        staticClass: "tawk-form-width-100 tawk-button-hover tawk-custom-color tawk-custom-border-color",
                        attrs: {
                            label: t.$i18n("form", "start_chat_button")
                        },
                        on: {
                            click: function(e) {
                                return t.submitForm({
                                    formData: {}
                                })
                            }
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "send"
                        }
                    }), t._v(" " + t._s(t.$i18n("form", "start_chat_button")) + " ")], 1)], 1)], 1) : t._e()], 2)
                }), [], !1, null, null, null).exports,
                I = a("9f3e"),
                N = a("dbd1");

            function F(t) {
                return (F = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function z(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function U(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? z(Object(a), !0).forEach((function(e) {
                        q(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : z(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function q(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != F(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != F(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == F(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var Z = {
                    name: "Home",
                    components: {
                        BaseFrame: I.a,
                        BaseBody: N.a,
                        HomeHeader: P,
                        HomeBody: W,
                        ConsentForm: function() {
                            return a.e("chunk-2d0e4831").then(a.bind(null, "9114"))
                        }
                    },
                    props: {
                        isVisible: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    computed: U({}, Object(i.c)({
                        states: "widget/states",
                        pageStatus: "session/pageStatus",
                        hasChatStarted: "chat/hasChatStarted",
                        prechatFormSubmitted: "session/prechatFormSubmitted",
                        needConsent: "session/needConsent",
                        kbSelected: "knowledgeBase/selected"
                    })),
                    watch: {
                        pageStatus: function(t) {
                            this.homeLoaded(), "offline" === t ? this.$eventBus.$emit("formOpened") : this.$eventBus.$emit("formClosed"), this.$refs["tawk-chat-panel"].scrollTop = 0
                        },
                        isVisible: function() {
                            for (var t = this.$refs["tawk-main-panel"].querySelectorAll(".tawk-video-el"), e = 0; e < t.length; e++) {
                                var a = t[e];
                                "about:blank" !== a.src ? a.src = "about:blank" : a.getAttribute("data-src") && (a.src = a.getAttribute("data-src"))
                            }
                        }
                    },
                    data: function() {
                        return {
                            headerClass: ""
                        }
                    },
                    methods: U(U({}, Object(i.b)({
                        routerPush: "router/routerPush"
                    })), {}, {
                        homeLoaded: function() {
                            var t = this;
                            setTimeout((function() {
                                t.$refs["tawk-chat-panel"] && t.$refs["tawk-chat-panel"].$scrollbar && t.$refs["tawk-chat-panel"].$scrollbar.update()
                            }), 500)
                        },
                        handleScroll: function() {
                            this.$refs && this.$refs["tawk-chat-panel"] && this.$eventBus.$emit("chatPanelScroll", {
                                scrollTop: this.$refs["tawk-chat-panel"].scrollTop
                            })
                        }
                    }),
                    mounted: function() {
                        var t = this;
                        "offline" === this.pageStatus && this.$eventBus.$emit("formOpened"), this.$eventBus.$on("scrollToTop", (function() {
                            t.$refs["tawk-chat-panel"].$scrollbar.update(), t.$refs["tawk-chat-panel"].scrollTop = 0
                        }))
                    },
                    destroyed: function() {
                        this.$eventBus.$emit("formClosed")
                    }
                },
                G = Object(c.a)(Z, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("base-frame", {
                        staticClass: "tawk-home-view tawk-custom-flex-1",
                        attrs: {
                            hasBackground: !0
                        },
                        on: {
                            "&scroll": function(e) {
                                return t.handleScroll.apply(null, arguments)
                            }
                        }
                    }, [e("base-body", {
                        ref: "tawk-home-body"
                    }, [t.needConsent ? e("consent-form") : [e("home-header", {
                        ref: "tawk-home-header",
                        attrs: {
                            state: t.pageStatus
                        }
                    }), e("home-body", {
                        staticClass: "tawk-margin-top",
                        attrs: {
                            state: t.pageStatus
                        },
                        on: {
                            homeLoaded: t.homeLoaded
                        }
                    })]], 2)], 1)
                }), [], !1, null, null, null).exports,
                J = {
                    name: "base-header"
                };

            function K(t) {
                return (K = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function X(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function Q(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? X(Object(a), !0).forEach((function(e) {
                        Y(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : X(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function Y(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != K(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != K(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == K(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var tt = {
                    name: "chat-header",
                    components: {
                        BaseHeader: Object(c.a)(J, (function(t, e) {
                            return t("div", e._g(e._b({
                                class: ["tawk-card tawk-card-primary tawk-card-small tawk-header-container tawk-flex-none tawk-header tawk-custom-color", e.data.class, e.data.staticClass],
                                style: [e.data.staticStyle, e.data.style]
                            }, "div", e.data.attrs, !1), e.listeners), [t("div", {
                                staticClass: "tawk-text-center"
                            }, [e._t("default")], 2)])
                        }), [], !0, null, null, null).exports,
                        ChatAgents: function() {
                            return a.e("chunk-2d0a4ee2").then(a.bind(null, "0914"))
                        }
                    },
                    mounted: function() {
                        this.addWaitTime()
                    },
                    computed: Q(Q({}, Object(i.c)({
                        states: "widget/states",
                        pageStatus: "session/pageStatus",
                        agents: "chat/agents",
                        agentsCount: "chat/agentsCount",
                        activeProfiles: "chat/activeProfiles",
                        hasChatStarted: "chat/hasChatStarted",
                        agentHasMessaged: "chat/agentHasMessaged",
                        showEstimatedWaitTime: "widget/showEstimatedWaitTime",
                        waitTime: "session/waitTime"
                    })), {}, {
                        header: function() {
                            return this.states[this.pageStatus] ? this.states[this.pageStatus].header : null
                        },
                        logoUrl: function() {
                            return "https://tawk.link"
                        },
                        hasHomeView: function() {
                            var t = this.states[this.pageStatus];
                            return !t || !t.body || 1 !== t.body.length || "chat" !== t.body[0].type
                        }
                    }),
                    methods: Q(Q({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        addWaitTime: "session/addWaitTime",
                        showOverlay: "overlay/showOverlay"
                    })), {}, {
                        changeView: function() {
                            this.routerPush("agents"), this.showOverlay(!0)
                        }
                    })
                },
                et = Object(c.a)(tt, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", [0 === t.activeProfiles.length ? [t.hasChatStarted && !t.agentHasMessaged && t.showEstimatedWaitTime && t.waitTime ? e("base-header", [e("p", {
                        staticClass: "tawk-margin-xsmall-bottom",
                        domProps: {
                            innerHTML: t._s(t.$i18n("chat", "message_queued_text_other", {
                                count: Math.ceil(t.waitTime / 6e4),
                                strongStart: "<b>",
                                strongEnd: "</b>"
                            }))
                        }
                    })]) : t._e()] : t._e(), t.activeProfiles.length > 1 ? e("base-header", {
                        ref: "tawk-base-header"
                    }, [e("chat-agents", {
                        attrs: {
                            profiles: t.activeProfiles,
                            role: "button",
                            tabindex: "0"
                        },
                        nativeOn: {
                            click: function(e) {
                                return t.changeView.apply(null, arguments)
                            }
                        }
                    })], 1) : t._e()], 2)
                }), [], !1, null, null, null).exports,
                at = a("3519"),
                it = a("3f09"),
                st = {
                    name: "progress-bar",
                    props: {
                        handle: {
                            type: String,
                            default: ""
                        },
                        fileName: {
                            type: String,
                            default: ""
                        },
                        fileSize: {
                            type: String,
                            default: ""
                        },
                        percentage: {
                            type: Number,
                            default: 0
                        }
                    },
                    computed: {
                        progressWidth: function() {
                            return "width : ".concat(this.percentage, "%")
                        }
                    },
                    methods: {
                        beautifyFilename: function(t, e) {
                            var a = t.lastIndexOf("."),
                                i = t.substring(0, a),
                                s = ".".concat(t.substring(a + 1));
                            return i.length > 7 && (s = i.substring(i.length - 3) + s, i = i.substring(0, i.length - 3)), '<span class="tawk-text-truncate">'.concat(i, '</span><span class="tawk-flex-none">').concat(s, '</span><span class="tawk-flex-none">&nbsp;(').concat(e, ")</span>")
                        }
                    }
                },
                nt = Object(c.a)(st, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("div", {
                        staticClass: "file-upload-progress"
                    }, [e("div", {
                        staticClass: "tawk-flex tawk-flex-middle",
                        domProps: {
                            innerHTML: t._s(t.beautifyFilename(t.fileName, t.fileSize))
                        }
                    }), e("div", {
                        staticClass: "progress active tawk-margin-small-top"
                    }, [e("div", {
                        staticClass: "progress-bar",
                        style: t.progressWidth,
                        attrs: {
                            role: "progressbar"
                        }
                    })])])
                }), [], !1, null, null, null).exports;

            function rt(t) {
                return (rt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function ot(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function ct(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? ot(Object(a), !0).forEach((function(e) {
                        lt(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : ot(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function lt(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != rt(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != rt(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == rt(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var ut = {
                    name: "chat-main",
                    mixins: [it.a],
                    components: {
                        BaseFrame: I.a,
                        BaseBody: N.a,
                        ChatHeader: et,
                        ChatBody: at.a,
                        TawkIcon: s.TawkIcon,
                        TawkButton: s.TawkButton,
                        TawkAvatar: s.TawkAvatar,
                        ProgressBar: nt,
                        TawkAlert: s.TawkAlert
                    },
                    computed: ct({}, Object(i.c)({
                        chatVersion: "chat/chatVersion",
                        incomingMessage: "chat/incomingMessage",
                        agentProfile: "chat/agentProfile",
                        chatMessages: "chat/chatMessages",
                        unreadMessageCount: "chat/unreadMessageCount",
                        lastMessageTimestamp: "session/lastMessageTimestamp",
                        showAgentTyping: "widget/showAgentTyping",
                        hasChatEnded: "chat/hasChatEnded",
                        uploadFiles: "chat/uploadFiles",
                        lastScrollPositon: "chat/lastScrollPositon",
                        outgoingMessage: "chat/outgoingMessage",
                        historyProcessed: "chat/historyProcessed",
                        messageBlocks: "chat/messageBlocks",
                        emojiEnabled: "widget/emojiEnabled",
                        currentRoute: "router/current",
                        chatWindowState: "session/chatWindowState",
                        isFocus: "widget/isFocus"
                    })),
                    data: function() {
                        return {
                            barMessageId: null,
                            isLoading: !1,
                            barMessageRerence: null,
                            unseenMessages: [],
                            showNotification: !1,
                            agentTyping: {},
                            clearBarTimeout: 0,
                            tooBigFileList: null,
                            showLatest: !1
                        }
                    },
                    watch: {
                        incomingMessage: function(t) {
                            var e = this.isScrollBarBottom();
                            this.displayMessages({
                                message: t,
                                isIncoming: !0
                            }), this.updateScrollbar(), e && this.scrollToBottom()
                        },
                        unreadMessageCount: function(t) {
                            0 === t && this.clearBarMessageId()
                        },
                        hasChatEnded: function(t) {
                            t && this.clearData()
                        },
                        uploadFiles: function() {
                            this.scrollToBottom()
                        },
                        outgoingMessage: function(t) {
                            this.isLoading || t && (this.displayMessages({
                                message: t,
                                isIncoming: !0
                            }), this.$store.commit("chat/setOutgoingMessage", null))
                        },
                        historyProcessed: function(t) {
                            t && this.processChatMessages()
                        },
                        currentRoute: function(t, e) {
                            "chat" === t && (this.$refs["tawk-chat-panel"] && this.$refs["tawk-chat-panel"].$scrollbar && this.$refs["tawk-chat-panel"].$scrollbar.update(), this.checkSeenMessageViewport(), this.checkBarPosition()), "chat" === e && this.saveScrollPosition()
                        },
                        chatWindowState: function(t) {
                            "max" === t && "chat" === this.currentRoute && (this.toggleFocus(!0), this.checkSeenMessageViewport())
                        },
                        isFocus: function(t) {
                            t && "chat" === this.currentRoute && this.checkSeenMessageViewport()
                        }
                    },
                    created: function() {
                        var t = this;
                        this.$eventBus.$on("tooBigFileList", (function(e) {
                            t.tooBigFileList = e.join(", ")
                        }))
                    },
                    mounted: function() {
                        var t = this;
                        this.processChatMessages(), this.showAgentTyping && (this.$eventBus.$on("agentIsTyping", (function(e) {
                            var a = t.agentProfile(e.rsc),
                                i = t.isScrollBarBottom();
                            a && (t.updateAgentTyping(e, a), t.updateScrollbar()), i && t.scrollToBottom()
                        })), this.$eventBus.$on("agentStopedTyping", (function(e) {
                            t.removeAgentIsTyping(e.rsc), t.updateScrollbar()
                        }))), this.$eventBus.$on("updateScrollPosition", (function() {
                            t.updateScrollbar()
                        })), this.$eventBus.$on("callDataUpdated", (function(e) {
                            for (var a = t.isScrollBarBottom(), i = 0; i < t.messageBlocks.length; i++) {
                                var s = t.messageBlocks[i];
                                if ("call" === s.messageType && s.ownerId === e.callId) {
                                    s.callData = e;
                                    break
                                }
                            }
                            a && t.scrollToBottom()
                        }))
                    },
                    beforeDestroy: function() {
                        this.saveScrollPosition(), this.clearData()
                    },
                    methods: ct(ct({}, Object(i.b)({
                        clearMessageBlock: "chat/clearMessageBlock",
                        toggleAgentAvatarToolbar: "widget/toggleAgentAvatarToolbar",
                        toggleFocus: "widget/toggleFocus"
                    })), {}, {
                        updateAgentTyping: function(t, e) {
                            this.$set(this.agentTyping, t.rsc, e.profileImage)
                        },
                        scrollToBottom: function(t) {
                            var e = this.$refs["tawk-chat-panel"];
                            e && setTimeout((function() {
                                e.scrollTop = t || e.scrollHeight
                            }), 300)
                        },
                        handleScrollProcess: function() {
                            this.checkBarPosition(), this.checkSeenMessageViewport(), this.handleAgentsAvatarToolbar()
                        },
                        scrollToEl: function(t) {
                            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
                            if (t) {
                                var a = this.$refs["chat-body"],
                                    i = a ? a.$refs[t] : null,
                                    s = this.$refs["tawk-chat-panel"];
                                i && i.length && s ? (void 0 !== i[0].offsetTop ? s.scrollTop = i[0].offsetTop - 40 : s.scrollTop = i[0].offsetTop, this.$refs["tawk-chat-panel"] && this.$refs["tawk-chat-panel"].$scrollbar && this.$refs["tawk-chat-panel"].$scrollbar.update(), e()) : e(i)
                            }
                        },
                        clearBarMessageId: function() {
                            var t = this;
                            clearTimeout(this.clearBarTimeout), this.clearBarTimeout = setTimeout((function() {
                                t.barMessageId = null, t.barMessageRerence && (t.barMessageRerence.showBar = !1), t.showNotification = !1, t.barMessageRerence = null
                            }), 1e3)
                        },
                        checkSeenMessageViewport: function() {
                            var t, e = -1,
                                a = this.$refs["chat-body"];
                            if (0 !== this.unseenMessages.length && a && this.isFocus) {
                                for (var i = 0; i < this.unseenMessages.length; i++) {
                                    t = this.unseenMessages[i];
                                    var s = a.$refs[t.blockId];
                                    if (s && this.chatElementInView(s) && t.timeStamp > this.lastMessageTimestamp) {
                                        e = i;
                                        break
                                    }
                                } - 1 !== e && ((t = this.unseenMessages[this.unseenMessages.length - 1]) && (this.unseenMessages = [], this.$store.dispatch("session/updateVisitorChatSeen", t.timeStamp)))
                            }
                        },
                        chatElementInView: function(t) {
                            var e = this.$refs["tawk-chat-panel"];
                            return !!e && !!(t[0].offsetTop >= e.scrollTop && t[0].offsetTop <= e.scrollTop + e.offsetHeight && 0 !== t[0].clientWidth && 0 !== t[0].clientHeight)
                        },
                        removeAgentIsTyping: function(t) {
                            this.$delete(this.agentTyping, t)
                        },
                        checkBarPosition: function() {
                            var t = this;
                            this.$nextTick((function() {
                                if (t.showNotification = !1, t.barMessageRerence && t.barMessageId) {
                                    var e = t.$refs[t.barMessageId],
                                        a = t.$refs["chat-body"];
                                    if (a && a.$refs[t.barMessageId] && (e = a.$refs[t.barMessageId]), e)
                                        if (t.chatElementInView(e)) t.clearBarMessageId();
                                        else {
                                            var i = t.$refs["tawk-chat-panel"];
                                            i && i.scrollTop < e[0].offsetTop && (t.showNotification = !0)
                                        }
                                }
                                t.isScrollBarBottom() || t.showNotification || t.unreadMessageCount ? t.showLatest = !1 : t.showLatest = !0
                            }))
                        },
                        clearData: function() {
                            clearTimeout(this.clearBarTimeout), this.barMessageId = null, this.isLoading = !1, this.barMessageRerence = null, this.unseenMessages = [], this.showNotification = !1, this.agentTyping = [], this.clearBarTimeout = 0
                        },
                        retryUpload: function(t) {
                            for (var e = 0; e < this.uploadFiles.length; e++)
                                if (this.uploadFiles[e].handle === t.handle) {
                                    this.uploadFiles.splice(e, 1);
                                    break
                                }
                            this.$TawkChatManager.uploadFiles([t.fileData])
                        },
                        processChatMessages: function() {
                            var t = this;
                            this.isLoading = !0;
                            var e = !1;
                            for (var a in this.clearMessageBlock(), this.chatMessages) {
                                var i = this.chatMessages[a];
                                this.outgoingMessage && !e && i.messageId === this.outgoingMessage.messageId ? (e = !0, this.displayMessages({
                                    message: i,
                                    isIncoming: !0
                                })) : this.displayMessages({
                                    message: i
                                })
                            }
                            this.outgoingMessage && !e && this.displayMessages({
                                message: this.outgoingMessage,
                                isIncoming: !0
                            }), this.isLoading = !1, setTimeout((function() {
                                t.barMessageId ? (t.scrollToEl(t.barMessageId, (function(e) {
                                    void 0 === e && t.scrollToBottom(t.lastScrollPositon)
                                })), t.checkBarPosition()) : t.scrollToBottom(t.lastScrollPositon), t.checkSeenMessageViewport()
                            }), 1e3 / 66)
                        },
                        imageLoaded: function() {
                            this.isScrollBarBottom() && this.scrollToBottom(), this.$refs["tawk-chat-panel"] && this.$refs["tawk-chat-panel"].$scrollbar && this.$refs["tawk-chat-panel"].$scrollbar.update()
                        },
                        handleAgentsAvatarToolbar: function() {
                            if (this.$refs["tawk-home-header"]) {
                                var t = this.$refs["tawk-home-header"].$el.offsetHeight;
                                this.$refs["tawk-chat-panel"].scrollTop > t / 4 ? this.toggleAgentAvatarToolbar(!0) : this.toggleAgentAvatarToolbar(!1)
                            }
                        },
                        saveScrollPosition: function() {
                            var t = this.$refs["tawk-chat-panel"];
                            t && this.$store.commit("chat/setLastScrollPosition", this.isScrollBarBottom() ? 9999999999 : t.scrollTop)
                        },
                        convertFileSize: function(t) {
                            return t < 1024 ? t + "B" : t < Math.pow(1024, 2) ? (t / 1024).toFixed(2) + "KB" : t < Math.pow(1024, 3) ? (t / Math.pow(1024, 2)).toFixed(2) + "MB" : (t / Math.pow(1024, 3)).toFixed(2) + "GB"
                        },
                        updateScrollbar: function() {
                            var t = this;
                            setTimeout((function() {
                                t.$refs["tawk-chat-panel"] && t.$refs["tawk-chat-panel"].$scrollbar && t.$refs["tawk-chat-panel"].$scrollbar.update()
                            }), 800)
                        }
                    })
                },
                ht = Object(c.a)(ut, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("base-frame", {
                        staticClass: "tawk-chat-view",
                        on: {
                            "&scroll": function(e) {
                                return t.handleScrollProcess.apply(null, arguments)
                            }
                        }
                    }, [e("chat-header", {
                        ref: "tawk-home-header",
                        staticClass: "tawk-flex-none"
                    }), e("base-body", {
                        ref: "tawk-base-body"
                    }, [e("chat-body", {
                        ref: "chat-body",
                        attrs: {
                            isLoading: t.isLoading,
                            messageBlocks: t.messageBlocks,
                            barMessageRerence: t.barMessageId,
                            emojiEnabled: t.emojiEnabled
                        },
                        on: {
                            imageLoaded: t.imageLoaded
                        }
                    }), e("transition-group", {
                        attrs: {
                            name: "list"
                        }
                    }, t._l(t.agentTyping, (function(a, i) {
                        return e("div", {
                            key: i
                        }, [e("div", {
                            staticClass: "tawk-flex tawk-flex-middle tawk-margin-small-bottom"
                        }, [e("tawk-avatar", {
                            staticClass: "tawk-message-profile",
                            attrs: {
                                size: "small",
                                src: a,
                                alt: "".concat(t.$i18n("chat", "agent_profile_image"))
                            }
                        }), e("div", {
                            staticClass: "agentTypingIndicator tawk-margin-xsmall-left"
                        }, [e("div", {
                            staticClass: "dot tawk-agent-chat-bubble-dots"
                        }), e("div", {
                            staticClass: "dot tawk-agent-chat-bubble-dots"
                        }), e("div", {
                            staticClass: "dot tawk-agent-chat-bubble-dots"
                        })]), e("div", {
                            staticClass: "clearfix"
                        })], 1)])
                    })), 0), e("transition-group", {
                        staticStyle: {
                            width: "100%",
                            overflow: "hidden"
                        },
                        attrs: {
                            tag: "div",
                            name: "list"
                        }
                    }, t._l(t.uploadFiles, (function(a, i) {
                        return e("div", {
                            key: "key-".concat(i),
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom"
                        }, [a.hasError ? e("div", [e("tawk-alert", {
                            attrs: {
                                status: "danger",
                                icon: "error",
                                title: t.$i18n("chat", "general_upload_error_label"),
                                description: t.$i18n("chat", "general_upload_error", {
                                    fileName: a.fileName
                                })
                            }
                        }), e("tawk-button", {
                            staticClass: "tawk-text-red-1 tawk-margin-auto-left tawk-button tawk-button-text tawk-text-regular-2 tawk-margin-xsmall-top",
                            staticStyle: {
                                display: "block"
                            },
                            attrs: {
                                label: t.$i18n("chat", "try_again"),
                                isText: !0
                            },
                            on: {
                                click: function(e) {
                                    return t.retryUpload(a)
                                }
                            }
                        }, [t._v(" " + t._s(t.$i18n("chat", "try_again")) + " ")])], 1) : e("progress-bar", {
                            attrs: {
                                handle: a.handle,
                                fileName: a.fileName,
                                fileSize: t.convertFileSize(a.fileData.file.size),
                                percentage: a.percentage,
                                "aria-busy": "true",
                                "aria-valuemin": "0",
                                "aria-valuemax": "100",
                                "aria-valuenow": a.percentage
                            }
                        })], 1)
                    })), 0), t.tooBigFileList ? e("div", [e("tawk-alert", {
                        staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                        attrs: {
                            status: "danger",
                            icon: "error",
                            title: t.$i18n("notifications", "maximum_size_upload_warning", {
                                limitFileSize: "50MB"
                            }),
                            description: t.tooBigFileList
                        }
                    })], 1) : t._e()], 1), e("div", {
                        attrs: {
                            slot: "unseen-message-count"
                        },
                        slot: "unseen-message-count"
                    }, [e("transition", {
                        attrs: {
                            name: "slide-fade"
                        }
                    }, [t.showLatest ? e("tawk-button", {
                        staticClass: "tawk-new-messages-notification",
                        attrs: {
                            label: "scroll to bottom",
                            isCircle: !0
                        },
                        on: {
                            click: function(e) {
                                return t.scrollToBottom()
                            }
                        }
                    }, [e("tawk-icon", {
                        attrs: {
                            type: "caret-down",
                            size: "medium"
                        }
                    })], 1) : t._e()], 1)], 1)], 1)
                }), [], !1, null, null, null).exports;

            function dt(t) {
                return (dt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function mt(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function ft(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? mt(Object(a), !0).forEach((function(e) {
                        pt(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : mt(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function pt(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != dt(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != dt(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == dt(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var gt = {
                    name: "prechat-form",
                    components: {
                        BaseFrame: I.a,
                        BaseBody: N.a,
                        HomeHeader: P,
                        HomeBody: W
                    },
                    data: function() {
                        return {
                            isDropdownOpen: !1,
                            isSubmitting: !1,
                            submissionError: !1,
                            submissionSuccess: !1
                        }
                    },
                    computed: ft({}, Object(i.c)({
                        states: "widget/states",
                        departments: "session/departments",
                        name: "visitor/name",
                        email: "visitor/getEmailValue",
                        pageStatus: "session/pageStatus"
                    })),
                    watch: {
                        pageStatus: function(t) {
                            "offline" === t && this.showOverlay(!1)
                        }
                    },
                    methods: ft(ft({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        showOverlay: "overlay/showOverlay",
                        removeRoute: "router/removeRoute"
                    })), {}, {
                        submitForm: function(t) {
                            var e = this;
                            t.hasError || (this.isSubmitting = !0, this.submissionError = !1, this.submissionSuccess = !1, this.$store.commit("session/setIsNotValidEmail", null), this.$store.commit("session/setIsNotValidPhone", null), this.$socket.publish("notifyPrechat", t.formData, (function(a) {
                                var i = "";
                                if (e.isSubmitting = !1, a) return "InvalidArgument" === a.code ? ("email" === a.message && e.$store.commit("session/setIsNotValidEmail", "email"), "phone" === a.message && e.$store.commit("session/setIsNotValidPhone", "phone"), void e.$emit("update:isSubmitting", !1)) : void(e.submissionError = !0);
                                e.$store.commit("session/setPrechatSubmitted", !0), e.$TawkJSAPI.triggerApiHandlers("onPrechatSubmit", t.formData.questions), e.$nextTick((function() {
                                    if (t.formData.questions && t.formData.questions.length > 0)
                                        for (var a = 0, s = t.formData.questions.length; a < s; a++) i += "".concat(t.formData.questions[a].label, " : ").concat(t.formData.questions[a].answer), a !== s - 1 && (i += "\r\n");
                                    i && e.$TawkChatManager.sendMessageToServer({
                                        message: i
                                    }), e.routerPush("chat"), e.removeRoute("prechat"), e.showOverlay(!1)
                                }))
                            })))
                        },
                        homeLoaded: function() {
                            var t = this;
                            setTimeout((function() {
                                t.$refs["tawk-chat-panel"] && t.$refs["tawk-chat-panel"].$scrollbar && t.$refs["tawk-chat-panel"].$scrollbar.update()
                            }), 500)
                        },
                        handleScroll: function() {
                            this.$refs && this.$refs["tawk-chat-panel"] && this.$eventBus.$emit("chatPanelScroll", {
                                scrollTop: this.$refs["tawk-chat-panel"].scrollTop
                            })
                        }
                    }),
                    mounted: function() {
                        var t = this;
                        setTimeout((function() {
                            t.$eventBus.$emit("formOpened")
                        }), 50)
                    },
                    destroyed: function() {
                        this.$eventBus.$emit("formClosed"), this.$emit("homeLoaded")
                    }
                },
                wt = Object(c.a)(gt, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("base-frame", {
                        ref: "tawk-frame",
                        staticClass: "tawk-prechat-view",
                        attrs: {
                            hasBackground: !0
                        },
                        on: {
                            "&scroll": function(e) {
                                return t.handleScroll.apply(null, arguments)
                            }
                        }
                    }, [e("base-body", [e("home-header", {
                        ref: "tawk-prechat-header",
                        attrs: {
                            state: "prechat"
                        }
                    }), e("div", {
                        staticClass: "tawk-margin-top",
                        staticStyle: {
                            width: "100%"
                        }
                    }, [e("home-body", {
                        ref: "tawk-prechat-body",
                        attrs: {
                            state: "prechat",
                            overwriteSubmit: !0
                        },
                        on: {
                            submitForm: t.submitForm,
                            homeLoaded: t.homeLoaded
                        }
                    })], 1)], 1)], 1)
                }), [], !1, null, null, null).exports,
                bt = a("90c2"),
                vt = a("87dd");

            function yt(t) {
                return (yt = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                })(t)
            }

            function kt(t, e) {
                var a = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), a.push.apply(a, i)
                }
                return a
            }

            function Ct(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var a = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? kt(Object(a), !0).forEach((function(e) {
                        Ot(t, e, a[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : kt(Object(a)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e))
                    }))
                }
                return t
            }

            function Ot(t, e, a) {
                return (e = function(t) {
                    var e = function(t, e) {
                        if ("object" != yt(t) || !t) return t;
                        var a = t[Symbol.toPrimitive];
                        if (void 0 !== a) {
                            var i = a.call(t, e || "default");
                            if ("object" != yt(i)) return i;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === e ? String : Number)(t)
                    }(t, "string");
                    return "symbol" == yt(e) ? e : e + ""
                }(e)) in t ? Object.defineProperty(t, e, {
                    value: a,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = a, t
            }
            var St = {
                    name: "MaximizeWidget",
                    components: {
                        IFrame: n.a,
                        CallWidget: function() {
                            return a.e("chunk-2d21ad1b").then(a.bind(null, "bcae"))
                        },
                        EndChat: function() {
                            return a.e("chunk-2d0e982e").then(a.bind(null, "8e9d"))
                        },
                        InactiveOverlay: function() {
                            return a.e("chunk-2d0af2da").then(a.bind(null, "0ce6"))
                        },
                        Toolbar: p,
                        TawkAlert: s.TawkAlert,
                        TawkOverlay: s.TawkOverlay,
                        HomeView: G,
                        ChatView: ht,
                        MaximizeFooter: C,
                        PrechatView: wt,
                        MessagesView: bt.default
                    },
                    mixins: [vt.a],
                    data: function() {
                        return {
                            cssLink: "".concat("https://embed.tawk.to/_s/v4/app/6880b98ef42", "/css/max-widget.css"),
                            classString: "",
                            showEndChat: !1,
                            noZoomMetaTag: null,
                            resizeHeightTo: null,
                            formIsOpen: !1,
                            isDraggedOver: !1,
                            originalBodyStyle: null,
                            isLoaded: !1,
                            isChatStatus: {},
                            routeLoadedTimeout: null,
                            powerImageUrl: "".concat("https://embed.tawk.to/_s/v4/assets", "/images/power.svg"),
                            initialized: !1,
                            iframe: {
                                height: "",
                                width: ""
                            },
                            isVisible: !1,
                            key: s.Helper.generateUUID(),
                            showConnected: !1
                        }
                    },
                    computed: Ct(Ct({}, Object(i.c)({
                        maxDimension: "widget/maxDesktop",
                        minDesktop: "widget/minDesktop",
                        chatWindowState: "session/chatWindowState",
                        states: "widget/states",
                        pageStatus: "session/pageStatus",
                        isRoundWidget: "widget/isRoundWidget",
                        branding: "widget/branding",
                        features: "widget/features",
                        currentView: "router/getCurrentView",
                        activeProfiles: "chat/activeProfiles",
                        hasChatStarted: "chat/hasChatStarted",
                        prechatFormSubmitted: "session/prechatFormSubmitted",
                        isPrechatEnabled: "widget/isPrechatEnabled",
                        isWindowed: "widget/isWindowed",
                        mobileBrowserName: "browserData/mobileBrowserName",
                        isEmbedded: "widget/isEmbedded",
                        hasChatEnded: "chat/hasChatEnded",
                        needConsent: "session/needConsent",
                        isInactive: "session/isInactive",
                        isRight: "widget/isRight",
                        isBottom: "widget/isBottom",
                        isCenter: "widget/isCenter",
                        isOverlayOpen: "overlay/isOpen",
                        getHistory: "router/getHistory",
                        hasLiveChat: "widget/hasLiveChat",
                        webrtcOptions: "widget/webrtcOptions",
                        agentsCount: "chat/agentsCount",
                        currentRoute: "router/current",
                        isReconnecting: "session/isReconnecting",
                        chatOrder: "chat/chatOrder",
                        unreadMessageCount: "chat/unreadMessageCount",
                        desktopVisibility: "widget/desktopVisibility",
                        showMessagePreview: "widget/showMessagePreview",
                        firstIncoming: "chat/firstIncoming",
                        isReady: "socket/isReady",
                        isConnecting: "socket/isConnecting",
                        isIE: "browserData/isIE",
                        components: "widget/components",
                        onClick: "widget/onClick"
                    })), {}, {
                        xOffset: function() {
                            return this.$TawkWidgetSettings.xOffset()
                        },
                        yOffset: function() {
                            return this.$TawkWidgetSettings.yOffset()
                        },
                        styleObject: function() {
                            var t, e = null === (t = this.$TawkJSAPI) || void 0 === t || null === (t = t.local_API) || void 0 === t || null === (t = t.customStyle) || void 0 === t ? void 0 : t.visibility,
                                a = {
                                    "border-radius:": "".concat(this.borderRadius, " !important;"),
                                    "z-index:": "1000002 !important;",
                                    "height:": "".concat(this.iframe.height, " !important;"),
                                    "width:": "".concat(this.iframe.width, " !important;"),
                                    "min-height:": "".concat(this.iframe.height, " !important;"),
                                    "min-width:": "".concat(this.iframe.width, " !important;"),
                                    "max-height:": "".concat(this.iframe.height, " !important;"),
                                    "max-width:": "".concat(this.iframe.width, " !important;")
                                };
                            if (this.isWindowed || this.isEmbedded ? a["position:"] = "absolute !important;" : a["position:"] = "fixed !important;", this.isWindowed || this.mobileBrowserName || this.isEmbedded) {
                                var i = 0,
                                    s = 0,
                                    n = 0,
                                    r = 0;
                                this.mobileBrowserName && e && e.mobile && e.mobile.maximized && (e.mobile.maximized.bottomOffset && (i = e.mobile.maximized.bottomOffset), e.mobile.maximized.topOffset && (r = e.mobile.maximized.topOffset), e.mobile.maximized.leftOffset && (n = e.mobile.maximized.leftOffset), e.mobile.maximized.rightOffset && (s = e.mobile.maximized.rightOffset), a["height:"] = "calc(100% - ".concat(i + r, "px) !important;"), a["min-height:"] = "calc(100% - ".concat(i + r, "px) !important;"), a["max-height:"] = "calc(100% - ".concat(i + r, "px) !important;"), a["width:"] = "calc(100% - ".concat(n + s, "px) !important;"), a["min-width:"] = "calc(100% - ".concat(n + s, "px) !important;"), a["max-width:"] = "calc(100% - ".concat(n + s, "px) !important;")), a["bottom:"] = "".concat(i, "px !important;"), a["right:"] = "".concat(s, "px !important;"), a["left:"] = "".concat(n, "px !important;"), a["top:"] = "".concat(r, "px !important;")
                            } else {
                                var o;
                                o = "slide" === this.onClick ? 0 : this.isCenter && this.isRoundWidget ? this.minDesktop.width + this.xOffset + 18 : this.xOffset, this.isRight ? a["right:"] = "".concat(o, "px !important;") : a["left:"] = "".concat(o, "px !important;"), this.isRoundWidget && "slide" !== this.onClick ? this.isBottom ? a["bottom:"] = "".concat(this.minDesktop.height + this.yOffset + 18, "px !important;") : (a["top:"] = "".concat(this.minDesktop.height + this.yOffset + 18, "px !important;"), a["bottom:"] = "auto !important;") : a["bottom:"] = "0px !important;"
                            }
                            return "max" === this.chatWindowState || this.isWindowed || this.isEmbedded ? a["display:"] = "block !important;" : a["display:"] = "none !important;", Ct(Ct({}, this.genericStyles), a)
                        },
                        borderRadius: function() {
                            return this.isWindowed || this.mobileBrowserName || this.isEmbedded || "slide" === this.onClick ? "0px" : this.isRoundWidget ? "18px" : "18px 18px  0 0"
                        },
                        borderRadiusTop: function() {
                            return this.isWindowed || this.mobileBrowserName || this.isEmbedded || "slide" === this.onClick ? "0px" : "18px 18px 0 0"
                        },
                        hasHomeView: function() {
                            return this.hasChatEnded, !0
                        },
                        showBackButton: function() {
                            return this.currentView && ("chat" === this.currentView.path || "agents" === this.currentView.path || "prechat" === this.currentView.path || "messages" === this.currentView.path) && this.hasHomeView && ("agents" === this.currentView.path || "messages" === this.currentView.path || !this.isOverlayOpen)
                        },
                        isToolbarElementsVisible: function() {
                            return !(!this.mobileBrowserName && this.isRoundWidget && "/" === this.currentRoute && (void 0 === this.webrtcOptions || !this.webrtcOptions.enabled || this.isPrechatEnabled && !this.prechatFormSubmitted))
                        },
                        isChatInputBottom: function() {
                            var t = !1,
                                e = this.states[this.pageStatus];
                            return e && e.body.length && (t = "chat" === e.body[e.body.length - 1].type), t
                        },
                        showChatInput: function() {
                            return this.currentView && ("/" === this.currentView.path && this.hasChatStarted || "chat" === this.currentView.path)
                        },
                        hasPrechatHistory: function() {
                            if (0 === this.getHistory.length) return !1;
                            var t = !1;
                            return this.getHistory.filter((function(e) {
                                "prechat" === e && (t = !0)
                            })), t
                        },
                        isHomeViewVisible: function() {
                            return this.needConsent || "chat" !== this.currentRoute && "agents" !== this.currentRoute && "prechat" !== this.currentRoute && "messages" !== this.currentRoute && this.hasHomeView && (!this.hasPrechatHistory || this.prechatFormSubmitted)
                        },
                        isWebrtcEnabled: function() {
                            return this.components && this.components.webrtc
                        },
                        maximizeStyle: function() {
                            return {
                                borderRadius: this.borderRadius
                            }
                        }
                    }),
                    watch: {
                        chatWindowState: function(t) {
                            var e = this;
                            "max" === t ? (this.classString = "open", this.openView(), this.formIsOpen && this.resizeFrame(), this.isChatStatus["display:"] = "block !important;", this.showMaxWidget()) : (this.classString = "closed", this.noZoomMetaTag.content = "", this.noZoomMetaTag.parentNode && this.noZoomMetaTag.parentNode.removeChild(this.noZoomMetaTag), null !== this.originalBodyStyle && (document.body.style.cssText = this.originalBodyStyle), this.mobileBrowserName ? this.isChatStatus["display:"] = "none !important;" : setTimeout((function() {
                                e.isChatStatus["display:"] = "none !important;"
                            }), 250), this.hideMaxWidget())
                        },
                        pageStatus: function() {
                            "max" === this.chatWindowState && this.openView(), "offline" === this.pageStatus && (this.showOverlay(!1), this.routerPush("/"), this.clearHistory())
                        },
                        unreadMessageCount: function(t) {
                            this.isWindowed || this.isEmbedded || (!this.mobileBrowserName && !this.desktopVisibility.show && t > 0 && "max" !== this.chatWindowState && this.updateChatWindowState("max"), !this.firstIncoming || this.mobileBrowserName || this.showMessagePreview || "max" === this.chatWindowState || this.updateChatWindowState("max"))
                        },
                        isReady: function(t, e) {
                            var a = this;
                            t !== e && (this.showConnected = !0, setTimeout((function() {
                                a.showConnected = !1
                            }), 1e3))
                        },
                        isReconnecting: function(t, e) {
                            var a = this;
                            t !== e && (this.showConnected = !0, setTimeout((function() {
                                a.showConnected = !1
                            }), 1e3))
                        }
                    },
                    methods: Ct(Ct({}, Object(i.b)({
                        routerPush: "router/routerPush",
                        updateRoute: "router/updateRoute",
                        toggleWidget: "session/toggleWidget",
                        toggleLocalSound: "widget/toggleLocalSound",
                        showOverlay: "overlay/showOverlay",
                        routerBack: "router/routerBack",
                        clearHistory: "router/clearHistory",
                        updateChatWindowState: "session/updateChatWindowState",
                        toggleFocus: "widget/toggleFocus"
                    })), {}, {
                        triggerClick: function() {
                            this.$store.dispatch("session/toggleWidget")
                        },
                        openView: function() {
                            if (this.initialized = !0, this.showMaxWidget(), this.mobileBrowserName) {
                                var t = document.querySelector("meta[name=viewport]") || document.querySelector("meta[name=VIEWPORT]");
                                this.$TawkWindow.isMobileOptimizedWebsite || null === this.noZoomMetaTag || (this.$TawkWindow.metaContent || "" !== this.noZoomMetaTag.content ? this.$TawkWindow.metaContent && !this.$TawkWindow.hasNoScale && t && t.setAttribute("content", this.$TawkWindow.metaContent + ", user-scalable=no") : (this.noZoomMetaTag.content = "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no", this.noZoomMetaTag.parentNode || document.getElementsByTagName("head")[0].appendChild(this.noZoomMetaTag)));
                                var e = document.body;
                                this.originalBodyStyle = e.style.cssText;
                                for (var a = ["height", "min-height", "max-height", "width", "min-width", "max-width"], i = 0; i < a.length; i++) e.style.setProperty(a[i], "100%", "important");
                                e.style.setProperty("overflow", "hidden", "important"), e.style.setProperty("position", "fixed", "important")
                            }
                            if (!this.currentView && this.hasHomeView && this.routerPush("/"), "offline" !== this.pageStatus) return this.hasHomeView || this.prechatFormSubmitted || !this.isPrechatEnabled ? !this.hasChatStarted && 0 === this.chatOrder || !this.hasLiveChat || !this.prechatFormSubmitted && this.isPrechatEnabled ? void(this.currentView && ("/" !== this.currentRoute || this.hasHomeView) || (this.hasLiveChat && this.hasChatStarted || !this.hasHomeView ? (this.routerPush("chat"), this.showOverlay(!1)) : this.showOverlay(!1))) : (this.showOverlay(!1), this.routerPush("chat")) : this.routerPush("prechat");
                            this.showOverlay(!1)
                        },
                        loaded: function() {
                            var t = this;
                            if (this.hasHomeView || (this.updateRoute({
                                    path: "chat",
                                    hasBack: !1
                                }), this.updateRoute({
                                    path: "prechat",
                                    hasBack: !1
                                })), this.isWindowed || this.isEmbedded || "max" === this.chatWindowState ? this.openView() : this.$refs["max-widget"].$el.style.setProperty("display", "none", "important"), this.$eventBus.$on("formOpened", (function() {
                                    "max" === t.chatWindowState ? t.resizeFrame() : t.formIsOpen = !0
                                })), this.$eventBus.$on("formClosed", (function() {
                                    t.resizeHeightTo = null, t.formIsOpen = !1
                                })), this.$eventBus.$on("resetState", (function() {
                                    t.$store.commit("router/changeCurrentView", "/"), t.$TawkActivityMonitor.setupMaxWidgetListeners()
                                })), !this.isWindowed && !this.isEmbedded) {
                                var e, a, i = "",
                                    s = "tawkMaxOpen",
                                    n = "tawkMaxClose",
                                    r = this.$el.id;
                                this.isBottom ? (e = "transform:translate(0, 30px);", a = "transform:translate(0, 0px);") : this.isCenter ? this.isRight ? (e = "transform:translate(30px,0);", a = "transform:translate(0px,0);") : (e = "transform:translate(-30px,0);", a = "transform:translate(0px,0);") : (e = "transform:translate(0, -30px);", a = "transform:translate(0, 0px);");
                                var o, c = "{0%{opacity:0;" + e + ";}to{opacity:1;" + a + "}}";
                                i += "@keyframes " + s + c, i += "@-moz-keyframes " + s + c, i += "@-webkit-keyframes " + s + c, i += "#" + r + ".open{animation : " + s + " .25s ease!important;}", this.mobileBrowserName || (this.isRoundWidget, i += "@keyframes " + n + (o = "{from{opacity: 1;" + a + ";}to{opacity: 0;" + e + ";}}"), i += "@-moz-keyframes " + n + o, i += "@-webkit-keyframes " + n + o, i += "#" + r + ".closed{animation: " + n + " .25s ease!important}");
                                var l = document.head,
                                    u = document.createDocumentFragment(),
                                    h = document.createElement("style"),
                                    d = document.createTextNode(i);
                                h.type = "text/css", u.appendChild(h), l.appendChild(u), h.styleSheet ? h.styleSheet.cssText = d.nodeValue : h.appendChild(d)
                            }
                            this.$TawkActivityMonitor.setupMaxWidgetListeners()
                        },
                        widgetFocus: function(t) {
                            this.$eventBus.$emit("widgetOnFocus", t)
                        },
                        resizeFrame: function() {
                            var t = this,
                                e = 0,
                                a = 0,
                                i = 0;
                            this.isWindowed || this.mobileBrowserName || this.isEmbedded || setTimeout((function() {
                                if (!t.isOverlayOpen && t.$refs["main-toolbar"] && t.$refs["main-toolbar"].$el && (e = t.$refs["main-toolbar"].$el.offsetHeight), t.isOverlayOpen && t.$refs["view-overlay"] && t.$refs["view-overlay"].$el.children[0] && (e = t.$refs["view-overlay"].$el.children[0].offsetHeight), !t.isOverlayOpen && t.$refs["main-footer"] && (a = t.$refs["main-footer"].$el.offsetHeight), t.isOverlayOpen && t.$refs["overlay-footer"] && (a = t.$refs["overlay-footer"].$el.offsetHeight), t.$refs["router-view"] && t.$refs["router-view"].$children.length) {
                                    var s = t.$refs["router-view"].$children.length ? t.$refs["router-view"].$children[0] : null;
                                    s && s.$refs && s.$refs["tawk-inner-panel"] && (i = s.$refs["tawk-inner-panel"].offsetHeight)
                                }
                                if (!t.$refs["router-view"].$children.length) {
                                    var n;
                                    "chat" === t.currentRoute && t.$refs["chat-view"] ? n = t.$refs["chat-view"].$refs["tawk-inner-panel"] : "prechat" === t.currentRoute && t.$refs["prechat-view"] ? n = t.$refs["prechat-view"].$refs["tawk-inner-panel"] : t.$refs["home-view"] && (n = t.$refs["home-view"].$refs["tawk-inner-panel"]);
                                    var r = n ? n.lastChild : null;
                                    if (r && 0 === r.offsetHeight) return t.resizeHeightTo = null;
                                    i = n ? n.offsetHeight : 0
                                }
                                return 0 === i ? t.resizeHeightTo = null : (i < 250 && (i = 250), 0 === i ? t.resizeHeightTo = null : void((i += e + a) && t.maxDimension.height > i + 10 && (t.resizeHeightTo = i + 10)))
                            }), 300)
                        },
                        handleOverlayBack: function() {
                            this.routerBack(), "/" !== this.currentRoute && "messages" !== this.currentRoute || this.showOverlay(!1), this.isDraggedOver = !1
                        },
                        checkRouteLoaded: function() {
                            var t = this;
                            clearTimeout(this.routeLoadedTimeout), void 0 !== this.$refs["router-view"] ? this.isLoaded = !0 : this.routeLoadedTimeout = setTimeout((function() {
                                t.checkRouteLoaded()
                            }), 1e3)
                        },
                        handleFocus: function() {
                            this.toggleFocus(!0)
                        },
                        handleBlur: function() {
                            this.toggleFocus(!1)
                        },
                        calculateHeight: function() {
                            if (this.isWindowed || this.mobileBrowserName || this.isEmbedded || "slide" === this.onClick) this.iframe.height = "100%";
                            else if (this.resizeHeightTo) this.iframe.height = this.resizeHeightTo + "px";
                            else {
                                if (this.isRoundWidget) {
                                    var t = this.minDesktop.height + this.yOffset + 10;
                                    if (this.maxDimension.height + t > window.innerHeight) return void(this.iframe.height = "".concat(window.innerHeight - t - 10, "px"))
                                }
                                this.maxDimension.height >= window.innerHeight ? this.iframe.height = "".concat(window.innerHeight - 10, "px") : this.iframe.height = "".concat(this.maxDimension.height, "px")
                            }
                        },
                        calculateWidth: function() {
                            if (this.isWindowed || this.mobileBrowserName || this.isEmbedded) this.iframe.width = "100%";
                            else {
                                if (this.isRoundWidget) {
                                    var t = this.minDesktop.width + this.xOffset + 10;
                                    if (this.maxDimension.width + t > window.innerWidth) return void(this.iframe.width = "".concat(window.innerWidth - t - 10, "px"))
                                }
                                this.maxDimension.width >= window.innerWidth ? this.iframe.width = "".concat(window.innerWidth - 10, "px") : this.iframe.width = this.maxDimension.width + "px"
                            }
                        },
                        calculateIframeSize: function() {
                            this.calculateHeight(), this.calculateWidth()
                        },
                        showMaxWidget: function() {
                            var t = this;
                            this.$refs["max-widget"].$el.style.setProperty("display", "block", "important"), setTimeout((function() {
                                t.isVisible = !0, t.$refs["max-widget"].$el.style.setProperty("box-shadow", "10px 10px 40px 0px rgba(0, 0, 0, 0.08), 5px 14px 80px 0px rgba(26, 26, 26, 0.12)", "important")
                            }), 250)
                        },
                        hideMaxWidget: function() {
                            var t = this;
                            this.$nextTick((function() {
                                t.$refs["max-widget"].$el.style.setProperty("display", "block", "important"), t.isVisible = !1, t.$refs["max-widget"].$el.style.setProperty("box-shadow", "none", "important")
                            })), setTimeout((function() {
                                t.$refs["max-widget"].$el.style.setProperty("display", "none", "important")
                            }), 250)
                        },
                        injectStyleNode: function() {
                            if (!this.mobileBrowserName && "slide" === this.onClick) {
                                var t = "-100%",
                                    e = this.$refs["max-widget"].$el.contentDocument,
                                    a = document.createElement("style");
                                a.type = "text/css", a.classList.add("tawk-dynamic-style"), this.isRight && (t = "100%"), a.appendChild(document.createTextNode("\n\t\t\t\t.tawk-max-slide-enter-active,\n\t\t\t\t.tawk-max-slide-leave-active {\n\t\t\t\t\ttransition: all 0.25s;\n\t\t\t\t\ttransition-timing-function: ease-in-out;\n\t\t\t\t}\n\n\t\t\t\t.tawk-max-slide-enter {\n\t\t\t\t\ttransform: translateX(".concat(t, ");\n\t\t\t\t\topacity: 0;\n\t\t\t\t}\n\n\t\t\t\t.tawk-max-slide-enter-to {\n\t\t\t\t\ttransform: translateX(0%);\n\t\t\t\t\topacity: 1;\n\t\t\t\t}\n\n\t\t\t\t.tawk-max-slide-leave {\n\t\t\t\t\ttransform: translateX(0%);\n\t\t\t\t\topacity: 1;\n\t\t\t\t}\n\n\t\t\t\t.tawk-max-slide-leave-to {\n\t\t\t\t\ttransform: translateX(").concat(t, ");\n\t\t\t\t\topacity: 0;\n\t\t\t\t}\n\t\t\t"))), e.head.appendChild(a)
                            }
                        },
                        removeStyleNode: function() {
                            var t = this.$refs["max-widget"].$el.contentDocument.querySelector(".tawk-dynamic-style");
                            t && t.parentNode.removeChild(t)
                        }
                    }),
                    mounted: function() {
                        var t = this;
                        this.calculateIframeSize(), this.noZoomMetaTag = document.createElement("meta"), this.noZoomMetaTag.name = "viewport", this.checkRouteLoaded(), this.$el.contentWindow.addEventListener("focus", this.handleFocus), this.$el.contentWindow.addEventListener("blur", this.handleBlur), window.addEventListener("resize", this.calculateIframeSize), this.$eventBus.$on("switchWidget", (function() {
                            t.key = s.Helper.generateUUID(), t.calculateIframeSize(), t.$nextTick((function() {
                                t.injectStyleNode()
                            }))
                        })), this.$eventBus.$on("forceUpdate", (function() {
                            t.initialized = !1, t.$nextTick((function() {
                                t.initialized = !0
                            }))
                        })), this.injectStyleNode(), this.$eventBus.$on("updateWidgetSettings", (function() {
                            t.removeStyleNode(), t.$nextTick((function() {
                                t.injectStyleNode()
                            }))
                        })), this.$store.dispatch("form/get")
                    },
                    beforeDestroy: function() {
                        this.$el.contentWindow.removeEventListener("focus", this.handleFocus), this.$el.contentWindow.removeEventListener("blur", this.handleBlur), window.removeEventListener("resize", this.calculateIframeSize)
                    }
                },
                xt = Object(c.a)(St, (function() {
                    var t = this,
                        e = t._self._c;
                    return e("i-frame", {
                        key: t.key,
                        ref: "max-widget",
                        attrs: {
                            width: t.iframe.width,
                            height: t.iframe.height,
                            cssLink: t.cssLink,
                            styleObject: t.styleObject,
                            classString: t.classString
                        }
                    }, [e("transition", {
                        attrs: {
                            tag: "div",
                            name: "tawk-max-slide"
                        }
                    }, [e("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isVisible,
                            expression: "isVisible"
                        }],
                        on: {
                            "&scroll": function(e) {
                                return t.handleScroll.apply(null, arguments)
                            }
                        }
                    }, [t.initialized ? e("div", {
                        staticClass: "tawk-max-container tawk-flex tawk-flex-column",
                        class: [!t.isToolbarElementsVisible && "tawk-no-toolbar-elements"],
                        style: t.maximizeStyle,
                        on: {
                            click: t.widgetFocus,
                            keyup: function(e) {
                                return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.widgetFocus.apply(null, arguments)
                            }
                        }
                    }, [e("toolbar", {
                        ref: "main-toolbar",
                        attrs: {
                            borderRadiusTop: t.borderRadiusTop,
                            showBackButton: t.showBackButton,
                            currentView: t.currentView,
                            showWebRtcButtons: !0,
                            showAgentAvatars: !0
                        },
                        on: {
                            showEndChat: function(e) {
                                t.showEndChat = !0
                            }
                        }
                    }), t.isWebrtcEnabled ? e("call-widget") : t._e(), e("tawk-overlay", {
                        ref: "view-overlay",
                        style: {
                            borderRadius: t.borderRadius
                        },
                        attrs: {
                            isOpen: t.isOverlayOpen,
                            title: t.currentView && t.currentView.title ? t.currentView.title() : "",
                            backTooltipText: t.$i18n("rollover", "back"),
                            headerClass: "tawk-custom-color",
                            options: "history-chat" === t.currentRoute ? {
                                alignAllButtons: "left"
                            } : {}
                        },
                        on: {
                            goBack: t.handleOverlayBack
                        }
                    }, [e("div", {
                        attrs: {
                            slot: "options"
                        },
                        slot: "options"
                    }, [t.isOverlayOpen ? e("toolbar", {
                        attrs: {
                            borderRadiusTop: t.borderRadiusTop,
                            currentView: t.currentView
                        },
                        on: {
                            showEndChat: function(e) {
                                t.showEndChat = !0
                            }
                        }
                    }) : t._e()], 1), e("div", {
                        staticClass: "tawk-flex tawk-flex-column",
                        staticStyle: {
                            height: "100%",
                            overflow: "hidden"
                        }
                    }, [e("div", {
                        staticClass: "tawk-flex tawk-flex-column tawk-flex-1 tawk-custom-flex-1"
                    }, [e("div", {
                        staticClass: "tawk-router-view tawk-flex tawk-flex-1 tawk-custom-flex-1"
                    }, [e("tawk-router-view", {
                        ref: "router-view"
                    })], 1), e("maximize-footer", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isOverlayOpen,
                            expression: "isOverlayOpen"
                        }],
                        ref: "overlay-footer"
                    })], 1)])]), t.isInactive ? e("inactive-overlay") : t._e(), t.showEndChat && !t.hasChatEnded ? e("end-chat", {
                        on: {
                            cancelEnd: function(e) {
                                t.showEndChat = !1
                            }
                        }
                    }) : t._e(), e("div", {
                        staticClass: "tawk-flex tawk-flex-column tawk-flex-1"
                    }, [e("div", {
                        staticClass: "tawk-router-view tawk-flex tawk-flex-1"
                    }, [t.isLoaded ? t._e() : e("div", {
                        staticClass: "tawk-flex tawk-flex-middle tawk-flex-center",
                        style: {
                            width: "100%",
                            height: "100%",
                            left: 0,
                            top: 0,
                            position: "absolute"
                        }
                    }, [e("div", {
                        staticClass: "tawk-spinner-loader",
                        style: {
                            margin: "1px"
                        }
                    })]), e("transition", {
                        attrs: {
                            name: "slide-fade",
                            mode: "out-in"
                        }
                    }, [!t.hasLiveChat || t.needConsent || !t.chatOrder && !t.hasChatStarted && t.hasHomeView ? t._e() : e("chat-view", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "chat" === t.currentRoute || "agents" === t.currentRoute,
                            expression: "currentRoute === 'chat' || currentRoute === 'agents'"
                        }],
                        ref: "chat-view"
                    })], 1), e("transition", {
                        attrs: {
                            name: "slide-fade",
                            mode: "out-in"
                        }
                    }, [t.hasLiveChat && !t.needConsent && t.isPrechatEnabled && t.isReady && !t.prechatFormSubmitted && ("prechat" === t.currentRoute || !t.hasHomeView || t.hasPrechatHistory && !t.prechatFormSubmitted) ? e("prechat-view", {
                        ref: "prechat-view"
                    }) : t._e()], 1), e("transition", {
                        attrs: {
                            name: "slide-fade",
                            mode: "out-in"
                        }
                    }, [t.hasHomeView || t.needConsent ? e("home-view", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.isHomeViewVisible && !t.isOverlayOpen,
                            expression: "isHomeViewVisible && !isOverlayOpen"
                        }],
                        ref: "home-view",
                        attrs: {
                            isVisible: t.isHomeViewVisible && !t.isOverlayOpen
                        }
                    }) : t._e()], 1), e("transition", {
                        attrs: {
                            name: "slide-fade",
                            mode: "out-in"
                        }
                    }, ["messages" === t.currentRoute ? e("messages-view", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: "messages" === t.currentRoute && !t.isOverlayOpen,
                            expression: "currentRoute === 'messages' && !isOverlayOpen"
                        }],
                        ref: "messages-view"
                    }) : t._e()], 1)], 1), e("maximize-footer", {
                        ref: "main-footer"
                    })], 1), e("transition", {
                        attrs: {
                            name: "slide-fade"
                        }
                    }, [t.isReconnecting ? e("tawk-alert", {
                        staticStyle: {
                            position: "absolute",
                            bottom: "16px",
                            left: "16px",
                            right: "16px",
                            width: "auto",
                            "z-index": "10"
                        },
                        attrs: {
                            title: t.$i18n("notifications", "reconnecting"),
                            status: "danger",
                            description: "",
                            icon: "error"
                        }
                    }) : t._e()], 1)], 1) : t._e()])])], 1)
                }), [], !1, null, null, null);
            e.default = xt.exports
        }
    }
]);