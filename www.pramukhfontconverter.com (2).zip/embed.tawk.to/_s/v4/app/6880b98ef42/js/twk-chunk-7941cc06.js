/*! For license information please see twk-chunk-7941cc06.js.LICENSE */
(window.tawkJsonp = window.tawkJsonp || []).push([
    ["chunk-7941cc06"], {
        3519: function(e, t, r) {
            "use strict";
            var n = r("2f62"),
                i = r("f0b0"),
                a = {
                    name: "TawkSpinner"
                },
                s = r("2877"),
                o = Object(s.a)(a, (function() {
                    return this._self._c, this._m(0)
                }), [function() {
                    var e = this._self._c;
                    return e("div", {
                        staticClass: "lds-spinner loader",
                        attrs: {
                            role: "status"
                        }
                    }, [e("div", {
                        staticClass: "spin spin-1"
                    }), e("div", {
                        staticClass: "spin spin-2"
                    }), e("div", {
                        staticClass: "spin spin-3"
                    }), e("div", {
                        staticClass: "spin spin-4"
                    }), e("div", {
                        staticClass: "spin spin-5"
                    }), e("div", {
                        staticClass: "spin spin-6"
                    }), e("div", {
                        staticClass: "spin spin-7"
                    }), e("div", {
                        staticClass: "spin spin-8"
                    }), e("div", {
                        staticClass: "spin spin-9"
                    }), e("div", {
                        staticClass: "spin spin-10"
                    }), e("div", {
                        staticClass: "spin spin-11"
                    }), e("div", {
                        staticClass: "spin spin-12"
                    })])
                }], !1, null, null, null).exports;

            function l(e) {
                return (l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function c() {
                c = function() {
                    return t
                };
                var e, t = {},
                    r = Object.prototype,
                    n = r.hasOwnProperty,
                    i = Object.defineProperty || function(e, t, r) {
                        e[t] = r.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    s = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    u = a.toStringTag || "@@toStringTag";

                function m(e, t, r) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    m({}, "")
                } catch (e) {
                    m = function(e, t, r) {
                        return e[t] = r
                    }
                }

                function d(e, t, r, n) {
                    var a = t && t.prototype instanceof y ? t : y,
                        s = Object.create(a.prototype),
                        o = new O(n || []);
                    return i(s, "_invoke", {
                        value: E(e, r, o)
                    }), s
                }

                function f(e, t, r) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, r)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }
                t.wrap = d;
                var p = "suspendedStart",
                    h = "executing",
                    v = "completed",
                    g = {};

                function y() {}

                function b() {}

                function k() {}
                var w = {};
                m(w, s, (function() {
                    return this
                }));
                var T = Object.getPrototypeOf,
                    x = T && T(T(C([])));
                x && x !== r && n.call(x, s) && (w = x);
                var F = k.prototype = y.prototype = Object.create(w);

                function _(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        m(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function $(e, t) {
                    function r(i, a, s, o) {
                        var c = f(e[i], e, a);
                        if ("throw" !== c.type) {
                            var u = c.arg,
                                m = u.value;
                            return m && "object" == l(m) && n.call(m, "__await") ? t.resolve(m.__await).then((function(e) {
                                r("next", e, s, o)
                            }), (function(e) {
                                r("throw", e, s, o)
                            })) : t.resolve(m).then((function(e) {
                                u.value = e, s(u)
                            }), (function(e) {
                                return r("throw", e, s, o)
                            }))
                        }
                        o(c.arg)
                    }
                    var a;
                    i(this, "_invoke", {
                        value: function(e, n) {
                            function i() {
                                return new t((function(t, i) {
                                    r(e, n, t, i)
                                }))
                            }
                            return a = a ? a.then(i, i) : i()
                        }
                    })
                }

                function E(t, r, n) {
                    var i = p;
                    return function(a, s) {
                        if (i === h) throw Error("Generator is already running");
                        if (i === v) {
                            if ("throw" === a) throw s;
                            return {
                                value: e,
                                done: !0
                            }
                        }
                        for (n.method = a, n.arg = s;;) {
                            var o = n.delegate;
                            if (o) {
                                var l = I(o, n);
                                if (l) {
                                    if (l === g) continue;
                                    return l
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if (i === p) throw i = v, n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            i = h;
                            var c = f(t, r, n);
                            if ("normal" === c.type) {
                                if (i = n.done ? v : "suspendedYield", c.arg === g) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (i = v, n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function I(t, r) {
                    var n = r.method,
                        i = t.iterator[n];
                    if (i === e) return r.delegate = null, "throw" === n && t.iterator.return && (r.method = "return", r.arg = e, I(t, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), g;
                    var a = f(i, t.iterator, r.arg);
                    if ("throw" === a.type) return r.method = "throw", r.arg = a.arg, r.delegate = null, g;
                    var s = a.arg;
                    return s ? s.done ? (r[t.resultName] = s.value, r.next = t.nextLoc, "return" !== r.method && (r.method = "next", r.arg = e), r.delegate = null, g) : s : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, g)
                }

                function S(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function j(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(S, this), this.reset(!0)
                }

                function C(t) {
                    if (t || "" === t) {
                        var r = t[s];
                        if (r) return r.call(t);
                        if ("function" == typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var i = -1,
                                a = function r() {
                                    for (; ++i < t.length;)
                                        if (n.call(t, i)) return r.value = t[i], r.done = !1, r;
                                    return r.value = e, r.done = !0, r
                                };
                            return a.next = a
                        }
                    }
                    throw new TypeError(l(t) + " is not iterable")
                }
                return b.prototype = k, i(F, "constructor", {
                    value: k,
                    configurable: !0
                }), i(k, "constructor", {
                    value: b,
                    configurable: !0
                }), b.displayName = m(k, u, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === b || "GeneratorFunction" === (t.displayName || t.name))
                }, t.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, k) : (e.__proto__ = k, m(e, u, "GeneratorFunction")), e.prototype = Object.create(F), e
                }, t.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, _($.prototype), m($.prototype, o, (function() {
                    return this
                })), t.AsyncIterator = $, t.async = function(e, r, n, i, a) {
                    void 0 === a && (a = Promise);
                    var s = new $(d(e, r, n, i), a);
                    return t.isGeneratorFunction(r) ? s : s.next().then((function(e) {
                        return e.done ? e.value : s.next()
                    }))
                }, _(F), m(F, u, "Generator"), m(F, s, (function() {
                    return this
                })), m(F, "toString", (function() {
                    return "[object Generator]"
                })), t.keys = function(e) {
                    var t = Object(e),
                        r = [];
                    for (var n in t) r.push(n);
                    return r.reverse(),
                        function e() {
                            for (; r.length;) {
                                var n = r.pop();
                                if (n in t) return e.value = n, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, t.values = C, O.prototype = {
                    constructor: O,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(j), !t)
                            for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = e)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var r = this;

                        function i(n, i) {
                            return o.type = "throw", o.arg = t, r.next = n, i && (r.method = "next", r.arg = e), !!i
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var s = this.tryEntries[a],
                                o = s.completion;
                            if ("root" === s.tryLoc) return i("end");
                            if (s.tryLoc <= this.prev) {
                                var l = n.call(s, "catchLoc"),
                                    c = n.call(s, "finallyLoc");
                                if (l && c) {
                                    if (this.prev < s.catchLoc) return i(s.catchLoc, !0);
                                    if (this.prev < s.finallyLoc) return i(s.finallyLoc)
                                } else if (l) {
                                    if (this.prev < s.catchLoc) return i(s.catchLoc, !0)
                                } else {
                                    if (!c) throw Error("try statement without catch or finally");
                                    if (this.prev < s.finallyLoc) return i(s.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var i = this.tryEntries[r];
                            if (i.tryLoc <= this.prev && n.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                                var a = i;
                                break
                            }
                        }
                        a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                        var s = a ? a.completion : {};
                        return s.type = e, s.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, g) : this.complete(s)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), g
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.finallyLoc === e) return this.complete(r.completion, r.afterLoc), j(r), g
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.tryLoc === e) {
                                var n = r.completion;
                                if ("throw" === n.type) {
                                    var i = n.arg;
                                    j(r)
                                }
                                return i
                            }
                        }
                        throw Error("illegal catch attempt")
                    },
                    delegateYield: function(t, r, n) {
                        return this.delegate = {
                            iterator: C(t),
                            resultName: r,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = e), g
                    }
                }, t
            }

            function u(e, t, r, n, i, a, s) {
                try {
                    var o = e[a](s),
                        l = o.value
                } catch (e) {
                    return void r(e)
                }
                o.done ? t(l) : Promise.resolve(l).then(n, i)
            }

            function m(e) {
                return function() {
                    var t = this,
                        r = arguments;
                    return new Promise((function(n, i) {
                        var a = e.apply(t, r);

                        function s(e) {
                            u(a, n, i, s, o, "next", e)
                        }

                        function o(e) {
                            u(a, n, i, s, o, "throw", e)
                        }
                        s(void 0)
                    }))
                }
            }

            function d(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function f(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != l(e) || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != l(n)) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == l(t) ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var p = {
                    name: "InlineForm",
                    mixins: [r("e49c").a],
                    components: {
                        TawkInput: i.TawkInput,
                        TawkPhoneInput: i.TawkPhoneInput,
                        TawkTextarea: i.TawkTextarea,
                        TawkRadio: i.TawkRadio,
                        TawkCheckbox: i.TawkCheckbox,
                        TawkButton: i.TawkButton,
                        TawkIcon: i.TawkIcon
                    },
                    props: {
                        form: {
                            type: Array,
                            default: function() {
                                return []
                            }
                        },
                        isSubmitting: {
                            type: Boolean,
                            default: !1
                        },
                        submissionError: {
                            type: String,
                            default: null
                        }
                    },
                    data: function() {
                        return {
                            formFields: this.form,
                            values: [],
                            assetPath: "https://embed.tawk.to/_s/v4/assets"
                        }
                    },
                    watch: {
                        isNotValidEmail: function(e) {
                            var t = this;
                            this.formFields.forEach((function(r) {
                                "email" === r.type && null != t.isNotValidEmail && (r.invalidType = e)
                            }))
                        },
                        isNotValidPhone: function(e) {
                            var t = this;
                            this.formFields.forEach((function(r) {
                                "phone" === r.type && null != t.isNotValidPhone && (r.invalidType = e)
                            }))
                        },
                        name: function(e, t) {
                            e !== t && this.updateFormValues()
                        },
                        email: function(e, t) {
                            e !== t && this.updateFormValues()
                        }
                    },
                    mounted: function() {
                        this.updateFormValues()
                    },
                    computed: function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var r = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? d(Object(r), !0).forEach((function(t) {
                                f(e, t, r[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : d(Object(r)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                            }))
                        }
                        return e
                    }({}, Object(n.c)({
                        name: "visitor/name",
                        email: "visitor/getEmailValue",
                        isNotValidEmail: "session/isNotValidEmail",
                        isNotValidPhone: "session/isNotValidPhone",
                        countryCode: "session/countryCode"
                    })),
                    methods: {
                        submitForm: function() {
                            var e = this;
                            return m(c().mark((function t() {
                                var r, n, i;
                                return c().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 2, e.formatInlineFormData();
                                        case 2:
                                            if (r = t.sent, n = r.formData, !(i = r.error) || !i.hasError && !i.message) {
                                                t.next = 8;
                                                break
                                            }
                                            return e.$emit("update:submissionError", null == i ? void 0 : i.message), t.abrupt("return");
                                        case 8:
                                            e.$emit("update:submissionError", ""), e.$emit("submit", n);
                                        case 10:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))()
                        },
                        updateFormValues: function() {
                            var e = this;
                            return m(c().mark((function t() {
                                return c().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.next = 2, e.formatFields(e.formFields);
                                        case 2:
                                            return e.formFields = t.sent, t.next = 5, e.formFields.forEach((function(t) {
                                                e.$set(e.values, t.id, t.value)
                                            }));
                                        case 5:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))()
                        }
                    }
                },
                h = Object(s.a)(p, (function() {
                    var e = this,
                        t = e._self._c;
                    return t("div", {
                        staticClass: "tawk-margin-small-top"
                    }, [t("form", {
                        ref: "tawk-inline-form",
                        attrs: {
                            name: "tawk-inline-form"
                        }
                    }, e._l(e.formFields, (function(r, n) {
                        return t("fieldset", {
                            key: n
                        }, ["text" === r.type ? t("tawk-input", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            attrs: {
                                label: r.label,
                                isRequired: r.isRequired,
                                errorMessage: r.errorMessage,
                                value: e.values[r.id],
                                invalidType: r.invalidType
                            },
                            on: {
                                "update:errorMessage": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error-message": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error": function(t) {
                                    return e.setError(t, r)
                                },
                                "update:invalidType": [function(t) {
                                    return e.setInvalidType(t, r)
                                }, function(t) {
                                    return e.$set(r, "invalidType", t)
                                }],
                                "update:invalid-type": function(t) {
                                    return e.$set(r, "invalidType", t)
                                },
                                input: function(t) {
                                    return e.setValue(t, r)
                                }
                            },
                            model: {
                                value: e.values[r.id],
                                callback: function(t) {
                                    e.$set(e.values, r.id, t)
                                },
                                expression: "values[field.id]"
                            }
                        }) : e._e(), "name" === r.type || "email" === r.type ? t("tawk-input", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            attrs: {
                                validation: r.type,
                                label: r.label,
                                isRequired: r.isRequired,
                                errorMessage: r.errorMessage,
                                value: e.values[r.id],
                                invalidType: r.invalidType,
                                name: "phone" === r.type ? "tel" : r.type
                            },
                            on: {
                                "update:errorMessage": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error-message": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error": function(t) {
                                    return e.setError(t, r)
                                },
                                "update:invalidType": [function(t) {
                                    return e.setInvalidType(t, r)
                                }, function(t) {
                                    return e.$set(r, "invalidType", t)
                                }],
                                "update:invalid-type": function(t) {
                                    return e.$set(r, "invalidType", t)
                                },
                                input: function(t) {
                                    return e.setValue(t, r)
                                }
                            },
                            model: {
                                value: e.values[r.id],
                                callback: function(t) {
                                    e.$set(e.values, r.id, t)
                                },
                                expression: "values[field.id]"
                            }
                        }) : e._e(), "phone" === r.type ? t("tawk-phone-input", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            attrs: {
                                name: "tel",
                                value: e.values[r.id],
                                preSelectCountryCode: e.countryCode,
                                label: r.label,
                                isRequired: r.isRequired,
                                validation: r.type,
                                errorMessage: r.errorMessage,
                                invalidType: r.invalidType,
                                assetPath: e.assetPath
                            },
                            on: {
                                "update:errorMessage": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error-message": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:invalidType": [function(t) {
                                    return e.$set(r, "invalidType", t)
                                }, function(t) {
                                    return e.setInvalidType(t, r)
                                }],
                                "update:invalid-type": function(t) {
                                    return e.$set(r, "invalidType", t)
                                },
                                input: function(t) {
                                    return e.setValue(t, r)
                                },
                                "update:error": function(t) {
                                    return e.setError(t, r)
                                }
                            },
                            model: {
                                value: e.values[r.id],
                                callback: function(t) {
                                    e.$set(e.values, r.id, t)
                                },
                                expression: "values[field.id]"
                            }
                        }) : e._e(), "textarea" === r.type || "message" === r.type ? t("tawk-textarea", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            attrs: {
                                label: r.label,
                                isRequired: r.isRequired,
                                errorMessage: r.errorMessage,
                                value: e.values[r.id],
                                invalidType: r.invalidType
                            },
                            on: {
                                "update:errorMessage": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error-message": function(t) {
                                    return e.$set(r, "errorMessage", t)
                                },
                                "update:error": function(t) {
                                    return e.setError(t, r)
                                },
                                "update:invalidType": [function(t) {
                                    return e.setInvalidType(t, r)
                                }, function(t) {
                                    return e.$set(r, "invalidType", t)
                                }],
                                "update:invalid-type": function(t) {
                                    return e.$set(r, "invalidType", t)
                                },
                                input: function(t) {
                                    return e.setValue(t, r)
                                }
                            },
                            model: {
                                value: e.values[r.id],
                                callback: function(t) {
                                    e.$set(e.values, r.id, t)
                                },
                                expression: "values[field.id]"
                            }
                        }) : e._e(), "radio" === r.type ? t("tawk-radio", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            attrs: {
                                label: r.label,
                                options: r.selections,
                                isRequired: r.isRequired,
                                errorMessage: r.errorMessage
                            },
                            on: {
                                input: function(t) {
                                    return e.setValue(t, r)
                                }
                            }
                        }) : e._e(), "checkbox" === r.type ? t("tawk-checkbox", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            attrs: {
                                label: r.label,
                                value: r.value,
                                options: r.selections,
                                isRequired: r.isRequired,
                                errorMessage: r.errorMessage
                            }
                        }) : e._e(), "dropdown" === r.type ? t("select", {
                            ref: r.id,
                            refInFor: !0,
                            staticClass: "tawk-select tawk-margin-xsmall-top tawk-margin-xsmall-bottom",
                            on: {
                                input: function(t) {
                                    return e.setValue(t.target.value, r)
                                }
                            }
                        }, [r.label ? t("option", {
                            attrs: {
                                selected: "",
                                disabled: ""
                            }
                        }, [e._v(" " + e._s(r.label) + " ")]) : e._e(), e._l(r.selections, (function(r, n) {
                            return t("option", {
                                key: n,
                                domProps: {
                                    value: r.label
                                }
                            }, [e._v(" " + e._s(r.label) + " ")])
                        }))], 2) : e._e()], 1)
                    })), 0), e.submissionError ? t("p", {
                        staticClass: "tawk-margin-xsmall tawk-text-red-1 tawk-text-regular-1"
                    }, [e._v(" " + e._s(e.submissionError) + " ")]) : e._e(), t("tawk-button", {
                        attrs: {
                            label: e.$i18n("form", "submit_button"),
                            disabled: e.isSubmitting
                        },
                        on: {
                            click: e.submitForm
                        }
                    }, [e.isSubmitting ? t("div", {
                        staticClass: "tawk-flex tawk-flex-center"
                    }, [t("div", {
                        staticClass: "tawk-spinner-loader"
                    })]) : [t("tawk-icon", {
                        attrs: {
                            type: "send"
                        }
                    }), e._v(" " + e._s(e.$i18n("form", "submit_button")) + " ")]], 2)], 1)
                }), [], !1, null, null, null).exports,
                v = r("bdd0"),
                g = r("5868");

            function y(e) {
                return (y = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function b() {
                b = function() {
                    return t
                };
                var e, t = {},
                    r = Object.prototype,
                    n = r.hasOwnProperty,
                    i = Object.defineProperty || function(e, t, r) {
                        e[t] = r.value
                    },
                    a = "function" == typeof Symbol ? Symbol : {},
                    s = a.iterator || "@@iterator",
                    o = a.asyncIterator || "@@asyncIterator",
                    l = a.toStringTag || "@@toStringTag";

                function c(e, t, r) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }
                try {
                    c({}, "")
                } catch (e) {
                    c = function(e, t, r) {
                        return e[t] = r
                    }
                }

                function u(e, t, r, n) {
                    var a = t && t.prototype instanceof v ? t : v,
                        s = Object.create(a.prototype),
                        o = new O(n || []);
                    return i(s, "_invoke", {
                        value: E(e, r, o)
                    }), s
                }

                function m(e, t, r) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, r)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }
                t.wrap = u;
                var d = "suspendedStart",
                    f = "executing",
                    p = "completed",
                    h = {};

                function v() {}

                function g() {}

                function k() {}
                var w = {};
                c(w, s, (function() {
                    return this
                }));
                var T = Object.getPrototypeOf,
                    x = T && T(T(C([])));
                x && x !== r && n.call(x, s) && (w = x);
                var F = k.prototype = v.prototype = Object.create(w);

                function _(e) {
                    ["next", "throw", "return"].forEach((function(t) {
                        c(e, t, (function(e) {
                            return this._invoke(t, e)
                        }))
                    }))
                }

                function $(e, t) {
                    function r(i, a, s, o) {
                        var l = m(e[i], e, a);
                        if ("throw" !== l.type) {
                            var c = l.arg,
                                u = c.value;
                            return u && "object" == y(u) && n.call(u, "__await") ? t.resolve(u.__await).then((function(e) {
                                r("next", e, s, o)
                            }), (function(e) {
                                r("throw", e, s, o)
                            })) : t.resolve(u).then((function(e) {
                                c.value = e, s(c)
                            }), (function(e) {
                                return r("throw", e, s, o)
                            }))
                        }
                        o(l.arg)
                    }
                    var a;
                    i(this, "_invoke", {
                        value: function(e, n) {
                            function i() {
                                return new t((function(t, i) {
                                    r(e, n, t, i)
                                }))
                            }
                            return a = a ? a.then(i, i) : i()
                        }
                    })
                }

                function E(t, r, n) {
                    var i = d;
                    return function(a, s) {
                        if (i === f) throw Error("Generator is already running");
                        if (i === p) {
                            if ("throw" === a) throw s;
                            return {
                                value: e,
                                done: !0
                            }
                        }
                        for (n.method = a, n.arg = s;;) {
                            var o = n.delegate;
                            if (o) {
                                var l = I(o, n);
                                if (l) {
                                    if (l === h) continue;
                                    return l
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if (i === d) throw i = p, n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            i = f;
                            var c = m(t, r, n);
                            if ("normal" === c.type) {
                                if (i = n.done ? p : "suspendedYield", c.arg === h) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (i = p, n.method = "throw", n.arg = c.arg)
                        }
                    }
                }

                function I(t, r) {
                    var n = r.method,
                        i = t.iterator[n];
                    if (i === e) return r.delegate = null, "throw" === n && t.iterator.return && (r.method = "return", r.arg = e, I(t, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), h;
                    var a = m(i, t.iterator, r.arg);
                    if ("throw" === a.type) return r.method = "throw", r.arg = a.arg, r.delegate = null, h;
                    var s = a.arg;
                    return s ? s.done ? (r[t.resultName] = s.value, r.next = t.nextLoc, "return" !== r.method && (r.method = "next", r.arg = e), r.delegate = null, h) : s : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, h)
                }

                function S(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function j(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function O(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(S, this), this.reset(!0)
                }

                function C(t) {
                    if (t || "" === t) {
                        var r = t[s];
                        if (r) return r.call(t);
                        if ("function" == typeof t.next) return t;
                        if (!isNaN(t.length)) {
                            var i = -1,
                                a = function r() {
                                    for (; ++i < t.length;)
                                        if (n.call(t, i)) return r.value = t[i], r.done = !1, r;
                                    return r.value = e, r.done = !0, r
                                };
                            return a.next = a
                        }
                    }
                    throw new TypeError(y(t) + " is not iterable")
                }
                return g.prototype = k, i(F, "constructor", {
                    value: k,
                    configurable: !0
                }), i(k, "constructor", {
                    value: g,
                    configurable: !0
                }), g.displayName = c(k, l, "GeneratorFunction"), t.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === g || "GeneratorFunction" === (t.displayName || t.name))
                }, t.mark = function(e) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(e, k) : (e.__proto__ = k, c(e, l, "GeneratorFunction")), e.prototype = Object.create(F), e
                }, t.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, _($.prototype), c($.prototype, o, (function() {
                    return this
                })), t.AsyncIterator = $, t.async = function(e, r, n, i, a) {
                    void 0 === a && (a = Promise);
                    var s = new $(u(e, r, n, i), a);
                    return t.isGeneratorFunction(r) ? s : s.next().then((function(e) {
                        return e.done ? e.value : s.next()
                    }))
                }, _(F), c(F, l, "Generator"), c(F, s, (function() {
                    return this
                })), c(F, "toString", (function() {
                    return "[object Generator]"
                })), t.keys = function(e) {
                    var t = Object(e),
                        r = [];
                    for (var n in t) r.push(n);
                    return r.reverse(),
                        function e() {
                            for (; r.length;) {
                                var n = r.pop();
                                if (n in t) return e.value = n, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, t.values = C, O.prototype = {
                    constructor: O,
                    reset: function(t) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(j), !t)
                            for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = e)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(t) {
                        if (this.done) throw t;
                        var r = this;

                        function i(n, i) {
                            return o.type = "throw", o.arg = t, r.next = n, i && (r.method = "next", r.arg = e), !!i
                        }
                        for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                            var s = this.tryEntries[a],
                                o = s.completion;
                            if ("root" === s.tryLoc) return i("end");
                            if (s.tryLoc <= this.prev) {
                                var l = n.call(s, "catchLoc"),
                                    c = n.call(s, "finallyLoc");
                                if (l && c) {
                                    if (this.prev < s.catchLoc) return i(s.catchLoc, !0);
                                    if (this.prev < s.finallyLoc) return i(s.finallyLoc)
                                } else if (l) {
                                    if (this.prev < s.catchLoc) return i(s.catchLoc, !0)
                                } else {
                                    if (!c) throw Error("try statement without catch or finally");
                                    if (this.prev < s.finallyLoc) return i(s.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                            var i = this.tryEntries[r];
                            if (i.tryLoc <= this.prev && n.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                                var a = i;
                                break
                            }
                        }
                        a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                        var s = a ? a.completion : {};
                        return s.type = e, s.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, h) : this.complete(s)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), h
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.finallyLoc === e) return this.complete(r.completion, r.afterLoc), j(r), h
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var r = this.tryEntries[t];
                            if (r.tryLoc === e) {
                                var n = r.completion;
                                if ("throw" === n.type) {
                                    var i = n.arg;
                                    j(r)
                                }
                                return i
                            }
                        }
                        throw Error("illegal catch attempt")
                    },
                    delegateYield: function(t, r, n) {
                        return this.delegate = {
                            iterator: C(t),
                            resultName: r,
                            nextLoc: n
                        }, "next" === this.method && (this.arg = e), h
                    }
                }, t
            }

            function k(e, t, r, n, i, a, s) {
                try {
                    var o = e[a](s),
                        l = o.value
                } catch (e) {
                    return void r(e)
                }
                o.done ? t(l) : Promise.resolve(l).then(n, i)
            }

            function w(e) {
                return function() {
                    var t = this,
                        r = arguments;
                    return new Promise((function(n, i) {
                        var a = e.apply(t, r);

                        function s(e) {
                            k(a, n, i, s, o, "next", e)
                        }

                        function o(e) {
                            k(a, n, i, s, o, "throw", e)
                        }
                        s(void 0)
                    }))
                }
            }

            function T(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function x(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? T(Object(r), !0).forEach((function(t) {
                        F(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : T(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function F(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != y(e) || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != y(n)) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == y(t) ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var _ = {
                    name: "chat-body-messsage-bubble",
                    components: {
                        TawkCard: i.TawkCard,
                        TawkSpinner: o,
                        TawkAlert: i.TawkAlert,
                        TawkEmoji: i.TawkEmoji,
                        TawkIcon: i.TawkIcon,
                        TawkButton: i.TawkButton,
                        TawkChatBubble: i.TawkChatBubble,
                        TawkInput: i.TawkInput,
                        TawkPhoneInput: i.TawkPhoneInput,
                        TawkTextarea: i.TawkTextarea,
                        TawkTimeago: i.TawkTimeago,
                        TawkInlineForm: h
                    },
                    data: function() {
                        return {
                            ticketForm: {
                                name: "",
                                email: "",
                                phone: "",
                                subject: "",
                                message: "",
                                referenceId: this.msg.ticketFormRef,
                                isSubmitting: !1,
                                submissionError: null,
                                submissionSuccess: !1,
                                invalid: {
                                    name: null,
                                    email: null,
                                    phone: null,
                                    subject: null,
                                    message: null
                                }
                            },
                            leadForm: {
                                name: "",
                                email: "",
                                phone: "",
                                message: "",
                                referenceId: this.msg.leadFormRef,
                                isSubmitting: !1,
                                submissionError: null,
                                submissionSuccess: !1,
                                invalid: {
                                    name: null,
                                    email: null,
                                    phone: null,
                                    message: null
                                }
                            },
                            assetPath: "https://embed.tawk.to/_s/v4/assets"
                        }
                    },
                    props: {
                        msg: {
                            type: Object,
                            required: !0
                        },
                        barMessageRerence: {
                            type: String,
                            default: null
                        },
                        emojiEnabled: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    mounted: function() {
                        this.ticketForm.name = this.name, this.ticketForm.email = this.email, this.leadForm.name = this.name, this.leadForm.email = this.email
                    },
                    watch: {
                        name: function(e, t) {
                            e !== t && (this.ticketForm.name = e, this.leadForm.name = e)
                        },
                        email: function(e, t) {
                            e !== t && (this.ticketForm.email = e, this.leadForm.email = e)
                        }
                    },
                    computed: x(x({}, Object(n.c)({
                        name: "visitor/name",
                        email: "visitor/getEmailValue",
                        formRefs: "chat/formRefs",
                        propertyId: "property/id",
                        widgetId: "widget/id",
                        os: "browserData/os",
                        forms: "form/forms",
                        countryCode: "session/countryCode"
                    })), {}, {
                        getTicketImageUrl: function() {
                            return "".concat("https://embed.tawk.to/_s/v4/assets", "/images/ticket-submit-success.svg")
                        },
                        hasTicketFormSubmit: function() {
                            return !!this.msg.ticketFormRef && this.formRefs[this.msg.ticketFormRef]
                        },
                        hasLeadFormSubmit: function() {
                            return !!this.msg.leadFormRef && this.formRefs[this.msg.leadFormRef]
                        },
                        getLeadForm: function() {
                            var e;
                            if (this.msg.leadFormRef) {
                                var t = this.forms.find((function(e) {
                                    return "lead-capture-form" === e.formId
                                }));
                                return (null == t || null === (e = t.content) || void 0 === e ? void 0 : e.fields) || []
                            }
                        }
                    }),
                    methods: {
                        updateInvalidType: function(e, t) {
                            e && e.length > 0 && (this.ticketForm.invalid[t] = e)
                        },
                        validatePhoneField: function() {
                            var e = this.ticketForm.phone;
                            if (e && e.trim().length > 0) {
                                var t = e.replace(/[\s\-()]/g, ""),
                                    r = /^[1-9]\d{1,14}$/.test(t) && t.length >= 8;
                                this.ticketForm.invalid.phone = r ? "" : "phone"
                            } else this.ticketForm.invalid.phone = ""
                        },
                        handlePhoneInput: function(e) {
                            var t = e;
                            if (t && t.trim().length > 0) {
                                var r = t.replace(/[\s\-()]/g, ""),
                                    n = /^[1-9]\d{1,14}$/.test(r) && r.length >= 8;
                                this.ticketForm.invalid.phone = n ? "" : "phone"
                            } else this.ticketForm.invalid.phone = ""
                        },
                        handleAttachmentProps: function(e) {
                            return w(b().mark((function t() {
                                var r, n;
                                return b().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return r = e.fileType, n = {}, t.next = 4, e.attachments.forEach((function(t) {
                                                "image" === t.type ? n.images.push({
                                                    source: t.fileLink,
                                                    name: t.fileName
                                                }) : "video" === r ? n.videos.push({
                                                    name: e.fileName,
                                                    source: "selfhosted",
                                                    url: e.fileLink,
                                                    options: {
                                                        controls: "",
                                                        mute: !0,
                                                        loop: !1,
                                                        startTime: "0"
                                                    },
                                                    size: e.humanizeFileSize
                                                }) : "audio" === r ? n.audios.push({
                                                    source: e.fileLink,
                                                    type: e.data.file.mimetype,
                                                    name: e.fileName,
                                                    size: e.humanizeFileSize
                                                }) : n.files.push({
                                                    source: e.fileLink,
                                                    name: e.fileName,
                                                    size: e.humanizeFileSize
                                                })
                                            }));
                                        case 4:
                                            return t.abrupt("return", n);
                                        case 5:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))()
                        },
                        sendTicketForm: function() {
                            var e = this;
                            return w(b().mark((function t() {
                                var r, n, i;
                                return b().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            if (e.ticketForm.submissionError = null, e.$refs["ticket-name-input"] && e.$refs["ticket-name-input"].validate(), e.$refs["ticket-email-input"] && e.$refs["ticket-email-input"].validate(), e.$refs["ticket-phone-input"] && e.validatePhoneField(), e.$refs["ticket-subject-input"] && e.$refs["ticket-subject-input"].validate(), e.$refs["ticket-message-input"] && e.$refs["ticket-message-input"].validate(), !(e.ticketForm.invalid.name || e.ticketForm.invalid.email || e.ticketForm.invalid.phone || e.ticketForm.invalid.subject || e.ticketForm.invalid.message)) {
                                                t.next = 8;
                                                break
                                            }
                                            return t.abrupt("return");
                                        case 8:
                                            return e.ticketForm.isSubmitting = !0, t.prev = 9, t.next = 12, e.$store.dispatch("session/checkTokenValidity");
                                        case 12:
                                            t.next = 18;
                                            break;
                                        case 14:
                                            return t.prev = 14, t.t0 = t.catch(9), console.error("[JSAPI/Login]", t.t0), t.abrupt("return");
                                        case 18:
                                            (r = e.$TawkSessionManager.getStoredToken()) && (n = {
                                                "X-Tawk-Token": r
                                            }), i = {
                                                referenceId: e.msg.ticketFormRef,
                                                name: e.ticketForm.name,
                                                email: e.ticketForm.email,
                                                phone: e.ticketForm.phone ? "+".concat(e.ticketForm.phone) : void 0,
                                                subject: e.ticketForm.subject,
                                                message: e.ticketForm.message
                                            }, v.a.post("".concat("https://va.tawk.to", "/v1/ticket/create"), i, n, (function(t, r) {
                                                if (t || r.error) {
                                                    if (e.ticketForm.isSubmitting = !1, r && r.error) {
                                                        if ("InternalServerError" === r.error.code) return void(e.ticketForm.submissionError = "The server is unavailable. Please try again.");
                                                        if ("TooManyRequestsError" === r.error.code) return void(e.ticketForm.submissionError = "You have made too many requests.");
                                                        if ("GoneError" === r.error.code) return void(e.ticketForm.submissionError = "Property is not available");
                                                        if ("NotFoundError" === r.error.code) return void(e.ticketForm.submissionError = "Session not found")
                                                    }
                                                    e.ticketForm.submissionError = "Unable to submit form. Please try again"
                                                } else e.ticketForm.isSubmitting = !1, e.ticketForm.submissionSuccess = !0, e.$store.commit("chat/setFormRefs", {
                                                    id: e.msg.ticketFormRef,
                                                    done: !0
                                                }), e.$nextTick((function() {
                                                    e.$eventBus.$emit("updateScrollPosition")
                                                }))
                                            }), !1, !0);
                                        case 22:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t, null, [
                                    [9, 14]
                                ])
                            })))()
                        },
                        sendLeadForm: function(e) {
                            var t = this;
                            return w(b().mark((function r() {
                                var n, i, a;
                                return b().wrap((function(r) {
                                    for (;;) switch (r.prev = r.next) {
                                        case 0:
                                            return t.leadForm.isSubmitting = !0, t.leadForm.submissionError = null, r.prev = 2, r.next = 5, t.$store.dispatch("session/checkTokenValidity");
                                        case 5:
                                            r.next = 11;
                                            break;
                                        case 7:
                                            return r.prev = 7, r.t0 = r.catch(2), console.error("[JSAPI/Login]", r.t0), r.abrupt("return");
                                        case 11:
                                            (n = t.$TawkSessionManager.getStoredToken()) && (i = {
                                                "X-Tawk-Token": n
                                            }), 0 === (null == (a = x({
                                                referenceId: t.msg.leadFormRef
                                            }, e)) ? void 0 : a.additionalInfo.length) && delete a.additionalInfo, v.a.post("".concat("https://va.tawk.to", "/v1/form/lead-capture/submit"), a, i, (function(e, r) {
                                                if (e || r.error) {
                                                    if (t.leadForm.isSubmitting = !1, r && r.error) {
                                                        if ("BadRequestError" === r.error.code) return void(t.leadForm.submissionError = "Invalid parameters");
                                                        if ("NotFoundError" === r.error.code) return void(t.leadForm.submissionError = "Form reference not found.");
                                                        if ("ConflictError" === r.error.code) return void(t.leadForm.submissionError = "Form already submitted");
                                                        if ("InternalServerError" === r.error.code) return void(t.leadForm.submissionError = "The server is unavailable. Please try again.")
                                                    }
                                                    t.leadForm.submissionError = "Unable to submit form. Please try again"
                                                } else t.leadForm.isSubmitting = !1, t.leadForm.submissionSuccess = !0, t.$store.commit("chat/setFormRefs", {
                                                    id: t.leadForm.referenceId,
                                                    done: !0
                                                }), t.$nextTick((function() {
                                                    t.$eventBus.$emit("updateScrollPosition")
                                                }))
                                            }), !1, !0);
                                        case 16:
                                        case "end":
                                            return r.stop()
                                    }
                                }), r, null, [
                                    [2, 7]
                                ])
                            })))()
                        },
                        handleResendMessage: function(e) {
                            this.$emit("resendMessage", e)
                        },
                        parseMDToHTML: function(e) {
                            try {
                                var t, r = this.$TawkWindow.makeHtml(e);
                                return ((r = r.replace(g.a.regLineBreaks, g.a.br)) instanceof Error || void 0 === r) && this.$TawkLogger.reportError({
                                    error: r,
                                    source: {
                                        name: "views/chat/body/message-bubble.vue",
                                        method: "parseMDToHTML()"
                                    },
                                    data: {
                                        propertyId: this.propertyId,
                                        widgetId: this.widgetId,
                                        os: this.os,
                                        userAgent: null === (t = navigator) || void 0 === t ? void 0 : t.userAgent
                                    }
                                }), r
                            } catch (t) {
                                var n;
                                return this.$TawkLogger.reportError({
                                    error: t,
                                    source: {
                                        name: "views/chat/body/message-bubble.vue",
                                        method: "parseMDToHTML()"
                                    },
                                    data: {
                                        propertyId: this.propertyId,
                                        widgetId: this.widgetId,
                                        os: this.os,
                                        userAgent: null === (n = navigator) || void 0 === n ? void 0 : n.userAgent
                                    }
                                }), e
                            }
                        }
                    }
                },
                $ = Object(s.a)(_, (function() {
                    var e = this,
                        t = e._self._c;
                    return t("div", {
                        ref: e.msg.messageId,
                        staticClass: "tawk-message-bubble",
                        attrs: {
                            id: "messageId-".concat(e.msg.messageId)
                        }
                    }, [e.msg.showBar && e.barMessageRerence ? t("div", {
                        staticStyle: {
                            position: "relative"
                        }
                    }, [t("div", [t("span", {
                        staticStyle: {
                            position: "absolute",
                            right: "0",
                            background: "#fff",
                            transform: "translate(0, -50%)",
                            padding: "0 10px"
                        }
                    }, [e._v(e._s(e.$i18n("chat", "new_messages")))]), t("hr")])]) : e._e(), "c" === e.msg.type ? [t("div", {
                        staticClass: "tawk-flex tawk-flex-middle",
                        class: ["v" == e.msg.senderType ? "tawk-visitor-chat" : "tawk-agent-chat"],
                        on: {
                            mouseenter: function(t) {
                                return e.$emit("onMouseEnter")
                            }
                        }
                    }, ["v" === e.msg.senderType ? t("div", {
                        staticClass: "tawk-flex-none",
                        staticStyle: {
                            "min-width": "40px"
                        }
                    }, [e.msg.time ? t("tawk-timeago", {
                        staticClass: "tawk-time-display",
                        attrs: {
                            datetime: e.msg.time,
                            isLive: !1,
                            timeOnly: !0
                        }
                    }) : e._e()], 1) : e._e(), t("div", {
                        staticClass: "tawk-message-body tawk-margin-xsmall-left",
                        class: ["v" !== e.msg.senderType ? "tawk-margin-xsmall-right" : ""]
                    }, [e.msg.isPending ? t("tawk-spinner", {
                        class: ["v" !== e.msg.senderType ? "lds-spinner-left" : ""]
                    }) : e._e(), [e.msg.rawMessage.md && e.msg.rawMessage.md.rt ? t("div", {
                        staticClass: "tawk-chat-rating"
                    }, [t("tawk-icon", {
                        attrs: {
                            type: e.msg.message,
                            size: "xxlarge"
                        }
                    })], 1) : e.msg.attchs || e.msg.message ? t("tawk-chat-bubble", {
                        class: ["v" === e.msg.senderType ? "tawk-visitor-chat-bubble" : "tawk-agent-chat-bubble", "tawk-text-regular-4"],
                        attrs: {
                            attachments: e.msg.attchs,
                            time: e.msg.time
                        }
                    }, [e.msg.message ? t("tawk-emoji", {
                        attrs: {
                            emoji: e.parseMDToHTML(e.msg.message),
                            enabled: e.emojiEnabled
                        }
                    }) : e._e()], 1) : e._e(), "v" !== e.msg.senderType && e.msg.ticketFormRef ? t("div", [e.hasTicketFormSubmit || e.ticketForm.submissionSuccess ? [t("div", {
                        staticClass: "tawk-chat-alert"
                    }, [t("div", {
                        staticClass: "tawk-chat-alert-content"
                    }, [t("p", {
                        staticClass: "tawk-text-regular-2"
                    }, [e._v(e._s(e.$i18n("form", "ticket_form_success_message")))]), t("tawk-timeago", {
                        staticClass: "tawk-margin-xsmall-top",
                        attrs: {
                            datetime: e.msg.time,
                            isLive: !0,
                            isDuration: !0,
                            timeOnly: !0
                        }
                    })], 1)])] : [t("tawk-input", {
                        ref: "ticket-name-input",
                        staticClass: "tawk-margin-small-top tawk-margin-small-bottom",
                        attrs: {
                            label: e.$i18n("form", "name"),
                            isRequired: !0,
                            value: e.ticketForm.name,
                            invalidType: e.ticketForm.invalid.name,
                            errorMessage: {
                                required: e.$i18n("form", "required_error_message")
                            }
                        },
                        on: {
                            "update:invalidType": function(t) {
                                return e.$set(e.ticketForm.invalid, "name", t)
                            },
                            "update:invalid-type": function(t) {
                                return e.$set(e.ticketForm.invalid, "name", t)
                            }
                        },
                        model: {
                            value: e.ticketForm.name,
                            callback: function(t) {
                                e.$set(e.ticketForm, "name", t)
                            },
                            expression: "ticketForm.name"
                        }
                    }), t("tawk-input", {
                        ref: "ticket-email-input",
                        staticClass: "tawk-margin-small",
                        attrs: {
                            label: e.$i18n("form", "email"),
                            isRequired: !0,
                            value: e.ticketForm.email,
                            invalidType: e.ticketForm.invalid.email,
                            errorMessage: {
                                required: e.$i18n("form", "required_error_message"),
                                email: e.$i18n("form", "email_error_message")
                            }
                        },
                        on: {
                            "update:invalidType": function(t) {
                                return e.$set(e.ticketForm.invalid, "email", t)
                            },
                            "update:invalid-type": function(t) {
                                return e.$set(e.ticketForm.invalid, "email", t)
                            }
                        },
                        model: {
                            value: e.ticketForm.email,
                            callback: function(t) {
                                e.$set(e.ticketForm, "email", t)
                            },
                            expression: "ticketForm.email"
                        }
                    }), t("tawk-phone-input", {
                        ref: "ticket-phone-input",
                        staticClass: "tawk-margin-small",
                        attrs: {
                            label: e.$i18n("form", "phone"),
                            isRequired: !1,
                            value: e.ticketForm.phone,
                            preSelectCountryCode: e.countryCode,
                            invalidType: e.ticketForm.invalid.phone,
                            errorMessage: {
                                required: e.$i18n("form", "required_error_message"),
                                phone: e.$i18n("form", "phone_error_message")
                            },
                            assetPath: e.assetPath
                        },
                        on: {
                            "update:invalidType": [function(t) {
                                return e.$set(e.ticketForm.invalid, "phone", t)
                            }, function(t) {
                                return e.updateInvalidType(t, "phone")
                            }],
                            "update:invalid-type": function(t) {
                                return e.$set(e.ticketForm.invalid, "phone", t)
                            },
                            input: e.handlePhoneInput,
                            blur: e.validatePhoneField
                        },
                        model: {
                            value: e.ticketForm.phone,
                            callback: function(t) {
                                e.$set(e.ticketForm, "phone", t)
                            },
                            expression: "ticketForm.phone"
                        }
                    }), t("tawk-input", {
                        ref: "ticket-subject-input",
                        staticClass: "tawk-margin-small",
                        attrs: {
                            label: e.$i18n("form", "subject"),
                            isRequired: !0,
                            value: e.ticketForm.subject,
                            invalidType: e.ticketForm.invalid.subject,
                            errorMessage: {
                                required: e.$i18n("form", "required_error_message")
                            }
                        },
                        on: {
                            "update:invalidType": function(t) {
                                return e.$set(e.ticketForm.invalid, "subject", t)
                            },
                            "update:invalid-type": function(t) {
                                return e.$set(e.ticketForm.invalid, "subject", t)
                            }
                        },
                        model: {
                            value: e.ticketForm.subject,
                            callback: function(t) {
                                e.$set(e.ticketForm, "subject", t)
                            },
                            expression: "ticketForm.subject"
                        }
                    }), t("tawk-textarea", {
                        ref: "ticket-message-input",
                        staticClass: "tawk-margin-small",
                        attrs: {
                            label: e.$i18n("form", "message"),
                            isRequired: !0,
                            value: e.ticketForm.message,
                            invalidType: e.ticketForm.invalid.message,
                            errorMessage: {
                                required: e.$i18n("form", "required_error_message")
                            }
                        },
                        on: {
                            "update:invalidType": function(t) {
                                return e.$set(e.ticketForm.invalid, "message", t)
                            },
                            "update:invalid-type": function(t) {
                                return e.$set(e.ticketForm.invalid, "message", t)
                            }
                        },
                        model: {
                            value: e.ticketForm.message,
                            callback: function(t) {
                                e.$set(e.ticketForm, "message", t)
                            },
                            expression: "ticketForm.message"
                        }
                    }), e.ticketForm.submissionError ? t("p", {
                        staticClass: "tawk-margin-xsmall tawk-text-red-1 tawk-text-regular-1"
                    }, [e._v(e._s(e.ticketForm.submissionError))]) : e._e(), t("tawk-button", {
                        attrs: {
                            label: e.$i18n("form", "submit_button"),
                            disabled: e.ticketForm.isSubmitting
                        },
                        on: {
                            click: function(t) {
                                return e.sendTicketForm()
                            }
                        }
                    }, [e.ticketForm.isSubmitting ? t("div", {
                        staticClass: "tawk-flex tawk-flex-center"
                    }, [t("div", {
                        staticClass: "tawk-spinner-loader"
                    })]) : [t("tawk-icon", {
                        attrs: {
                            type: "send"
                        }
                    }), e._v(" " + e._s(e.$i18n("form", "submit_button")) + " ")]], 2)]], 2) : e._e(), "v" !== e.msg.senderType && e.msg.leadFormRef ? t("div", [e.hasLeadFormSubmit || e.leadForm.submissionSuccess ? [t("div", {
                        staticClass: "tawk-chat-alert"
                    }, [t("div", {
                        staticClass: "tawk-chat-alert-content"
                    }, [t("p", {
                        staticClass: "tawk-text-regular-2"
                    }, [e._v(e._s(e.$i18n("form", "lead_form_success_message")))]), t("tawk-timeago", {
                        staticClass: "tawk-margin-xsmall-top",
                        attrs: {
                            datetime: e.msg.time,
                            isLive: !0,
                            isDuration: !0,
                            timeOnly: !0
                        }
                    })], 1)])] : [e.getLeadForm.length ? t("tawk-inline-form", {
                        attrs: {
                            form: e.getLeadForm,
                            isSubmitting: e.leadForm.isSubmitting,
                            submissionError: e.leadForm.submissionError
                        },
                        on: {
                            "update:submissionError": function(t) {
                                return e.$set(e.leadForm, "submissionError", t)
                            },
                            "update:submission-error": function(t) {
                                return e.$set(e.leadForm, "submissionError", t)
                            },
                            submit: e.sendLeadForm
                        }
                    }) : e._e()]], 2) : e._e()]], 2), "v" !== e.msg.senderType ? t("div", {
                        staticClass: "tawk-flex-none",
                        staticStyle: {
                            "min-width": "40px"
                        }
                    }, [e.msg.time ? t("tawk-timeago", {
                        staticClass: "tawk-time-display",
                        attrs: {
                            datetime: e.msg.time,
                            isLive: !1,
                            timeOnly: !0
                        }
                    }) : e._e()], 1) : e._e()]), e.msg.sendFailed ? t("div", {
                        staticClass: "tawk-chat-resend"
                    }, [t("p", [t("tawk-icon", {
                        attrs: {
                            type: "close-circle",
                            size: "small"
                        }
                    }), t("span", [e._v("Failed")])], 1), t("tawk-button", {
                        attrs: {
                            label: e.$i18n("chat", "resend"),
                            isText: !0
                        },
                        on: {
                            click: function(t) {
                                return e.handleResendMessage(e.msg)
                            }
                        }
                    }, [e._v(" Resend ")])], 1) : e._e()] : e._e(), "v" === e.msg.senderType && "n" === e.msg.type ? t("div", [t("tawk-card", {
                        attrs: {
                            color: "inverse",
                            size: "xsmall"
                        }
                    }, [t("tawk-alert", {
                        attrs: {
                            title: e.msg.message,
                            description: "",
                            icon: "alert"
                        }
                    }, [t("tawk-timeago", {
                        staticClass: "tawk-time-display",
                        attrs: {
                            slot: "alert-description",
                            datetime: e.msg.time,
                            isLive: !1,
                            timeOnly: !0
                        },
                        slot: "alert-description"
                    })], 1)], 1)], 1) : e._e(), t("div", {
                        staticClass: "clearfix"
                    })], 2)
                }), [], !1, null, null, null).exports,
                E = r("2966");

            function I(e) {
                return (I = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function S(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function j(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? S(Object(r), !0).forEach((function(t) {
                        O(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : S(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function O(e, t, r) {
                return (t = function(e) {
                    var t = function(e, t) {
                        if ("object" != I(e) || !e) return e;
                        var r = e[Symbol.toPrimitive];
                        if (void 0 !== r) {
                            var n = r.call(e, t || "default");
                            if ("object" != I(n)) return n;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return ("string" === t ? String : Number)(e)
                    }(e, "string");
                    return "symbol" == I(t) ? t : t + ""
                }(t)) in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function C(e, t) {
                var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (!r) {
                    if (Array.isArray(e) || (r = function(e, t) {
                            if (e) {
                                if ("string" == typeof e) return P(e, t);
                                var r = {}.toString.call(e).slice(8, -1);
                                return "Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r ? Array.from(e) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? P(e, t) : void 0
                            }
                        }(e)) || t && e && "number" == typeof e.length) {
                        r && (e = r);
                        var n = 0,
                            i = function() {};
                        return {
                            s: i,
                            n: function() {
                                return n >= e.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: e[n++]
                                }
                            },
                            e: function(e) {
                                throw e
                            },
                            f: i
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var a, s = !0,
                    o = !1;
                return {
                    s: function() {
                        r = r.call(e)
                    },
                    n: function() {
                        var e = r.next();
                        return s = e.done, e
                    },
                    e: function(e) {
                        o = !0, a = e
                    },
                    f: function() {
                        try {
                            s || null == r.return || r.return()
                        } finally {
                            if (o) throw a
                        }
                    }
                }
            }

            function P(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
                return n
            }
            var L = {
                    name: "chat-body",
                    props: {
                        isLoading: {
                            type: Boolean,
                            default: !0
                        },
                        messageBlocks: {
                            type: Array,
                            default: function() {
                                return []
                            }
                        },
                        barMessageRerence: {
                            type: String,
                            default: null
                        },
                        isHistory: {
                            type: Boolean,
                            default: !1
                        },
                        emojiEnabled: {
                            type: Boolean,
                            default: !0
                        }
                    },
                    data: function() {
                        return {
                            showSurveryOptions: !0
                        }
                    },
                    components: {
                        TawkAvatar: i.TawkAvatar,
                        TawkIcon: i.TawkIcon,
                        SurveyOptions: E.a,
                        ChatMessageBubble: $
                    },
                    methods: {
                        callStatus: function(e) {
                            return e.isMissed || e.isRejected ? "danger" : "success"
                        },
                        callTitle: function(e) {
                            return e.isDone ? e.isRejected ? this.$i18n("chat", "rejected_call") : e.isMissed ? this.$i18n("chat", "missed_" + ("v" === e.caller.t ? "agent" : "visitor")) : this.$i18n("chat", "completed_call") : this.$i18n("chat", "ongoing_call")
                        },
                        callDescription: function(e) {
                            var t = new Date(e.startedAt),
                                r = t.getHours(),
                                n = t.getMinutes();
                            if (e.isDone) {
                                if (r < 10 && (r = "0" + r), n < 10 && (n = "0" + n), e.isRejected || e.isMissed) return this.$i18n("chat", "call_started_on", {
                                    startedOn: "".concat(r, ":").concat(n)
                                });
                                var i, a, s, o = 6e4,
                                    l = 60 * o,
                                    c = new Date(e.endedAt).getTime() - new Date(e.startedAt).getTime();
                                return c >= l ? (i = Math.round(c / l), s = "hours") : c >= o ? (i = Math.round(c / o), s = "minutes") : (i = Math.round(c / 1e3), s = "seconds"), a = this.$i18n("chat", s, {
                                    num: i
                                }), this.$i18n("chat", "call_end_details", {
                                    startedOn: "".concat(r, ":").concat(n),
                                    duration: a
                                })
                            }
                            return ""
                        },
                        callIcon: function(e) {
                            return e.isVideo ? "video-call-on" : e.isScreenshare ? "share-screen" : "call"
                        },
                        submitSurvey: function(e) {
                            var t = this;
                            this.isHistory || (this.$TawkChatManager.sendMessage({
                                message: e
                            }), this.showSurveryOptions = !1, this.$nextTick((function() {
                                t.$eventBus.$emit("updateScrollPosition")
                            })))
                        },
                        imageLoaded: function() {
                            this.$emit("imageLoaded", !0)
                        },
                        resendMessage: function(e) {
                            for (var t = 0; t < this.messageBlocks.length; t++) {
                                var r = this.messageBlocks[t];
                                if (r.blockId === e.blockId) {
                                    for (var n = 0; n < r.messages.length; n++)
                                        if (r.messages[n].messageId === e.messageId) {
                                            r.messages.splice(n, 1);
                                            break
                                        }
                                    break
                                }
                            }
                            this.$TawkChatManager.sendMessage({
                                message: e.rawMessage.m,
                                attachments: e.rawMessage.attchs
                            })
                        },
                        getMessageBlockClasses: function(e) {
                            var t = this.messageBlocks.findIndex((function(t) {
                                return t.blockId === e.blockId
                            }));
                            if (t + 1 < this.messageBlocks.length) {
                                var r = this.messageBlocks[t + 1];
                                if ("v" === e.senderType && "a" === r.senderType && 1 === r.messages.length && !this.showSender(r.messages)) return "tawk-flex tawk-flex-bottom tawk-message-block";
                                if ("a" === e.senderType && 1 === e.messages.length && !this.showSender(e.messages)) return "tawk-flex tawk-flex-bottom tawk-message-block"
                            }
                            return "tawk-margin-small-bottom tawk-flex tawk-flex-bottom tawk-message-block"
                        },
                        showSender: function(e) {
                            var t, r = !1,
                                n = C(e);
                            try {
                                for (n.s(); !(t = n.n()).done;) {
                                    var i = t.value;
                                    if (i.message.length || i.attchs) {
                                        r = !0;
                                        break
                                    }
                                }
                            } catch (e) {
                                n.e(e)
                            } finally {
                                n.f()
                            }
                            return r
                        },
                        showSenderName: function(e, t) {
                            var r = t.findIndex((function(t) {
                                return t.messageId === e.messageId
                            }));
                            return 0 === r || t[r - 1].senderType !== e.senderType
                        }
                    },
                    computed: j(j({}, Object(n.c)({
                        agents: "chat/agents",
                        chatTransferData: "chat/chatTransferData"
                    })), {}, {
                        getSurveyOptions: function() {
                            var e = this,
                                t = {};
                            if (this.messageBlocks.length) {
                                var r = this.messageBlocks.length - 1,
                                    n = this.messageBlocks[r];
                                if ("call" !== n.messageType && n.messages.length) {
                                    var i = n.messages.length - 1,
                                        a = n.messages[i];
                                    a.surveyObj && ((t = a.surveyObj).senderType = a.senderType, this.$nextTick((function() {
                                        e.$eventBus.$emit("updateScrollPosition")
                                    })))
                                }
                            }
                            return t
                        }
                    })
                },
                M = Object(s.a)(L, (function() {
                    var e = this,
                        t = e._self._c;
                    return t("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !e.isLoading,
                            expression: "!isLoading"
                        }],
                        ref: "tawk-chat-message-container",
                        staticClass: "tawk-chat-message-container"
                    }, [null !== e.chatTransferData ? t("div", {
                        staticClass: "tawk-chat-inline-alert-wrapper"
                    }, [t("div", {
                        staticClass: "tawk-chat-inline-alert"
                    }, [t("tawk-icon", {
                        attrs: {
                            type: "details",
                            size: "small"
                        }
                    }), t("p", [e._v("You're being transferred.")])], 1)]) : e._e(), t("transition-group", {
                        attrs: {
                            name: "list"
                        }
                    }, e._l(e.messageBlocks, (function(r) {
                        return t("div", {
                            key: r.blockId,
                            ref: r.blockId,
                            refInFor: !0,
                            class: e.getMessageBlockClasses(r),
                            attrs: {
                                id: "blockId-".concat(r.blockId)
                            }
                        }, ["call" === r.messageType ? [r.callData && !r.callData.hasError ? t("div", {
                            staticClass: "tawk-chat-alert tawk-chat-alert-icon tawk-margin-medium-top tawk-margin-small-bottom"
                        }, [t("div", {
                            staticClass: "tawk-chat-alert-floating-icon"
                        }, [t("tawk-icon", {
                            attrs: {
                                type: e.callIcon(r.callData)
                            }
                        })], 1), t("div", {
                            staticClass: "tawk-chat-alert-content"
                        }, [t("p", {
                            staticClass: "tawk-text-regular-3"
                        }, [e._v(" " + e._s(e.callTitle(r.callData)) + " ")]), t("p", {
                            staticClass: "tawk-text-regular-1 tawk-text-grey-2"
                        }, [e._v(" " + e._s(e.callDescription(r.callData)) + " ")])])]) : t("div", {
                            staticClass: "tawk-chat-alert tawk-chat-alert-icon tawk-margin-xlarge-top tawk-margin-small-bottom"
                        }, [t("div", {
                            staticClass: "tawk-chat-alert-floating-icon"
                        }, [t("tawk-icon", {
                            attrs: {
                                type: "call"
                            }
                        })], 1), t("div", {
                            staticClass: "tawk-chat-alert-content"
                        }, [t("p", [e._v(e._s(e.$i18n("chat", "error_title")))]), t("p", [e._v(e._s(e.$i18n("chat", "call_error_load")))])])])] : ["c" === r.messageType && "v" !== r.senderType && e.showSender(r.messages) ? t("tawk-avatar", {
                            staticClass: "tawk-message-profile tawk-flex-none",
                            class: Object.keys(e.agents).length > 1 ? "tawk-margin-bottom" : "",
                            attrs: {
                                size: "small",
                                src: r.profileImage,
                                alt: "".concat(e.$i18n("chat", "agent_profile_image"))
                            }
                        }) : e._e(), t("div", {
                            staticClass: "tawk-message-group tawk-flex-1",
                            class: ["v" === r.senderType ? "tawk-margin-auto-left" : ""]
                        }, [t("div", {
                            staticClass: "tawk-messages"
                        }, e._l(r.messages, (function(n) {
                            return t("div", {
                                key: n.messageId,
                                class: "v" === n.senderType ? "tawk-visitor" : "tawk-agent"
                            }, [e.showSenderName(n, r.messages) && "v" !== n.senderType ? t("p", {
                                staticClass: "tawk-margin-xsmall-left tawk-chat-name-margin tawk-text-regular-2 tawk-text-truncate"
                            }, [e._v(" " + e._s(n.name) + " ")]) : e._e(), n.message && n.message.length || n.ticketFormRef || n.leadFormRef || n.attchs ? t("chat-message-bubble", {
                                attrs: {
                                    msg: n,
                                    emojiEnabled: e.emojiEnabled,
                                    barMessageRerence: e.barMessageRerence
                                },
                                on: {
                                    resendMessage: e.resendMessage
                                }
                            }) : e._e()], 1)
                        })), 0)])]], 2)
                    })), 0), !e.isHistory && Object.keys(e.getSurveyOptions).length && "v" !== e.getSurveyOptions.senderType ? t("div", {
                        staticClass: "tawk-margin-top tawk-margin-small-bottom tawk-flex tawk-flex-bottom tawk-message-block"
                    }, [t("div", {
                        staticClass: "tawk-message-group tawk-flex-1 tawk-margin-auto-left"
                    }, [t("div", {
                        staticClass: "tawk-message-bubble"
                    }, [t("survey-options", {
                        attrs: {
                            options: e.getSurveyOptions.options
                        },
                        on: {
                            selectSurvey: e.submitSurvey
                        }
                    })], 1), t("div", {
                        staticClass: "clearfix"
                    })])]) : e._e()], 1)
                }), [], !1, null, null, null);
            t.a = M.exports
        },
        "3f09": function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return a
            }));
            var n = r("f0b0"),
                i = r("028e"),
                a = {
                    data: function() {
                        return {
                            headerClass: ""
                        }
                    },
                    methods: {
                        displayMessages: function(e) {
                            var t, r = e.message,
                                a = void 0 === r ? {} : r,
                                s = e.isIncoming,
                                o = void 0 !== s && s,
                                l = e.isLive,
                                c = void 0 === l || l,
                                u = this.isScrollBarBottom(),
                                m = c ? this.$store.getters["chat/messageBlocks"] : this.$store.getters["history/messageBlocks"];
                            if (!a.profileImage && a.data && a.data.rsc) {
                                var d = this.$store.getters["chat/agentProfile"](a.data.rsc);
                                if (!d) return;
                                a.profileImage = d.profileImage
                            }
                            if (m.length > 0 && "c" === a.type && ((t = m[m.length - 1]).ownerId === a.ownerId ? (a.blockId = t.blockId, t.messages.push(a)) : t = null), a.timeStamp > this.lastMessageTimestamp && ("v" === a.senderType ? this.$store.dispatch("session/updateVisitorChatSeen", a.timeStamp) : (this.unseenMessages.push(a), "chat" === this.currentRoute && u && !this.isLoading || this.barMessageId || (a.showBar = !0, this.barMessageId = a.messageId, this.barMessageRerence = a))), o && "a" === a.senderType && a.data && a.data.rsc && this.removeAgentIsTyping(a.data.rsc), a.isCallView) {
                                i.a.callStatusUpdate({
                                    clid: a.callId,
                                    f: {}
                                });
                                var f = {
                                    ownerId: a.callId,
                                    callData: a.callData,
                                    messageType: "call",
                                    blockId: n.Helper.generateUUID(),
                                    callId: a.callId
                                };
                                c ? this.$store.dispatch("chat/addMessageBlock", f) : this.$store.dispatch("history/addMessageBlock", f)
                            } else if (!t) {
                                if (void 0 === a.ownerId && "n" === a.type) return;
                                var p = {
                                    ownerId: a.ownerId,
                                    messages: [a],
                                    senderType: a.senderType,
                                    messageType: a.type,
                                    blockId: n.Helper.generateUUID(),
                                    profileImage: a.profileImage
                                };
                                a.blockId = p.blockId, c ? this.$store.dispatch("chat/addMessageBlock", p) : this.$store.dispatch("history/addMessageBlock", p)
                            }
                            o && ("v" === a.senderType || u ? this.scrollToBottom() : this.checkBarPosition())
                        },
                        isScrollBarBottom: function() {
                            var e = this.$refs["tawk-chat-panel"];
                            if (e) {
                                var t = e.offsetHeight + 10;
                                return e.scrollHeight - (e.scrollTop + t) < 30
                            }
                        }
                    }
                }
        },
        e49c: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return a
            }));
            var n = r("f0b0"),
                i = r("7f46"),
                a = {
                    methods: {
                        setError: function(e, t) {
                            t.isError = e
                        },
                        setValue: function(e, t) {
                            t.value = e;
                            var r = t.value || "";
                            "string" == typeof e && (r = e.trim()), ("text" === t.type || "textarea" === t.type) && t.isRequired && r.length > 0 && (t.invalidType = "")
                        },
                        setInvalidType: function(e, t) {
                            t.invalidTypeValue = e, e && e.length > 0 && (t.isError = !0)
                        },
                        isValidE164PhoneNumber: function(e) {
                            var t = e.replace(/[\s\-()]/g, "");
                            return /^[1-9]\d{1,14}$/.test(t) && t.length >= 8
                        },
                        formatFields: function(e) {
                            for (var t = [], r = 0; r < e.length; r++) {
                                var i = e[r],
                                    a = {},
                                    s = "";
                                if (i.required && (a.required = this.$i18n("form", "required_error_message")), i.context && "email" === i.context && (a.email = this.$i18n("form", "email_error_message"), s = this.email), i.context && "name" === i.context && (s = this.name), i.context && "phone" === i.context && (a.phone = this.$i18n("form", "invalid_length"), a.starts_with_zero = this.$i18n("form", "phone_error_message"), a.required = this.$i18n("form", "required_error_message"), a.invalid_length = this.$i18n("form", "incomplete_number"), a.invalid_country_code = this.$i18n("form", "phone_invalid_country_code")), "department" === i.context && this.departments.length) {
                                    for (var o = {
                                            online: [],
                                            offline: []
                                        }, l = 0; l < this.departments.length; l++) {
                                        var c = this.departments[l];
                                        "online" === c.st ? o.online.push({
                                            status: c.st,
                                            text: c.n,
                                            rawText: c.n,
                                            value: c.did
                                        }) : o.offline.push({
                                            status: c.st,
                                            text: c.n,
                                            rawText: c.n,
                                            value: c.did
                                        })
                                    }
                                    for (var u in o) o[u].sort((function(e, t) {
                                        var r = e.text.toUpperCase(),
                                            n = t.text.toUpperCase();
                                        return r < n ? -1 : r > n ? 1 : 0
                                    }));
                                    t.push({
                                        label: i.label,
                                        type: i.context,
                                        isRequired: i.required,
                                        selections: o || [],
                                        id: n.Helper.generateUUID(),
                                        errorMessage: a,
                                        isError: !1,
                                        invalidTypeValue: ""
                                    })
                                } else t.push({
                                    label: i.label,
                                    type: i.context || i.type,
                                    isRequired: i.required,
                                    selections: i.options ? this.formatOptions(i.options, i.type) : null,
                                    value: "checkbox" === i.type ? [] : s,
                                    id: n.Helper.generateUUID(),
                                    errorMessage: a,
                                    invalidTypeValue: ""
                                })
                            }
                            return t
                        },
                        formatOptions: function(e, t) {
                            var r, i = [];
                            "radio" === t && (r = n.Helper.generateUUID());
                            for (var a = 0; a < e.length; a++) {
                                var s = {
                                    value: e[a],
                                    label: e[a],
                                    id: n.Helper.generateUUID(),
                                    name: r
                                };
                                i.push(s)
                            }
                            return i
                        },
                        formatFormData: function() {
                            var e = {},
                                t = !1;
                            e.questions = [];
                            for (var r = 0; r < this.formFields.length; r++) {
                                var n = this.formFields[r],
                                    a = n.value || "";
                                if ("string" == typeof a && (a = a.trim()), "name" === n.type) e.name = a;
                                else if ("email" === n.type) e.email = a;
                                else if ("phone" === n.type && a.length > 0) {
                                    var s = a.replace(/[\s\-()]/g, "");
                                    if (!this.isValidE164PhoneNumber(a) && s.length > 8) {
                                        n.invalidType = "phone", n.isError = !0, t = !0;
                                        continue
                                    }
                                    e.phone = "+".concat(s)
                                } else if ("department" === n.type) {
                                    if (n.isRequired && !this.selectedDepartment) {
                                        if (!n.selections || !n.selections.online.length && !n.selections.offline.length) continue;
                                        n.isError = !0, t = !0;
                                        continue
                                    }
                                    if (n.isError = !1, !this.selectedDepartment) continue;
                                    e.department = this.selectedDepartment.value, e.questions.push({
                                        label: i.a.rawDecode(n.label),
                                        answer: i.a.rawDecode(this.selectedDepartment.rawText)
                                    })
                                }
                                n.isRequired && 0 === a.length && "department" !== n.type && (this.$refs[n.id] && this.$refs[n.id].length && this.$refs[n.id][0] && this.$refs[n.id][0].validate && this.$refs[n.id][0].validate(), t = !0), n.isError ? t = !0 : a && a.length && ("string" == typeof a ? e.questions.push({
                                    label: i.a.rawDecode(n.label),
                                    answer: a
                                }) : e.questions.push({
                                    label: i.a.rawDecode(n.label),
                                    answer: a.join(", ")
                                }))
                            }
                            return {
                                formData: e,
                                hasError: t
                            }
                        },
                        formatInlineFormData: function() {
                            for (var e = {
                                    additionalInfo: []
                                }, t = !1, r = null, n = 0; n < this.formFields.length; n++) {
                                var a = this.formFields[n],
                                    s = a.value || "";
                                if ("string" == typeof s && (s = s.trim()), a.isRequired && 0 === s.length) {
                                    r = this.$i18n("form", "all_required_error_message"), t = !0;
                                    break
                                }
                                if ("name" === a.type) e.name = s.length ? s : void 0;
                                else if ("email" === a.type) e.email = s.length ? s : void 0;
                                else if ("phone" === a.type)
                                    if (s.length > 0) {
                                        var o = s.replace(/[\s\-()]/g, "");
                                        if (!this.isValidE164PhoneNumber(s) && o.length > 8) {
                                            a.invalidType = "phone", a.isError = !0, t = !0, r = this.$i18n("form", "phone_invalid_country_code");
                                            break
                                        }
                                        e.phone = "+".concat(o)
                                    } else e.phone = void 0;
                                else if ("message" === a.type) e.message = s.length ? s : void 0;
                                else {
                                    var l;
                                    null !== (l = s) && void 0 !== l && l.length && "string" == typeof s ? a.value.length && e.additionalInfo.push({
                                        label: i.a.rawDecode(a.label),
                                        type: a.type,
                                        value: s
                                    }) : a.value.length && e.additionalInfo.push({
                                        label: i.a.rawDecode(a.label),
                                        type: a.type,
                                        value: s.join(", ")
                                    })
                                }
                                a.isError && (t = !0)
                            }
                            return {
                                formData: e,
                                error: {
                                    hasError: t,
                                    message: r
                                }
                            }
                        }
                    }
                }
        }
    }
]);
//# sourceMappingURL=twk-chunk-7941cc06.js.map