(function() {
    var n, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        },
        da =
        ca(this),
        p = function(a, b) {
            if (b) a: {
                var c = da;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    p("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.Lg = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.Lg
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("b");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    p("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = da[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && ba(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return fa(aa(this))
                }
            })
        }
        return a
    });
    p("Symbol.asyncIterator", function(a) {
        return a ? a : Symbol("Symbol.asyncIterator")
    });
    var fa = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        ha = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ia;
    if (typeof Object.setPrototypeOf == "function") ia = Object.setPrototypeOf;
    else {
        var ja;
        a: {
            var ka = {
                    a: !0
                },
                la = {};
            try {
                la.__proto__ = ka;
                ja = la.a;
                break a
            } catch (a) {}
            ja = !1
        }
        ia = ja ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError("c`" + a);
            return a
        } : null
    }
    var na = ia,
        q = function(a, b) {
            a.prototype = ha(b.prototype);
            a.prototype.constructor = a;
            if (na) na(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Li = b.prototype
        },
        y = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error("d`" + String(a));
        },
        z = function(a) {
            if (!(a instanceof Array)) {
                a = y(a);
                for (var b,
                        c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        pa = function(a) {
            return oa(a, a)
        },
        oa = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        qa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ra = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) qa(d, e) && (a[e] = d[e])
            }
            return a
        };
    p("Object.assign", function(a) {
        return a || ra
    });
    var sa = function() {
        this.nc = !1;
        this.Va = null;
        this.aa = void 0;
        this.u = 1;
        this.Ea = this.va = 0;
        this.ae = this.fa = null
    };
    sa.prototype.Ja = function() {
        if (this.nc) throw new TypeError("f");
        this.nc = !0
    };
    sa.prototype.wc = function(a) {
        this.aa = a
    };
    sa.prototype.Hc = function(a) {
        this.fa = {
            xf: a,
            Vf: !0
        };
        this.u = this.va || this.Ea
    };
    sa.prototype.return = function(a) {
        this.fa = {
            return: a
        };
        this.u = this.Ea
    };
    var ta = function(a, b, c) {
        a.u = c;
        return {
            value: b
        }
    };
    sa.prototype.Ha = function(a) {
        this.u = a
    };
    var ua = function(a, b, c) {
            a.va = b;
            c != void 0 && (a.Ea = c)
        },
        va = function(a) {
            a.va = 0;
            var b = a.fa.xf;
            a.fa = null;
            return b
        },
        wa = function(a, b, c, d) {
            d ? a.ae[d] = a.fa : a.ae = [a.fa];
            a.va = b || 0;
            a.Ea = c || 0
        },
        xa = function(a, b, c) {
            c = a.ae.splice(c || 0)[0];
            (c = a.fa = a.fa || c) ? c.Vf ? a.u = a.va || a.Ea : c.Ha != void 0 && a.Ea < c.Ha ? (a.u = c.Ha, a.fa = null) : a.u = a.Ea: a.u = b
        };
    sa.prototype.forIn = function(a) {
        return new ya(a)
    };
    var ya = function(a) {
            this.kg = [];
            for (var b in a) this.kg.push(b);
            this.kg.reverse()
        },
        za = function(a) {
            this.A = new sa;
            this.ni = a
        };
    za.prototype.wc = function(a) {
        this.A.Ja();
        if (this.A.Va) return Aa(this, this.A.Va.next, a, this.A.wc);
        this.A.wc(a);
        return Ba(this)
    };
    var Ca = function(a, b) {
        a.A.Ja();
        var c = a.A.Va;
        if (c) return Aa(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.A.return);
        a.A.return(b);
        return Ba(a)
    };
    za.prototype.Hc = function(a) {
        this.A.Ja();
        if (this.A.Va) return Aa(this, this.A.Va["throw"], a, this.A.wc);
        this.A.Hc(a);
        return Ba(this)
    };
    var Aa = function(a, b, c, d) {
            try {
                var e = b.call(a.A.Va, c);
                if (!(e instanceof Object)) throw new TypeError("e`" + e);
                if (!e.done) return a.A.nc = !1, e;
                var f = e.value
            } catch (g) {
                return a.A.Va = null, a.A.Hc(g), Ba(a)
            }
            a.A.Va = null;
            d.call(a.A, f);
            return Ba(a)
        },
        Ba = function(a) {
            for (; a.A.u;) try {
                var b = a.ni(a.A);
                if (b) return a.A.nc = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.A.aa = void 0, a.A.Hc(c)
            }
            a.A.nc = !1;
            if (a.A.fa) {
                b = a.A.fa;
                a.A.fa = null;
                if (b.Vf) throw b.xf;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        },
        Da = function(a) {
            this.next =
                function(b) {
                    return a.wc(b)
                };
            this.throw = function(b) {
                return a.Hc(b)
            };
            this.return = function(b) {
                return Ca(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        },
        Ea = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        },
        Fa = function(a) {
            return Ea(new Da(new za(a)))
        },
        Ga = function(a) {
            this[Symbol.asyncIterator] = function() {
                return this
            };
            this[Symbol.iterator] = function() {
                return a
            };
            this.next = function(b) {
                return Promise.resolve(a.next(b))
            };
            this["throw"] = function(b) {
                return new Promise(function(c, d) {
                    var e = a["throw"];
                    e !== void 0 ? c(e.call(a, b)) : (c = a["return"], c !== void 0 && c.call(a), d(new TypeError("g")))
                })
            };
            a["return"] !== void 0 && (this["return"] = function(b) {
                return Promise.resolve(a["return"](b))
            })
        },
        B = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    p("globalThis", function(a) {
        return a || da
    });
    p("Reflect.setPrototypeOf", function(a) {
        return a ? a : na ? function(b, c) {
            try {
                return na(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    });
    p("Promise", function(a) {
        function b() {
            this.Ka = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.gf = function(g) {
            if (this.Ka == null) {
                this.Ka = [];
                var h = this;
                this.hf(function() {
                    h.ph()
                })
            }
            this.Ka.push(g)
        };
        var d = da.setTimeout;
        b.prototype.hf = function(g) {
            d(g, 0)
        };
        b.prototype.ph = function() {
            for (; this.Ka && this.Ka.length;) {
                var g = this.Ka;
                this.Ka = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.Tg(l)
                    }
                }
            }
            this.Ka = null
        };
        b.prototype.Tg = function(g) {
            this.hf(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.Sb = 0;
            this.Dc = void 0;
            this.Lb = [];
            this.ag = !1;
            var h = this.Td();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.Td = function() {
            function g(l) {
                return function(m) {
                    k || (k = !0, l.call(h, m))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.Ai),
                reject: g(this.De)
            }
        };
        e.prototype.Ai = function(g) {
            if (g === this) this.De(new TypeError("h"));
            else if (g instanceof e) this.Fi(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = g != null;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.zi(g) : this.Af(g)
            }
        };
        e.prototype.zi = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.De(k);
                return
            }
            typeof h == "function" ? this.Gi(h, g) : this.Af(g)
        };
        e.prototype.De = function(g) {
            this.sg(2, g)
        };
        e.prototype.Af = function(g) {
            this.sg(1, g)
        };
        e.prototype.sg = function(g, h) {
            if (this.Sb != 0) throw Error("i`" + g + "`" + h + "`" + this.Sb);
            this.Sb = g;
            this.Dc = h;
            this.Sb === 2 && this.Ci();
            this.qh()
        };
        e.prototype.Ci = function() {
            var g = this;
            d(function() {
                if (g.ei()) {
                    var h = da.console;
                    typeof h !== "undefined" && h.error(g.Dc)
                }
            }, 1)
        };
        e.prototype.ei = function() {
            if (this.ag) return !1;
            var g = da.CustomEvent,
                h = da.Event,
                k = da.dispatchEvent;
            if (typeof k === "undefined") return !0;
            typeof g === "function" ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : typeof h === "function" ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = da.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.Dc;
            return k(g)
        };
        e.prototype.qh = function() {
            if (this.Lb != null) {
                for (var g = 0; g < this.Lb.length; ++g) f.gf(this.Lb[g]);
                this.Lb = null
            }
        };
        var f = new b;
        e.prototype.Fi = function(g) {
            var h =
                this.Td();
            g.Sc(h.resolve, h.reject)
        };
        e.prototype.Gi = function(g, h) {
            var k = this.Td();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(r, t) {
                return typeof r == "function" ? function(w) {
                    try {
                        l(r(w))
                    } catch (v) {
                        m(v)
                    }
                } : t
            }
            var l, m, u = new e(function(r, t) {
                l = r;
                m = t
            });
            this.Sc(k(g, l), k(h, m));
            return u
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.Sc = function(g, h) {
            function k() {
                switch (l.Sb) {
                    case 1:
                        g(l.Dc);
                        break;
                    case 2:
                        h(l.Dc);
                        break;
                    default:
                        throw Error("j`" +
                            l.Sb);
                }
            }
            var l = this;
            this.Lb == null ? f.gf(k) : this.Lb.push(k);
            this.ag = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = y(g), m = l.next(); !m.done; m = l.next()) c(m.value).Sc(h, k)
            })
        };
        e.all = function(g) {
            var h = y(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, m) {
                function u(w) {
                    return function(v) {
                        r[w] = v;
                        t--;
                        t == 0 && l(r)
                    }
                }
                var r = [],
                    t = 0;
                do r.push(void 0), t++, c(k.value).Sc(u(r.length - 1), m), k = h.next(); while (!k.done)
            })
        };
        return e
    });
    p("Object.setPrototypeOf", function(a) {
        return a || na
    });
    p("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    p("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) qa(b, d) && c.push(b[d]);
            return c
        }
    });
    var Ha = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    p("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Ha(this, function(b) {
                return b
            })
        }
    });
    p("WeakMap", function(a) {
        function b() {}

        function c(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function d(k) {
            if (!qa(k, f)) {
                var l = new b;
                ba(k, f, {
                    value: l
                })
            }
        }

        function e(k) {
            var l = Object[k];
            l && (Object[k] = function(m) {
                if (m instanceof b) return m;
                Object.isExtensible(m) && d(m);
                return l(m)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        m = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (m.get(k) != 2 || m.get(l) != 3) return !1;
                    m.delete(k);
                    m.set(l, 4);
                    return !m.has(k) && m.get(l) == 4
                } catch (u) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            h = function(k) {
                this.jc = (g += Math.random() + 1).toString();
                if (k) {
                    k = y(k);
                    for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        h.prototype.set = function(k, l) {
            if (!c(k)) throw Error("k");
            d(k);
            if (!qa(k, f)) throw Error("l`" + k);
            k[f][this.jc] = l;
            return this
        };
        h.prototype.get = function(k) {
            return c(k) && qa(k, f) ? k[f][this.jc] : void 0
        };
        h.prototype.has = function(k) {
            return c(k) && qa(k, f) && qa(k[f], this.jc)
        };
        h.prototype.delete = function(k) {
            return c(k) &&
                qa(k, f) && qa(k[f], this.jc) ? delete k[f][this.jc] : !1
        };
        return h
    });
    p("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(y([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        m = l.next();
                    if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
                    m = l.next();
                    return m.done || m.value[0].x != 4 || m.value[1] != "t" || !l.next().done ? !1 : !0
                } catch (u) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] =
                    f();
                this.size = 0;
                if (h) {
                    h = y(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                Ia: this[1].Ia,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].Ia.next = l.entry, this[1].Ia = l.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.Ia.next =
                h.entry.next, h.entry.next.Ia = h.entry.Ia, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].Ia = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach =
            function(h, k) {
                for (var l = this.entries(), m; !(m = l.next()).done;) m = m.value, h.call(k, m[1], m[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var m = h[0][l];
                if (m && qa(h[0], l))
                    for (h = 0; h < m.length; h++) {
                        var u = m[h];
                        if (k !== k && u.key !== u.key || k === u.key) return {
                            id: l,
                            list: m,
                            index: h,
                            entry: u
                        }
                    }
                return {
                    id: l,
                    list: m,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return fa(function() {
                    if (l) {
                        for (; l.head !=
                            h[1];) l = l.Ia;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.Ia = h.next = h.head = h
            },
            g = 0;
        return c
    });
    p("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(y([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.xa = new Map;
            if (c) {
                c =
                    y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.xa.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.xa.set(c, c);
            this.size = this.xa.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.xa.delete(c);
            this.size = this.xa.size;
            return c
        };
        b.prototype.clear = function() {
            this.xa.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.xa.has(c)
        };
        b.prototype.entries = function() {
            return this.xa.entries()
        };
        b.prototype.values = function() {
            return this.xa.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.xa.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    p("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Ha(this, function(b, c) {
                return [b, c]
            })
        }
    });
    var Ia = function(a, b, c) {
        if (a == null) throw new TypeError("m`" + c);
        if (b instanceof RegExp) throw new TypeError("n`" + c);
        return a + ""
    };
    p("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ia(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    p("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    p("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = Ia(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    });
    p("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    p("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    p("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return Ia(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    p("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) qa(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    p("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    p("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    p("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    p("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    p("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    p("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    p("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    });
    p("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    p("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    p("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Ha(this, function(b, c) {
                return c
            })
        }
    });
    p("Array.prototype.fill", function(a) {
        return a ? a : function(b, c, d) {
            var e = this.length || 0;
            c < 0 && (c = Math.max(0, e + c));
            if (d == null || d > e) d = e;
            d = Number(d);
            d < 0 && (d = Math.max(0, e + d));
            for (c = Number(c || 0); c < d; c++) this[c] = b;
            return this
        }
    });
    var Ja = function(a) {
        return a ? a : Array.prototype.fill
    };
    p("Int8Array.prototype.fill", Ja);
    p("Uint8Array.prototype.fill", Ja);
    p("Uint8ClampedArray.prototype.fill", Ja);
    p("Int16Array.prototype.fill", Ja);
    p("Uint16Array.prototype.fill", Ja);
    p("Int32Array.prototype.fill", Ja);
    p("Uint32Array.prototype.fill", Ja);
    p("Float32Array.prototype.fill", Ja);
    p("Float64Array.prototype.fill", Ja);
    p("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = Ia(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? c.repeat(Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    });
    p("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = b === void 0 ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && b > 0 ? (d = Array.prototype.flat.call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var Ka = this || self,
        Na = function(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = Ka, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        },
        Oa = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        Pa = function(a) {
            var b = Oa(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        Qa = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        Ra = function(a) {
            return a
        },
        Sa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.Li = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.Bj = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
    var Ta = function() {
        this.zg = 0
    };
    Ta.prototype.Tb = function(a, b) {
        var c = this;
        return function() {
            var d = B.apply(0, arguments);
            c.zg = a;
            return b.apply(null, z(d))
        }
    };
    var Ua = function() {
            var a = {};
            this.ya = (a[3] = [], a[2] = [], a[1] = [], a);
            this.qe = !1
        },
        Wa = function(a, b, c) {
            var d = Va(a, c);
            a.ya[c].push(b);
            d && a.ya[c].length === 1 && a.flush()
        },
        Va = function(a, b) {
            return Object.keys(a.ya).map(function(c) {
                return Number(c)
            }).filter(function(c) {
                return !isNaN(c) && c > b
            }).every(function(c) {
                return a.ya[c].length === 0
            })
        };
    Ua.prototype.flush = function() {
        if (!this.qe) {
            this.qe = !0;
            try {
                for (; Object.values(this.ya).some(function(a) {
                        return a.length > 0
                    });) Xa(this, 3), Xa(this, 2), Xa(this, 1)
            } catch (a) {
                throw Object.values(this.ya).forEach(function(b) {
                    return void b.splice(0, b.length)
                }), a;
            } finally {
                this.qe = !1
            }
        }
    };
    var Xa = function(a, b) {
        for (; Va(a, b) && a.ya[b].length > 0;) a.ya[b][0](), a.ya[b].shift()
    };
    da.Object.defineProperties(Ua.prototype, {
        mg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Object.values(this.ya).some(function(a) {
                    return a.length > 0
                })
            }
        }
    });

    function Ya(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var Za = {};
    var ab = globalThis.trustedTypes,
        bb;

    function cb() {
        var a = null;
        if (!ab) return a;
        try {
            var b = function(c) {
                return c
            };
            a = ab.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {
            throw c;
        }
        return a
    };
    var db = function(a) {
        if (Za !== Za) throw Error("o");
        this.jg = a
    };
    db.prototype.toString = function() {
        return this.jg + ""
    };

    function eb(a) {
        var b;
        bb === void 0 && (bb = cb());
        a = (b = bb) ? b.createScriptURL(a) : a;
        return new db(a)
    };
    var fb = pa([""]),
        gb = oa(["\x00"], ["\\0"]),
        hb = oa(["\n"], ["\\n"]),
        ib = oa(["\x00"], ["\\u0000"]),
        lb = pa([""]),
        mb = oa(["\x00"], ["\\0"]),
        nb = oa(["\n"], ["\\n"]),
        ob = oa(["\x00"], ["\\u0000"]);

    function pb(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function qb(a) {
        return a.toString().indexOf("`") === -1
    }
    var rb = qb(function(a) {
            return a(fb)
        }) || qb(function(a) {
            return a(gb)
        }) || qb(function(a) {
            return a(hb)
        }) || qb(function(a) {
            return a(ib)
        }),
        sb = pb(lb) && pb(mb) && pb(nb) && pb(ob);
    var tb = function(a) {
        if (Za !== Za) throw Error("o");
        this.mi = a
    };
    tb.prototype.toString = function() {
        return this.mi
    };
    new tb("about:blank");
    new tb("about:invalid#zClosurez");
    var ub = [],
        vb = function(a) {
            console.warn("q`" + a)
        };
    ub.indexOf(vb) === -1 && ub.push(vb);

    function wb(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, wb);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    Sa(wb, Error);
    wb.prototype.name = "CustomError";
    var xb;

    function yb(a, b) {
        var c = wb.call;
        a = a.split("%s");
        for (var d = "", e = a.length - 1, f = 0; f < e; f++) d += a[f] + (f < b.length ? b[f] : "%s");
        c.call(wb, this, d + a[e])
    }
    Sa(yb, wb);
    yb.prototype.name = "AssertionError";

    function zb(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new yb("" + e, f || []);
    }
    var D = function(a, b, c) {
            a || zb("", null, b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        F = function(a, b, c) {
            a == null && zb("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Bb = function(a, b) {
            throw new yb("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
        },
        Cb = function(a, b, c) {
            typeof a !== "number" && zb("Expected number but got %s: %s.", [Oa(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Db = function(a, b, c) {
            typeof a !== "string" && zb("Expected string but got %s: %s.", [Oa(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Eb = function(a, b, c) {
            typeof a !== "function" && zb("Expected function but got %s: %s.", [Oa(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Fb = function(a, b, c) {
            Qa(a) || zb("Expected object but got %s: %s.", [Oa(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        G = function(a, b, c) {
            Array.isArray(a) || zb("Expected array but got %s: %s.", [Oa(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Hb = function(a, b, c, d) {
            a instanceof b || zb("Expected instanceof %s but got %s.", [Gb(b), Gb(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function Gb(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : a === null ? "null" : typeof a
    };
    var Ib = Array.prototype.forEach ? function(a, b) {
            D(a.length != null);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        Jb = Array.prototype.map ? function(a, b) {
            D(a.length != null);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        },
        Kb = Array.prototype.some ? function(a, b) {
            D(a.length !=
                null);
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };

    function Lb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Mb(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Nb(a, b, c) {
        if (!Pa(a) || !Pa(b) || a.length != b.length) return !1;
        var d = a.length;
        c = c || Ob;
        for (var e = 0; e < d; e++)
            if (!c(a[e], b[e])) return !1;
        return !0
    }

    function Ob(a, b) {
        return a === b
    }

    function Pb(a, b) {
        return Lb.apply([], Jb(a, b))
    };

    function Qb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Rb = function(a, b) {
        this.name = a;
        this.value = b
    };
    Rb.prototype.toString = function() {
        return this.name
    };
    var Sb = new Rb("OFF", Infinity),
        Tb = new Rb("WARNING", 900),
        Ub = new Rb("INFO", 800),
        Vb = new Rb("CONFIG", 700),
        Wb = function() {
            this.Tc = 0;
            this.clear()
        },
        Xb;
    Wb.prototype.clear = function() {
        this.F = Array(this.Tc);
        this.qf = -1;
        this.Wf = !1
    };
    var Yb = function(a, b, c) {
        this.reset(a || Sb, b, c, void 0, void 0)
    };
    Yb.prototype.reset = function(a, b, c, d) {
        d || Date.now();
        this.ci = b
    };
    Yb.prototype.getMessage = function() {
        return this.ci
    };
    var Zb = function(a, b) {
            this.level = null;
            this.zh = [];
            this.parent = (b === void 0 ? null : b) || null;
            this.children = [];
            this.Uh = {
                getName: function() {
                    return a
                }
            }
        },
        $b = function(a) {
            if (a.level) return a.level;
            if (a.parent) return $b(a.parent);
            Bb("Root logger has no level set.");
            return Sb
        },
        ac = function(a, b) {
            for (; a;) a.zh.forEach(function(c) {
                c(b)
            }), a = a.parent
        },
        bc = function() {
            this.entries = {};
            var a = new Zb("");
            a.level = Vb;
            this.entries[""] = a
        },
        cc, dc = function(a, b, c) {
            var d = a.entries[b];
            if (d) return c !== void 0 && (d.level = c), d;
            d = b.lastIndexOf(".");
            d = b.slice(0, Math.max(d, 0));
            d = dc(a, d);
            var e = new Zb(b, d);
            a.entries[b] = e;
            d.children.push(e);
            c !== void 0 && (e.level = c);
            return e
        },
        ec = function() {
            cc || (cc = new bc);
            return cc
        },
        ic = function(a) {
            var b = fc;
            if (b) {
                var c = a,
                    d = Tb;
                if (a = b)
                    if (a = b && d) {
                        a = d.value;
                        var e = b ? $b(dc(ec(), b.getName())) : Sb;
                        a = a >= e.value
                    }
                if (a) {
                    d = d || Sb;
                    a = dc(ec(), b.getName());
                    typeof c === "function" && (c = c());
                    Xb || (Xb = new Wb);
                    e = Xb;
                    b = b.getName();
                    if (e.Tc > 0) {
                        var f = (e.qf + 1) % e.Tc;
                        e.qf = f;
                        e.Wf ? (e = e.F[f], e.reset(d, c, b), b = e) : (e.Wf = f == e.Tc - 1, b = e.F[f] = new Yb(d, c, b))
                    } else b =
                        new Yb(d, c, b);
                    ac(a, b)
                }
            }
        };
    var jc = function() {
        this.names = new Map
    };
    jc.prototype.getName = function(a) {
        var b = this.names.get(a);
        if (b) return b;
        var c;
        b = (c = a.description) != null ? c : Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36);
        this.names.set(a, b);
        return b
    };
    /*


     Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors
     Licensed under the Apache License, Version 2.0 (the "License");
     you may not use this file except in compliance with the License.
     You may obtain a copy of the License at
         http://www.apache.org/licenses/LICENSE-2.0
     Unless required by applicable law or agreed to in writing, software
     distributed under the License is distributed on an "AS IS" BASIS,
     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     See the License for the specific language governing permissions and
     limitations under the License.
    */
    var lc = function(a) {
        var b = Error.call(this, a ? a.length + " errors occurred during unsubscription:\n" + a.map(function(c, d) {
            return d + 1 + ") " + c.toString()
        }).join("\n  ") : "");
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.errors = a;
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "UnsubscriptionError"
    };
    q(lc, Error);

    function mc(a, b) {
        a && (b = a.indexOf(b), 0 <= b && a.splice(b, 1))
    };

    function I(a) {
        return typeof a === "function"
    };
    var nc = function(a) {
        this.Fh = a;
        this.closed = !1;
        this.Vb = this.yb = null
    };
    n = nc.prototype;
    n.unsubscribe = function() {
        if (!this.closed) {
            this.closed = !0;
            var a = this.yb;
            if (Array.isArray(a))
                for (var b = y(a), c = b.next(); !c.done; c = b.next()) c.value.remove(this);
            else a == null || a.remove(this);
            b = this.Fh;
            if (I(b)) try {
                b()
            } catch (f) {
                var d = f instanceof lc ? f.errors : [f]
            }
            var e = this.Vb;
            if (e)
                for (this.Vb = null, b = y(e), c = b.next(); !c.done; c = b.next()) {
                    c = c.value;
                    try {
                        I(c) ? c() : c.unsubscribe()
                    } catch (f) {
                        c = void 0, d = (c = d) != null ? c : [], f instanceof lc ? d = [].concat(z(d), z(f.errors)) : d.push(f)
                    }
                }
            if (d) throw new lc(d);
        }
    };
    n.add = function(a) {
        if (a && a !== this)
            if (this.closed) I(a) ? a() : a.unsubscribe();
            else {
                if (a instanceof nc) {
                    if (a.closed || a.Ng(this)) return;
                    a.Mg(this)
                }
                var b;
                (this.Vb = (b = this.Vb) != null ? b : []).push(a)
            }
    };
    n.Ng = function(a) {
        var b = this.yb;
        return b === a || Array.isArray(b) && b.includes(a)
    };
    n.Mg = function(a) {
        var b = this.yb;
        this.yb = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a
    };
    n.Og = function(a) {
        var b = this.yb;
        b === a ? this.yb = null : Array.isArray(b) && mc(b, a)
    };
    n.remove = function(a) {
        var b = this.Vb;
        b && mc(b, a);
        a instanceof nc && a.Og(this)
    };
    var oc = new nc;
    oc.closed = !0;
    nc.EMPTY = oc;

    function pc(a) {
        return a instanceof nc || a && "closed" in a && I(a.remove) && I(a.add) && I(a.unsubscribe)
    };
    var qc = function() {
        setTimeout.apply(null, z(B.apply(0, arguments)))
    };

    function rc() {};

    function sc(a) {
        qc(function() {
            throw a;
        })
    };
    var tc = function(a) {
        nc.call(this);
        this.R = !1;
        this.destination = a instanceof tc ? a : new uc(!a || I(a) ? {
            next: a != null ? a : void 0
        } : a);
        pc(a) && a.add(this)
    };
    q(tc, nc);
    tc.EMPTY = nc.EMPTY;
    tc.create = function(a, b, c) {
        return new vc(a, b, c)
    };
    n = tc.prototype;
    n.next = function(a) {
        this.R || this.Fd(a)
    };
    n.error = function(a) {
        this.R || (this.R = !0, this.af(a))
    };
    n.complete = function() {
        this.R || (this.R = !0, this.Mc())
    };
    n.unsubscribe = function() {
        this.closed || (this.R = !0, nc.prototype.unsubscribe.call(this))
    };
    n.Fd = function(a) {
        this.destination.next(a)
    };
    n.af = function(a) {
        this.destination.error(a);
        this.unsubscribe()
    };
    n.Mc = function() {
        this.destination.complete();
        this.unsubscribe()
    };
    var uc = function(a) {
        this.ye = a
    };
    uc.prototype.next = function(a) {
        var b = this.ye;
        if (b.next) try {
            b.next(a)
        } catch (c) {
            sc(c)
        }
    };
    uc.prototype.error = function(a) {
        var b = this.ye;
        if (b.error) try {
            b.error(a)
        } catch (c) {
            sc(c)
        } else sc(a)
    };
    uc.prototype.complete = function() {
        var a = this.ye;
        if (a.complete) try {
            a.complete()
        } catch (b) {
            sc(b)
        }
    };
    var vc = function(a, b, c) {
        tc.call(this);
        this.destination = new uc(I(a) || !a ? {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0
        } : a)
    };
    q(vc, tc);
    vc.EMPTY = tc.EMPTY;
    vc.create = tc.create;
    var wc = typeof Symbol === "function" && Symbol.observable || "@@observable";

    function xc(a) {
        return a
    };

    function J() {
        return yc(B.apply(0, arguments))
    }

    function yc(a) {
        return a.length === 0 ? xc : a.length === 1 ? a[0] : function(b) {
            return a.reduce(function(c, d) {
                return d(c)
            }, b)
        }
    };
    var K = function(a) {
        a && (this.Aa = a)
    };
    n = K.prototype;
    n.mb = function(a) {
        var b = new K;
        b.source = this;
        b.operator = a;
        return b
    };
    n.subscribe = function(a, b, c) {
        a = a && a instanceof tc || a && I(a.next) && I(a.error) && I(a.complete) && pc(a) ? a : new vc(a, b, c);
        b = this.operator;
        c = this.source;
        a.add(b ? b.call(a, c) : c ? this.Aa(a) : this.Hd(a));
        return a
    };
    n.Hd = function(a) {
        try {
            return this.Aa(a)
        } catch (b) {
            a.error(b)
        }
    };
    n.forEach = function(a, b) {
        var c = this;
        b = zc(b);
        return new b(function(d, e) {
            var f = c.subscribe(function(g) {
                try {
                    a(g)
                } catch (h) {
                    e(h), f == null || f.unsubscribe()
                }
            }, e, d)
        })
    };
    n.Aa = function(a) {
        var b;
        return (b = this.source) == null ? void 0 : b.subscribe(a)
    };
    K.prototype[wc] = function() {
        return this
    };
    K.prototype.g = function() {
        var a = B.apply(0, arguments);
        return a.length ? yc(a)(this) : this
    };
    K.create = function(a) {
        return new K(a)
    };

    function zc(a) {
        var b;
        return (b = a != null ? a : void 0) != null ? b : Promise
    };
    var Ac = function() {
        var a = Error.call(this, "object unsubscribed");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "ObjectUnsubscribedError"
    };
    q(Ac, Error);
    var L = function() {
        this.Kb = [];
        this.ed = this.R = this.closed = !1;
        this.Le = null
    };
    q(L, K);
    n = L.prototype;
    n.mb = function(a) {
        var b = new Bc(this, this);
        b.operator = a;
        return b
    };
    n.Wa = function() {
        if (this.closed) throw new Ac;
    };
    n.next = function(a) {
        this.Wa();
        if (!this.R) {
            var b = this.Kb.slice();
            b = y(b);
            for (var c = b.next(); !c.done; c = b.next()) c.value.next(a)
        }
    };
    n.error = function(a) {
        this.Wa();
        if (!this.R) {
            this.ed = this.R = !0;
            this.Le = a;
            for (var b = this.Kb; b.length;) b.shift().error(a)
        }
    };
    n.complete = function() {
        this.Wa();
        if (!this.R) {
            this.R = !0;
            for (var a = this.Kb; a.length;) a.shift().complete()
        }
    };
    n.unsubscribe = function() {
        this.R = this.closed = !0;
        this.Kb = null
    };
    n.Hd = function(a) {
        this.Wa();
        return K.prototype.Hd.call(this, a)
    };
    n.Aa = function(a) {
        this.Wa();
        this.Ze(a);
        return this.cf(a)
    };
    n.cf = function(a) {
        var b = this,
            c = this.R,
            d = this.Kb;
        return this.ed || c ? nc.EMPTY : (d.push(a), new nc(function() {
            return mc(b.Kb, a)
        }))
    };
    n.Ze = function(a) {
        var b = this.Le,
            c = this.R;
        this.ed ? a.error(b) : c && a.complete()
    };
    n.S = function() {
        var a = new K;
        a.source = this;
        return a
    };
    L.create = function(a, b) {
        return new Bc(a, b)
    };
    var Bc = function(a, b) {
        L.call(this);
        this.destination = a;
        this.source = b
    };
    q(Bc, L);
    Bc.create = L.create;
    Bc.prototype.next = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.next) == null || c.call(b, a)
    };
    Bc.prototype.error = function(a) {
        var b, c;
        (b = this.destination) == null || (c = b.error) == null || c.call(b, a)
    };
    Bc.prototype.complete = function() {
        var a, b;
        (a = this.destination) == null || (b = a.complete) == null || b.call(a)
    };
    Bc.prototype.Aa = function(a) {
        var b, c;
        return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null ? c : nc.EMPTY
    };
    var Cc = function(a) {
        L.call(this);
        this.Id = a
    };
    q(Cc, L);
    Cc.create = L.create;
    Cc.prototype.Aa = function(a) {
        var b = L.prototype.Aa.call(this, a);
        !b.closed && a.next(this.Id);
        return b
    };
    Cc.prototype.getValue = function() {
        var a = this.Le,
            b = this.Id;
        if (this.ed) throw a;
        this.Wa();
        return b
    };
    Cc.prototype.next = function(a) {
        L.prototype.next.call(this, this.Id = a)
    };
    da.Object.defineProperties(Cc.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.getValue()
            }
        }
    });
    var Ec = new K(function(a) {
        return a.complete()
    });

    function Gc(a, b) {
        return new K(function(c) {
            var d = 0;
            return b.G(function() {
                d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.G())
            })
        })
    };

    function Hc(a, b) {
        if (!a) throw Error("r");
        return new K(function(c) {
            var d = new nc;
            d.add(b.G(function() {
                var e = a[Symbol.asyncIterator]();
                d.add(b.G(function() {
                    var f = this;
                    e.next().then(function(g) {
                        g.done ? c.complete() : (c.next(g.value), f.G())
                    })
                }))
            }));
            return d
        })
    };
    var Ic = typeof Symbol === "function" && Symbol.iterator ? Symbol.iterator : "@@iterator";

    function Jc(a, b, c) {
        b = b.G(function() {
            try {
                c.call(this)
            } catch (d) {
                a.error(d)
            }
        }, 0);
        a.add(b)
    };

    function Kc(a, b) {
        return new K(function(c) {
            var d;
            c.add(b.G(function() {
                d = a[Ic]();
                Jc(c, b, function() {
                    var e = d.next(),
                        f = e.value;
                    e.done ? c.complete() : (c.next(f), this.G())
                })
            }));
            return function() {
                var e;
                return I((e = d) == null ? void 0 : e.return) && d.return()
            }
        })
    };

    function Lc(a, b) {
        return new K(function(c) {
            var d = new nc;
            d.add(b.G(function() {
                var e = a[wc]();
                d.add(e.subscribe({
                    next: function(f) {
                        d.add(b.G(function() {
                            return c.next(f)
                        }))
                    },
                    error: function(f) {
                        d.add(b.G(function() {
                            return c.error(f)
                        }))
                    },
                    complete: function() {
                        d.add(b.G(function() {
                            return c.complete()
                        }))
                    }
                }))
            }));
            return d
        })
    };

    function Mc(a, b) {
        return new K(function(c) {
            return b.G(function() {
                return a.then(function(d) {
                    c.add(b.G(function() {
                        c.next(d);
                        c.add(b.G(function() {
                            return c.complete()
                        }))
                    }))
                }, function(d) {
                    c.add(b.G(function() {
                        return c.error(d)
                    }))
                })
            })
        })
    };
    var Nc = function(a) {
        return a && typeof a.length === "number" && typeof a !== "function"
    };

    function Oc(a) {
        return new TypeError("s`" + (a !== null && typeof a === "object" ? "an invalid object" : "'" + a + "'"))
    };

    function Pc(a, b) {
        if (a != null) {
            if (I(a[wc])) return Lc(a, b);
            if (Nc(a)) return Gc(a, b);
            if (I(a == null ? void 0 : a.then)) return Mc(a, b);
            if (Symbol.asyncIterator && I(a == null ? void 0 : a[Symbol.asyncIterator])) return Hc(a, b);
            if (I(a == null ? void 0 : a[Ic])) return Kc(a, b)
        }
        throw Oc(a);
    };

    function Qc(a, b) {
        return b ? Pc(a, b) : Rc(a)
    }

    function Rc(a) {
        if (a instanceof K) return a;
        if (a != null) {
            if (I(a[wc])) return Sc(a);
            if (Nc(a)) return Tc(a);
            if (I(a == null ? void 0 : a.then)) return Uc(a);
            if (Symbol.asyncIterator && I(a == null ? void 0 : a[Symbol.asyncIterator])) return Vc(a);
            if (I(a == null ? void 0 : a[Ic])) return Wc(a)
        }
        throw Oc(a);
    }

    function Sc(a) {
        return new K(function(b) {
            var c = a[wc]();
            if (I(c.subscribe)) return c.subscribe(b);
            throw new TypeError("t");
        })
    }

    function Tc(a) {
        return new K(function(b) {
            for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
            b.complete()
        })
    }

    function Uc(a) {
        return new K(function(b) {
            a.then(function(c) {
                b.closed || (b.next(c), b.complete())
            }, function(c) {
                return b.error(c)
            }).then(null, sc)
        })
    }

    function Wc(a) {
        return new K(function(b) {
            for (var c = a[Ic](); !b.closed;) {
                var d = c.next(),
                    e = d.value;
                d.done ? b.complete() : b.next(e)
            }
            return function() {
                return I(c == null ? void 0 : c.return) && c.return()
            }
        })
    }

    function Vc(a) {
        return new K(function(b) {
            Xc(a, b).catch(function(c) {
                return b.error(c)
            })
        })
    }

    function Xc(a, b) {
        var c, d, e, f, g, h;
        return Fa(function(k) {
            switch (k.u) {
                case 1:
                    ua(k, 2, 3);
                    var l = a[Symbol.asyncIterator];
                    f = l !== void 0 ? l.call(a) : new Ga(y(a));
                case 5:
                    return ta(k, f.next(), 8);
                case 8:
                    d = k.aa;
                    if (d.done) {
                        k.Ha(3);
                        break
                    }
                    g = d.value;
                    b.next(g);
                    k.Ha(5);
                    break;
                case 3:
                    wa(k);
                    k.va = 0;
                    k.Ea = 9;
                    if (!d || d.done || !(e = f.return)) {
                        k.Ha(9);
                        break
                    }
                    return ta(k, e.call(f), 9);
                case 9:
                    wa(k, 0, 0, 1);
                    if (c) throw c.error;
                    xa(k, 10, 1);
                    break;
                case 10:
                    xa(k, 4);
                    break;
                case 2:
                    h = va(k);
                    c = {
                        error: h
                    };
                    k.Ha(3);
                    break;
                case 4:
                    b.complete(), k.u = 0
            }
        })
    };

    function Yc(a, b) {
        return b ? Gc(a, b) : Tc(a)
    };

    function Zc(a) {
        return I(a[a.length - 1]) ? a.pop() : void 0
    }

    function $c(a) {
        var b = a[a.length - 1];
        return b && I(b.G) ? a.pop() : void 0
    };

    function ad() {
        var a = B.apply(0, arguments),
            b = $c(a);
        return b ? Gc(a, b) : Yc(a)
    };

    function bd(a) {
        var b = I(a) ? a : function() {
            return a
        };
        return new K(function(c) {
            return c.error(b())
        })
    };
    var cd = {
        now: function() {
            return (cd.ih || Date).now()
        },
        ih: void 0
    };
    var dd = function(a, b, c) {
        a = a === void 0 ? Infinity : a;
        b = b === void 0 ? Infinity : b;
        c = c === void 0 ? cd : c;
        L.call(this);
        this.bufferSize = a;
        this.Gg = b;
        this.Ag = c;
        this.buffer = [];
        this.je = b === Infinity;
        this.bufferSize = Math.max(1, a);
        this.Gg = Math.max(1, b)
    };
    q(dd, L);
    dd.create = L.create;
    dd.prototype.next = function(a) {
        var b = this.buffer,
            c = this.je,
            d = this.Ag,
            e = this.Gg;
        this.R || (b.push(a), !c && b.push(d.now() + e));
        ed(this);
        L.prototype.next.call(this, a)
    };
    dd.prototype.Aa = function(a) {
        this.Wa();
        ed(this);
        for (var b = this.cf(a), c = this.je, d = this.buffer.slice(), e = 0; e < d.length && !a.closed; e += c ? 1 : 2) a.next(d[e]);
        this.Ze(a);
        return b
    };
    var ed = function(a) {
        var b = a.bufferSize,
            c = a.Ag,
            d = a.buffer;
        a = a.je;
        var e = (a ? 1 : 2) * b;
        b < Infinity && e < d.length && d.splice(0, d.length - e);
        if (!a) {
            b = c.now();
            c = 0;
            for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
            c && d.splice(0, c + 1)
        }
    };
    var gd = function(a, b) {
        b = b === void 0 ? fd : b;
        this.Di = a;
        this.now = b
    };
    gd.prototype.G = function(a, b, c) {
        b = b === void 0 ? 0 : b;
        return (new this.Di(this, a)).G(c, b)
    };
    var fd = cd.now;
    var hd = function() {
        var a = Error.call(this, "no elements in sequence");
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        Object.setPrototypeOf(this, this.constructor.prototype);
        this.name = "EmptyError"
    };
    q(hd, Error);

    function id(a) {
        return new Promise(function(b, c) {
            var d = new vc({
                next: function(e) {
                    b(e);
                    d.unsubscribe()
                },
                error: c,
                complete: function() {
                    c(new hd)
                }
            });
            a.subscribe(d)
        })
    };
    var jd = function(a, b, c, d, e) {
        tc.call(this, a);
        this.ji = e;
        b && (this.Fd = function(f) {
            try {
                b(f)
            } catch (g) {
                this.destination.error(g)
            }
        });
        c && (this.af = function(f) {
            try {
                c(f)
            } catch (g) {
                this.destination.error(g)
            }
            this.unsubscribe()
        });
        d && (this.Mc = function() {
            try {
                d()
            } catch (f) {
                this.destination.error(f)
            }
            this.unsubscribe()
        })
    };
    q(jd, tc);
    jd.EMPTY = tc.EMPTY;
    jd.create = tc.create;
    jd.prototype.unsubscribe = function() {
        var a;
        this.closed || (a = this.ji) != null && a.call(this);
        tc.prototype.unsubscribe.call(this)
    };

    function kd(a) {
        return function(b) {
            if (I(b == null ? void 0 : b.mb)) return b.mb(function(c) {
                try {
                    return a(c, this)
                } catch (d) {
                    this.error(d)
                }
            });
            throw new TypeError("u");
        }
    };

    function ld() {
        return kd(function(a, b) {
            var c = null;
            a.Nc++;
            var d = new jd(b, void 0, void 0, void 0, function() {
                if (!a || a.Nc <= 0 || 0 < --a.Nc) c = null;
                else {
                    var e = a.xb,
                        f = c;
                    c = null;
                    !e || f && e !== f || e.unsubscribe();
                    b.unsubscribe()
                }
            });
            a.subscribe(d);
            d.closed || (c = a.connect())
        })
    };
    var md = function(a, b) {
        this.source = a;
        this.ug = b;
        this.Oc = null;
        this.Nc = 0;
        this.xb = null
    };
    q(md, K);
    md.create = K.create;
    md.prototype.Aa = function(a) {
        return nd(this).subscribe(a)
    };
    var nd = function(a) {
        var b = a.Oc;
        if (!b || b.R) a.Oc = a.ug();
        return a.Oc
    };
    md.prototype.Gd = function() {
        this.Nc = 0;
        var a = this.xb;
        this.Oc = this.xb = null;
        a == null || a.unsubscribe()
    };
    md.prototype.connect = function() {
        var a = this,
            b = this.xb;
        if (!b) {
            b = this.xb = new nc;
            var c = nd(this);
            b.add(this.source.subscribe(new jd(c, void 0, function(d) {
                a.Gd();
                c.error(d)
            }, function() {
                a.Gd();
                c.complete()
            }, function() {
                return a.Gd()
            })));
            b.closed && (this.xb = null, b = nc.EMPTY)
        }
        return b
    };

    function pd() {
        var a = qd;
        var b = b === void 0 ? 0 : b;
        return kd(function(c, d) {
            d.add(a.G(function() {
                return c.subscribe(d)
            }, b))
        })
    };

    function M(a) {
        return kd(function(b, c) {
            var d = 0;
            b.subscribe(new jd(c, function(e) {
                c.next(a.call(void 0, e, d++))
            }))
        })
    };
    var rd = Array.isArray;

    function sd(a) {
        return M(function(b) {
            return rd(b) ? a.apply(null, z(b)) : a(b)
        })
    };
    var td = Array.isArray,
        ud = Object,
        vd = ud.getPrototypeOf,
        wd = ud.prototype,
        xd = ud.keys;

    function yd(a) {
        if (a.length === 1) {
            var b = a[0];
            if (td(b)) return {
                args: b,
                keys: null
            };
            if (b && typeof b === "object" && vd(b) === wd) return a = xd(b), {
                args: a.map(function(c) {
                    return b[c]
                }),
                keys: a
            }
        }
        return {
            args: a,
            keys: null
        }
    };

    function zd() {
        var a = B.apply(0, arguments),
            b = $c(a),
            c = Zc(a);
        a = yd(a);
        var d = a.args,
            e = a.keys;
        if (d.length === 0) return Qc([], b);
        b = new K(Ad(d, b, e ? function(f) {
            for (var g = {}, h = 0; h < f.length; h++) g[e[h]] = f[h];
            return g
        } : xc));
        return c ? b.g(sd(c)) : b
    }
    var Bd = function(a, b, c) {
        tc.call(this, a);
        this.Fd = b;
        this.Ii = c
    };
    q(Bd, tc);
    Bd.EMPTY = tc.EMPTY;
    Bd.create = tc.create;
    Bd.prototype.Mc = function() {
        this.Ii() ? tc.prototype.Mc.call(this) : this.unsubscribe()
    };

    function Ad(a, b, c) {
        c = c === void 0 ? xc : c;
        return function(d) {
            Cd(b, function() {
                for (var e = a.length, f = Array(e), g = e, h = a.map(function() {
                        return !1
                    }), k = !0, l = {
                        hb: 0
                    }; l.hb < e; l = {
                        hb: l.hb
                    }, l.hb++) Cd(b, function(m) {
                    return function() {
                        Qc(a[m.hb], b).subscribe(new Bd(d, function(u) {
                            f[m.hb] = u;
                            k && (h[m.hb] = !0, k = !h.every(xc));
                            k || d.next(c(f.slice()))
                        }, function() {
                            return --g === 0
                        }))
                    }
                }(l), d)
            }, d)
        }
    }

    function Cd(a, b, c) {
        a ? c.add(a.G(b)) : b()
    };

    function Dd(a, b, c, d) {
        var e = [],
            f = 0,
            g = 0,
            h = !1,
            k = function(l) {
                f++;
                Rc(c(l, g++)).subscribe(new jd(b, function(m) {
                    b.next(m)
                }, void 0, function() {
                    f--;
                    for (var m = {}; e.length && f < d; m = {
                            kf: void 0
                        }) m.kf = e.shift(), k(m.kf);
                    !h || e.length || f || b.complete()
                }))
            };
        a.subscribe(new jd(b, function(l) {
            return f < d ? k(l) : e.push(l)
        }, void 0, function() {
            h = !0;
            !h || e.length || f || b.complete()
        }));
        return function() {
            e = null
        }
    };

    function Ed(a, b) {
        var c = c === void 0 ? Infinity : c;
        if (I(b)) return Ed(function(d, e) {
            return M(function(f, g) {
                return b(d, f, e, g)
            })(Rc(a(d, e)))
        }, c);
        typeof b === "number" && (c = b);
        return kd(function(d, e) {
            return Dd(d, e, a, c)
        })
    };

    function Fd(a) {
        a = a === void 0 ? Infinity : a;
        return Ed(xc, a)
    };

    function Gd() {
        var a = B.apply(0, arguments);
        return Fd(1)(Yc(a, $c(a)))
    };

    function Hd(a) {
        return new K(function(b) {
            Rc(a()).subscribe(b)
        })
    };
    var Id = ["addListener", "removeListener"],
        Jd = ["addEventListener", "removeEventListener"],
        Kd = ["on", "off"];

    function Ld(a, b, c) {
        if (I(c)) {
            var d = c;
            c = void 0
        }
        if (d) return Ld(a, b, c).g(sd(d));
        d = y(I(a.addEventListener) && I(a.removeEventListener) ? Jd.map(function(g) {
            return function(h) {
                return a[g](b, h, c)
            }
        }) : I(a.addListener) && I(a.removeListener) ? Id.map(Md(a, b)) : I(a.Xj) && I(a.Kj) ? Kd.map(Md(a, b)) : []);
        var e = d.next().value,
            f = d.next().value;
        return !e && Nc(a) ? Ed(function(g) {
            return Ld(g, b, c)
        })(Yc(a)) : new K(function(g) {
            if (!e) throw new TypeError("v");
            var h = function() {
                var k = B.apply(0, arguments);
                return g.next(1 < k.length ? k : k[0])
            };
            e(h);
            return function() {
                return f(h)
            }
        })
    }

    function Md(a, b) {
        return function(c) {
            return function(d) {
                return a[c](b, d)
            }
        }
    };
    var Nd = function() {
        nc.call(this)
    };
    q(Nd, nc);
    Nd.EMPTY = nc.EMPTY;
    Nd.prototype.G = function() {
        return this
    };
    var Od = function(a, b) {
        return setInterval.apply(null, [a, b].concat(z(B.apply(2, arguments))))
    };
    var Pd = function(a, b) {
        nc.call(this);
        this.scheduler = a;
        this.Te = b;
        this.pending = !1
    };
    q(Pd, Nd);
    Pd.EMPTY = Nd.EMPTY;
    Pd.prototype.G = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (this.closed) return this;
        this.state = a;
        a = this.id;
        var c = this.scheduler;
        a != null && (this.id = Qd(this, a, b));
        this.pending = !0;
        this.delay = b;
        this.id = this.id || this.Fe(c, this.id, b);
        return this
    };
    Pd.prototype.Fe = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return Od(a.flush.bind(a, this), c)
    };
    var Qd = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        if (c != null && a.delay === c && a.pending === !1) return b;
        clearInterval(b)
    };
    Pd.prototype.execute = function(a, b) {
        if (this.closed) return Error("w");
        this.pending = !1;
        if (a = this.bf(a, b)) return a;
        this.pending === !1 && this.id != null && (this.id = Qd(this, this.id, null))
    };
    Pd.prototype.bf = function(a) {
        var b = !1;
        try {
            this.Te(a)
        } catch (d) {
            b = !0;
            var c = !!d && d || Error(d)
        }
        if (b) return this.unsubscribe(), c
    };
    Pd.prototype.unsubscribe = function() {
        if (!this.closed) {
            var a = this.id,
                b = this.scheduler.actions;
            this.Te = this.state = this.scheduler = null;
            this.pending = !1;
            mc(b, this);
            a != null && (this.id = Qd(this, a, null));
            this.delay = null;
            Nd.prototype.unsubscribe.call(this)
        }
    };
    var Rd = function(a, b) {
        b = b === void 0 ? fd : b;
        gd.call(this, a, b);
        this.actions = [];
        this.active = !1
    };
    q(Rd, gd);
    Rd.prototype.flush = function(a) {
        var b = this.actions;
        if (this.active) b.push(a);
        else {
            var c;
            this.active = !0;
            do
                if (c = a.execute(a.state, a.delay)) break; while (a = b.shift());
            this.active = !1;
            if (c) {
                for (; a = b.shift();) a.unsubscribe();
                throw c;
            }
        }
    };

    function Sd() {
        var a = B.apply(0, arguments),
            b = $c(a);
        var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
        return a.length ? a.length === 1 ? Rc(a[0]) : Fd(c)(Yc(a, b)) : Ec
    };
    var Td = new K(rc);
    var Ud = Array.isArray;

    function Vd(a) {
        return a.length === 1 && Ud(a[0]) ? a[0] : a
    };

    function Wd() {
        var a = Vd(B.apply(0, arguments));
        return kd(function(b, c) {
            var d = [b].concat(z(a)),
                e = function() {
                    if (!c.closed)
                        if (d.length > 0) {
                            try {
                                var f = Rc(d.shift())
                            } catch (h) {
                                e();
                                return
                            }
                            var g = new jd(c, void 0, rc, rc);
                            c.add(f.subscribe(g));
                            g.add(e)
                        } else c.complete()
                };
            e()
        })
    };

    function N(a) {
        return kd(function(b, c) {
            var d = 0;
            b.subscribe(new jd(c, function(e) {
                return a.call(void 0, e, d++) && c.next(e)
            }))
        })
    };

    function Xd() {
        var a = B.apply(0, arguments);
        a = Vd(a);
        return a.length === 1 ? Rc(a[0]) : new K(Yd(a))
    }

    function Yd(a) {
        return function(b) {
            for (var c = [], d = {
                    Cb: 0
                }; c && !b.closed && d.Cb < a.length; d = {
                    Cb: d.Cb
                }, d.Cb++) c.push(Rc(a[d.Cb]).subscribe(new jd(b, function(e) {
                return function(f) {
                    if (c) {
                        for (var g = 0; g < c.length; g++) g !== e.Cb && c[g].unsubscribe();
                        c = null
                    }
                    b.next(f)
                }
            }(d))))
        }
    };

    function Zd() {
        var a = B.apply(0, arguments),
            b = Zc(a),
            c = Vd(a);
        return c.length ? new K(function(d) {
            var e = c.map(function() {
                    return []
                }),
                f = c.map(function() {
                    return !1
                });
            d.add(function() {
                e = f = null
            });
            for (var g = {
                    Ta: 0
                }; !d.closed && g.Ta < c.length; g = {
                    Ta: g.Ta
                }, g.Ta++) Rc(c[g.Ta]).subscribe(new jd(d, function(h) {
                    return function(k) {
                        e[h.Ta].push(k);
                        e.every(function(l) {
                            return l.length
                        }) && (k = e.map(function(l) {
                            return l.shift()
                        }), d.next(b ? b.apply(null, z(k)) : k), e.some(function(l, m) {
                            return !l.length && f[m]
                        }) && d.complete())
                    }
                }(g), void 0,
                function(h) {
                    return function() {
                        f[h.Ta] = !0;
                        !e[h.Ta].length && d.complete()
                    }
                }(g)));
            return function() {
                e = f = null
            }
        }) : Ec
    };
    var $d = function(a, b) {
        Pd.call(this, a, b);
        this.scheduler = a;
        this.Te = b
    };
    q($d, Pd);
    $d.EMPTY = Pd.EMPTY;
    $d.prototype.G = function(a, b) {
        b = b === void 0 ? 0 : b;
        if (b > 0) return Pd.prototype.G.call(this, a, b);
        this.delay = b;
        this.state = a;
        this.scheduler.flush(this);
        return this
    };
    $d.prototype.execute = function(a, b) {
        return b > 0 || this.closed ? Pd.prototype.execute.call(this, a, b) : this.bf(a, b)
    };
    $d.prototype.Fe = function(a, b, c) {
        c = c === void 0 ? 0 : c;
        return c != null && c > 0 || c == null && this.delay > 0 ? Pd.prototype.Fe.call(this, a, b, c) : a.flush(this)
    };
    var ae = function() {
        Rd.apply(this, arguments)
    };
    q(ae, Rd);
    var qd = new ae($d);
    var be = function() {
        this.H = new Ta;
        this.h = new Ua;
        this.Kh = Symbol();
        this.dc = new jc
    };
    be.prototype.de = function() {
        return Td
    };
    var ce = function(a, b) {
            a.Ca !== null && a.Ca.next(b)
        },
        de = function(a) {
            if ((typeof a === "bigint" || typeof a === "number" || typeof a === "string") && typeof BigInt === "function") return BigInt(a)
        };
    da.Object.defineProperties(be.prototype, {
        sb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Kh
            }
        }
    });
    var ee = function(a, b) {
        b = Error.call(this, b ? a + ": " + b : String(a));
        this.message = b.message;
        "stack" in b && (this.stack = b.stack);
        this.code = a;
        this.__proto__ = ee.prototype;
        this.name = String(a)
    };
    q(ee, Error);
    var fe = function(a) {
        ee.call(this, 1E3, 'sfr:"' + a + '"');
        this.Yh = a;
        this.__proto__ = fe.prototype
    };
    q(fe, ee);
    var ge = function() {
        ee.call(this, 1003);
        this.__proto__ = ge.prototype
    };
    q(ge, ee);
    var he = function() {
        ee.call(this, 1009);
        this.__proto__ = he.prototype
    };
    q(he, ee);
    var ie = function() {
        ee.call(this, 1011);
        this.__proto__ = ie.prototype
    };
    q(ie, ee);
    var je = function() {
        ee.call(this, 1007);
        this.__proto__ = ge.prototype
    };
    q(je, ee);
    var ke = function() {
        ee.call(this, 1008);
        this.__proto__ = ge.prototype
    };
    q(ke, ee);
    var le = function() {
        ee.call(this, 1001);
        this.__proto__ = le.prototype
    };
    q(le, ee);
    var me = function(a) {
        ee.call(this, 1004, String(a));
        this.Gh = a;
        this.__proto__ = me.prototype
    };
    q(me, ee);
    var oe = function(a) {
        ee.call(this, 1010, a);
        this.__proto__ = ne.prototype
    };
    q(oe, ee);
    var ne = function(a) {
        ee.call(this, 1005, a);
        this.__proto__ = ne.prototype
    };
    q(ne, ee);
    var pe = function(a) {
        var b = B.apply(1, arguments),
            c = this;
        this.Mb = [];
        this.Mb.push(a);
        b.forEach(function(d) {
            c.Mb.push(d)
        })
    };
    pe.prototype.L = function(a) {
        return this.Mb.some(function(b) {
            return b.L(a)
        })
    };
    pe.prototype.J = function(a, b) {
        for (var c = 0; c < this.Mb.length; c++)
            if (this.Mb[c].L(b)) return this.Mb[c].J(a, b);
        throw new he;
    };

    function qe(a) {
        var b, c, d;
        return !!a && typeof a.active === "boolean" && typeof((b = a.clock) == null ? void 0 : b.now) === "function" && ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 && !((d = a.D) == null || !d.timestamp) && typeof a.Y === "function" && typeof a.ja === "function" && typeof a.qa === "function" && typeof a.map === "function" && typeof a.sa === "function"
    };
    var re = Symbol("time-origin"),
        se = Symbol("date"),
        te = function(a, b) {
            this.value = a;
            this.timeline = b
        },
        ue = function(a, b) {
            if (b.timeline !== a.timeline) throw new je;
        },
        ve = function(a, b) {
            ue(a, b);
            return a.value - b.value
        };
    n = te.prototype;
    n.equals = function(a) {
        return ve(this, a) === 0
    };
    n.maximum = function(a) {
        ue(this, a);
        return this.value >= a.value ? this : a
    };
    n.round = function() {
        return new te(Math.round(this.value), this.timeline)
    };
    n.add = function(a) {
        return new te(this.value + a, this.timeline)
    };
    n.toString = function() {
        return String(this.value)
    };

    function we(a) {
        function b(c) {
            return typeof c === "boolean" || typeof c === "string" || typeof c === "number" || c === void 0 || c === null
        }
        return b(a) ? !0 : Array.isArray(a) ? a.every(b) : typeof a === "object" ? Object.keys(a).every(function(c) {
            return typeof c === "string"
        }) && Object.values(a).every(function(c) {
            return Array.isArray(c) ? c.every(b) : b(c)
        }) : !1
    }

    function ze(a) {
        if (we(a)) return a;
        if (qe(a)) return {
            D: {
                value: ze(a.D.value),
                timestamp: ve(a.D.timestamp, new te(0, a.D.timestamp.timeline))
            },
            active: a.active
        };
        try {
            return JSON.parse(JSON.stringify(a))
        } catch (b) {}
        return String(a)
    };
    var Ae = {
        Zi: "app",
        xj: "web"
    };
    var Be = ["sessionStart", "sessionError", "sessionFinish"],
        Ce = function(a, b) {
            this.da = a;
            this.Bd = b;
            this.ready = !1;
            this.nb = [];
            this.og = function() {};
            this.Eg = function() {};
            this.Bf = function() {};
            this.Nf = function() {};
            this.sd = function() {}
        },
        De = function(a, b) {
            a.og = b
        },
        Ee = function(a, b) {
            a.Eg = b
        },
        Fe = function(a, b) {
            a.Bf = b
        },
        Ge = function(a, b) {
            a.Nf = b
        },
        He = function(a, b) {
            a.sd = b;
            a.sd(a.nb.length)
        },
        Me = function(a) {
            for (var b = y("geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(" ")),
                    c = b.next(); !c.done; c = b.next()) a.da.addEventListener(c.value, function(d) {
                Ie(a, d)
            });
            Je(a.da, function(d) {
                d.type !== "sessionStart" && Ie(a, d)
            }, a.Bd);
            Je(a.da, function(d) {
                d.type === "sessionStart" && (Ie(a, d), Ke(a), Le(a))
            }, a.Bd)
        },
        Ie = function(a, b) {
            a.nb.push(b);
            a.sd(a.nb.length);
            Le(a)
        },
        Le = function(a) {
            if (a.ready)
                for (; a.nb.length > 0;) {
                    var b = a.nb.pop();
                    b !== void 0 && (b.type === "geometryChange" ? a.Bf(b) : b.type === "impression" ? a.Nf(b) : Be.includes(b.type) ? a.og(b) : a.Eg(b));
                    a.sd(a.nb.length)
                }
        },
        Ke = function(a) {
            a.ready || (a.ready = !0, a.nb.sort(function(b, c) {
                return c.timestamp - b.timestamp
            }))
        };

    function Ne(a) {
        return kd(function(b, c) {
            var d = null,
                e = !1,
                f;
            d = b.subscribe(new jd(c, void 0, function(g) {
                f = Rc(a(g, Ne(a)(b)));
                d ? (d.unsubscribe(), d = null, f.subscribe(c)) : e = !0
            }));
            e && (d.unsubscribe(), d = null, f.subscribe(c))
        })
    };

    function Oe(a, b, c) {
        return function(d, e) {
            var f = c,
                g = b,
                h = 0;
            d.subscribe(new jd(e, function(k) {
                var l = h++;
                g = f ? a(g, k, l) : (f = !0, k);
                e.next(g)
            }, void 0, void 0))
        }
    };

    function Pe() {
        var a = B.apply(0, arguments),
            b = Zc(a);
        return b ? J(Pe.apply(null, z(a)), sd(b)) : kd(function(c, d) {
            Ad([c].concat(z(Vd(a))))(d)
        })
    }

    function Qe() {
        return Pe.apply(null, z(B.apply(0, arguments)))
    };

    function Re(a) {
        a = a === void 0 ? null : a;
        return kd(function(b, c) {
            var d = !1;
            b.subscribe(new jd(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                d || c.next(a);
                c.complete()
            }))
        })
    };

    function Se() {
        return kd(function(a, b) {
            a.subscribe(new jd(b, rc))
        })
    };

    function Te(a) {
        return kd(function(b, c) {
            b.subscribe(new jd(c, function() {
                return c.next(a)
            }))
        })
    };

    function Ue(a) {
        return a <= 0 ? function() {
            return Ec
        } : kd(function(b, c) {
            var d = 0;
            b.subscribe(new jd(c, function(e) {
                ++d <= a && (c.next(e), a <= d && c.complete())
            }))
        })
    };

    function Ve(a) {
        return Ed(function(b, c) {
            return a(b, c).g(Ue(1), Te(b))
        })
    };

    function We(a) {
        return kd(function(b, c) {
            var d = new Set;
            b.subscribe(new jd(c, function(e) {
                var f = a ? a(e) : e;
                d.has(f) || (d.add(f), c.next(e))
            }))
        })
    };

    function O(a) {
        var b = b === void 0 ? xc : b;
        var c;
        a = (c = a) != null ? c : Xe;
        return kd(function(d, e) {
            var f, g = !0;
            d.subscribe(new jd(e, function(h) {
                var k = b(h);
                if (g || !a(f, k)) g = !1, f = k, e.next(h)
            }))
        })
    }

    function Xe(a, b) {
        return a === b
    };

    function Ye(a) {
        a = a === void 0 ? Ze : a;
        return kd(function(b, c) {
            var d = !1;
            b.subscribe(new jd(c, function(e) {
                d = !0;
                c.next(e)
            }, void 0, function() {
                return d ? c.complete() : c.error(a())
            }))
        })
    }

    function Ze() {
        return new hd
    };

    function $e() {
        var a = B.apply(0, arguments);
        return function(b) {
            return Gd(b, ad.apply(null, z(a)))
        }
    };

    function af(a) {
        return kd(function(b, c) {
            var d = 0;
            b.subscribe(new jd(c, function(e) {
                a.call(void 0, e, d++, b) || (c.next(!1), c.complete())
            }, void 0, function() {
                c.next(!0);
                c.complete()
            }))
        })
    };

    function bf() {
        return kd(function(a, b) {
            var c = [];
            a.subscribe(new jd(b, function(d) {
                c.push(d);
                1 < c.length && c.shift()
            }, void 0, function() {
                for (var d = y(c), e = d.next(); !e.done; e = d.next()) b.next(e.value);
                b.complete()
            }, function() {
                c = null
            }))
        })
    };

    function cf(a, b) {
        var c = arguments.length >= 2;
        return function(d) {
            return d.g(a ? N(function(e, f) {
                return a(e, f, d)
            }) : xc, bf(), c ? Re(b) : Ye(function() {
                return new hd
            }))
        }
    };

    function df(a) {
        var b = I(a) ? a : function() {
            return a
        };
        return I() ? kd(function(c, d) {
            var e = b();
            (void 0)(e).subscribe(d).add(c.subscribe(e))
        }) : function(c) {
            var d = new md(c, b);
            I(c == null ? void 0 : c.mb) && (d.mb = c.mb);
            d.source = c;
            d.ug = b;
            return d
        }
    };

    function ef(a) {
        var b = new dd(a, void 0, void 0);
        return function(c) {
            return df(function() {
                return b
            })(c)
        }
    };

    function ff() {
        var a = a === void 0 ? Infinity : a;
        return a <= 0 ? function() {
            return Ec
        } : kd(function(b, c) {
            var d = 0,
                e, f = function() {
                    var g = !1;
                    e = b.subscribe(new jd(c, void 0, void 0, function() {
                        ++d < a ? e ? (e.unsubscribe(), e = null, f()) : g = !0 : c.complete()
                    }));
                    g && (e.unsubscribe(), e = null, f())
                };
            f()
        })
    };

    function gf(a, b) {
        return kd(Oe(a, b, arguments.length >= 2))
    };

    function hf() {
        var a = a || {};
        var b = a.ah === void 0 ? function() {
                return new L
            } : a.ah,
            c = a.wi === void 0 ? !0 : a.wi,
            d = a.xi === void 0 ? !0 : a.xi,
            e = a.yi === void 0 ? !0 : a.yi;
        return function(f) {
            var g = null,
                h = null,
                k = 0,
                l = !1,
                m = !1,
                u = function() {
                    g = h = null;
                    l = m = !1
                };
            return kd(function(r, t) {
                k++;
                var w;
                h = (w = h) != null ? w : b();
                t.add(function() {
                    k--;
                    if (e && !k && !m && !l) {
                        var v = g;
                        u();
                        v == null || v.unsubscribe()
                    }
                });
                h.subscribe(t);
                !g && k > 0 && (g = new vc({
                    next: function(v) {
                        return h.next(v)
                    },
                    error: function(v) {
                        m = !0;
                        var x = h;
                        d && u();
                        x.error(v)
                    },
                    complete: function() {
                        l = !0;
                        var v = h;
                        c && u();
                        v.complete()
                    }
                }), Qc(r).subscribe(g))
            })(f)
        }
    };

    function P() {
        var a = B.apply(0, arguments),
            b = $c(a);
        return kd(function(c, d) {
            (b ? Gd(a, c, b) : Gd(a, c)).subscribe(d)
        })
    };

    function R(a) {
        return kd(function(b, c) {
            var d = null,
                e = 0,
                f = !1;
            b.subscribe(new jd(c, function(g) {
                var h;
                (h = d) == null || h.unsubscribe();
                h = e++;
                Rc(a(g, h)).subscribe(d = new jd(c, function(k) {
                    return c.next(k)
                }, void 0, function() {
                    d = null;
                    f && !d && c.complete()
                }))
            }, void 0, function() {
                (f = !0, !d) && c.complete()
            }))
        })
    };

    function jf(a, b) {
        b = b === void 0 ? !1 : b;
        return kd(function(c, d) {
            var e = 0;
            c.subscribe(new jd(d, function(f) {
                var g = a(f, e++);
                (g || b) && d.next(f);
                !g && d.complete()
            }))
        })
    };

    function kf(a, b, c) {
        var d = I(a) || b || c ? {
            next: a,
            error: b,
            complete: c
        } : a;
        return d ? kd(function(e, f) {
            e.subscribe(new jd(f, function(g) {
                var h;
                (h = d.next) == null || h.call(d, g);
                f.next(g)
            }, function(g) {
                var h;
                (h = d.error) == null || h.call(d, g);
                f.error(g)
            }, function() {
                var g;
                (g = d.complete) == null || g.call(d);
                f.complete()
            }))
        }) : xc
    };

    function lf() {
        var a = B.apply(0, arguments),
            b = Zc(a);
        return kd(function(c, d) {
            for (var e = a.length, f = Array(e), g = a.map(function() {
                    return !1
                }), h = !1, k = {
                    Oa: 0
                }; k.Oa < e; k = {
                    Oa: k.Oa
                }, k.Oa++) Rc(a[k.Oa]).subscribe(new jd(d, function(l) {
                return function(m) {
                    f[l.Oa] = m;
                    h || g[l.Oa] || (g[l.Oa] = !0, (h = g.every(xc)) && (g = null))
                }
            }(k), void 0, rc));
            c.subscribe(new jd(d, function(l) {
                h && (l = [l].concat(z(f)), d.next(b ? b.apply(null, z(l)) : l))
            }))
        })
    };
    var mf = function(a) {
        this.da = a
    };
    mf.prototype.L = function(a) {
        return (a == null ? 0 : a.Wb) ? !0 : (a == null ? void 0 : a.ha) === "POST" || (a == null ? 0 : a.cb) || (a == null ? 0 : a.Yc) ? !1 : this.da.L()
    };
    mf.prototype.ping = function() {
        var a = this,
            b = ad.apply(null, z(B.apply(0, arguments))).g(Ed(function(c) {
                return nf(a, c)
            }), af(function(c) {
                return c
            }), ef(1));
        b.connect();
        return b
    };
    var nf = function(a, b) {
        var c = new dd(1); of (a.da, b, function() {
            c.next(!0);
            c.complete()
        }, function() {
            c.next(!1);
            c.complete()
        });
        return c
    };
    mf.prototype.rd = function(a, b, c) {
        this.ping.apply(this, z(B.apply(3, arguments)))
    };

    function pf(a, b) {
        var c = !1;
        return new K(function(d) {
            var e = a.setTimeout(function() {
                c = !0;
                d.next(!0);
                d.complete()
            }, b);
            return function() {
                c || a.clearTimeout(e)
            }
        })
    };
    var qf = function(a) {
        this.da = a;
        this.timeline = se
    };
    n = qf.prototype;
    n.setTimeout = function(a, b) {
        return Number(this.da.setTimeout(function() {
            return a()
        }, b))
    };
    n.clearTimeout = function(a) {
        this.da.clearTimeout(a)
    };
    n.now = function() {
        return new te(Date.now(), this.timeline)
    };
    n.interval = function(a, b) {
        var c = this.Ga(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ga = function(a) {
        return pf(this, a).g(ff(), gf(function(b) {
            return b + 1
        }, -1))
    };
    n.ga = function() {
        return !0
    };
    var rf = function(a, b) {
        this.context = a;
        this.Nb = b
    };
    rf.prototype.L = function(a) {
        return this.Nb.L(a)
    };
    rf.prototype.J = function(a, b) {
        if (!this.L(b)) throw new he;
        return new sf(this.context, this.Nb, b != null ? b : void 0, a)
    };
    var sf = function(a, b, c, d) {
        var e = this;
        this.Nb = b;
        this.properties = c;
        this.url = d;
        this.jd = !0;
        this.cb = new Map;
        this.body = void 0;
        var f;
        this.method = (f = c == null ? void 0 : c.ha) != null ? f : "GET";
        this.Ug = a.de().subscribe(function() {
            e.sendNow()
        })
    };
    sf.prototype.deactivate = function() {
        this.jd = !1
    };
    sf.prototype.sendNow = function() {
        if (this.jd)
            if (this.Ug.unsubscribe(), this.Nb.L(this.properties)) try {
                if (this.cb.size > 0 || this.body !== void 0) {
                    var a, b;
                    this.Nb.rd((a = this.properties) != null ? a : {}, this.cb, (b = this.body) != null ? b : "", this.url)
                } else this.Nb.ping(this.url);
                this.jd = !1
            } catch (c) {} else this.jd = !1
    };
    var uf = function(a, b, c, d, e, f) {
            this.mode = a;
            this.j = b;
            this.setTime = c;
            this.Cc = d;
            this.Oi = e;
            this.Zg = f;
            this.completed = !1;
            this.id = this.mode === 0 ? tf(this) : 0
        },
        tf = function(a) {
            return a.j.setTimeout(function() {
                vf(a)
            }, a.Cc)
        },
        wf = function(a, b) {
            var c = ve(b, a.setTime);
            c >= a.Cc ? vf(a) : (a.setTime = b, a.Cc -= c)
        },
        vf = function(a) {
            try {
                a.Oi(a.setTime.add(a.Cc))
            } finally {
                a.completed = !0, a.Zg()
            }
        };
    uf.prototype.Pe = function(a, b) {
        this.completed || (this.mode === 1 && a === 1 ? wf(this, b) : this.mode === 1 && a === 0 ? (this.mode = a, wf(this, this.j.now()), this.completed || (this.id = tf(this))) : this.mode === 0 && a === 1 && (this.mode = a, this.clear(), wf(this, b)))
    };
    uf.prototype.clear = function() {
        this.completed || this.j.clearTimeout(this.id)
    };
    var xf = function(a) {
        this.Zc = a;
        this.Ih = this.mode = 0;
        this.Gb = {};
        this.timeline = a.timeline;
        this.lb = a.now()
    };
    n = xf.prototype;
    n.Pe = function(a, b) {
        this.mode = a;
        ue(this.lb, b);
        this.lb = b;
        Object.values(this.Gb).forEach(function(c) {
            return void c.Pe(a, b)
        })
    };
    n.now = function() {
        return this.mode === 1 ? this.lb : this.Zc.now()
    };
    n.setTimeout = function(a, b) {
        var c = this,
            d = ++this.Ih,
            e = this.mode === 1 ? this.lb : this.Zc.now();
        this.Gb[d] = new uf(this.mode, this.Zc, e, b, function(f) {
            var g = c.lb;
            c.mode === 1 && (c.lb = f);
            a();
            c.lb = g
        }, function() {
            delete c.Gb[d]
        });
        return d
    };
    n.clearTimeout = function(a) {
        this.Gb[a] && (this.Gb[a].clear(), delete this.Gb[a])
    };
    n.interval = function() {
        throw Error("x");
    };
    n.Ga = function() {
        throw Error("y");
    };
    n.ga = function() {
        return this.Zc.ga()
    };

    function yf(a, b) {
        var c = new xf(a);
        a = b.subscribe(function(d) {
            c.Pe(d.value ? 1 : 0, d.timestamp)
        });
        return {
            j: c,
            Jj: a
        }
    };

    function zf(a) {
        var b = Object.assign({}, a);
        delete b.timestamp;
        return {
            timestamp: new te(a.timestamp, se),
            value: b
        }
    };

    function Af(a) {
        return a !== void 0 && typeof a.x === "number" && typeof a.y === "number" && typeof a.width === "number" && typeof a.height === "number"
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function Bf(a) {
        var b = B.apply(1, arguments),
            c = b.length;
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !rb && a === a.raw || !(rb && !sb || pb(a)) || c + 1 !== a.length) throw new TypeError("p");
        if (b.length === 0) return eb(a[0]);
        c = a[0].toLowerCase();
        if (/^data:/.test(c)) throw Error("F");
        if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
            var d = c.indexOf("//") + 2;
            var e = c.indexOf("/", d);
            if (e <= d) throw Error("z");
            d = c.substring(d, e);
            if (!/^[0-9a-z.:-]+$/i.test(d)) throw Error("A");
            if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("B");
            if (!/(^|\.)[a-z][^.]*$/i.test(d)) throw Error("C");
            d = !0
        } else d = !1;
        if (!d)
            if (/^\//.test(c))
                if (c === "/" || c.length > 1 && c[1] !== "/" && c[1] !== "\\") d = !0;
                else throw Error("E");
        else d = !1;
        if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
            if (/^about:blank/.test(c)) {
                if (c !== "about:blank" && !/^about:blank#/.test(c)) throw Error("D");
                d = !0
            } else d = !1;
        if (!d) throw Error("G");
        c = a[0];
        for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return eb(c)
    };
    var Cf = pa(["https://www.googleadservices.com/pagead/managed/js/activeview/", "/reach_worklet.html"]),
        Df = pa(["./reach_worklet.js"]),
        Ef = pa(["./reach_worklet.js"]),
        Ff = pa(["./reach_worklet.html"]),
        Gf = pa(["./reach_worklet.js"]),
        Hf = pa(["./reach_worklet.js"]);

    function If(a) {
        var b = {};
        return b[0] = Bf(Cf, a), b[1] = Bf(Df), b[2] = Bf(Ef), b
    }
    Bf(Ff);
    Bf(Gf);
    Bf(Hf);
    var Kf = function(a, b, c, d) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? If("current") : d;
        be.call(this);
        this.da = a;
        this.Bd = b;
        this.Ca = c;
        this.Je = d;
        this.Qa = null;
        this.He = new dd(3);
        this.He.g(N(function(e) {
            return e.value.type === "sessionStart"
        }));
        this.Ei = this.He.g(N(function(e) {
            return e.value.type === "sessionFinish"
        }));
        this.Of = new dd(1);
        this.Si = new dd;
        this.Cf = new dd(10);
        this.I = new rf(this, new mf(a));
        this.Ph = this.da.L();
        this.j = Jf(this, new qf(this.da))
    };
    q(Kf, be);
    var Lf = function(a) {
        a.Qa !== null && Me(a.Qa)
    };
    Kf.prototype.validate = function() {
        return this.Ph
    };
    var Jf = function(a, b) {
        a.Qa = new Ce(a.da, a.Bd);
        var c = new dd;
        De(a.Qa, function(f) {
            f = zf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.He.next(f)
        });
        Fe(a.Qa, function(f) {
            if (f === void 0) var g = !1;
            else {
                g = f.data;
                var h;
                (h = g === void 0) || (h = g.viewport, h = h === void 0 || h !== void 0 && typeof h.width === "number" && typeof h.height === "number");
                h ? (g = g.adView, g = g !== void 0 && typeof g.percentageInView === "number" && (g.geometry === void 0 || Af(g.geometry)) && (g.onScreenGeometry === void 0 || Af(g.onScreenGeometry))) : g = !1
            }
            g ? (f = zf(f), c.next({
                timestamp: f.timestamp,
                value: !0
            }), a.Cf.next(f)) : .01 >= Math.random() && (f = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" + JSON.stringify(f), a.I.J(f).sendNow())
        });
        Ee(a.Qa, function(f) {
            f = zf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Si.next(f)
        });
        Ge(a.Qa, function(f) {
            f = zf(f);
            c.next({
                timestamp: f.timestamp,
                value: !0
            });
            a.Of.next(f)
        });
        var d = 0;
        He(a.Qa, function(f) {
            d += f;
            d > 0 && f === 0 && c.next({
                timestamp: a.j.now(),
                value: !1
            })
        });
        var e = c.g(jf(function(f) {
            return f.value
        }, !0));
        return yf(b,
            e).j
    };
    da.Object.defineProperties(Kf.prototype, {
        global: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return Mf
            }
        }
    });
    var Mf = {};

    function Nf(a, b) {
        if (!b) throw Error("H`" + a);
        if (typeof b !== "string" && !(b instanceof String)) throw Error("I`" + a);
        if (b.trim() === "") throw Error("J`" + a);
    }

    function Of(a) {
        if (!a) throw Error("M`functionToExecute");
    }

    function Pf(a, b) {
        if (b == null) throw Error("K`" + a);
        if (typeof b !== "number" || isNaN(b)) throw Error("L`" + a);
        if (b < 0) throw Error("N`" + a);
    };

    function Qf() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.5.2-google_20241009")
    }

    function Rf() {
        for (var a = ["1", "5", "2"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
            var d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };
    var Sf = function(a, b, c, d) {
            this.Mf = a;
            this.method = b;
            this.version = c;
            this.args = d
        },
        Tf = function(a) {
            return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
        },
        Uf = function(a) {
            return new Sf(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
        };
    Sf.prototype.Sa = function() {
        var a = {};
        a = (a.omid_message_guid = this.Mf, a.omid_message_method = this.method, a.omid_message_version = this.version, a);
        this.args !== void 0 && (a.omid_message_args = this.args);
        return a
    };
    var Vf = function(a) {
        this.to = a
    };
    Vf.prototype.Sa = function() {
        return JSON.stringify(void 0)
    };

    function Wf(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }
    var Xf = function(a) {
            return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
                return Wf(a, b)
            })
        },
        Yf = function(a) {
            for (var b = y(Object.values(Ae)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = {};
                d = (d.app = "omid_v1_present_app", d.web = "omid_v1_present_web", d)[c];
                if (Wf(a, d)) return c
            }
            return null
        };

    function Zf(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function $f() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(a) {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function ag() {
        var a = B.apply(0, arguments);
        bg(function() {
            throw new(Function.prototype.bind.apply(Error, [null, "Could not complete the test successfully - "].concat(z(a))));
        }, function() {
            return console.error.apply(console, z(a))
        })
    }

    function bg(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var cg = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("O");
    }();
    var dg = function(a) {
        this.to = a;
        this.handleExportedMessage = dg.prototype.xh.bind(this)
    };
    q(dg, Vf);
    dg.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("P");
        b.handleExportedMessage(a.Sa(), this)
    };
    dg.prototype.xh = function(a, b) {
        if (Tf(a) && this.onMessage) this.onMessage(Uf(a), b)
    };

    function eg(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function fg(a) {
        if (a === cg) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function gg() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return eg(a) ? a : cg
    };
    var hg = function(a, b) {
        this.to = b = b === void 0 ? cg : b;
        var c = this;
        a.addEventListener("message", function(d) {
            if (typeof d.data === "object") {
                var e = d.data;
                if (Tf(e) && d.source && c.onMessage) c.onMessage(Uf(e), d.source)
            }
        })
    };
    q(hg, Vf);
    hg.prototype.sendMessage = function(a, b) {
        b = b === void 0 ? this.to : b;
        if (!b) throw Error("P");
        b.postMessage(a.Sa(), "*")
    };
    var ig = ["omid", "v1_VerificationServiceCommunication"],
        jg = ["omidVerificationProperties", "serviceWindow"];

    function kg(a, b) {
        return b.reduce(function(c, d) {
            return c && c[d]
        }, a)
    };
    var lg = function(a) {
        if (!a) {
            a = gg();
            var b = b === void 0 ? Xf : b;
            var c = [],
                d = kg(a, jg);
            d && c.push(d);
            c.push(eg(a) ? a.top : cg);
            a: {
                c = y(c);
                for (var e = c.next(); !e.done; e = c.next()) {
                    b: {
                        d = a;e = e.value;
                        var f = b;
                        if (!fg(e)) try {
                            var g = kg(e, ig);
                            if (g) {
                                var h = new dg(g);
                                break b
                            }
                        } catch (k) {}
                        h = f(e) ? new hg(d, e) : null
                    }
                    if (d = h) {
                        a = d;
                        break a
                    }
                }
                a = null
            }
        }
        if (this.ac = a) this.ac.onMessage = this.yh.bind(this);
        else if (b = (b = cg.omid3p) && typeof b.registerSessionObserver === "function" && typeof b.addEventListener === "function" ? b : null) this.xc = b;
        this.si = this.ti =
            0;
        this.Nd = {};
        this.ge = [];
        this.lc = (b = cg.omidVerificationProperties) ? b.injectionId : void 0
    };
    lg.prototype.L = function() {
        var a = gg();
        var b = (b = cg.omidVerificationProperties) && b.injectionSource ? b.injectionSource : void 0;
        return (b || Yf(a) || Yf(eg(a) ? a.top : cg)) !== "web" || this.lc ? !(!this.ac && !this.xc) : !1
    };
    var Je = function(a, b, c) {
        Of(b);
        a.xc ? a.xc.registerSessionObserver(b, c, a.lc) : a.Qb("addSessionListener", b, c, a.lc)
    };
    lg.prototype.addEventListener = function(a, b) {
        Nf("eventType", a);
        Of(b);
        this.xc ? this.xc.addEventListener(a, b, this.lc) : this.Qb("addEventListener", b, a, this.lc)
    };
    var of = function(a, b, c, d) {
        Nf("url", b);
        cg.document && cg.document.createElement ? mg(a, b, c, d) : a.Qb("sendUrl", function(e) {
            e && c ? c() : !e && d && d()
        }, b)
    }, mg = function(a, b, c, d) {
        var e = cg.document.createElement("img");
        a.ge.push(e);
        var f = function(g) {
            var h = a.ge.indexOf(e);
            h >= 0 && a.ge.splice(h, 1);
            g && g()
        };
        e.addEventListener("load", f.bind(a, c));
        e.addEventListener("error", f.bind(a, d));
        e.src = b
    };
    lg.prototype.setTimeout = function(a, b) {
        Of(a);
        Pf("timeInMillis", b);
        if (ng()) return cg.setTimeout(a, b);
        var c = this.ti++;
        this.Qb("setTimeout", a, c, b);
        return c
    };
    lg.prototype.clearTimeout = function(a) {
        Pf("timeoutId", a);
        ng() ? cg.clearTimeout(a) : this.ng("clearTimeout", a)
    };
    lg.prototype.setInterval = function(a, b) {
        Of(a);
        Pf("timeInMillis", b);
        if (og()) return cg.setInterval(a, b);
        var c = this.si++;
        this.Qb("setInterval", a, c, b);
        return c
    };
    lg.prototype.clearInterval = function(a) {
        Pf("intervalId", a);
        og() ? cg.clearInterval(a) : this.ng("clearInterval", a)
    };
    var ng = function() {
            return typeof cg.setTimeout === "function" && typeof cg.clearTimeout === "function"
        },
        og = function() {
            return typeof cg.setInterval === "function" && typeof cg.clearInterval === "function"
        };
    lg.prototype.yh = function(a) {
        var b = a.method,
            c = a.Mf;
        a = a.args;
        if (b === "response" && this.Nd[c]) {
            var d = Qf() && Rf() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
            this.Nd[c].apply(this, d)
        }
        b === "error" && window.console && ag(a)
    };
    lg.prototype.ng = function(a) {
        this.Qb.apply(this, [a, null].concat(z(B.apply(1, arguments))))
    };
    lg.prototype.Qb = function(a, b) {
        var c = B.apply(2, arguments);
        if (this.ac) {
            var d = $f();
            b && (this.Nd[d] = b);
            var e = "VerificationService." + a;
            c = Qf() && Rf() ? c : JSON.stringify(c);
            this.ac.sendMessage(new Sf(d, e, "1.5.2-google_20241009", c))
        }
    };
    var rg = void 0;
    if (rg = rg === void 0 ? typeof omidExports === "undefined" ? null : omidExports : rg) {
        var sg = ["OmidVerificationClient"];
        sg.slice(0, sg.length - 1).reduce(Zf, rg)[sg[sg.length - 1]] = lg
    };

    function tg(a, b) {
        return function(c) {
            return new K(function(d) {
                return c.subscribe(function(e) {
                    a.Tb(b, function() {
                        d.next(e)
                    })()
                }, function(e) {
                    a.Tb(b, function() {
                        d.error(e)
                    })()
                }, function() {
                    a.Tb(b, function() {
                        d.complete()
                    })()
                })
            })
        }
    };
    var vg = function() {
        for (var a = y(B.apply(0, arguments)), b = a.next(); !b.done; b = a.next())
            if (b = b.value, b.ga()) {
                this.j = b;
                return
            }
        this.j = new ug
    };
    n = vg.prototype;
    n.ga = function() {
        return this.j.ga()
    };
    n.now = function() {
        return this.j.now()
    };
    n.setTimeout = function(a, b) {
        return this.j.setTimeout(a, b)
    };
    n.clearTimeout = function(a) {
        this.j.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ga(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ga = function(a) {
        return this.j.Ga(a)
    };
    da.Object.defineProperties(vg.prototype, {
        timeline: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.j.timeline
            }
        }
    });
    var ug = function() {
        this.timeline = Symbol()
    };
    n = ug.prototype;
    n.ga = function() {
        return !1
    };
    n.now = function() {
        return new te(0, this.timeline)
    };
    n.setTimeout = function() {
        return 0
    };
    n.clearTimeout = function() {};
    n.interval = function() {
        return function() {}
    };
    n.Ga = function() {
        return Td
    };
    var wg = function(a, b) {
        this.M = a;
        this.H = b
    };
    n = wg.prototype;
    n.setTimeout = function(a, b) {
        return this.M.setTimeout(this.H.Tb(734, a), b)
    };
    n.clearTimeout = function(a) {
        this.M.clearTimeout(a)
    };
    n.interval = function(a, b) {
        var c = this.Ga(a).subscribe(b);
        return function() {
            return void c.unsubscribe()
        }
    };
    n.Ga = function(a) {
        var b = this;
        return new K(function(c) {
            var d = 0,
                e = b.M.setInterval(function() {
                    c.next(d++)
                }, a);
            return function() {
                b.M.clearInterval(e)
            }
        })
    };
    n.ga = function() {
        return !!this.M.clearTimeout && "setTimeout" in this.M && "setInterval" in this.M && !!this.M.clearInterval
    };
    var xg = function(a, b) {
        wg.call(this, a, b);
        this.timeline = se
    };
    q(xg, wg);
    xg.prototype.now = function() {
        return new te(this.M.Date.now(), this.timeline)
    };
    xg.prototype.ga = function() {
        return !!this.M.Date && !!this.M.Date.now && wg.prototype.ga.call(this)
    };
    var yg = function(a, b) {
        wg.call(this, a, b);
        this.timeline = re
    };
    q(yg, wg);
    yg.prototype.now = function() {
        return new te(this.M.performance.now(), this.timeline)
    };
    yg.prototype.ga = function() {
        return !!this.M.performance && !!this.M.performance.now && wg.prototype.ga.call(this)
    };

    function zg(a) {
        a = a.global;
        if (a.fetchLater) return a.fetchLater.bind(a)
    }

    function Ag(a) {
        var b, c, d = (b = a.global) == null ? void 0 : (c = b.document) == null ? void 0 : c.createElement("meta");
        if (d) try {
            return d.httpEquiv = "origin-trial", d.content = "AxjhRadLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9", a.global.document.head.append(d), d
        } catch (e) {}
    }
    var Cg = function(a) {
            this.context = a;
            Bg === void 0 && (Bg = Ag(a))
        },
        Bg;
    Cg.prototype.L = function(a) {
        return zg(this.context) !== void 0 && !(a == null || !a.tf) && !Dg(this.context) && !(a == null ? 0 : a.Wb) && !(a == null ? 0 : a.cb) && !(a == null ? 0 : a.Yc)
    };
    Cg.prototype.J = function(a, b) {
        if (!this.L(b)) throw new he;
        return new Eg(this.context, a, b)
    };
    var Eg = function(a, b, c) {
            this.context = a;
            this.properties = c;
            this.wb = b;
            var d;
            this.ha = (d = c == null ? void 0 : c.ha) != null ? d : "GET";
            a = zg(this.context);
            if (a === void 0) throw Error();
            this.fetchLater = a;
            Fg(this, this.rc())
        },
        Fg = function(a, b) {
            a.La && a.La.activated || (a.Xb = new AbortController, a.La = a.fetchLater(b, {
                method: a.ha,
                cache: "no-cache",
                mode: "no-cors",
                signal: a.Xb.signal,
                activateAfter: 96E4
            }))
        };
    Eg.prototype.rc = function() {
        var a = this.wb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "flapi=1"
    };
    Eg.prototype.deactivate = function() {
        this.La && !this.La.activated && this.Xb && (this.Xb.abort(), this.La = void 0)
    };
    Eg.prototype.sendNow = function() {};
    da.Object.defineProperties(Eg.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.wb
            },
            set: function(a) {
                this.wb = a;
                a = this.rc();
                this.La && this.La.activated || !this.Xb || (this.Xb.abort(), this.La = void 0);
                Fg(this, a)
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.ha
            }
        }
    });
    var Gg = function(a) {
        this.context = a
    };
    Gg.prototype.L = function() {
        return !Dg(this.context) && !!this.context.global.fetch
    };
    Gg.prototype.ping = function() {
        var a = this;
        return Sd.apply(null, z(B.apply(0, arguments).map(function(b) {
            return Qc(a.context.global.fetch(b, {
                method: "GET",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors"
            })).g(M(function(c) {
                return c.status === 200
            }))
        }))).g(af(function(b) {
            return b
        }), cf())
    };
    Gg.prototype.rd = function(a, b, c) {
        for (var d = B.apply(3, arguments), e = this, f = new Headers, g = y(b.entries()), h = g.next(); !h.done; h = g.next()) {
            var k = y(h.value);
            h = k.next().value;
            k = k.next().value;
            f.set(h, k)
        }
        var l, m = (l = a.keepAlive) != null ? l : !1;
        Sd.apply(null, z(d.map(function(u) {
            return Qc(e.context.global.fetch(u, Object.assign({}, {
                method: String(a.ha),
                cache: "no-cache"
            }, m ? {
                keepalive: !0
            } : {}, {
                mode: "no-cors",
                headers: f,
                body: c
            }))).g(M(function(r) {
                return r.status === 200
            }))
        }))).g(af(function(u) {
            return u
        }), cf())
    };

    function Hg(a, b) {
        b = b === void 0 ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return Hg(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = Ig(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = y(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + Hg(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = Ig(c.constructor)), typeof a.toString === "function" && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + Ig(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function Ig(a) {
        var b = a.displayName;
        return b && typeof b === "string" || (b = a.name) && typeof b === "string" ? b : (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)"
    };

    function Jg(a, b) {
        var c = Kg,
            d = [];
        Lg(b, a, d) || Mg.apply(null, [void 0, c, "Guard " + b.Lf().trim() + " failed:"].concat(z(d.reverse())))
    }

    function Ng(a, b) {
        a.Ej = !0;
        a.Lf = typeof b === "function" ? b : function() {
            return b
        };
        return a
    }

    function Lg(a, b, c) {
        var d = a(b, c);
        d || Og(c, function() {
            var e = "";
            e.length > 0 && (e += ": ");
            return e + "Expected " + a.Lf().trim() + ", got " + Hg(b)
        });
        return d
    }

    function Og(a, b) {
        a == null || a.push((typeof b === "function" ? b() : b).trim())
    }
    var Kg = void 0;

    function Pg(a) {
        return typeof a === "function" ? a() : a
    }

    function Mg() {
        throw Error(B.apply(0, arguments).map(Pg).filter(Boolean).join("\n").trim().replace(/:$/, ""));
    };
    var Qg = Ng(function(a) {
            return typeof a === "string"
        }, "string"),
        Rg = Ng(function(a) {
            return typeof a === "bigint"
        }, "bigint");

    function Sg() {
        var a = Error;
        return Ng(function(b) {
            return b instanceof a
        }, function() {
            return Ig(a)
        })
    };
    var Tg = Na(1, !0),
        Ug = Na(610401301, !1);
    Na(899588437, !1);
    Na(772657768, !1);
    Na(513659523, !0);
    Na(568333945, !0);
    Na(1331761403, !1);
    Na(651175828, !0);
    Na(722764542, !0);
    Na(748402145, !0);
    Na(748402146, !0);
    var Vg = Na(748402147, !0);
    Na(333098724, !1);
    Na(2147483644, !1);
    Na(2147483645, !0);
    Na(2147483646, Tg);
    Na(2147483647, !0);

    function Wg() {
        var a = Ka.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Xg, Yg = Ka.navigator;
    Xg = Yg ? Yg.userAgentData || null : null;

    function Zg(a) {
        if (!Ug || !Xg) return !1;
        for (var b = 0; b < Xg.brands.length; b++) {
            var c = Xg.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function S(a) {
        return Wg().indexOf(a) != -1
    };

    function $g() {
        return Ug ? !!Xg && Xg.brands.length > 0 : !1
    }

    function ah() {
        return $g() ? !1 : S("Opera")
    }

    function bh() {
        return S("Firefox") || S("FxiOS")
    }

    function ch() {
        return S("Safari") && !(dh() || ($g() ? 0 : S("Coast")) || ah() || ($g() ? 0 : S("Edge")) || ($g() ? Zg("Microsoft Edge") : S("Edg/")) || ($g() ? Zg("Opera") : S("OPR")) || bh() || S("Silk") || S("Android"))
    }

    function dh() {
        return $g() ? Zg("Chromium") : (S("Chrome") || S("CriOS")) && !($g() ? 0 : S("Edge")) || S("Silk")
    }

    function eh() {
        return S("Android") && !(dh() || bh() || ah() || S("Silk"))
    };
    var gh = function() {
            return Ug && Xg ? Xg.mobile : !fh() && (S("iPod") || S("iPhone") || S("Android") || S("IEMobile"))
        },
        fh = function() {
            return Ug && Xg ? !Xg.mobile && (S("iPad") || S("Android") || S("Silk")) : S("iPad") || S("Android") && !S("Mobile") || S("Silk")
        };
    var hh = function(a) {
        hh[" "](a);
        return a
    };
    hh[" "] = function() {};
    var ih = function(a, b) {
        try {
            return hh(a[b]), !0
        } catch (c) {}
        return !1
    };

    function jh() {
        return Ug ? !!Xg && !!Xg.platform : !1
    }

    function kh() {
        return S("iPhone") && !S("iPod") && !S("iPad")
    }

    function lh() {
        kh() || S("iPad") || S("iPod")
    };
    ah();
    var mh = $g() ? !1 : S("Trident") || S("MSIE");
    S("Edge");
    var nh = S("Gecko") && !(Ya(Wg(), "WebKit") && !S("Edge")) && !(S("Trident") || S("MSIE")) && !S("Edge"),
        oh = Ya(Wg(), "WebKit") && !S("Edge");
    oh && S("Mobile");
    jh() || S("Macintosh");
    jh() || S("Windows");
    (jh() ? Xg.platform === "Linux" : S("Linux")) || jh() || S("CrOS");
    jh() || S("Android");
    kh();
    S("iPad");
    S("iPod");
    lh();
    Ya(Wg(), "KaiOS");
    var ph = function(a) {
        try {
            return !!a && a.location.href != null && ih(a, "foo")
        } catch (b) {
            return !1
        }
    };
    var qh = function(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    };
    n = qh.prototype;
    n.clone = function() {
        return new qh(this.x, this.y)
    };
    n.toString = function() {
        return "(" + this.x + ", " + this.y + ")"
    };
    n.equals = function(a) {
        return a instanceof qh && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    n.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    n.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    n.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    n.translate = function(a, b) {
        a instanceof qh ? (this.x += a.x, this.y += a.y) : (this.x += Number(a), typeof b === "number" && (this.y += b));
        return this
    };
    n.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };
    var rh = function(a, b) {
        this.width = a;
        this.height = b
    };
    n = rh.prototype;
    n.clone = function() {
        return new rh(this.width, this.height)
    };
    n.toString = function() {
        return "(" + this.width + " x " + this.height + ")"
    };
    n.aspectRatio = function() {
        return this.width / this.height
    };
    n.isEmpty = function() {
        return !(this.width * this.height)
    };
    n.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    n.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    n.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    n.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };
    var uh = function(a) {
            return a ? new sh(th(a)) : xb || (xb = new sh)
        },
        vh = function(a) {
            var b = a.scrollingElement ? a.scrollingElement : oh || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
            a = a.defaultView;
            return new qh(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
        },
        wh = function(a, b, c) {
            function d(h) {
                h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!Pa(f) || Qa(f) && f.nodeType > 0) d(f);
                else {
                    a: {
                        if (f && typeof f.length == "number") {
                            if (Qa(f)) {
                                var g =
                                    typeof f.item == "function" || typeof f.item == "string";
                                break a
                            }
                            if (typeof f === "function") {
                                g = typeof f.item == "function";
                                break a
                            }
                        }
                        g = !1
                    }
                    Ib(g ? Mb(f) : f, d)
                }
            }
        },
        th = function(a) {
            D(a, "Node cannot be null or undefined.");
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        xh = function(a, b) {
            a && (a = a.parentNode);
            for (var c = 0; a;) {
                D(a.name != "parentNode");
                if (b(a)) return a;
                a = a.parentNode;
                c++
            }
            return null
        },
        sh = function(a) {
            this.fc = a || Ka.document || document
        };
    n = sh.prototype;
    n.getElementsByTagName = function(a, b) {
        return (b || this.fc).getElementsByTagName(String(a))
    };
    n.createElement = function(a) {
        var b = this.fc;
        a = String(a);
        b.contentType === "application/xhtml+xml" && (a = a.toLowerCase());
        return b.createElement(a)
    };
    n.createTextNode = function(a) {
        return this.fc.createTextNode(String(a))
    };
    n.appendChild = function(a, b) {
        D(a != null && b != null, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    n.append = function(a, b) {
        wh(th(a), a, arguments)
    };
    n.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    n.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    n.isElement = function(a) {
        return Qa(a) && a.nodeType == 1
    };
    n.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function yh(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    n = yh.prototype;
    n.Kf = function() {
        return this.right - this.left
    };
    n.Hf = function() {
        return this.bottom - this.top
    };
    n.clone = function() {
        return new yh(this.top, this.right, this.bottom, this.left)
    };
    n.toString = function() {
        return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
    };
    n.contains = function(a) {
        return this && a ? a instanceof yh ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    n.expand = function(a, b, c, d) {
        Qa(a) ? (this.top -= a.top, this.right += a.right, this.bottom += a.bottom, this.left -= a.left) : (this.top -= a, this.right += Number(b), this.bottom += Number(c), this.left -= Number(d));
        return this
    };
    n.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    n.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    n.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    n.translate = function(a, b) {
        a instanceof qh ? (this.left += a.x, this.right += a.x, this.top += a.y, this.bottom += a.y) : (Cb(a), this.left += a, this.right += a, typeof b === "number" && (this.top += b, this.bottom += b));
        return this
    };
    n.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };
    var zh = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };

    function Ah(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    };
    var Bh = function(a) {
        this.context = a
    };
    Bh.prototype.L = function(a) {
        return (a == null ? 0 : a.Wb) || (a == null ? void 0 : a.ha) === "POST" || (a == null ? 0 : a.cb) || (a == null ? 0 : a.Yc) || (a == null ? 0 : a.keepAlive) ? !1 : !Dg(this.context)
    };
    Bh.prototype.ping = function() {
        var a = this;
        return ad(B.apply(0, arguments).map(function(b) {
            try {
                var c = a.context.global;
                c.google_image_requests || (c.google_image_requests = []);
                var d = c.document;
                d = d === void 0 ? document : d;
                var e = d.createElement("img");
                e.src = b;
                c.google_image_requests.push(e);
                return !0
            } catch (f) {
                return !1
            }
        }).every(function(b) {
            return b
        }))
    };
    Bh.prototype.rd = function(a, b, c) {
        this.ping.apply(this, z(B.apply(3, arguments)))
    };

    function Ch(a) {
        a = a.global;
        if (a.PendingGetBeacon) return a.PendingGetBeacon
    }
    var Dh = function(a) {
        this.context = a
    };
    Dh.prototype.L = function(a) {
        return Eh && !Dg(this.context) && Ch(this.context) !== void 0 && !(a == null ? 0 : a.Wb) && (a == null ? void 0 : a.ha) !== "POST" && !(a == null ? 0 : a.cb) && !(a == null ? 0 : a.Yc)
    };
    Dh.prototype.J = function(a, b) {
        if (!this.L(b)) throw new he;
        return new Fh(this.context, a)
    };
    var Eh = !1,
        Fh = function(a, b) {
            this.context = a;
            this.wb = b;
            a = Ch(this.context);
            if (a === void 0) throw Error();
            this.Ue = new a(this.rc(), {})
        };
    Fh.prototype.rc = function() {
        var a = this.wb;
        return (a.slice(-1)[0] === "&" ? a : a + "&") + "pbapi=1"
    };
    Fh.prototype.deactivate = function() {
        this.Ue.deactivate()
    };
    Fh.prototype.sendNow = function() {
        this.Ue.sendNow()
    };
    da.Object.defineProperties(Fh.prototype, {
        url: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.wb
            },
            set: function(a) {
                this.wb = a;
                this.Ue.setURL(this.rc())
            }
        },
        method: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "GET"
            },
            set: function(a) {
                if (a !== "GET") throw new he;
            }
        }
    });
    var Gh = function(a) {
        this.context = a
    };
    Gh.prototype.L = function(a) {
        if ((a == null ? 0 : a.Wb) || (a == null ? void 0 : a.ha) === "GET" || (a == null ? 0 : a.cb) || (a == null ? 0 : a.Yc) || (a == null ? 0 : a.keepAlive)) return !1;
        var b;
        return !Dg(this.context) && ((b = this.context.global.navigator) == null ? void 0 : b.sendBeacon) !== void 0
    };
    Gh.prototype.ping = function() {
        var a = this;
        return ad(B.apply(0, arguments).map(function(b) {
            var c;
            return (c = a.context.global.navigator) == null ? void 0 : c.sendBeacon(b)
        }).every(function(b) {
            return b
        }))
    };
    Gh.prototype.rd = function(a, b, c) {
        this.ping.apply(this, z(B.apply(3, arguments)))
    };

    function Hh(a) {
        return function(b) {
            return b.g(Ih(a, df(new L)))
        }
    }

    function U(a, b) {
        return function(c) {
            return c.g(Ih(a, ef(b)))
        }
    }

    function Ih(a, b) {
        function c(d) {
            return new K(function(e) {
                return d.subscribe(function(f) {
                    Wa(a, function() {
                        return void e.next(f)
                    }, 3)
                }, function(f) {
                    Wa(a, function() {
                        return void e.error(f)
                    }, 3)
                }, function() {
                    Wa(a, function() {
                        return void e.complete()
                    }, 3)
                })
            })
        }
        return J(c, pd(), b, ld(), c)
    };
    var V = function(a) {
        this.value = a
    };
    V.prototype.S = function(a) {
        return ad(this.value).g(U(a, 1))
    };
    var Jh = new V(!1);

    function Kh(a) {
        Ka.setTimeout(function() {
            throw a;
        }, 0)
    };
    bh();
    kh() || S("iPod");
    S("iPad");
    eh();
    dh();
    ch() && lh();
    var Lh = {},
        Mh = null,
        Nh = nh || oh || typeof Ka.btoa == "function",
        Ph = function(a) {
            var b;
            D(Pa(a), "encodeByteArray takes an array as a parameter");
            b === void 0 && (b = 0);
            Oh();
            b = Lh[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = "" + l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = "" + b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        Rh = function(a) {
            var b =
                a.length,
                c = b * 3 / 4;
            c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            Qh(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        Qh = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        m = Mh[l];
                    if (m != null) return m;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("R`" + l);
                }
                return k
            }
            Oh();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (h === 64 && e === -1) break;
                b(e << 2 | f >> 4);
                g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
            }
        },
        Oh = function() {
            if (!Mh) {
                Mh = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                    var d = a.concat(b[c].split(""));
                    Lh[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e],
                            g = Mh[f];
                        g === void 0 ? Mh[f] = e : D(g === e)
                    }
                }
            }
        };

    function Sh(a) {
        var b = Th(a);
        return b === null ? new V(null) : b.g(M(function(c) {
            c = c.Sa();
            if (Nh) c = Ka.btoa(c);
            else {
                for (var d = [], e = 0, f = 0; f < c.length; f++) {
                    var g = c.charCodeAt(f);
                    if (g > 255) throw Error("Q");
                    d[e++] = g
                }
                c = Ph(d)
            }
            return c
        }), Ue(1), U(a.h, 1))
    };

    function Uh(a) {
        var b = b === void 0 ? {} : b;
        if (typeof Event === "function") return new Event(a, b);
        if (typeof document !== "undefined") {
            var c = document.createEvent("CustomEvent");
            c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
            return c
        }
        throw Error();
    };
    var Vh = function(a) {
        this.value = a;
        this.Ee = new L
    };
    Vh.prototype.release = function() {
        this.Ee.next();
        this.Ee.complete();
        this.value = void 0
    };
    da.Object.defineProperties(Vh.prototype, {
        i: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.value
            }
        },
        released: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ee
            }
        }
    });
    var Wh = ["FRAME", "IMG", "IFRAME"],
        Xh = /^[01](px)?$/,
        Yh = function() {
            this.Rh = this.ef = this.ig = this.pf = !1
        },
        Zh = function() {
            var a = new Yh;
            a.pf = !0;
            a.ig = !0;
            return a
        };

    function $h(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }

    function ai(a, b) {
        b = b === void 0 ? !1 : b;
        if (a.tagName === "IMG") {
            if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
            var c;
            if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
        }
        var d, e;
        return Xh.test((d = a.getAttribute("width")) != null ? d : "") && Xh.test((e = a.getAttribute("height")) != null ? e : "")
    }

    function bi(a, b) {
        if (a.tagName === "IMG") return a.naturalWidth && a.naturalHeight ? !0 : !1;
        try {
            if (a.readyState) var c = a.readyState;
            else {
                var d, e;
                c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
            }
            return c === "complete"
        } catch (f) {
            return b === void 0 ? !1 : b
        }
    }

    function ci(a) {
        a || (a = function(b, c, d) {
            b.addEventListener(c, d)
        });
        return a
    }

    function di(a, b) {
        var c = Zh();
        c = c === void 0 ? new Yh : c;
        if (a = $h(a)) {
            var d = ci(d);
            for (var e = !1, f = function(x) {
                    e || (e = !0, b(x))
                }, g, h = 2, k = 0; k < Wh.length; ++k)
                if (Wh[k] === a.tagName) {
                    h = 3;
                    g = [a];
                    break
                }
            g || (g = a.querySelectorAll(Wh.join(",")));
            var l = 0,
                m = 0,
                u = !c.ef,
                r = a = !1;
            k = {};
            for (var t = 0; t < g.length; k = {
                    kd: void 0
                }, t++) {
                var w = g[t];
                if (!ai(w, c.ef))
                    if (k.kd = w.tagName === "IMG", bi(w, c.pf)) a = !0, k.kd && (u = !0);
                    else {
                        l++;
                        var v = function(x) {
                            return function(A) {
                                l--;
                                !l && u && f(h);
                                x.kd && (A = A && A.type === "error", m--, A || (u = !0), !m && r && u && f(h))
                            }
                        }(k);
                        d(w, "load", v);
                        k.kd && (m++, d(w, "error", v))
                    }
            }
            m === 0 && (u = !0);
            g = null;
            g = Ka.document.readyState === "complete";
            if (c.Rh && g) {
                if (m > 0) {
                    r = !0;
                    return
                }
                h = 5
            } else if (l === 0 && !a && g) h = 5;
            else if (l || !a) {
                d(Ka, "load", function() {
                    !c.ig || !m && u ? f(4) : r = !0
                });
                return
            }
            f(h)
        }
    };

    function ei(a, b, c) {
        if (a)
            for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
    }

    function fi(a, b) {
        ei(a, function(c) {
            try {
                return c === c.parent ? null : c.parent
            } catch (d) {}
            return null
        }, b)
    }

    function gi(a, b) {
        if (a.tagName == "IFRAME") b(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var c = 0; c < a.length && !b(a[c]); ++c);
        }
    }

    function hi(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function ii(a, b, c) {
        try {
            var d = JSON.parse(c.data)
        } catch (g) {}
        if (typeof d === "object" && d && d.type === "creativeLoad") {
            var e = hi(a);
            if (c.source && e) {
                var f;
                fi(c.source, function(g) {
                    try {
                        if (g.parent === e) return f = g, !0
                    } catch (h) {}
                });
                f && gi(a, function(g) {
                    if (g.contentWindow === f) return b(d), !0
                })
            }
        }
    }

    function ji(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    }
    var ki = function(a, b) {
        var c = ji(a);
        if (c)
            if (c.onCreativeLoad) c.onCreativeLoad(b);
            else {
                var d = b ? [b] : [],
                    e = function(f) {
                        for (var g = 0; g < d.length; ++g) try {
                            d[g](1, f)
                        } catch (h) {}
                        d = {
                            push: function(h) {
                                h(1, f)
                            }
                        }
                    };
                c.onCreativeLoad = function(f) {
                    d.push(f)
                };
                c.setAttribute("data-creative-load-listener", "");
                c.addEventListener("creativeLoad", function(f) {
                    e(f.detail)
                });
                Ka.addEventListener("message", function(f) {
                    ii(c, e, f)
                })
            }
    };
    var li = function(a, b) {
            var c = this;
            this.global = a;
            this.qd = b;
            this.ki = this.document ? Sd(ad(!0), Ld(this.document, "visibilitychange")).g(tg(this.qd.H, 748), M(function() {
                return c.document ? c.document.visibilityState : "visible"
            }), O()) : ad("visible");
            this.hi = this.document ? Ld(this.document, "DOMContentLoaded").g(tg(this.qd.H, 739), Ue(1)) : ad(Uh("DOMContentLoaded"))
        },
        mi = function(a) {
            return a.document ? a.document.readyState : "complete"
        },
        ni = function(a) {
            return a.document !== null && a.document.visibilityState !== void 0
        };
    li.prototype.querySelector = function(a) {
        return this.document ? this.document.querySelector(a) : null
    };
    li.prototype.querySelectorAll = function(a) {
        return this.document ? Mb(this.document.querySelectorAll(a)) : []
    };
    li.prototype.elementFromPoint = function(a, b) {
        if (!this.document || this.document === null || typeof this.document.elementFromPoint !== "function") return null;
        a = this.document.elementFromPoint(a, b);
        return a === null ? null : new Vh(a)
    };
    var oi = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            if (b.i === void 0 || !a.document) return ad(b).g(tg(a.qd.H, 749));
            var d = new dd(1),
                e = function() {
                    d.next(b)
                };
            c || ki(b.i, e);
            di(b.i, e);
            return d.g(tg(a.qd.H, 749), Ue(1))
        },
        pi = function(a, b) {
            a = a.document;
            if (!a) return ad(!1);
            var c = Sd(ad(null), Ld(a, "DOMContentLoaded", {
                    once: !0
                }), Ld(a, "load", {
                    once: !0
                })),
                d = new Vh({
                    document: a,
                    element: b
                });
            return c.g(M(function() {
                if (!d.i) return !1;
                var e = d.i,
                    f = e.document;
                e = e.element;
                var g, h, k = (h = (g = f.body) != null ? g : f.children[0]) != null ? h : f;
                try {
                    k.appendChild(e),
                        d.release()
                } catch (l) {}
                return !d.i
            }), N(function(e) {
                return e
            }), Ue(1), Re(!1), kf({
                complete: function() {
                    return void d.release()
                }
            }))
        },
        qi = function(a, b, c) {
            var d, e, f;
            return Fa(function(g) {
                if (g.u == 1) {
                    d = a.global.document.createElement("iframe");
                    e = new Promise(function(k) {
                        d.onload = k;
                        d.onerror = k
                    });
                    if (b instanceof db) var h = b.jg;
                    else throw Error("Unexpected type when unwrapping TrustedResourceUrl");
                    d.src = h.toString();
                    return ta(g, id(pi(a, d)), 2)
                }
                if (g.u != 3) {
                    if (!g.aa) return g.return();
                    d.style.display = "none";
                    return ta(g,
                        e, 3)
                }
                f = d.contentWindow;
                if (!f) return g.return();
                f.postMessage(c, "*");
                return g.return(d)
            })
        };
    da.Object.defineProperties(li.prototype, {
        document: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return ih(this.global, "document") ? this.global.document || null : null
            }
        }
    });
    var ri = {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };

    function si(a, b) {
        return a.left === b.left && a.top === b.top && a.width === b.width && a.height === b.height
    }

    function ti(a, b) {
        return {
            left: Math.max(a.left, b.left),
            top: Math.max(a.top, b.top),
            width: Math.max(0, Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)),
            height: Math.max(0, Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top))
        }
    }

    function ui(a, b) {
        return {
            left: Math.round(a.left + b.x),
            top: Math.round(a.top + b.y),
            width: a.width,
            height: a.height
        }
    };

    function vi(a, b) {
        var c = fh() || gh();
        try {
            if (a) {
                if (!b.top) return new yh(-12245933, -12245933, -12245933, -12245933);
                b = b.top
            }
            a: {
                var d = b;
                if (a && d !== null && d != d.top) {
                    if (!d.top) {
                        var e = new rh(-12245933, -12245933);
                        break a
                    }
                    d = d.top
                }
                try {
                    if (c === void 0 ? 0 : c) var f = (new rh(d.innerWidth, d.innerHeight)).round();
                    else {
                        var g = (d || window).document,
                            h = g.compatMode == "CSS1Compat" ? g.documentElement : g.body;
                        f = (new rh(h.clientWidth, h.clientHeight)).round()
                    }
                    e = f
                } catch (w) {
                    e = new rh(-12245933, -12245933)
                }
            }
            a = e;
            var k = a.height,
                l = a.width;
            if (l ===
                -12245933) return new yh(l, l, l, l);
            var m = uh(b.document);
            var u = vh(m.fc);
            var r = u.x,
                t = u.y;
            return new yh(t, r + l, t + k, r)
        } catch (w) {
            return new yh(-12245933, -12245933, -12245933, -12245933)
        }
    };

    function wi(a, b) {
        if (a) throw Error("S");
        b.push(65533)
    }

    function xi(a, b) {
        b = String.fromCharCode.apply(null, b);
        return a == null ? b : a + b
    }
    var yi = void 0,
        zi, Ai, Bi = typeof TextDecoder !== "undefined",
        Ci, Di = typeof String.prototype.isWellFormed === "function",
        Ei = typeof TextEncoder !== "undefined";
    var Fi = typeof Uint8Array !== "undefined",
        Ii = !mh && typeof btoa === "function",
        Ji = /[-_.]/g,
        Ki = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Li(a) {
        return Ki[a] || ""
    }

    function Mi(a) {
        if (!Ii) return Rh(a);
        var b = Ji.test(a) ? a.replace(Ji, Li) : a;
        try {
            var c = atob(b)
        } catch (d) {
            throw Error("U`" + a + "`" + d);
        }
        a = new Uint8Array(c.length);
        for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
        return a
    }
    var Ni = {};
    var Pi = function(a, b) {
        if (b !== Ni) throw Error("W");
        this.Kc = a;
        if (a != null && a.length === 0) throw Error("V");
        this.dontPassByteStringToStructuredClone = Oi
    };
    Pi.prototype.isEmpty = function() {
        return this.Kc == null
    };
    var Qi;

    function Oi() {};

    function Ri(a) {
        Hb(a, Pi);
        if (Ni !== Ni) throw Error("W");
        var b = a.Kc;
        b == null || Fi && b != null && b instanceof Uint8Array || (typeof b === "string" ? b = Mi(b) : (Bb("Cannot coerce to Uint8Array: " + Oa(b)), b = null));
        return (b == null ? b : a.Kc = b) || new Uint8Array(0)
    };
    var Si = function(a, b, c) {
        this.buffer = a;
        if (c && !b) throw Error("ea");
        this.Xf = b
    };

    function Ti(a, b) {
        if (typeof a === "string") return new Si(Mi(a), b);
        if (Array.isArray(a)) return new Si(new Uint8Array(a), b);
        if (a.constructor === Uint8Array) return new Si(a, !1);
        if (a.constructor === ArrayBuffer) return a = new Uint8Array(a), new Si(a, !1);
        if (a.constructor === Pi) return b = Ri(a), new Si(b, !0, a);
        if (a instanceof Uint8Array) return a = a.constructor === Uint8Array ? a : new Uint8Array(a.buffer, a.byteOffset, a.byteLength), new Si(a, !1);
        throw Error("fa");
    };

    function Ui() {
        return typeof BigInt === "function"
    };
    var Vi = typeof Ka.BigInt === "function" && typeof Ka.BigInt(0) === "bigint";
    var aj = Ng(function(a) {
            if (Vi) return Jg(Wi, Rg), Jg(Xi, Rg), a = BigInt(a), a >= Wi && a <= Xi;
            Jg(a, Qg);
            return a[0] === "-" ? Yi(a, Zi) : Yi(a, $i)
        }, "isSafeInt52"),
        Zi = Number.MIN_SAFE_INTEGER.toString(),
        Wi = Vi ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        $i = Number.MAX_SAFE_INTEGER.toString(),
        Xi = Vi ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function Yi(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
        c = Kg;
        Mg("Assertion fail:", "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." || c)
    };
    var bj = typeof Uint8Array.prototype.slice === "function",
        cj = 0,
        dj = 0,
        ej;

    function fj(a) {
        var b = a >>> 0;
        cj = b;
        dj = (a - b) / 4294967296 >>> 0
    }

    function gj(a) {
        if (a < 0) {
            fj(0 - a);
            var b = y(hj(cj, dj));
            a = b.next().value;
            b = b.next().value;
            cj = a >>> 0;
            dj = b >>> 0
        } else fj(a)
    }

    function ij(a) {
        D(a <= 8);
        return ej || (ej = new DataView(new ArrayBuffer(8)))
    }

    function jj(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : kj(a, b)
    }

    function lj(a, b) {
        var c = b & 2147483648;
        c && (a = ~a + 1 >>> 0, b = ~b >>> 0, a == 0 && (b = b + 1 >>> 0));
        a = jj(a, b);
        return typeof a === "number" ? c ? -a : a : c ? "-" + a : a
    }

    function kj(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else Ui() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), D(b), c = b + mj(c) + mj(a));
        return c
    }

    function mj(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function nj(a) {
        D(a.length > 0);
        if (a.length < 16) gj(Number(a));
        else if (Ui()) a = BigInt(a), cj = Number(a & BigInt(4294967295)) >>> 0, dj = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            D(a.length > 0);
            var b = +(a[0] === "-");
            dj = cj = 0;
            for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), dj *= 1E6, cj = cj * 1E6 + d, cj >= 4294967296 && (dj += Math.trunc(cj / 4294967296), dj >>>= 0, cj >>>= 0);
            b && (b = y(hj(cj, dj)), a = b.next().value, b = b.next().value, cj = a, dj = b)
        }
    }

    function hj(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    var oj = function(a, b, c, d) {
        this.F = this.ua = null;
        this.Md = !1;
        this.P = this.Da = this.Ja = 0;
        this.init(a, b, c, d)
    };
    n = oj.prototype;
    n.init = function(a, b, c, d) {
        var e = d === void 0 ? {} : d;
        d = e.Rc === void 0 ? !1 : e.Rc;
        e = e.zd === void 0 ? !1 : e.zd;
        this.Rc = d;
        this.zd = e;
        a && (this.F = a = Ti(a, this.zd), this.ua = a.buffer, this.Md = a.Xf, this.Ja = b || 0, this.Da = c !== void 0 ? this.Ja + c : this.ua.length, this.P = this.Ja)
    };
    n.be = function() {
        this.clear();
        pj.length < 100 && pj.push(this)
    };
    n.clear = function() {
        this.F = this.ua = null;
        this.Md = !1;
        this.P = this.Da = this.Ja = 0;
        this.Rc = !1
    };
    n.setEnd = function(a) {
        this.Da = a
    };
    n.reset = function() {
        this.P = this.Ja
    };
    n.Z = function() {
        return this.P
    };
    n.advance = function(a) {
        qj(this, this.P + a)
    };
    var rj = function(a, b) {
            var c = 0,
                d = 0,
                e = 0,
                f = a.ua,
                g = a.P;
            do {
                var h = f[g++];
                c |= (h & 127) << e;
                e += 7
            } while (e < 32 && h & 128);
            e > 32 && (d |= (h & 127) >> 4);
            for (e = 3; e < 32 && h & 128; e += 7) h = f[g++], d |= (h & 127) << e;
            qj(a, g);
            if (h < 128) return b(c >>> 0, d >>> 0);
            throw Error("ba");
        },
        qj = function(a, b) {
            a.P = b;
            if (b > a.Da) throw Error("ca`" + b + "`" + a.Da);
        },
        sj = function(a) {
            var b = a.ua,
                c = a.P,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 && b[c++] & 128 &&
                    b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error("ba");
            qj(a, c);
            return e
        },
        tj = function(a) {
            return sj(a) >>> 0
        },
        uj = function(a) {
            return rj(a, jj)
        },
        vj = function(a) {
            var b = a.ua,
                c = a.P,
                d = b[c + 0],
                e = b[c + 1],
                f = b[c + 2];
            b = b[c + 3];
            a.advance(4);
            return (d << 0 | e << 8 | f << 16 | b << 24) >>> 0
        },
        wj = function(a) {
            for (var b = 0, c = a.P, d = c + 10, e = a.ua; c < d;) {
                var f = e[c++];
                b |= f;
                if ((f & 128) === 0) return qj(a, c), !!(b & 127)
            }
            throw Error("ba");
        },
        xj = function(a) {
            return sj(a)
        },
        yj = function(a, b) {
            if (b < 0) throw Error("da`" + b);
            var c = a.P,
                d = c + b;
            if (d > a.Da) throw Error("ca`" +
                (a.Da - c) + "`" + b);
            a.P = d;
            return c
        };
    oj.prototype.lg = function(a, b) {
        var c = yj(this, a),
            d = D(this.ua);
        if (Bi) {
            var e;
            b ? (e = zi) || (e = zi = new TextDecoder("utf-8", {
                fatal: !0
            })) : (e = Ai) || (e = Ai = new TextDecoder("utf-8", {
                fatal: !1
            }));
            var f = c + a;
            d = c === 0 && f === d.length ? d : d.subarray(c, f);
            try {
                var g = e.decode(d)
            } catch (m) {
                if (b) {
                    if (yi === void 0) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (u) {}
                        try {
                            e.decode(new Uint8Array([97])), yi = !0
                        } catch (u) {
                            yi = !1
                        }
                    }
                    b = !yi
                }
                b && (zi = void 0);
                throw m;
            }
        } else {
            a = c + a;
            g = [];
            for (var h = null, k, l; c < a;) k = d[c++], k < 128 ? g.push(k) : k < 224 ? c >= a ? wi(b, g) : (l =
                d[c++], k < 194 || (l & 192) !== 128 ? (c--, wi(b, g)) : (k = (k & 31) << 6 | l & 63, D(k >= 128 && k <= 2047), g.push(k))) : k < 240 ? c >= a - 1 ? wi(b, g) : (l = d[c++], (l & 192) !== 128 || k === 224 && l < 160 || k === 237 && l >= 160 || ((e = d[c++]) & 192) !== 128 ? (c--, wi(b, g)) : (k = (k & 15) << 12 | (l & 63) << 6 | e & 63, D(k >= 2048 && k <= 65535), D(k < 55296 || k > 57343), g.push(k))) : k <= 244 ? c >= a - 2 ? wi(b, g) : (l = d[c++], (l & 192) !== 128 || (k << 28) + (l - 144) >> 30 !== 0 || ((e = d[c++]) & 192) !== 128 || ((f = d[c++]) & 192) !== 128 ? (c--, wi(b, g)) : (k = (k & 7) << 18 | (l & 63) << 12 | (e & 63) << 6 | f & 63, D(k >= 65536 && k <= 1114111), k -= 65536, g.push((k >>
                10 & 1023) + 55296, (k & 1023) + 56320))) : wi(b, g), g.length >= 8192 && (h = xi(h, g), g.length = 0);
            D(c === a, "expected " + c + " === " + a);
            g = xi(h, g)
        }
        return g
    };
    oj.prototype.Ce = function(a) {
        if (a == 0) return Qi || (Qi = new Pi(null, Ni));
        var b = yj(this, a);
        if (this.Rc && this.Md) b = this.ua.subarray(b, b + a);
        else {
            var c = D(this.ua);
            a = b + a;
            b = b === a ? new Uint8Array(0) : bj ? c.slice(b, a) : new Uint8Array(c.subarray(b, a))
        }
        Hb(b, Uint8Array);
        return b.length == 0 ? Qi || (Qi = new Pi(null, Ni)) : new Pi(b, Ni)
    };
    var pj = [];
    D(!0);
    var Aj = function(a, b, c, d) {
            if (pj.length) {
                var e = pj.pop();
                e.init(a, b, c, d);
                a = e
            } else a = new oj(a, b, c, d);
            this.m = a;
            this.eb = this.m.Z();
            this.l = this.pd = this.Jb = -1;
            zj(this, d)
        },
        zj = function(a, b) {
            b = b === void 0 ? {} : b;
            a.Wd = b.Wd === void 0 ? !1 : b.Wd
        },
        Cj = function(a, b, c, d) {
            if (Bj.length) {
                var e = Bj.pop();
                zj(e, d);
                e.m.init(a, b, c, d);
                return e
            }
            return new Aj(a, b, c, d)
        };
    Aj.prototype.be = function() {
        this.m.clear();
        this.l = this.Jb = this.pd = -1;
        Bj.length < 100 && Bj.push(this)
    };
    Aj.prototype.Z = function() {
        return this.m.Z()
    };
    Aj.prototype.reset = function() {
        this.m.reset();
        this.eb = this.m.Z();
        this.l = this.Jb = this.pd = -1
    };
    Aj.prototype.advance = function(a) {
        this.m.advance(a)
    };
    var Dj = function(a) {
            var b = a.m;
            if (b.P == b.Da) return !1;
            a.pd !== -1 && (b = a.m.Z(), a.m.P = a.eb, tj(a.m), a.l === 4 || a.l === 3 ? D(b === a.m.Z(), "Expected to not advance the cursor.  Group tags do not have values.") : D(b > a.m.Z(), "Expected to read the field, did you forget to call a read or skip method?"), a.m.P = b);
            a.eb = a.m.Z();
            b = tj(a.m);
            var c = b >>> 3,
                d = b & 7;
            if (!(d >= 0 && d <= 5)) throw Error("Y`" + d + "`" + a.eb);
            if (c < 1) throw Error("Z`" + c + "`" + a.eb);
            a.pd = b;
            a.Jb = c;
            a.l = d;
            return !0
        },
        Ej = function(a) {
            switch (a.l) {
                case 0:
                    a.l != 0 ? (Bb("Invalid wire type for skipVarintField"),
                        Ej(a)) : wj(a.m);
                    break;
                case 1:
                    D(a.l === 1);
                    a.m.advance(8);
                    break;
                case 2:
                    if (a.l != 2) Bb("Invalid wire type for skipDelimitedField"), Ej(a);
                    else {
                        var b = tj(a.m);
                        a.m.advance(b)
                    }
                    break;
                case 5:
                    D(a.l === 5);
                    a.m.advance(4);
                    break;
                case 3:
                    b = a.Jb;
                    do {
                        if (!Dj(a)) throw Error("$");
                        if (a.l == 4) {
                            if (a.Jb != b) throw Error("aa");
                            break
                        }
                        Ej(a)
                    } while (1);
                    break;
                default:
                    throw Error("Y`" + a.l + "`" + a.eb);
            }
        },
        Fj = function(a, b, c) {
            D(a.l == 2);
            var d = a.m.Da,
                e = tj(a.m),
                f = a.m.Z() + e,
                g = f - d;
            g <= 0 && (a.m.setEnd(f), c(b, a, void 0, void 0, void 0), g = f - a.m.Z());
            if (g) throw Error("X`" +
                e + "`" + (e - g));
            a.m.P = f;
            a.m.setEnd(d)
        },
        Gj = function(a) {
            D(a.l == 0);
            return sj(a.m)
        },
        Hj = function(a) {
            D(a.l == 0);
            return tj(a.m)
        },
        Ij = function(a) {
            D(a.l == 0);
            return uj(a.m)
        },
        Jj = function(a) {
            D(a.l == 0);
            return sj(a.m)
        };
    Aj.prototype.lg = function() {
        return Kj(this)
    };
    var Kj = function(a) {
        D(a.l == 2);
        var b = tj(a.m);
        return a.m.lg(b, !0)
    };
    Aj.prototype.Ce = function() {
        D(this.l == 2);
        var a = tj(this.m);
        return this.m.Ce(a)
    };
    var Lj = function(a, b, c) {
            D(a.l == 2);
            var d = tj(a.m);
            for (d = a.m.Z() + d; a.m.Z() < d;) c.push(b(a.m))
        },
        Bj = [];
    var Mj = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function Nj(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Oj = Nj("jas", void 0, !0),
        Pj = Nj("defaultInstance", "0di"),
        Qj = Nj("unknownBinaryFields", Symbol()),
        Rj = Nj("unknownBinaryThrottleKey", "0ub"),
        Sj = Nj("unknownBinaryThrottleKey", "0ubs"),
        Tj = Nj("unknownBinarySerializeBinaryThrottleKey", "0ubsb"),
        Uj = Nj("m_m", "Hj", !0),
        Vj = Nj("validPivotSelector", "vps"),
        Wj = Nj("lazilyParseLateLoadedExtensions");
    D(Math.round(Math.log2(Math.max.apply(Math, z(Object.values({
        oj: 1,
        nj: 2,
        mj: 4,
        sj: 8,
        vj: 16,
        qj: 32,
        aj: 64,
        kj: 128,
        ej: 256,
        uj: 512,
        fj: 1024,
        lj: 2048,
        rj: 4096
    }))))) === 12);
    var Xj = {
            Hh: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        Yj = Object.defineProperties,
        W = Mj ? F(Oj) : "Hh",
        Zj, ak = [];
    bk(ak, 7);
    Zj = Object.freeze(ak);

    function ck(a) {
        G(a, "state is only maintained on arrays.");
        return a[W] | 0
    }

    function dk(a, b) {
        D((b & 8388607) === b);
        G(a, "state is only maintained on arrays.");
        Mj || W in a || Yj(a, Xj);
        a[W] |= b
    }

    function bk(a, b) {
        D((b & 8388607) === b);
        G(a, "state is only maintained on arrays.");
        Mj || W in a || Yj(a, Xj);
        a[W] = b
    }

    function ek(a, b, c) {
        (c === void 0 || !c || b & 2048) && D(b & 64, "state for messages must be constructed");
        D((b & 5) === 0, "state for messages should not contain repeated field state");
        if (b & 64) {
            D(b & 64);
            c = b >> 13 & 1023 || 536870912;
            D(b & 64);
            var d = a.length;
            D(c + (b & 128 ? 0 : -1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
            b & 128 && D(typeof a[0] === "string", "arrays with a message_id bit must have a string in the first position, got: %s", a[0])
        }
    }

    function fk(a) {
        G(a, "state is only maintained on arrays.");
        var b = a[W] | 0;
        ek(a, b);
        return b
    }

    function gk(a) {
        G(a, "state is only maintained on arrays.");
        return !!((a[W] | 0) & 2)
    }

    function hk(a, b) {
        Cb(b);
        D(b > 0 && b <= 1023 || 536870912 === b, "pivot must be in the range [1, 1024) or NO_PIVOT got %s", b);
        return a & -8380417 | (b & 1023) << 13
    }
    var ik = Object.getOwnPropertyDescriptor(Array.prototype, "Qh");
    Object.defineProperties(Array.prototype, {
        Qh: {
            get: function() {
                var a = jk(this);
                return ik ? ik.get.call(this) + "|" + a : a
            },
            configurable: !0,
            enumerable: !1
        }
    });

    function jk(a) {
        function b(e, f) {
            e & c && d.push(f)
        }
        var c = ck(a),
            d = [];
        b(1, "IS_REPEATED_FIELD");
        b(2, "IS_IMMUTABLE_ARRAY");
        b(4, "IS_API_FORMATTED");
        b(512, "STRING_FORMATTED");
        b(1024, "GBIGINT_FORMATTED");
        b(1024, "BINARY");
        b(8, "ONLY_MUTABLE_VALUES");
        b(16, "UNFROZEN_SHARED");
        b(32, "MUTABLE_REFERENCES_ARE_OWNED");
        b(64, "CONSTRUCTED");
        b(128, "HAS_MESSAGE_ID");
        b(256, "FROZEN_ARRAY");
        b(2048, "HAS_WRAPPER");
        b(4096, "MUTABLE_SUBSTRUCTURES");
        c & 64 && (D(c & 64), a = c >> 13 & 1023 || 536870912, a !== 536870912 && d.push("pivot: " + a));
        return d.join(",")
    };
    var X = Mj && Math.random() < .5,
        Y = X ? Symbol() : void 0,
        kk, lk = typeof Uj === "symbol",
        mk = {};

    function Z(a) {
        var b = a[Uj],
            c = b === mk;
        D(!kk || c === a instanceof kk);
        if (lk && b && !c) throw Error("ia");
        return c
    }

    function nk(a) {
        return a != null && Z(a)
    }

    function ok(a, b) {
        Cb(a);
        D(a > 0);
        D(b === 0 || b === -1);
        return a + b
    }

    function pk(a, b) {
        D(b === qk || b === void 0);
        return a + (b ? 0 : -1)
    }

    function rk(a, b) {
        Cb(a);
        D(a >= 0);
        D(b === 0 || b === -1);
        return a - b
    }

    function sk(a, b) {
        if (b === void 0) {
            if (b = !tk(a)) D(Z(a)), a = X ? a[F(Y)] : a.o, G(a, "state is only maintained on arrays."), b = a[W] | 0, ek(a, b), b = !!(2 & b);
            return b
        }
        D(Z(a));
        var c = X ? a[F(Y)] : a.o;
        G(c, "state is only maintained on arrays.");
        var d = c[W] | 0;
        ek(c, d);
        D(b === d);
        return !!(2 & b) && !tk(a)
    }
    var uk = {};

    function tk(a) {
        var b = a.dh,
            c;
        (c = !b) || (D(Z(a)), a = X ? a[F(Y)] : a.o, G(a, "state is only maintained on arrays."), c = a[W] | 0, ek(a, c), c = !!(2 & c));
        D(c);
        D(b === void 0 || b === uk);
        return b === uk
    }

    function vk(a, b) {
        D(Z(a));
        var c = X ? a[F(Y)] : a.o;
        G(c, "state is only maintained on arrays.");
        var d = c[W] | 0;
        ek(c, d);
        D(b === !!(2 & d));
        a.dh = b ? uk : void 0
    }
    var wk = Symbol("exempted jspb subclass"),
        xk = typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";

    function yk() {}

    function zk(a, b) {
        var c = G(a);
        G(c, "state is only maintained on arrays.");
        c = c[W] | 0;
        b || D(!(c & 2 && c & 4 || c & 256) || Object.isFrozen(a));
        Ak(a)
    }

    function Ak(a) {
        G(a, "state is only maintained on arrays.");
        a = a[W] | 0;
        var b = a & 4,
            c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
        D(b && c <= 1 || !b && c === 0, "Expected at most 1 type-specific formatting bit, but got " + c + " with state: " + a)
    }
    var Bk = Object.freeze({}),
        Ck = Symbol("debugExtensions");

    function Dk(a, b, c) {
        D(b & 64);
        D(b & 64);
        var d = b & 128 ? 0 : -1;
        var e = a.length,
            f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        var g = e + (f ? -1 : 0),
            h = a[e - 1];
        D(!!f === (h != null && typeof h === "object" && h.constructor === Object));
        for (b = b & 128 ? 1 : 0; b < g; b++) h = a[b], c(rk(b, d), h);
        if (f) {
            a = a[e - 1];
            for (var k in a) !isNaN(k) && c(+k, a[k])
        }
    }
    var qk = {};

    function Ek(a, b) {
        G(a, "state is only maintained on arrays.");
        a = a[W] | 0;
        D(a & 64);
        a & 128 ? D(b === qk) : D(b === void 0)
    }

    function Fk(a) {
        D(a & 64);
        return a & 128 ? qk : void 0
    };
    var Gk = {};

    function Hk(a) {
        a = Error(a);
        Qb(a, "warning");
        return a
    }

    function Ik(a, b, c) {
        if (a != null) {
            var d;
            var e = (d = Gk) != null ? d : Gk = {};
            d = e[a] || 0;
            d >= b || (e[a] = d + 1, a = Error(c), Qb(a, "incident"), Kh(a))
        }
    };

    function Jk(a) {
        return Array.prototype.slice.call(a)
    };
    var Kk = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Lk = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        Mk = Number.isSafeInteger,
        Nk = Number.isFinite,
        Ok = Math.trunc,
        Pk = Number.MAX_SAFE_INTEGER;

    function Qk(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Rk(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function Sk(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    var Tk = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Uk(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Nk(a);
            case "string":
                return Tk.test(a);
            default:
                return !1
        }
    }

    function Vk(a) {
        if (!Nk(a)) throw a = "Expected enum as finite number but got " + Oa(a) + ": " + a, Hk(a);
        return a | 0
    }

    function Wk(a) {
        return a == null ? a : Nk(a) ? a | 0 : void 0
    }

    function Xk(a) {
        return "Expected int32 as finite number but got " + Oa(a) + ": " + a
    }

    function Yk(a) {
        if (typeof a !== "number") throw Hk(Xk(a));
        if (!Nk(a)) throw Hk(Xk(a));
        return a | 0
    }

    function Zk(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Nk(a) ? a | 0 : void 0
    }

    function $k(a) {
        return "Expected uint32 as finite number but got " + Oa(a) + ": " + a
    }

    function al(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Nk(a) ? a >>> 0 : void 0
    }

    function bl(a) {
        if (a[0] === "-") return !1;
        var b = a.length;
        return b < 20 ? !0 : b === 20 && Number(a.substring(0, 6)) < 184467
    }

    function cl(a) {
        D(a < 0 || !(0 < a && a < Pk));
        D(Number.isInteger(a));
        if (a < 0) {
            gj(a);
            var b = kj(cj, dj);
            a = Number(b);
            return Mk(a) ? a : b
        }
        b = String(a);
        if (bl(b)) return b;
        gj(a);
        return jj(cj, dj)
    }

    function dl(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Kk(64, a));
        if (Uk(a)) {
            if (b === "string") return D(Uk(a)), D(!0), b = Ok(Number(a)), Mk(b) ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), D(a.indexOf(".") === -1), b = a.length, (a[0] === "-" ? b < 20 || b === 20 && Number(a.substring(0, 7)) > -922337 : b < 19 || b === 19 && Number(a.substring(0, 6)) < 922337) || (nj(a), a = cj, b = dj, b & 2147483648 ? Ui() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = y(hj(a, b)), a = b.next().value, b = b.next().value, a = "-" + kj(a, b)) :
                a = kj(a, b))), a;
            if (b === "number") return D(Uk(a)), D(!0), a = Ok(a), Mk(a) || (D(!Mk(a)), D(Number.isInteger(a)), gj(a), a = lj(cj, dj)), a
        }
    }

    function el(a) {
        if (a == null) return a;
        var b = typeof a;
        if (b === "bigint") return String(Lk(64, a));
        if (Uk(a)) {
            if (b === "string") return D(Uk(a)), D(!0), b = Ok(Number(a)), Mk(b) && b >= 0 ? a = String(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), D(a.indexOf(".") === -1), bl(a) || (nj(a), a = kj(cj, dj))), a;
            if (b === "number") return D(Uk(a)), D(!0), a = Ok(a), a >= 0 && Mk(a) ? a : cl(a)
        }
    }

    function fl(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function gl(a, b) {
        if (!(a instanceof b)) throw Error("na`" + Rk(b) + "`" + (a && Rk(a.constructor)));
    }

    function hl(a, b, c) {
        if (nk(a)) return a;
        if (Array.isArray(a)) {
            G(a, "state is only maintained on arrays.");
            var d = a[W] | 0;
            c = d | c & 32 | c & 2;
            c !== d && bk(a, c);
            return new b(a)
        }
    };
    var il = function(a, b) {
            this.oc = a >>> 0;
            this.hc = b >>> 0
        },
        kl = function(a) {
            if (!a) return jl || (jl = new il(0, 0));
            if (!/^\d+$/.test(a)) return null;
            nj(a);
            return new il(cj, dj)
        },
        jl, ll = function(a, b) {
            this.oc = a >>> 0;
            this.hc = b >>> 0
        },
        nl = function(a) {
            if (!a) return ml || (ml = new ll(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            nj(a);
            return new ll(cj, dj)
        },
        ml;
    var ol = function() {
        this.F = []
    };
    ol.prototype.length = function() {
        return this.F.length
    };
    ol.prototype.end = function() {
        var a = this.F;
        this.F = [];
        return a
    };
    ol.prototype.Ua = function(a, b) {
        D(a == Math.floor(a));
        D(b == Math.floor(b));
        D(a >= 0 && a < 4294967296);
        for (D(b >= 0 && b < 4294967296); b > 0 || a > 127;) this.F.push(a & 127 | 128), a = (a >>> 7 | b << 25) >>> 0, b >>>= 7;
        this.F.push(a)
    };
    ol.prototype.Ye = function(a, b) {
        D(a == Math.floor(a));
        D(b == Math.floor(b));
        D(a >= 0 && a < 4294967296);
        D(b >= 0 && b < 4294967296);
        this.za(a);
        this.za(b)
    };
    var pl = function(a, b) {
            D(b == Math.floor(b));
            for (D(b >= 0 && b < 4294967296); b > 127;) a.F.push(b & 127 | 128), b >>>= 7;
            a.F.push(b)
        },
        ql = function(a, b) {
            D(b == Math.floor(b));
            D(b >= -2147483648 && b < 2147483648);
            if (b >= 0) pl(a, b);
            else {
                for (var c = 0; c < 9; c++) a.F.push(b & 127 | 128), b >>= 7;
                a.F.push(1)
            }
        };
    n = ol.prototype;
    n.za = function(a) {
        D(a == Math.floor(a));
        D(a >= 0 && a < 4294967296);
        this.F.push(a >>> 0 & 255);
        this.F.push(a >>> 8 & 255);
        this.F.push(a >>> 16 & 255);
        this.F.push(a >>> 24 & 255)
    };
    n.Jg = function(a) {
        D(a == Math.floor(a));
        D(a >= 0 && a < 1.8446744073709552E19);
        fj(a);
        this.za(cj);
        this.za(dj)
    };
    n.Hg = function(a) {
        D(a == Math.floor(a));
        D(a >= -2147483648 && a < 2147483648);
        this.F.push(a >>> 0 & 255);
        this.F.push(a >>> 8 & 255);
        this.F.push(a >>> 16 & 255);
        this.F.push(a >>> 24 & 255)
    };
    n.Ig = function(a) {
        D(a == Math.floor(a));
        D(a >= -0x7fffffffffffffff && a < 0x7fffffffffffffff);
        gj(a);
        this.Ye(cj, dj)
    };
    n.Xe = function(a) {
        D(a == Infinity || a == -Infinity || isNaN(a) || typeof a === "number" && a >= -3.4028234663852886E38 && a <= 3.4028234663852886E38);
        var b = ij(4);
        b.setFloat32(0, +a, !0);
        dj = 0;
        cj = b.getUint32(0, !0);
        this.za(cj)
    };
    n.We = function(a) {
        D(typeof a === "number" || a === "Infinity" || a === "-Infinity" || a === "NaN");
        var b = ij(8);
        b.setFloat64(0, +a, !0);
        cj = b.getUint32(0, !0);
        dj = b.getUint32(4, !0);
        this.za(cj);
        this.za(dj)
    };
    n.Ve = function(a) {
        D(typeof a === "boolean" || typeof a === "number");
        this.F.push(a ? 1 : 0)
    };
    n.Cd = function(a) {
        D(a == Math.floor(a));
        D(a >= -2147483648 && a < 2147483648);
        ql(this, a)
    };
    var rl = function() {
            this.Ld = [];
            this.tb = 0;
            this.C = new ol
        },
        sl = function(a, b) {
            b.length !== 0 && (a.Ld.push(b), a.tb += b.length)
        },
        ul = function(a, b) {
            tl(a, b, 2);
            b = a.C.end();
            sl(a, b);
            b.push(a.tb);
            return b
        },
        vl = function(a, b) {
            var c = b.pop();
            c = a.tb + a.C.length() - c;
            for (D(c >= 0); c > 127;) b.push(c & 127 | 128), c >>>= 7, a.tb++;
            b.push(c);
            a.tb++
        },
        tl = function(a, b, c) {
            D(b >= 1 && b == Math.floor(b));
            pl(a.C, b * 8 + c)
        },
        wl = function(a, b, c) {
            if (c != null) switch (tl(a, b, 0), typeof c) {
                case "number":
                    a = a.C;
                    D(c == Math.floor(c));
                    D(c >= 0 && c < 1.8446744073709552E19);
                    gj(c);
                    a.Ua(cj, dj);
                    break;
                case "bigint":
                    c = BigInt.asUintN(64, c);
                    c = new il(Number(c & BigInt(4294967295)), Number(c >> BigInt(32)));
                    a.C.Ua(c.oc, c.hc);
                    break;
                default:
                    c = kl(c), a.C.Ua(c.oc, c.hc)
            }
        };
    n = rl.prototype;
    n.Hg = function(a, b) {
        b != null && (xl(a, b, b >= -2147483648 && b < 2147483648), b != null && (yl(a, b), tl(this, a, 0), ql(this.C, b)))
    };
    n.Ig = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    xl(a, b, nl(b));
                    break;
                case "number":
                    xl(a, b, b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    break;
                default:
                    xl(a, b, b >= BigInt(-0x7fffffffffffffff) && b < BigInt(0x7fffffffffffffff))
            }
            if (b != null) switch (tl(this, a, 0), typeof b) {
                case "number":
                    a = this.C;
                    D(b == Math.floor(b));
                    D(b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
                    gj(b);
                    a.Ua(cj, dj);
                    break;
                case "bigint":
                    b = BigInt.asUintN(64, b);
                    b = new ll(Number(b & BigInt(4294967295)), Number(b >> BigInt(32)));
                    this.C.Ua(b.oc,
                        b.hc);
                    break;
                default:
                    b = nl(b), this.C.Ua(b.oc, b.hc)
            }
        }
    };
    n.za = function(a, b) {
        b != null && (xl(a, b, b >= 0 && b < 4294967296), b != null && (tl(this, a, 0), pl(this.C, b)))
    };
    n.Jg = function(a, b) {
        if (b != null) {
            switch (typeof b) {
                case "string":
                    xl(a, b, kl(b));
                    break;
                case "number":
                    xl(a, b, b >= 0 && b < 1.8446744073709552E19);
                    break;
                default:
                    xl(a, b, b >= BigInt(0) && b < BigInt(1.8446744073709552E19))
            }
            wl(this, a, b)
        }
    };
    n.Xe = function(a, b) {
        b != null && (tl(this, a, 5), this.C.Xe(b))
    };
    n.We = function(a, b) {
        b != null && (tl(this, a, 1), this.C.We(b))
    };
    n.Ve = function(a, b) {
        b != null && (xl(a, b, typeof b === "boolean" || typeof b === "number"), tl(this, a, 0), this.C.Ve(b))
    };
    n.Cd = function(a, b) {
        b != null && (b = parseInt(b, 10), yl(a, b), tl(this, a, 0), ql(this.C, b))
    };
    n.Ye = function(a, b) {
        tl(this, a, 1);
        this.C.Ye(b)
    };
    n.Ua = function(a, b) {
        tl(this, a, 0);
        this.C.Ua(b)
    };

    function yl(a, b) {
        xl(a, b, b === Math.floor(b));
        xl(a, b, b >= -2147483648 && b < 2147483648)
    }

    function xl(a, b, c) {
        c || Bb("for [" + b + "] at [" + a + "]")
    };

    function zl() {
        var a = function() {
            throw Error("oa");
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var Al = zl(),
        Bl = zl(),
        Cl = zl(),
        Dl = zl(),
        El = zl(),
        Fl = zl(),
        Gl = zl(),
        Hl = zl(),
        Il = zl(),
        Jl = zl(),
        Kl = zl(),
        Ll = zl();

    function Ml(a) {
        return a
    }
    Ml[Vj] = {};

    function Nl(a) {
        return a
    };
    var Ol = function() {
        throw Error("pa");
    };
    if (xk) {
        var Pl = function() {
                throw Error("qa");
            },
            Ql = {};
        Object.defineProperties(Ol, (Ql[Symbol.hasInstance] = {
            value: Pl,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, Ql));
        D(Ol[Symbol.hasInstance] === Pl, "defineProperties did not work: was it monkey-patched?")
    };

    function Rl(a) {
        var b = Ra(Qj);
        return b ? G(a)[b] : void 0
    }
    var Sl = function() {},
        Tl = function(a, b) {
            for (var c in a) !isNaN(c) && b(a, +c, G(a[c]))
        },
        Ul = function(a) {
            var b = new Sl;
            Tl(a, function(c, d, e) {
                b[d] = Jk(e)
            });
            b.Ge = a.Ge;
            return b
        },
        Vl = {
            Bi: !0
        };

    function Wl(a, b, c) {
        var d = d === void 0 ? !1 : d;
        if (Ra(Wj) && Ra(Qj) && c === Wj) {
            D(Z(a));
            c = X ? a[F(Y)] : a.o;
            var e = c[Qj];
            if (!e) return;
            if (e = e.Ge) try {
                e(c, b, Vl);
                return
            } catch (f) {
                throw Error("ra`" + b);
            }
        }
        d && (D(Z(a)), D(Z(a)), a = X ? a[F(Y)] : a.o, G(a), (d = Ra(Qj)) && d in a && (a = a[d]) && delete a[b])
    }

    function Xl(a, b) {
        D(Z(a));
        D(Z(a));
        a = X ? a[F(Y)] : a.o;
        G(a);
        var c = Ra(Qj),
            d;
        Mj && c && ((d = a[c]) == null ? void 0 : d[b]) != null && Ik(Rj, 3, "0ub:" + b)
    }

    function Yl(a, b) {
        b < 100 || Ik(Sj, 1, "0ubs:" + b)
    };

    function Zl(a, b, c, d, e) {
        var f = d !== void 0;
        d = !!d;
        var g = Ra(Qj),
            h;
        !f && Mj && g && (h = a[g]) && Tl(h, Yl);
        g = [];
        var k = a.length;
        h = 4294967295;
        var l = !1,
            m = !!(b & 64);
        if (m) {
            D(b & 64);
            var u = b & 128 ? 0 : -1
        } else u = void 0;
        if (!(b & 1)) {
            var r = k && a[k - 1];
            r != null && typeof r === "object" && r.constructor === Object ? (k--, h = k) : r = void 0;
            if (m && !(b & 128) && !f) {
                l = !0;
                var t;
                b = (t = $l) != null ? t : Ml;
                h = ok(b(rk(h, F(u)), F(u), a, r, e), F(u))
            }
        }
        e = void 0;
        for (t = 0; t < k; t++)
            if (b = a[t], b != null && (b = c(b, d)) != null)
                if (m && t >= h) {
                    am();
                    var w = rk(t, F(u)),
                        v = void 0;
                    ((v = e) != null ? v : e = {})[w] =
                    b
                } else g[t] = b;
        if (r)
            for (var x in r) k = r[x], k != null && (k = c(k, d)) != null && (t = +x, b = void 0, m && !Number.isNaN(t) && (b = ok(t, F(u))) < h ? (am(), g[F(b)] = k) : (t = void 0, ((t = e) != null ? t : e = {})[x] = k));
        e && (l ? g.push(e) : (D(h < 4294967295), g[h] = e));
        f && Ra(Qj) && (G(g), G(a), D(g[Qj] === void 0), (a = Rl(a)) && a instanceof Sl && (g[Qj] = Ul(a)));
        return g
    }

    function bm(a) {
        F(a);
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return aj(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    zk(a);
                    G(a, "state is only maintained on arrays.");
                    var b = a[W] | 0;
                    return a.length === 0 && b & 1 ? void 0 : Zl(a, b, bm)
                }
                if (nk(a)) return cm(a);
                if (a instanceof Pi) {
                    b = a.Kc;
                    if (b == null) a = "";
                    else if (typeof b === "string") a = b;
                    else {
                        if (Ii) {
                            for (var c = "", d = 0, e = b.length - 10240; d < e;) c += String.fromCharCode.apply(null, b.subarray(d, d += 10240));
                            c +=
                                String.fromCharCode.apply(null, d ? b.subarray(d) : b);
                            b = btoa(c)
                        } else b = Ph(b);
                        a = a.Kc = b
                    }
                    return a
                }
                D(!(a instanceof Uint8Array));
                return
        }
        return a
    }
    var $l;

    function dm(a) {
        D(!$l);
        return cm(a)
    }

    function cm(a) {
        D(Z(a));
        var b = X ? a[F(Y)] : a.o;
        G(b, "state is only maintained on arrays.");
        var c = b[W] | 0;
        ek(b, c);
        return Zl(b, c, bm, void 0, a.constructor)
    }

    function am() {
        var a, b = (a = $l) != null ? a : Ml;
        D(b !== Nl)
    };
    if (typeof Proxy !== "undefined") {
        var fm = em;
        new Proxy({}, {
            getPrototypeOf: fm,
            setPrototypeOf: fm,
            isExtensible: fm,
            preventExtensions: fm,
            getOwnPropertyDescriptor: fm,
            defineProperty: fm,
            has: fm,
            get: fm,
            set: fm,
            deleteProperty: fm,
            apply: fm,
            construct: fm
        })
    }

    function em() {
        throw Error("wa");
    };
    var gm, hm;

    function im(a) {
        switch (typeof a) {
            case "boolean":
                return gm || (gm = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? hm || (hm = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return G(a), D(a.length === 2 || a.length === 3 && a[2] === !0), D(a[0] == null || typeof a[0] === "number" && a[0] >= 0), D(a[1] == null || typeof a[1] === "string"), a
        }
    }

    function jm(a, b, c) {
        G(b);
        return a = km(a, b[0], b[1], c ? 1 : 2)
    }

    function km(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a != null)
            for (var e = 0; e < a.length; e++) {
                var f = a[e];
                Array.isArray(f) && zk(f)
            }
        if (a == null) e = 32, c ? (a = [c], e |= 128) : a = [], b && (e = hk(e, b));
        else {
            if (!Array.isArray(a)) throw Error("xa`" + JSON.stringify(a) + "`" + Oa(a));
            e = a;
            G(e, "state is only maintained on arrays.");
            e = e[W] | 0;
            if (Vg && 1 & e) throw Error("ya");
            2048 & e && !(2 & e) && lm();
            if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a)) throw Error("za");
            if (e & 256) throw Error("Aa");
            if (e & 64) return d !== 0 || e & 2048 || bk(a, e |= 2048), ek(a,
                e), a;
            if (c && (e |= 128, c !== a[0])) throw Error("Ba`" + c + "`" + JSON.stringify(a[0]) + "`" + Oa(a[0]));
            a: {
                c = a;e |= 64;
                var g = c.length;
                if (g) {
                    var h = g - 1;
                    f = c[h];
                    if (f != null && typeof f === "object" && f.constructor === Object) {
                        D(e & 64);
                        b = e & 128 ? 0 : -1;
                        g = rk(h, b);
                        if (g >= 1024) throw Error("Da`" + g);
                        for (var k in f) h = +k, h < g && (h = ok(h, b), D(c[h] == null), c[h] = f[k], delete f[k]);
                        e = hk(e, g);
                        break a
                    }
                }
                if (b) {
                    D(e & 64);
                    k = Math.max(b, rk(g, e & 128 ? 0 : -1));
                    if (k > 1024) throw Error("Ea`" + g);
                    e = hk(e, k)
                }
            }
        }
        e |= 64;
        d === 0 && (e |= 2048);
        bk(a, e);
        return a
    }

    function lm() {
        if (Vg) throw Error("Ca");
    };

    function mm(a) {
        D(!(2 & a));
        D(!(2048 & a));
        return !(4096 & a) && !(16 & a)
    }

    function nm(a, b) {
        F(a);
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            zk(a);
            G(a, "state is only maintained on arrays.");
            var c = a[W] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (b && mm(c) ? (dk(a, 34), c & 4 && Object.freeze(a)) : a = om(a, c, !1, b && !(c & 16)));
            return a
        }
        if (nk(a)) return D(nk(a)), D(Z(a)), b = X ? a[F(Y)] : a.o, G(b, "state is only maintained on arrays."), c = b[W] | 0, ek(b, c), sk(a, c) ? a : pm(a, b, c) ? qm(a, b) : om(b, c);
        if (a instanceof Pi) return a;
        D(!(a instanceof Uint8Array))
    }

    function qm(a, b, c) {
        a = new a.constructor(b);
        c && vk(a, !0);
        a.di = uk;
        return a
    }

    function om(a, b, c, d) {
        var e = b;
        G(a, "state is only maintained on arrays.");
        D(e === (a[W] | 0));
        d != null || (d = !!(34 & b));
        a = Zl(a, b, nm, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        bk(a, b);
        return a
    }

    function rm(a) {
        if (!tk(a)) return !1;
        var b;
        D(Z(a));
        var c = b = X ? a[F(Y)] : a.o;
        G(c, "state is only maintained on arrays.");
        var d = c[W] | 0;
        ek(c, d);
        D(d & 2);
        b = om(b, d);
        dk(b, 2048);
        D(Z(a));
        G(b);
        X ? a[F(Y)] = b : a.o = b;
        vk(a, !1);
        a.di = void 0;
        return !0
    }

    function sm(a) {
        if (!rm(a)) {
            D(Z(a));
            var b = X ? a[F(Y)] : a.o;
            G(b, "state is only maintained on arrays.");
            var c = b[W] | 0;
            ek(b, c);
            if (sk(a, c)) throw Error("ja");
        }
    }

    function tm(a, b) {
        if (b === void 0) G(a, "state is only maintained on arrays."), b = a[W] | 0, ek(a, b, !0);
        else {
            var c = b;
            G(a, "state is only maintained on arrays.");
            var d = a[W] | 0;
            ek(a, d, !0);
            D(c === d)
        }
        D(!(b & 2));
        b & 32 && !(b & 4096) && bk(a, b | 4096)
    }

    function pm(a, b, c) {
        return wk && a[wk] ? !1 : c & 2 ? !0 : c & 32 && !(c & 4096) ? (bk(b, c | 2), vk(a, !0), !0) : !1
    };
    var vm = function(a, b) {
            D(Object.isExtensible(a));
            D(Z(a));
            a = X ? a[F(Y)] : a.o;
            b = um(a, 0, b);
            (a = b !== null) || (a = void 0);
            if (a) return b
        },
        um = function(a, b, c, d, e) {
            Ek(a, d);
            if (c === -1) return null;
            b = pk(c, d);
            G(a, "state is only maintained on arrays.");
            var f = a[W] | 0;
            D(f & 64);
            D(b === ok(c, f & 128 ? 0 : -1));
            D(b >= 0);
            f = a.length - 1;
            if (!(f < pk(1, d))) {
                if (b >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        d = g[c];
                        var h = !0
                    } else if (b === f) d = g;
                    else return
                } else d = a[b];
                if (e && d != null) {
                    e = e(d);
                    if (e == null) return e;
                    if (!Object.is(e,
                            d)) return h ? g[c] = e : a[b] = e, e
                }
                return d
            }
        },
        xm = function(a, b, c) {
            sm(a);
            D(Z(a));
            var d = X ? a[F(Y)] : a.o;
            G(d, "state is only maintained on arrays.");
            var e = d[W] | 0;
            ek(d, e);
            wm(d, e, b, c);
            return a
        };

    function wm(a, b, c, d, e) {
        Ek(a, e);
        var f = pk(c, e);
        G(a, "state is only maintained on arrays.");
        var g = a[W] | 0;
        D(g & 64);
        D(f === ok(c, g & 128 ? 0 : -1));
        D(f >= 0);
        g = a.length - 1;
        if (g >= pk(1, e) && f >= g) {
            var h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && ((g = b) == null && (G(a, "state is only maintained on arrays."), b = a[W] | 0, ek(a, b), g = b), D(g & 64), g = g >> 13 & 1023 || 536870912, c >= g ? (D(g !== 536870912), d != null && (f = {}, a[pk(g, e)] = (f[c] = d, f))) : a[f] = d);
        return b
    }
    var zm = function(a, b, c, d) {
        D(Z(a));
        a = X ? a[F(Y)] : a.o;
        G(a, "state is only maintained on arrays.");
        var e = a[W] | 0;
        ek(a, e);
        return ym(a, e, b, c, d) !== void 0
    };

    function Am(a, b) {
        if (!a) return a;
        D(gk(b) ? sk(a) : !0);
        return a
    }

    function Bm(a, b, c) {
        c = c === void 0 ? !1 : c;
        zk(a, c);
        G(a, "state is only maintained on arrays.");
        var d = a[W] | 0;
        D(d & 1);
        c || (D(Object.isFrozen(a) || d & 16), D(gk(b) ? Object.isFrozen(a) : !0))
    }
    var Dm = function(a, b) {
        G(a, "state is only maintained on arrays.");
        var c = a[W] | 0;
        ek(a, c, !0);
        return Cm(a, c, b)
    };

    function Em(a, b, c, d, e) {
        D(Z(a));
        var f = X ? a[F(Y)] : a.o;
        var g = f;
        G(g, "state is only maintained on arrays.");
        var h = g[W] | 0;
        ek(g, h);
        g = h;
        d = sk(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && rm(a) && (D(Z(a)), g = f = X ? a[F(Y)] : a.o, G(g, "state is only maintained on arrays."), a = g[W] | 0, ek(g, a), g = a);
        h = a = Fm(f, b);
        h === Zj ? h = 7 : (G(h, "state is only maintained on arrays."), h = h[W] | 0);
        var k = Gm(h, g);
        Ak(a);
        var l = 4 & k ? !1 : !0;
        if (l) {
            4 & k && (a = Jk(a), h = 0, k = Hm(k, g), g = F(wm(f, g, b, a)));
            for (var m = 0, u = 0; m < a.length; m++) {
                var r = c(a[m]);
                r != null && (a[u++] = r)
            }
            u < m && (a.length =
                u);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (bk(a, k), 2 & k && Object.freeze(a));
        a = Im(a, k, f, g, b, d, l, e);
        Ak(a);
        e || Bm(a, f);
        return a
    }

    function Im(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Jm(b) || (e = !a.length || g && !(4096 & b) || !!(32 & d) && mm(b), b |= e ? 2 : 256, b !== k && bk(a, b), Object.freeze(a)) : (f === 2 && Jm(b) && (a = Jk(a), k = 0, b = Hm(b, d), d = F(wm(c, d, e, a))), Jm(b) || (h || (b |= 16), b !== k && bk(a, b)));
        2 & b || mm(b) || tm(c, d);
        return a
    }

    function Fm(a, b, c) {
        a = um(a, 0, b, c);
        return Array.isArray(a) ? a : Zj
    }

    function Gm(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Jm(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Cm(a, b, c) {
        if (b & 2) throw Error("ja");
        var d = Fk(b),
            e = Fm(a, c, d);
        var f = e;
        f === Zj ? f = 7 : (G(f, "state is only maintained on arrays."), f = f[W] | 0);
        var g = Gm(f, b);
        if (2 & g || Jm(g) || 16 & g) e = Jk(e), f = 0, g = Hm(g, b), F(wm(a, b, c, e, d));
        g &= -13;
        g !== f && bk(e, g);
        return e
    }
    var Km = function(a, b, c) {
        G(a, "state is only maintained on arrays.");
        var d = a[W] | 0;
        ek(a, d, !0);
        var e = Fk(d),
            f = um(a, 0, c, e),
            g;
        if (nk(f)) {
            if (!sk(f)) return rm(f), D(Z(f)), X ? f[F(Y)] : f.o;
            D(Z(f));
            var h = g = X ? f[F(Y)] : f.o;
            G(h, "state is only maintained on arrays.");
            D((h[W] | 0) & 2)
        } else Array.isArray(f) && (g = f);
        g && (h = g, G(h, "state is only maintained on arrays."), h = h[W] | 0, h & 2 && (g = om(g, h)));
        g = jm(g, b, !0);
        g !== f && wm(a, d, c, g, e);
        return g
    };

    function ym(a, b, c, d, e) {
        var f = !1;
        d = um(a, 0, d, e, function(g) {
            var h = hl(g, c, b);
            f = h !== g && h != null;
            return h
        });
        if (d != null) return f && !sk(d) && tm(a, b), Am(d, a)
    }
    var Mm = function(a) {
            var b = Lm;
            D(Z(a));
            a = X ? a[F(Y)] : a.o;
            G(a, "state is only maintained on arrays.");
            var c = a[W] | 0;
            ek(a, c);
            (a = ym(a, c, b, 2)) || (a = b[Pj]) || (a = new b, D(Z(a)), c = X ? a[F(Y)] : a.o, dk(c, 34), a = b[Pj] = a);
            return a
        },
        Nm = function(a, b, c, d) {
            D(Z(a));
            var e = X ? a[F(Y)] : a.o;
            var f = e;
            G(f, "state is only maintained on arrays.");
            var g = f[W] | 0;
            ek(f, g);
            b = ym(e, g, b, c, d);
            if (b == null) return b;
            f = e;
            G(f, "state is only maintained on arrays.");
            g = f[W] | 0;
            ek(f, g);
            f = g;
            if (!sk(a, f)) {
                g = b;
                D(Z(g));
                var h = X ? g[F(Y)] : g.o;
                G(h, "state is only maintained on arrays.");
                var k = h[W] | 0;
                ek(h, k);
                g = sk(g, k) ? pm(g, h, k) ? qm(g, h, !0) : new g.constructor(om(h, k, !1)) : g;
                g !== b && (rm(a) && (D(Z(a)), a = e = X ? a[F(Y)] : a.o, G(a, "state is only maintained on arrays."), b = a[W] | 0, ek(a, b), f = b), b = g, f = wm(e, f, c, b, d), tm(e, f))
            }
            return Am(b, e)
        },
        Pm = function(a) {
            var b = Om;
            D(Z(a));
            var c = X ? a[F(Y)] : a.o;
            G(c, "state is only maintained on arrays.");
            var d = c[W] | 0;
            ek(c, d);
            sk(a, d);
            var e = !!e || !1;
            a = Fm(c, 10);
            var f = a;
            f === Zj ? f = 7 : (G(f, "state is only maintained on arrays."), f = f[W] | 0);
            var g = Gm(f, d),
                h = !(4 & g);
            if (h) {
                var k = a,
                    l = d,
                    m = !!(2 & g);
                m && (l |= 2);
                for (var u = !m, r = !0, t = 0, w = 0; t < k.length; t++) {
                    var v = hl(k[t], b, l);
                    if (v instanceof b) {
                        if (!m) {
                            var x = sk(v);
                            u && (u = !x);
                            r && (r = x)
                        }
                        k[w++] = v
                    }
                }
                w < t && (k.length = w);
                g |= 4;
                g = r ? g & -4097 : g | 4096;
                g = u ? g | 8 : g & -9
            }
            g !== f && (bk(a, g), 2 & g && Object.freeze(a));
            a = Im(a, g, c, d, 10, 1, h, e);
            if (!e) {
                b = a;
                d = !1;
                d = d === void 0 ? !1 : d;
                e = gk(c);
                f = gk(b);
                h = Object.isFrozen(b) && f;
                Bm(b, c, d);
                if (e || f) d ? D(f) : D(h);
                G(b, "state is only maintained on arrays.");
                D(!!((b[W] | 0) & 4));
                if (f && b.length)
                    for (d = 0; d < 1; d++) Am(b[d], c)
            }
            return a
        },
        Qm = function(a, b, c, d) {
            d !=
                null ? gl(d, F(b)) : d = void 0;
            xm(a, c, d);
            d && !sk(d) && (D(Z(a)), b = X ? a[F(Y)] : a.o, tm(b));
            return a
        };

    function Hm(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }
    var Rm = function(a, b, c) {
            c = c === void 0 ? !1 : c;
            var d;
            return (d = Sk(vm(a, b))) != null ? d : c
        },
        Sm = function(a, b) {
            var c = c === void 0 ? 0 : c;
            var d;
            return (d = Zk(vm(a, b))) != null ? d : c
        },
        Tm = function(a, b) {
            var c = c === void 0 ? "" : c;
            a = fl(vm(a, b));
            return a != null ? a : c
        },
        Um = function(a, b, c) {
            if (c != null && typeof c !== "boolean") throw Error("la`" + Oa(c) + "`" + c);
            return xm(a, b, c)
        },
        Vm = function(a, b, c) {
            if (c != null) {
                if (typeof c !== "number") throw Hk($k(c));
                if (!Nk(c)) throw Hk($k(c));
                c >>>= 0
            }
            return xm(a, b, c)
        },
        Wm = function(a, b, c) {
            if (c != null && typeof c !== "string") throw Error("ma`" +
                c + "`" + Oa(c));
            return xm(a, b, c)
        },
        Xm = function(a, b, c) {
            return xm(a, b, c == null ? c : Vk(c))
        },
        Ym = function(a, b, c) {
            sm(a);
            b = Em(a, b, Wk, 2, !0);
            b !== Zj && G(b, "state is only maintained on arrays.");
            if (Array.isArray(c))
                for (var d = c.length, e = 0; e < d; e++) b.push(Vk(c[e]));
            else
                for (c = y(c), d = c.next(); !d.done; d = c.next()) b.push(Vk(d.value));
            Ak(b);
            return a
        };
    var Zm = function(a, b, c) {
        this.preventPassingToStructuredClone = yk;
        Hb(this, Zm, "The message constructor should only be used by subclasses");
        D(this.constructor !== Zm, "Message is an abstract class and cannot be directly constructed");
        a = km(a, b, c);
        D(Z(this));
        G(a);
        X ? this[F(Y)] = a : this.o = a;
        D(Z(this));
        a = X ? this[F(Y)] : this.o;
        G(a, "state is only maintained on arrays.");
        b = a[W] | 0;
        ek(a, b);
        D(b & 64);
        D(b & 2048)
    };
    n = Zm.prototype;
    n.toJSON = function() {
        return dm(this)
    };
    n.Sa = function() {
        return JSON.stringify(dm(this))
    };
    n.getExtension = function(a) {
        Hb(this, a.yf);
        var b = Hb(this, Zm);
        Xl(b, a.ba);
        Wl(b, a.ba, a.ue);
        return a.bb ? a.ld ? a.Ab(b, a.bb, a.ba, void 0 === Bk ? 2 : 4, a.gb) : a.Ab(b, a.bb, a.ba, a.gb) : a.ld ? a.Ab(b, a.ba, void 0 === Bk ? 2 : 4, a.gb) : a.Ab(b, a.ba, a.defaultValue, a.gb)
    };
    n.hasExtension = function(a) {
        D(!a.ld, "repeated extensions don't support hasExtension");
        var b = Hb(this, Zm);
        Xl(b, a.ba);
        Wl(b, a.ba, a.ue);
        a.bb ? a = zm(b, a.bb, a.ba, a.gb) : (D(!a.ld, "repeated extensions don't support getExtensionOrUndefined"), Hb(b, a.yf), b = Hb(b, Zm), Xl(b, a.ba), Wl(b, a.ba, a.ue), a = a.bb ? a.Ab(b, a.bb, a.ba, a.gb) : a.Ab(b, a.ba, null, a.gb), a = (a === null ? void 0 : a) !== void 0);
        return a
    };
    n.clone = function() {
        var a = Hb(this, Zm);
        D(nk(a));
        D(Z(a));
        var b = X ? a[F(Y)] : a.o;
        G(b, "state is only maintained on arrays.");
        var c = b[W] | 0;
        ek(b, c);
        return pm(a, b, c) ? qm(a, b, !0) : new a.constructor(om(b, c, !1))
    };
    n.Xf = function() {
        return sk(this)
    };
    kk = Zm;
    Zm.prototype[Uj] = mk;
    Zm.prototype.toString = function() {
        D(Z(this));
        return (X ? this[F(Y)] : this.o).toString()
    };
    var $m = function(a, b, c, d) {
        this.Dd = a;
        this.Ed = b;
        a = Ra(Bl);
        this.Kg = !!a && d === a || !1
    };

    function an(a) {
        var b = bn;
        var c = c === void 0 ? Bl : c;
        return new $m(a, b, !1, c)
    }

    function bn(a, b, c, d, e) {
        b = cn(b, d);
        b != null && (c = ul(a, c), e(b, a), vl(a, c))
    }
    var gn = an(function(a, b, c, d, e) {
            if (a.l !== 2) return !1;
            Fj(a, Km(b, d, c), e);
            return !0
        }),
        hn = an(function(a, b, c, d, e) {
            if (a.l !== 2) return !1;
            Fj(a, Km(b, d, c), e);
            return !0
        }),
        jn = Symbol(),
        kn = Symbol(),
        ln = Symbol(),
        mn = Symbol(),
        nn = Symbol(),
        on, pn;

    function qn(a, b, c, d) {
        var e = d[a];
        if (e) return e;
        e = {};
        e.Vg = d;
        e.vc = D(im(d[0]));
        var f = d[1],
            g = 1;
        f && f.constructor === Object && (e.Zd = f, f = d[++g], typeof f === "function" && (on != null && (D(on === f), D(pn === d[1 + g])), e.Zf = !0, on != null || (on = f), pn != null || (pn = Eb(d[g + 1])), f = d[g += 2]));
        for (var h = {}; f && rn(f);) {
            for (var k = 0; k < f.length; k++) h[f[k]] = f;
            f = d[++g]
        }
        for (k = 1; f !== void 0;) {
            typeof f === "number" && (D(f > 0), k += f, f = d[++g]);
            var l = void 0;
            if (f instanceof $m) var m = f;
            else m = gn, g--;
            f = void 0;
            if ((f = m) == null ? 0 : f.Kg) {
                f = d[++g];
                l = d;
                var u = g;
                typeof f ===
                    "function" && (D(f.length === 0), f = f(), l[u] = f);
                sn(f);
                l = f
            }
            f = d[++g];
            u = k + 1;
            typeof f === "number" && f < 0 && (u -= f, f = d[++g]);
            for (; k < u; k++) {
                var r = h[k];
                l ? c(e, k, D(m), l, r) : b(e, k, D(m), r)
            }
        }
        return d[a] = e
    }

    function rn(a) {
        return Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    }

    function sn(a) {
        if (Array.isArray(a) && a.length) {
            var b = a[0];
            var c = im(b);
            c != null && c !== b && (a[0] = c);
            b = c != null
        } else b = !1;
        D(b);
        return a
    }

    function tn(a) {
        return Array.isArray(a) ? a[0] instanceof $m ? (D(a.length === 2), sn(a[1]), a) : [hn, sn(a)] : [Hb(a, $m), void 0]
    }

    function cn(a, b) {
        if (a instanceof Zm) return D(Z(a)), X ? a[F(Y)] : a.o;
        if (Array.isArray(a)) return jm(a, b, !1)
    };

    function un(a) {
        return qn(kn, vn, wn, a)
    }

    function vn(a, b, c, d) {
        var e = c.Dd;
        a[b] = d ? function(f, g, h) {
            return e(f, g, h, d)
        } : e
    }

    function wn(a, b, c, d, e) {
        var f = c.Dd,
            g, h;
        a[b] = function(k, l, m) {
            return f(k, l, m, h || (h = un(d).vc), g || (g = xn(d)), e)
        }
    }

    function xn(a) {
        var b = a[ln];
        if (b != null) return b;
        var c = un(a);
        b = c.Zf ? function(d, e) {
            return D(on)(d, e, c)
        } : function(d, e) {
            G(d, "state is only maintained on arrays.");
            var f = d[W] | 0;
            ek(d, f, !0);
            for (D(!(f & 2)); Dj(e) && e.l != 4;) {
                f = e.Jb;
                var g = c[f];
                if (g == null) {
                    var h = c.Zd;
                    h && (h = h[f]) && (h = yn(h), h != null && (g = c[f] = h))
                }
                if (g == null || !g(e, d, f)) {
                    h = e;
                    g = h.eb;
                    Ej(h);
                    if (h.Wd) var k = void 0;
                    else {
                        var l = h.m.Z(),
                            m = l - g;
                        h.m.P = g;
                        g = h.m.Ce(m);
                        D(l == h.m.Z());
                        k = g
                    }
                    l = h = g = void 0;
                    m = d;
                    G(m);
                    k && ((g = (h = (l = m[Qj]) != null ? l : m[Qj] = new Sl)[f]) != null ? g : h[f] = []).push(k)
                }
            }
            if (d = Rl(d)) d.Ge = F(c.Vg[nn]);
            return !0
        };
        a[ln] = b;
        a[nn] = zn.bind(a);
        return b
    }

    function zn(a, b, c, d) {
        var e = this[kn],
            f = this[ln],
            g = jm(void 0, e.vc, !1),
            h = Rl(a);
        if (h) {
            var k = !1,
                l = e.Zd;
            if (l) {
                e = function(w, v, x) {
                    if (x.length !== 0)
                        if (l[v])
                            for (w = y(x), v = w.next(); !v.done; v = w.next()) {
                                v = Cj(v.value);
                                try {
                                    k = !0, f(g, v)
                                } finally {
                                    v.be()
                                }
                            } else d == null || d(a, v, x)
                };
                if (b == null) Tl(h, e);
                else if (h != null) {
                    var m = h[b];
                    m && e(h, b, m)
                }
                if (k) {
                    var u = fk(a);
                    if (u & 2 && u & 2048 && (c == null || !c.Bi)) throw Error("Ga");
                    var r = Fk(u),
                        t = function(w, v) {
                            if (um(a, 0, w, r) != null) switch (c == null ? void 0 : c.ck) {
                                case 1:
                                    return;
                                default:
                                    throw Error("Ha`" +
                                        w);
                            }
                            v != null && (u = F(wm(a, u, w, v, r)));
                            delete h[w]
                        };
                    b == null ? Dk(g, fk(g), function(w, v) {
                        t(w, v)
                    }) : t(b, um(g, fk(g), b, r))
                }
            }
        }
    }

    function yn(a) {
        a = tn(a);
        var b = Hb(a[0], $m).Dd;
        if (a = a[1]) {
            var c = xn(sn(a)),
                d = un(sn(a)).vc;
            return function(e, f, g) {
                return b(e, f, g, d, c)
            }
        }
        return b
    };

    function An(a, b, c) {
        a[b] = c.Ed
    }

    function Bn(a, b, c, d) {
        var e, f, g = c.Ed;
        a[b] = function(h, k, l) {
            return g(h, k, l, f || (f = qn(jn, An, Bn, d).vc), e || (e = Cn(d)))
        }
    }

    function Cn(a) {
        var b = a[mn];
        if (!b) {
            var c = qn(jn, An, Bn, a);
            b = function(d, e) {
                return Dn(d, e, c)
            };
            a[mn] = b
        }
        return b
    }

    function Dn(a, b, c) {
        var d = ck(a);
        Dk(a, d, function(e, f) {
            if (f != null) {
                var g = En(c, e);
                g ? g(b, f, e) : (G(a), e < 500 || Ik(Tj, 3, "0ubsb:" + e))
            }
        });
        (d = Rl(a)) && Tl(d, function(e, f, g) {
            sl(b, b.C.end());
            for (e = 0; e < g.length; e++) sl(b, Ri(g[e]))
        })
    }

    function En(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.Zd)
            if (c = c[b]) {
                c = tn(c);
                var d = Hb(c[0], $m).Ed;
                if (c = c[1]) {
                    c = sn(c);
                    var e = Cn(c),
                        f = qn(jn, An, Bn, c).vc;
                    c = a.Zf ? D(pn)(f, e) : function(g, h, k) {
                        return d(g, h, k, f, e)
                    }
                } else c = d;
                return a[b] = c
            }
    };

    function Fn(a, b, c) {
        if (Array.isArray(b)) {
            G(b, "state is only maintained on arrays.");
            var d = b[W] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                var g = a(b[e]);
                g != null && (D(typeof g !== "object" || g instanceof Pi), b[f++] = g)
            }
            f < e && (b.length = f);
            c && (bk(b, (d | 5) & -1537), d & 2 && Object.freeze(b));
            return b
        }
    }

    function Gn(a, b, c) {
        return new $m(a, b, !1, c)
    }

    function Hn(a, b, c) {
        return new $m(a, b, Al, c)
    }

    function In(a, b, c) {
        G(a, "state is only maintained on arrays.");
        var d = a[W] | 0;
        ek(a, d, !0);
        G(a, "state is only maintained on arrays.");
        wm(a, d, b, c, Fk(a[W] | 0))
    }

    function Jn(a, b, c) {
        if (a.l !== 0 && a.l !== 2) return !1;
        b = Dm(b, c);
        a.l == 2 ? Lj(a, xj, b) : b.push(Jj(a));
        return !0
    }
    var Kn = Gn(function(a, b, c) {
            if (a.l !== 1) return !1;
            D(a.l == 1);
            var d = a.m;
            a = vj(d);
            var e = vj(d);
            d = (e >> 31) * 2 + 1;
            var f = e >>> 20 & 2047;
            a = 4294967296 * (e & 1048575) + a;
            In(b, c, f == 2047 ? a ? NaN : d * Infinity : f == 0 ? d * 4.9E-324 * a : d * Math.pow(2, f - 1075) * (a + 4503599627370496));
            return !0
        }, function(a, b, c) {
            a.We(c, Qk(b))
        }, Kl),
        Ln = Gn(function(a, b, c) {
            if (a.l !== 5) return !1;
            D(a.l == 5);
            var d = vj(a.m);
            a = (d >> 31) * 2 + 1;
            var e = d >>> 23 & 255;
            d &= 8388607;
            In(b, c, e == 255 ? d ? NaN : a * Infinity : e == 0 ? a * 1.401298464324817E-45 * d : a * Math.pow(2, e - 150) * (d + 8388608));
            return !0
        }, function(a,
            b, c) {
            a.Xe(c, Qk(b))
        }, Jl),
        Mn = Gn(function(a, b, c) {
            if (a.l !== 0) return !1;
            D(a.l == 0);
            a = rj(a.m, lj);
            In(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Ig(c, dl(b))
        }, Hl),
        Nn = Gn(function(a, b, c) {
            if (a.l !== 0) return !1;
            In(b, c, Ij(a));
            return !0
        }, function(a, b, c) {
            a.Jg(c, el(b))
        }, Il),
        On = Hn(function(a, b, c) {
            if (a.l !== 0 && a.l !== 2) return !1;
            b = Dm(b, c);
            a.l == 2 ? Lj(a, uj, b) : b.push(Ij(a));
            return !0
        }, function(a, b, c) {
            b = Fn(el, b, !1);
            if (b != null)
                for (var d = 0; d < b.length; d++) wl(a, c, b[d])
        }, Il),
        Pn = Gn(function(a, b, c) {
            if (a.l !== 0) return !1;
            In(b, c, Gj(a));
            return !0
        }, function(a,
            b, c) {
            a.Hg(c, Zk(b))
        }, El),
        Qn = Hn(function(a, b, c) {
            if (a.l !== 0 && a.l !== 2) return !1;
            b = Dm(b, c);
            a.l == 2 ? Lj(a, sj, b) : b.push(Gj(a));
            return !0
        }, function(a, b, c) {
            b = Fn(Zk, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) {
                    var e = a,
                        f = c,
                        g = b[d];
                    g != null && (yl(f, g), tl(e, f, 0), ql(e.C, g))
                }
        }, El),
        Rn = Gn(function(a, b, c) {
            if (a.l !== 5) return !1;
            D(a.l == 5);
            a = vj(a.m);
            In(b, c, a);
            return !0
        }, function(a, b, c) {
            b = al(b);
            b != null && (xl(c, b, b >= 0 && b < 4294967296), tl(a, c, 5), a.C.za(b))
        }, Gl),
        Sn = Gn(function(a, b, c) {
            if (a.l !== 0) return !1;
            D(a.l == 0);
            a = wj(a.m);
            In(b, c, a);
            return !0
        }, function(a, b, c) {
            a.Ve(c, Sk(b))
        }, Cl),
        Tn = Gn(function(a, b, c) {
            if (a.l !== 2) return !1;
            In(b, c, Kj(a));
            return !0
        }, function(a, b, c) {
            b = fl(b);
            if (b != null) {
                var d = !0;
                d = d === void 0 ? !1 : d;
                Db(b);
                if (Ei) {
                    if (d && (Di ? !b.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(b))) throw Error("T");
                    b = (Ci || (Ci = new TextEncoder)).encode(b)
                } else {
                    for (var e = 0, f = new Uint8Array(3 * b.length), g = 0; g < b.length; g++) {
                        var h = b.charCodeAt(g);
                        if (h < 128) f[e++] = h;
                        else {
                            if (h < 2048) f[e++] = h >> 6 | 192;
                            else {
                                D(h <
                                    65536);
                                if (h >= 55296 && h <= 57343) {
                                    if (h <= 56319 && g < b.length) {
                                        var k = b.charCodeAt(++g);
                                        if (k >= 56320 && k <= 57343) {
                                            h = (h - 55296) * 1024 + k - 56320 + 65536;
                                            f[e++] = h >> 18 | 240;
                                            f[e++] = h >> 12 & 63 | 128;
                                            f[e++] = h >> 6 & 63 | 128;
                                            f[e++] = h & 63 | 128;
                                            continue
                                        } else g--
                                    }
                                    if (d) throw Error("T");
                                    h = 65533
                                }
                                f[e++] = h >> 12 | 224;
                                f[e++] = h >> 6 & 63 | 128
                            }
                            f[e++] = h & 63 | 128
                        }
                    }
                    b = e === f.length ? f : f.subarray(0, e)
                }
                tl(a, c, 2);
                pl(a.C, b.length);
                sl(a, a.C.end());
                sl(a, b)
            }
        }, Dl),
        Un, Vn = void 0;
    Vn = Vn === void 0 ? Bl : Vn;
    Un = new $m(function(a, b, c, d, e) {
        if (a.l !== 2) return !1;
        d = jm(void 0, d, !0);
        G(b, "state is only maintained on arrays.");
        var f = b[W] | 0;
        ek(b, f, !0);
        Cm(b, f, c).push(d);
        Fj(a, d, e);
        return !0
    }, function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (var f = 0; f < b.length; f++) {
                var g = a,
                    h = c,
                    k = e,
                    l = cn(b[f], d);
                l != null && (h = ul(g, h), k(l, g), vl(g, h))
            }
    }, Al, Vn);
    var Wn = Gn(function(a, b, c) {
            if (a.l !== 0) return !1;
            In(b, c, Hj(a));
            return !0
        }, function(a, b, c) {
            a.za(c, al(b))
        }, Fl),
        Xn = Hn(function(a, b, c) {
            if (a.l !== 0 && a.l !== 2) return !1;
            b = Dm(b, c);
            a.l == 2 ? Lj(a, tj, b) : b.push(Hj(a));
            return !0
        }, function(a, b, c) {
            b = Fn(al, b, !0);
            if (b != null && b.length) {
                c = ul(a, c);
                for (var d = 0; d < b.length; d++) pl(a.C, b[d]);
                vl(a, c)
            }
        }, Fl),
        Yn = Gn(function(a, b, c) {
            if (a.l !== 0) return !1;
            In(b, c, Jj(a));
            return !0
        }, function(a, b, c) {
            a.Cd(c, Zk(b))
        }, Ll),
        Zn = Hn(Jn, function(a, b, c) {
            b = Fn(Zk, b, !0);
            if (b != null)
                for (var d = 0; d < b.length; d++) a.Cd(c,
                    b[d])
        }, Ll),
        $n = Hn(Jn, function(a, b, c) {
            b = Fn(Zk, b, !0);
            if (b != null && b.length) {
                c = ul(a, c);
                for (var d = 0; d < b.length; d++) a.C.Cd(b[d]);
                vl(a, c)
            }
        }, Ll);
    var co = function() {
        var a = ao,
            b = bo;
        D(!0);
        this.ba = 4156379;
        this.yf = a;
        this.bb = b;
        this.ld = 0;
        this.Ab = Nm;
        this.defaultValue = void 0;
        this.gb = a.Gj != null ? qk : void 0;
        this.ue = void 0;
        D(!0, "lazyParse must be undefined or LAZILY_PARSE_LATE_LOADED_EXTENSIONS_SYMBOL")
    };
    co.prototype.register = function() {
        hh(this)
    };

    function eo(a) {
        if (a instanceof Zm) return a.constructor.U
    };
    (function() {
        var a = Ka.jspbGetTypeName;
        Ka.jspbGetTypeName = a ? function(b) {
            return a(b) || eo(b)
        } : eo
    })();
    var fo = Zm;

    function go(a, b) {
        return function(c, d) {
            var e = {
                zd: !0
            };
            d && Object.assign(e, d);
            c = Cj(c, void 0, void 0, e);
            try {
                var f = new a;
                D(Z(f));
                var g = X ? f[F(Y)] : f.o;
                xn(b)(g, c);
                var h = f
            } finally {
                c.be()
            }
            return h
        }
    }

    function ho(a) {
        return function() {
            var b = new rl;
            var c = Hb(this, Zm);
            D(Z(c));
            c = X ? c[F(Y)] : c.o;
            Dn(c, b, qn(jn, An, Bn, a));
            sl(b, b.C.end());
            c = new Uint8Array(b.tb);
            for (var d = b.Ld, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            D(f == c.length);
            b.Ld = [c];
            return c
        }
    }

    function io(a) {
        return function(b) {
            Eb(a);
            if (b == null || b == "") b = Hb(new a, Zm);
            else {
                Db(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Fa`" + Oa(b) + "`" + b);
                dk(b, 32);
                b = new a(b)
            }
            return b
        }
    };
    var Om = function(a) {
        fo.call(this, a)
    };
    q(Om, fo);
    Om.prototype.Jf = function() {
        return Tm(this, 2)
    };
    Om.U = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var jo = [0, Tn, -1];
    Om.prototype.N = ho(jo);
    var ko = function(a) {
        fo.call(this, a)
    };
    q(ko, fo);
    var lo = function(a, b) {
            return Wm(a, 2, b)
        },
        mo = function(a, b) {
            return Wm(a, 3, b)
        },
        no = function(a, b) {
            return Wm(a, 4, b)
        },
        oo = function(a, b) {
            return Wm(a, 5, b)
        },
        po = function(a, b) {
            return Wm(a, 9, b)
        },
        qo = function(a, b) {
            var c = Om;
            sm(a);
            D(Z(a));
            var d = X ? a[F(Y)] : a.o;
            G(d, "state is only maintained on arrays.");
            var e = d[W] | 0;
            ek(d, e);
            if (b == null) wm(d, e, 10);
            else {
                var f = b;
                if (!Array.isArray(f)) throw a = "Expected array but got " + Oa(f) + ": " + f, Hk(a);
                f = b;
                f === Zj ? f = 7 : (G(f, "state is only maintained on arrays."), f = f[W] | 0);
                for (var g = f, h = Jm(f),
                        k = h || Object.isFrozen(b), l = !0, m = !0, u = 0; u < b.length; u++) {
                    var r = b[u];
                    gl(r, F(c));
                    h || (r = sk(r), l && (l = !r), m && (m = r))
                }
                h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
                k && f === g || (b = Jk(b), g = 0, f = Hm(f, e));
                f !== g && bk(b, f);
                zk(b);
                e = wm(d, e, 10, b);
                2 & f || mm(f) || tm(d, e)
            }
            return a
        },
        ro = function(a, b) {
            return Um(a, 11, b)
        },
        so = function(a, b) {
            return Wm(a, 1, b)
        },
        to = function(a, b) {
            return Um(a, 7, b)
        };
    ko.U = "wireless.mdl.UserAgentClientHints";
    ko.prototype.N = ho([0, Tn, -4, Un, jo, Sn, Yn, Tn, Un, jo, Sn]);
    var uo = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function vo(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function wo(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function xo(a) {
        if (!wo(a)) return null;
        var b = vo(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(uo).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function yo(a) {
        var b;
        return ro(qo(oo(lo(so(no(to(po(mo(new ko, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new Om;
            d = Wm(d, 1, c.brand);
            return Wm(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function zo(a) {
        var b, c;
        return (c = (b = xo(a)) == null ? void 0 : b.then(function(d) {
            return yo(d)
        })) != null ? c : null
    };
    var Ao = function(a, b, c, d) {
        a = a === void 0 ? window : a;
        b = b === void 0 ? null : b;
        c = c === void 0 ? new Ta : c;
        d = d === void 0 ? If("current") : d;
        be.call(this);
        var e = this;
        this.global = a;
        this.Ca = b;
        this.H = c;
        this.Je = d;
        this.hg = Hd(function() {
            return Ld(e.global, "pagehide")
        }).g(tg(this.H, 941));
        this.gg = Hd(function() {
            return Ld(e.global, "load")
        }).g(tg(this.H, 738), Ue(1));
        this.ii = Hd(function() {
            return Ld(e.global, "resize")
        }).g(tg(this.H, 741));
        this.onMessage = Hd(function() {
            return Ld(e.global, "message")
        }).g(tg(this.H, 740));
        this.document = new li(this.global,
            this);
        this.j = new vg(new yg(this.M, this.H), new xg(this.M, this.H));
        this.I = new pe(new Cg(this), new Dh(this), new rf(this, new Gg(this)), new rf(this, new Gh(this)), new rf(this, new Bh(this)))
    };
    q(Ao, be);
    var Bo = function(a) {
            try {
                return !!a.global.sharedStorage
            } catch (b) {
                return b
            }
        },
        Dg = function(a) {
            var b = a.global;
            return !!a.global.HTMLFencedFrameElement && !!b.fence && typeof b.fence.reportEvent === "function"
        };
    Ao.prototype.Ob = function(a) {
        Dg(this) && this.global.fence.reportEvent(a)
    };
    Ao.prototype.de = function() {
        return this.hg.g(tg(this.H, 942), U(this.h, 1), M(function() {}))
    };
    var Co = function(a) {
            var b = new Ao(a.global.top, a.Ca);
            b.I = a.I;
            return b
        },
        Do = function(a, b) {
            b.start();
            return Ld(b, "message").g(tg(a.H, 740))
        };
    Ao.prototype.postMessage = function(a, b, c) {
        c = c === void 0 ? [] : c;
        this.global.postMessage(a, b, c)
    };
    Ao.prototype.Kf = function() {
        return ph(this.global) ? this.global.width : 0
    };
    Ao.prototype.Hf = function() {
        return ph(this.global) ? this.global.height : 0
    };
    var Eo = function(a, b) {
        try {
            var c = vi(b, a.global);
            return {
                left: c.left,
                top: c.top,
                width: c.Kf(),
                height: c.Hf()
            }
        } catch (d) {
            return ri
        }
    };
    Ao.prototype.validate = function() {
        var a = this.I.L() || Dg(this);
        return this.global && this.j.ga() && a
    };
    var Th = function(a) {
        return (a = zo(a.global)) ? Qc(a) : null
    };
    da.Object.defineProperties(Ao.prototype, {
        sharedStorage: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                try {
                    return this.global.sharedStorage
                } catch (a) {}
            }
        },
        M: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return window
            }
        },
        kc: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !ph(this.global.top)
            }
        },
        ie: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.kc || this.global.top !== this.global
            }
        },
        scrollY: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.global.scrollY
            }
        },
        MutationObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.M.MutationObserver
            }
        },
        ResizeObserver: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.M.ResizeObserver
            }
        },
        Xg: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return "vu" in this.global || "vv" in this.global
            }
        }
    });
    var Fo = !mh && !ch();

    function Go(a, b) {
        if (/-[a-z]/.test(b)) return null;
        if (Fo && a.dataset) {
            if (eh() && !(b in a.dataset)) return null;
            a = a.dataset[b];
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + String(b).replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var Ho = {},
        Io = (Ho["data-google-av-cxn"] = "_avicxn_", Ho["data-google-av-cpmav"] = "_cvu_", Ho["data-google-av-metadata"] = "_avm_", Ho["data-google-av-adk"] = "_adk_", Ho["data-google-av-btr"] = void 0, Ho["data-google-av-override"] = void 0, Ho["data-google-av-dm"] = void 0, Ho["data-google-av-immediate"] = void 0, Ho["data-google-av-aid"] = void 0, Ho["data-google-av-naid"] = void 0, Ho["data-google-av-inapp"] = void 0, Ho["data-google-av-slift"] = void 0, Ho["data-google-av-itpl"] = void 0, Ho["data-google-av-ext-cxn"] = void 0, Ho["data-google-av-rs"] =
            void 0, Ho["data-google-av-flags"] = void 0, Ho["data-google-av-turtlex"] = void 0, Ho["data-google-av-ufs-integrator-metadata"] = void 0, Ho["data-google-av-vattr"] = void 0, Ho["data-google-av-vrus"] = void 0, Ho),
        Jo = {},
        Ko = (Jo["data-google-av-adk"] = "googleAvAdk", Jo["data-google-av-btr"] = "googleAvBtr", Jo["data-google-av-cpmav"] = "googleAvCpmav", Jo["data-google-av-dm"] = "googleAvDm", Jo["data-google-av-ext-cxn"] = "googleAvExtCxn", Jo["data-google-av-immediate"] = "googleAvImmediate", Jo["data-google-av-inapp"] = "googleAvInapp",
            Jo["data-google-av-itpl"] = "googleAvItpl", Jo["data-google-av-metadata"] = "googleAvMetadata", Jo["data-google-av-naid"] = "googleAvNaid", Jo["data-google-av-override"] = "googleAvOverride", Jo["data-google-av-rs"] = "googleAvRs", Jo["data-google-av-slift"] = "googleAvSlift", Jo["data-google-av-cxn"] = "googleAvCxn", Jo["data-google-av-aid"] = void 0, Jo["data-google-av-flags"] = "googleAvFlags", Jo["data-google-av-turtlex"] = "googleAvTurtlex", Jo["data-google-av-ufs-integrator-metadata"] = "googleAvUfsIntegratorMetadata", Jo["data-google-av-vattr"] =
            "googleAvVattr", Jo["data-google-av-vrus"] = "googleAvVurs", Jo);

    function Lo(a, b) {
        if (a.i === void 0) return null;
        try {
            var c;
            var d = (c = a.i.getAttribute(b)) != null ? c : null;
            if (d !== null) return d
        } catch (g) {}
        try {
            var e = Io[b];
            if (e && (d = a.i[e], d !== void 0)) return d
        } catch (g) {}
        try {
            var f = Ko[b];
            if (f) return Go(a.i, f)
        } catch (g) {}
        return null
    }

    function Mo(a) {
        return M(function(b) {
            return Lo(b, a)
        })
    };
    var No = J(function(a) {
        return M(function(b) {
            return a.map(function(c) {
                return Lo(b, c)
            })
        })
    }(["data-google-av-cxn", "data-google-av-turtlex"]), M(function(a) {
        var b = y(a);
        a = b.next().value;
        b = b.next().value;
        if (!a) {
            if (b !== null) return [];
            throw new le;
        }
        return a.split("|")
    }));
    var Oo = function() {
        return J(Ed(function(a) {
            return a.element.g(No, Ne(function() {
                return ad([""])
            })).g(M(function(b) {
                return {
                    na: b,
                    Wc: a
                }
            }))
        }), We(function(a) {
            return a.na.sort().join(";")
        }), M(function(a) {
            return a.Wc
        }))
    };

    function Po() {
        return Ed(function(a) {
            return Qc(Qo(a)).g(Hh(a.h))
        })
    }

    function Qo(a) {
        return a.document.querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass").map(function(b) {
            return new Vh(b)
        })
    };

    function Ro(a) {
        var b = a.gg,
            c = a.document.hi;
        return Sd(ad({}), c, b).g(M(function() {
            return a
        }))
    };
    var To = M(So);

    function So(a) {
        var b = Number(Lo(a, "data-google-av-rs"));
        if (!isNaN(b) && b !== 0) return b;
        var c;
        return (a = (c = a.i) == null ? void 0 : c.id) ? a.startsWith("DfaVisibilityIdentifier") ? 6 : a.startsWith("YtKevlarVisibilityIdentifier") ? 15 : a.startsWith("YtSparklesVisibilityIdentifier") ? 17 : a.startsWith("YtKabukiVisibilityIdentifier") ? 18 : 0 : 0
    };

    function Uo() {
        return J(N(function(a) {
            return a !== void 0
        }), M(function(a) {
            return a
        }))
    };

    function Vo() {
        return function(a) {
            var b = [];
            return a.g(N(function(c) {
                if (c.i === void 0 || b.some(function(d) {
                        return d.i === c.i
                    })) return !1;
                b.push(c);
                return !0
            }))
        }
    };

    function Wo(a, b) {
        b = b === void 0 ? Ec : b;
        return Sd(Ro(a), b).g(Po(), Vo(), Uo(), U(a.h, 1))
    };

    function Xo(a, b) {
        return new K(function(c) {
            var d = !1,
                e = Array(b.length);
            e.fill(void 0);
            var f = new Set,
                g = new Set,
                h = function(u, r) {
                    a.mg ? (e[r] = u, f.add(r), d || (d = !0, Wa(a, function() {
                        d = !1;
                        c.next(Mb(e))
                    }, 1))) : c.error(new me(r))
                },
                k = function(u, r) {
                    g.add(r);
                    f.add(r);
                    Wa(a, function() {
                        c.error(u)
                    }, 1)
                },
                l = function(u) {
                    g.add(u);
                    Wa(a, function() {
                        g.size === b.length && c.complete()
                    }, 1)
                },
                m = b.map(function(u, r) {
                    return u.subscribe(function(t) {
                        return void h(t, r)
                    }, function(t) {
                        return void k(t, r)
                    }, function() {
                        return void l(r)
                    })
                });
            return function() {
                m.forEach(function(u) {
                    return void u.unsubscribe()
                })
            }
        })
    };

    function Yo(a, b, c) {
        function d() {
            if (b.Ca) {
                var x = b.Ca,
                    A = x.next;
                var Q = {
                    creativeId: b.dc.getName(c),
                    requiredSignals: e,
                    signals: Object.assign({}, f),
                    hasPrematurelyCompleted: g,
                    errorMessage: h,
                    erroredSignalKey: k
                };
                Q = {
                    specMajor: 2,
                    specMinor: 0,
                    specPatch: 0,
                    timestamp: ve(b.j.now(), new te(0, b.j.timeline)),
                    instanceId: b.dc.getName(b.sb),
                    creativeState: Q
                };
                A.call(x, Q)
            }
        }
        for (var e = Object.keys(a), f = {}, g = !1, h = null, k = null, l = {}, m = new Set, u = [], r = [], t = y(e), w = t.next(), v = {}; !w.done; v = {
                ka: void 0
            }, w = t.next()) v.ka = w.value, w = a[v.ka],
            w instanceof V ? (l[v.ka] = w.value, m.add(v.ka), b.Ca && (f[String(v.ka)] = ze(w.value))) : (w = w.g(O(function(x, A) {
                    return qe(x) || qe(A) ? !1 : x === A
                }), M(function(x) {
                    return function(A) {
                        b.Ca && (f[String(x.ka)] = ze(A), d());
                        var Q = {};
                        return Q[x.ka] = A, Q
                    }
                }(v)), Ne(function(x) {
                    return function(A) {
                        if (A instanceof me) throw new oe(String(x.ka));
                        throw A;
                    }
                }(v)), kf(function(x) {
                    return function() {
                        m.add(x.ka)
                    }
                }(v), function(x) {
                    return function(A) {
                        k = String(x.ka);
                        h = String(A);
                        d()
                    }
                }(v), function(x) {
                    return function() {
                        m.has(x.ka) || (g = !0, d())
                    }
                }(v))),
                r.push(v.ka), u.push(w));
        (a = Object.keys(f).length > 0) && d();
        t = Xo(b.h, u).g(Ne(function(x) {
            if (x instanceof me) throw new ne(String(r[x.Gh]));
            throw x;
        }), M(function(x) {
            return Object.freeze(Object.assign.apply(Object, [{}, l].concat(z(x))))
        }));
        return (u = u.length > 0) && a ? Sd(ad(Object.freeze(l)), t) : u ? t : ad(Object.freeze(l))
    };

    function Zo(a, b, c, d) {
        var e = $o(ap(bp(), cp), dp, ep);
        return a.H.Tb.bind(a.H)(733, function() {
            var f = {};
            try {
                return b.g(Ne(function(g) {
                    d(Object.assign({}, f, {
                        error: g
                    }));
                    return Ec
                }), Ed(function(g) {
                    try {
                        var h = c(a, g)
                    } catch (l) {
                        return d(Object.assign({}, f, {
                            error: l instanceof Error ? l : String(l)
                        })), Ec
                    }
                    var k = {};
                    return Yo(h, a, g.sb).g(kf(function(l) {
                        k = l
                    }), ef(1), ld()).g(e, Ne(function(l) {
                        d(Object.assign({}, k, {
                            error: l
                        }));
                        return Ec
                    }), $e(void 0), M(function() {
                        return !0
                    }))
                })).g(gf(function(g) {
                    return g + 1
                }, 0), Ne(function(g) {
                    d(Object.assign({},
                        f, {
                            error: g
                        }));
                    return Ec
                }))
            } catch (g) {
                return d(Object.assign({}, f, {
                    error: g
                })), Ec
            }
        })()
    };

    function fp(a, b) {
        return J(R(function(c) {
            var d = a(c),
                e = b(c),
                f = {};
            return d && e && f ? new K(function(g) {
                e(d, f, function(h) {
                    g.next(Object.assign({}, c, {
                        Za: h
                    }));
                    g.complete()
                });
                return function() {}
            }) : Td
        }), N(function(c) {
            return c.Za
        }))
    };
    var dp = J(N(function(a) {
        var b = a.I;
        var c = a.Zb;
        var d = a.Ub;
        var e = a.Ob;
        var f = a.kb;
        var g = a.Na;
        a = a.Yb;
        return g !== void 0 && a !== void 0 && b !== void 0 && c !== void 0 && d !== void 0 && (!f || e !== void 0)
    }), jf(function(a) {
        return !(a.Uf === !1 && a.uf !== void 0)
    }, !1), N(function(a) {
        var b = a.Uf;
        var c = a.fd;
        var d = a.Ui;
        a = a.Zb;
        return d ? !!c && a !== void 0 && (a == null ? void 0 : a.length) > 0 : !!b
    }), fp(function(a) {
        return a.Yb
    }, function(a) {
        return a.Na
    }), M(function(a) {
        a.kb || a.Ub(a.Zb, a).forEach(function(b) {
            a.I.J(b).sendNow()
        })
    }), Ue(1), Se());

    function gp(a) {
        var b = new Map;
        if (typeof a !== "object" || a === null) return b;
        Object.values(a).forEach(function(c) {
            c && typeof c.ja === "function" && (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()))
        });
        return b
    };

    function hp(a, b, c) {
        var d = ip,
            e = jp;
        c = c === void 0 ? .01 : c;
        return function(f) {
            c > 0 && Math.random() <= c && (a.global.HTMLFencedFrameElement && a.global.fence && typeof a.global.fence.reportEvent === "function" && a.global.fence.reportEvent({
                eventType: "active-view-error",
                eventData: "",
                destination: ["buyer"]
            }), f = Object.assign({}, f, {
                errorMessage: f.error instanceof Error && f.error.message ? f.error.message : String(f.error),
                vf: f.error instanceof Error && f.error.stack ? String(f.error.stack) : null,
                mh: f.error instanceof Error && f.error.name ?
                    String(f.error.name) : null,
                jh: String(a.H.zg),
                kh: f.escapedQueryId
            }), d(Object.assign({}, f, {
                W: function() {
                    return function(g) {
                        try {
                            return e(Object.assign({}, g))
                        } catch (h) {
                            return {}
                        }
                    }
                }(),
                na: [b]
            }), gp(f)).forEach(function(g) {
                a.I.J(g).sendNow()
            }))
        }
    };
    var ep = J(M(function(a) {
        var b = a.I;
        var c = a.sh;
        if (b === void 0 || c === void 0) return !1;
        if (a.uf !== void 0) return !0;
        if (c === null) return !1;
        for (a = 0; a < c; a++) b.J("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" + Math.floor(Math.random() * 1E7)).sendNow();
        return !0
    }), jf(function(a) {
        return !a
    }), Se());
    var kp = J(N(function(a) {
        return !!a.fd
    }), N(function(a) {
        var b = a.shouldSendExplicitDisplayMeasurablePing;
        a = a.ib;
        var c, d;
        return (d = b && ((c = a == null ? void 0 : a.length) != null ? c : 0) > 0) != null ? d : !1
    }), N(function(a) {
        return a.W !== void 0 && a.ib !== void 0 && a.ub !== void 0 && a.Fb !== void 0 && a.I !== void 0
    }), M(function(a) {
        return Object.assign({}, a, {
            vd: gp(a)
        })
    }), M(function(a) {
        a.ub(Object.assign({}, a, {
            na: a.ib,
            W: a.W,
            zc: a.Fb,
            Lc: 3,
            Bc: "m"
        }), a.vd).forEach(function(b) {
            a.I.J(b).sendNow()
        });
        return !0
    }), jf(function(a) {
        return !a
    }), Se());
    var jp = function(a) {
        return {
            id: a.zc,
            mcvt: a.tc,
            p: a.Xc,
            asp: a.yj,
            tm: a.wd,
            tu: a.xd,
            mtos: a.uc,
            tos: a.Ic,
            v: a.Wg,
            bin: a.Kd,
            avms: a.eg,
            bs: a.jf,
            mc: a.cg,
            "if": a.fh,
            vu: a.hh,
            app: a.jb,
            mse: a.we,
            mtop: a.xe,
            itpl: a.ke,
            adk: a.Jd,
            exk: a.Aj,
            rs: a.Ra,
            la: a.Yf,
            cr: a.pe,
            uach: a.Jc,
            vs: a.Lc,
            r: a.Bc,
            pay: a.Ah,
            co: a.Yg,
            rst: a.Qg,
            rpt: a.Pg,
            isd: a.Eh,
            lsd: a.Th,
            context: a.jh,
            msg: a.errorMessage,
            stack: a.vf,
            name: a.mh,
            ec: a.Bh,
            sfr: a.Ke,
            met: a.bc,
            wmsd: a.Se,
            pv: a.Yj,
            epv: a.Cj,
            pbe: a.Sf,
            fle: a.Ch,
            vae: a.Dh,
            spb: a.wg,
            sfl: a.vg,
            ffslot: a.Nh,
            reach: a.Hi,
            io2: a.Ad,
            rxdbg: a.dk,
            omida: a.Mj,
            omidp: a.Tj,
            omidpv: a.Uj,
            omidor: a.Sj,
            omidv: a.Wj,
            omids: a.Vj,
            omidam: a.Lj,
            omidct: a.Nj,
            omidia: a.Qj,
            omiddc: a.Oj,
            omidlat: a.Rj,
            omiddit: a.Pj,
            qid: a.kh
        }
    };

    function $o() {
        var a = B.apply(0, arguments);
        return function(b) {
            var c = b.g(ef(1), ld());
            b = a.map(function(d) {
                return c.g(d, $e(!0))
            });
            return zd(b).g(Ue(1), Se())
        }
    };

    function ap() {
        var a = B.apply(0, arguments);
        return function(b) {
            var c = b.g(ef(1), ld());
            b = a.map(function(d) {
                return c.g(d, $e(!0))
            });
            return Sd.apply(null, z(b)).g(Ue(1), Se())
        }
    };

    function bp() {
        var a = $o(kp, lp),
            b = mp;
        return function(c) {
            var d = c.g(ef(1), ld());
            c = d.g(a, $e(!0));
            d = d.g(J(b, ef(), ld()), $e(!0));
            c = zd([c, d]);
            return Xd(c, d).g(Ue(1), Se())
        }
    };
    var mp = function(a) {
        var b = [];
        return a.g(M(function(c) {
            var d = c.I,
                e = c.th,
                f = c.Ic,
                g = c.Ni,
                h = c.W,
                k = c.Mi,
                l = c.xg,
                m = c.ub,
                u = c.Qe,
                r = c.fd,
                t = c.Sf,
                w = c.wg,
                v = c.vg,
                x = c.Oe;
            if (!c.Df || !r || c.uc === void 0 || f === void 0 || g === void 0 || h === void 0 || k === void 0 || m === void 0 || d === void 0) return !1;
            if (c.kb) {
                if (l === void 0) return !1;
                g = c.Ob;
                if (!g) return !1;
                g({
                    eventType: "active-view-time-on-screen",
                    eventData: x != null ? x : "",
                    destination: ["buyer"]
                });
                return !0
            }
            if (!(t || v || l)) return !1;
            x = gp(c);
            var A;
            u = (A = u == null ? void 0 : u.ra(x).value) != null ? A : !1;
            A = m(Object.assign({},
                c, {
                    zc: k,
                    Lc: u ? 4 : 3,
                    Bc: l != null ? l : "u",
                    W: h,
                    na: g
                }), x);
            if (t) {
                for (; b.length > g.length;) c = void 0, (c = b.shift()) == null || c.deactivate();
                A.forEach(function(T, ma) {
                    ma >= b.length ? b.push(d.J(T)) : b[ma].url = T
                });
                return w && e && l !== void 0 ? (A.forEach(function(T) {
                    e.J(T).sendNow()
                }), !0) : l !== void 0
            }
            if (w && e && l !== void 0) return A.forEach(function(T) {
                e.J(T).sendNow()
            }), !0;
            if (v && e) {
                for (; b.length > g.length;) w = void 0, (w = b.shift()) == null || w.deactivate();
                var Q = m(Object.assign({}, c, {
                        zc: k,
                        Lc: u ? 4 : 3,
                        Bc: l != null ? l : "u",
                        W: h,
                        na: ["https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&lidartos"]
                    }),
                    x)[0];
                A.forEach(function(T, ma) {
                    ma >= b.length ? b.push(d.J(Q, {
                        tf: !0
                    })) : b[ma].url = Q
                });
                return l !== void 0 ? (A.forEach(function(T) {
                    e.J(T).sendNow()
                }), !0) : l !== void 0
            }
            return l !== void 0 ? (A.forEach(function(T) {
                d.J(T).sendNow()
            }), !0) : !1
        }), jf(function(c) {
            return !c
        }), Se())
    };

    function np(a) {
        return function(b) {
            return b.g(M(function(c) {
                a.mg || Bb("Assertion on queued Observable output failed");
                return c
            }))
        }
    };

    function op(a) {
        return function(b) {
            return new K(function(c) {
                var d = !1,
                    e = b.g(np(a)).subscribe(function(f) {
                        d = !0;
                        c.next(f)
                    }, c.error.bind(c), c.complete.bind(c));
                Wa(a, function() {
                    d || c.next(null)
                }, 3);
                return e
            })
        }
    };

    function pp(a, b) {
        return function(c) {
            return c.g(R(function(d) {
                return new K(function(e) {
                    function f() {
                        h.disconnect();
                        k.unsubscribe()
                    }
                    var g = a.MutationObserver;
                    if (g && d.i !== void 0) {
                        var h = new g(function(l) {
                            e.next(l)
                        });
                        h.observe(d.i, b);
                        var k = d.released.subscribe(f);
                        return f
                    }
                })
            }))
        }
    };
    var qp = {
        wj: 0,
        bj: 1,
        dj: 2,
        cj: 3,
        0: "UNKNOWN",
        1: "DEFER_MEASUREMENT",
        2: "DO_NOT_DEFER_MEASUREMENT",
        3: "DEFER_MEASUREMENT_AND_PING"
    };

    function rp(a, b) {
        var c = b.g(pp(a, {
            attributes: !0
        }), U(a.h, 1));
        return zd([b, c.g(U(a.h, 1), op(a.h))]).g(M(function(d) {
            return y(d).next().value
        }), Mo("data-google-av-dm"), M(sp))
    }

    function sp(a) {
        return a && a in qp ? Number(a) : 2
    };

    function tp(a) {
        if (a.Xh === 3) return null;
        if (a.xg !== void 0) {
            var b = a.eh === !1 ? "n" : null;
            if (b !== null) return b
        }
        return a.bd instanceof fe ? "msf" : a.Qd instanceof ge ? "c" : a.bh === !1 ? "pv" : a.bd || a.Qd ? "x" : null
    }
    var cp = J(N(function(a) {
        return a.ib !== void 0 && a.W !== void 0 && a.ub !== void 0 && a.Fb !== void 0 && a.I !== void 0
    }), N(function(a) {
        return tp(a) !== null
    }), fp(function(a) {
        return a.Pc
    }, function(a) {
        return a.Na
    }), M(function(a) {
        if (a.kb) {
            var b = a.Ob;
            if (b) {
                var c;
                b({
                    eventType: "active-view-unmeasurable",
                    eventData: (c = a.Oe) != null ? c : "",
                    destination: ["buyer"]
                })
            }
        } else {
            c = void 0;
            var d = tp(a);
            if (d === "x") {
                var e, f = (e = a.bd) != null ? e : a.Qd;
                f && (b = f.stack, c = f.message)
            }
            a.ub(Object.assign({}, a, {
                na: a.ib,
                W: a.W,
                zc: a.Fb,
                Lc: 2,
                Bc: d,
                errorMessage: c,
                vf: b
            }), gp(a)).forEach(function(g) {
                a.I.J(g).sendNow()
            })
        }
    }), Ue(1), Se());
    var up = function() {
            this.startTime = Math.floor(Date.now() / 1E3 - 1704067200);
            this.sequenceNumber = 0
        },
        vp = function(a) {
            var b = a.sequenceNumber.toString(10).padStart(2, "0");
            b = "" + a.startTime + b;
            a.sequenceNumber < 99 && a.sequenceNumber++;
            return b
        };

    function wp(a, b) {
        return typeof a === "string" ? encodeURIComponent(a) : typeof a === "number" ? String(a) : Array.isArray(a) ? a.map(function(c) {
            return wp(c, b)
        }).join(",") : a instanceof te ? a.toString() : a && typeof a.ja === "function" ? wp(a.ra(b).value, b) : a === !0 ? "1" : a === !1 ? "0" : a === void 0 || a === null ? null : a instanceof up ? vp(a) : [a.top, a.left, a.top + a.height, a.left + a.width].join()
    }

    function xp(a, b) {
        a = Object.entries(a).map(function(c) {
            var d = y(c);
            c = d.next().value;
            d = d.next().value;
            d = wp(d, b);
            return d === null ? "" : c + "=" + d
        }).filter(function(c) {
            return c !== ""
        });
        return a.length ? a.join("&") : ""
    };
    var yp = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
        fc = dc(ec(), "google3.javascript.ads.common.url_macros_substitutor", Ub).Uh;

    function zp(a, b) {
        return a.replace(yp, function(c, d) {
            try {
                var e = b !== null && d in b ? b[d] : void 0;
                if (e == null) return ic("No value supplied for unsupported macro: " + d), c;
                if (e.toString() == null) return ic("The toString method of value returns null for macro: " + d), c;
                e = e.toString();
                if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e))) return encodeURIComponent(e).replace(/%2C/g, ",");
                ic("Null value supplied for macro: " + d)
            } catch (f) {
                ic("Failed to set macro: " + d)
            }
            return c
        })
    };

    function Ap(a, b) {
        var c = Object.assign({}, a),
            d = a.Jc;
        c = (delete c.Jc, c);
        c = a.W(c);
        var e = xp(c, b);
        return Jb(a.na, function(f) {
            var g = "";
            typeof d === "string" && (g = "&" + xp({
                uach: d
            }, b));
            var h = {};
            return zp(f, (h.VIEWABILITY = e, h)) + g
        })
    };

    function ip(a, b) {
        var c = a.W(a),
            d = xp(c, b);
        return d ? Jb(a.na, function(e) {
            e = e.indexOf("?") >= 0 ? e : e + "?";
            e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
            return e + d
        }) : a.na
    };

    function Bp(a, b) {
        return Jb(a, function(c) {
            if (typeof b.Jc === "string") {
                var d = "&" + xp({
                    uach: b.Jc
                }, new Map);
                return c.substring(c.length - 7) == "&adurl=" ? c.substring(0, c.length - 7) + d + "&adurl=" : c + d
            }
            return c
        })
    };
    var lp = J(N(function(a) {
        return a.W !== void 0 && a.ib !== void 0 && a.ub !== void 0 && a.Fb !== void 0 && a.I !== void 0
    }), M(function(a) {
        return Object.assign({}, a, {
            vd: gp(a)
        })
    }), N(function(a) {
        var b = a.Qe;
        var c = a.fd;
        a = a.vd;
        var d;
        return !!c && ((d = b == null ? void 0 : b.ra(a).value) != null ? d : !1)
    }), fp(function(a) {
        return a.Qc
    }, function(a) {
        return a.Na
    }), M(function(a) {
        var b = a.I,
            c = a.Oe;
        if (a.kb) {
            var d = a.Ob;
            if (!d) return !1;
            d({
                eventType: "active-view-viewable",
                eventData: c != null ? c : "",
                destination: ["buyer"]
            });
            return !0
        }
        c = a.ub(Object.assign({},
            a, {
                na: a.ib,
                W: a.W,
                zc: a.Fb,
                Lc: 4,
                Bc: "v"
            }), a.vd);
        (d = a.Sd) && d.length > 0 && a.Ub && a.Ub(d, a).forEach(function(e) {
            b.J(e).sendNow()
        });
        (d = a.Re) && d.length > 0 && a.Ub && a.Ub(d, a).forEach(function(e) {
            b.J(e).sendNow()
        });
        c.forEach(function(e) {
            b.J(e, {
                Wb: a.se
            }).sendNow()
        });
        return !0
    }), jf(function(a) {
        return !a
    }), Se());

    function Cp(a, b, c, d) {
        var e = Object.keys(c).map(function(h) {
                return h
            }),
            f = e.filter(function(h) {
                var k = c[h];
                h = d[h];
                return k instanceof V && h instanceof V && k.value === h.value
            }),
            g = f.reduce(function(h, k) {
                var l = {};
                return Object.assign({}, h, (l[k] = c[k], l))
            }, {});
        return e.reduce(function(h, k) {
            if (f.indexOf(k) >= 0) return h;
            var l = {};
            return Object.assign({}, h, (l[k] = b.g(R(function(m) {
                return (m = m ? c[k] : d[k]) && (m instanceof K || I(m.mb) && I(m.subscribe)) ? m : m.S(a)
            })), l))
        }, g)
    };

    function Dp(a) {
        return J(M(function() {
            return !0
        }), P(!1), U(a, 1))
    };

    function Ep(a) {
        return a.length <= 0 ? Ec : zd(a.map(function(b) {
            var c = 0;
            return b.g(M(function(d) {
                return {
                    index: c++,
                    value: d
                }
            }))
        })).g(N(function(b) {
            return b.every(function(c) {
                return c.index === b[0].index
            })
        }), M(function(b) {
            return b.map(function(c) {
                return c.value
            })
        }))
    };

    function Fp(a, b) {
        a.Ba && (a.pb = a.Ba);
        a.Ba = b;
        a.pb && a.pb.value ? (b = Math.max(0, ve(b.timestamp, a.pb.timestamp)), a.totalTime += b, a.pa += b) : a.pa = 0;
        return a
    }

    function Gp() {
        return J(gf(Fp, {
            totalTime: 0,
            pa: 0
        }), M(function(a) {
            return a.totalTime
        }))
    }

    function Hp() {
        return J(gf(Fp, {
            totalTime: 0,
            pa: 0
        }), M(function(a) {
            return a.pa
        }))
    };

    function Ip(a, b) {
        return J(Mo("data-google-av-metadata"), M(function(c) {
            if (c === null) return b(void 0);
            c = c.split("&").map(function(d) {
                return d.split("=")
            }).filter(function(d) {
                return d[0] === a
            });
            if (c.length === 0) return b(void 0);
            c = c[0].slice(1).join("=");
            return b(c)
        }))
    };
    var Jp = {
        Xi: "asmreq",
        Yi: "asmres"
    };
    var Kp = function(a) {
        fo.call(this, a)
    };
    q(Kp, fo);
    Kp.prototype.pg = function(a) {
        Vm(this, 1, a)
    };
    Kp.U = "tagging.common.osd.AdSpeedMetricsRequest";
    Kp.prototype.N = ho([0, Wn]);
    var Lp = function(a) {
        fo.call(this, a)
    };
    q(Lp, fo);
    Lp.U = "tagging.common.osd.AdSpeedMetricsResponse.Box";
    var Mp = [0, Pn, -3];
    Lp.prototype.N = ho(Mp);
    var Np = function(a) {
        fo.call(this, a)
    };
    q(Np, fo);
    Np.prototype.pg = function(a) {
        Vm(this, 1, a)
    };
    var Op = io(Np);
    Np.U = "tagging.common.osd.AdSpeedMetricsResponse";
    Np.prototype.N = ho([0, Wn, Sn, Mp, Pn, -1]);

    function Pp(a, b) {
        var c = c === void 0 ? Co(a) : c;
        var d = new MessageChannel;
        b = b.g(M(function(f) {
            return Number(f)
        }), N(function(f) {
            return !isNaN(f) && f !== 0
        }), kf(function(f) {
            var g = new Kp;
            g.pg(f);
            f = {
                type: "asmreq",
                payload: g.Sa()
            };
            c.postMessage(f, "*", [d.port2])
        }), Ue(1));
        var e = Do(a, d.port1).g(N(function(f) {
                return typeof f.data === "object"
            }), M(function(f) {
                var g = f.data,
                    h = Object.values(Jp).includes(g.type);
                g = typeof g.payload === "string";
                if (!h || !g || f.data.type !== "asmres") return null;
                try {
                    return Op(f.data.payload)
                } catch (k) {
                    return null
                }
            }),
            N(function(f) {
                return f !== null
            }), M(function(f) {
                return f
            }));
        return b.g(R(function(f) {
            return ad(f).g(Qe(e))
        }), N(function(f) {
            var g = y(f);
            f = g.next().value;
            g = g.next().value;
            if (al(vm(g, 1)) != null) {
                var h = h === void 0 ? 0 : h;
                var k;
                g = ((k = al(vm(g, 1))) != null ? k : h) === f
            } else g = !1;
            return g
        }), M(function(f) {
            f = y(f);
            f.next();
            return f.next().value
        }), Hh(a.h))
    };

    function Qp(a, b, c) {
        var d = b.qc.g(Ue(1), R(function() {
            return Pp(a, c)
        }), N(function(f) {
            return Rm(f, 2) && zm(f, Lp, 3) && Zk(vm(f, 4)) != null && Zk(vm(f, 5)) != null
        }), Ue(1), Hh(a.h));
        b = d.g(M(function(f) {
            var g = Nm(f, Lp, 3);
            g = Sm(g, 2);
            f = Nm(f, Lp, 3);
            f = Sm(f, 1);
            return {
                x: g,
                y: f
            }
        }), O(function(f, g) {
            return f.x === g.x && f.y === g.y
        }), U(a.h, 1));
        var e = d.g(M(function(f) {
            return Sm(f, 4)
        }), U(a.h, 1));
        d = d.g(M(function(f) {
            return Sm(f, 5)
        }), U(a.h, 1));
        return {
            Eh: e,
            Sg: b,
            Th: d
        }
    };

    function Rp(a, b) {
        return b.qc.g(Ue(1), M(function() {
            return a.j.now().round()
        }))
    };
    var Sp = M(function(a) {
        return [a.value.X.width, a.value.X.height]
    });

    function Tp(a, b) {
        return function(c) {
            return Ep(b.map(function(d) {
                return c.g(a(d))
            }))
        }
    };

    function Up() {
        var a;
        return J(kf(function(b) {
            return void(a = b.timestamp)
        }), Hp(), M(function(b) {
            return {
                timestamp: a,
                value: Math.round(b)
            }
        }))
    };
    var Vp = function(a, b) {
            this.lf = a;
            this.options = b;
            this.me = this.le = null
        },
        Wp = function(a, b) {
            b ? a.me || (b = Object.assign({}, a.options, {
                delay: 100,
                trackVisibility: !0
            }), a.me = new IntersectionObserver(a.lf, b)) : a.le || (a.le = new IntersectionObserver(a.lf, a.options))
        },
        Xp = function(a, b) {
            a = b ? a.me : a.le;
            if (!a) throw new ie;
            return a
        };
    Vp.prototype.observe = function(a, b) {
        Xp(this, a).observe(b)
    };
    Vp.prototype.unobserve = function(a, b) {
        Xp(this, a).unobserve(b)
    };
    Vp.prototype.disconnect = function(a) {
        Xp(this, a).disconnect()
    };
    Vp.prototype.takeRecords = function(a) {
        return Xp(this, a).takeRecords()
    };
    var Yp = {
        ea: "ns",
        ia: ri,
        X: ri,
        ca: new L,
        T: "ns",
        K: ri,
        V: ri,
        oa: {
            x: 0,
            y: 0
        }
    };

    function Zp(a, b) {
        return si(a.X, b.X) && si(a.K, b.K) && si(a.ia, b.ia) && si(a.V, b.V) && a.T === b.T && a.ca === b.ca && a.ea === b.ea && a.oa.x === b.oa.x && a.oa.y === b.oa.y
    };

    function $p(a, b) {
        return function(c) {
            return function(d) {
                var e = d.g(df(new L), ld());
                d = c.element.g(O());
                e = e.g(M(function(f) {
                    return f.value
                }));
                return zd([d, e, b]).g(M(function(f) {
                    var g = y(f);
                    f = g.next().value;
                    var h = g.next().value;
                    g = g.next().value;
                    if (f.i === void 0) var k = {
                        top: 0,
                        left: 0,
                        width: 0,
                        height: 0
                    };
                    else {
                        k = f.i.getBoundingClientRect();
                        var l = f.i,
                            m = a.global,
                            u = new qh(0, 0);
                        var r = (r = th(l)) ? r.defaultView : window;
                        if (ih(r, "parent")) {
                            do {
                                if (r == m) {
                                    var t = l,
                                        w = th(t);
                                    Fb(t, "Parameter is required");
                                    var v = new qh(0, 0);
                                    var x =
                                        (w ? th(w) : document).documentElement;
                                    t != x && (t = zh(t), w = uh(w), w = vh(w.fc), v.x = t.left + w.x, v.y = t.top + w.y)
                                } else v = D(l), v = zh(v), v = new qh(v.left, v.top);
                                u.x += v.x;
                                u.y += v.y
                            } while (r && r != m && r != r.parent && (l = r.frameElement) && (r = r.parent))
                        }
                        k = {
                            top: u.y,
                            left: u.x,
                            width: k.width,
                            height: k.height
                        }
                    }
                    k = ui(k, h.oa);
                    m = ti(k, h.ia);
                    u = a.j.now();
                    r = Object;
                    l = r.assign;
                    if (g !== 2 || a.kc || m.width <= 0 || m.height <= 0) var A = !1;
                    else try {
                        var Q = a.document.elementFromPoint(m.left + m.width / 2, m.top + m.height / 2);
                        A = Q ? !aq(Q, f) : !1
                    } catch (T) {
                        A = !1
                    }
                    return {
                        timestamp: u,
                        value: l.call(r, {}, h, {
                            T: "geo",
                            V: A ? Yp.V : m,
                            K: k
                        })
                    }
                }), Hh(a.h))
            }
        }
    }

    function aq(a, b, c) {
        c = c === void 0 ? 0 : c;
        return a.i === void 0 || b.i === void 0 ? !1 : a.i === b.i || xh(b.i, function(d) {
            return d === a.i
        }) ? !0 : b.i.ownerDocument && b.i.ownerDocument.defaultView && b.i.ownerDocument.defaultView === b.i.ownerDocument.defaultView.top ? !1 : c < 10 && b.i.ownerDocument && b.i.ownerDocument.defaultView && b.i.ownerDocument.defaultView.frameElement ? aq(a, new Vh(b.i.ownerDocument.defaultView.frameElement), c + 1) : !0
    };

    function bq(a) {
        return function(b) {
            return b.g(a.ResizeObserver ? cq(a) : dq(a), ef(1), ld())
        }
    }

    function cq(a) {
        return function(b) {
            return b.g(R(function(c) {
                var d = a.ResizeObserver;
                if (!d || c.i === void 0) return ad(Yp.K);
                var e = (new K(function(f) {
                    function g() {
                        c.i !== void 0 && h.unobserve(c.i);
                        h.disconnect();
                        k.unsubscribe()
                    }
                    if (c.i === void 0) return f.complete(),
                        function() {};
                    var h = new d(function(l) {
                        l.forEach(function(m) {
                            f.next(m)
                        })
                    });
                    h.observe(c.i);
                    var k = c.released.subscribe(g);
                    return g
                })).g(tg(a.H, 736), M(function(f) {
                    return f.contentRect
                }));
                return Sd(ad(c.i.getBoundingClientRect()), e)
            }), O(si))
        }
    }

    function dq(a) {
        return function(b) {
            var c = b.g(pp(a, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                })),
                d = a.ii;
            c = Sd(b.g(M(function() {
                return Uh("resize")
            })), c, d);
            return zd(b, c).g(tg(a.H, 737), M(function(e) {
                e = y(e).next().value;
                return e.i === void 0 ? void 0 : e.i.getBoundingClientRect()
            }), Uo(), O(si))
        }
    };

    function eq(a, b) {
        var c = fq(a, b).g(ef(1), ld());
        return function(d) {
            return function(e) {
                e = e.g(R(function(f) {
                    return f.element
                }), O());
                return zd([c, e]).g(R(function(f) {
                    var g = y(f);
                    f = g.next().value;
                    g = g.next().value;
                    return gq(a, f.Lh, bq(a), f.gi, d, f.uh, g)
                }), Hh(a.h))
            }
        }
    }

    function hq(a, b, c) {
        var d = eq(a, c)(b);
        return function(e) {
            var f = d(ad(e));
            return function(g) {
                return zd([g, f]).g(M(function(h) {
                    var k = y(h);
                    h = k.next().value;
                    k = k.next().value;
                    var l = ui(k.value.K, h.value.oa),
                        m = ti(ui(k.value.V, h.value.oa), h.value.ia);
                    return {
                        timestamp: h.timestamp.maximum(k.timestamp),
                        value: Object.assign({}, h.value, {
                            T: "nio",
                            V: m,
                            K: l
                        })
                    }
                }))
            }
        }
    }

    function iq(a) {
        return M(function(b) {
            return b.value.ea !== "nio" ? b : Object.assign({}, b, {
                value: Object.assign({}, b.value, {
                    ia: Eo(a, !0),
                    X: Eo(a, !0)
                })
            })
        })
    }

    function jq(a, b) {
        return ad(b).g(a, M(function() {
            return b
        }))
    }

    function fq(a, b) {
        return a.j.timeline !== re ? bd(new fe(2)) : a.MutationObserver ? typeof IntersectionObserver === "undefined" ? bd(new fe(0)) : (new K(function(c) {
            var d = new L,
                e = new Vp(d.next.bind(d), {
                    threshold: [].concat(z(b))
                });
            c.next({
                gi: d.g(tg(a.H, 735)),
                Lh: e,
                uh: function(f) {
                    f = e.takeRecords(f);
                    f.length > 0 && d.next(f)
                }
            })
        })).g(Ue(1), ef(1), ld()) : bd(new fe(1))
    }

    function kq(a) {
        return Pc(a.sort(function(b, c) {
            return b.time - c.time
        }), qd)
    }

    function gq(a, b, c, d, e, f, g) {
        return new K(function(h) {
            function k() {
                w || (w = !0, g.i !== void 0 && b.unobserve(e, g.i), m.unsubscribe(), t.unsubscribe(), r.unsubscribe(), v.unsubscribe())
            }
            if (g.i !== void 0) {
                Wp(b, e);
                b.observe(e, g.i);
                var l = new Cc({
                        timestamp: a.j.now(),
                        value: Object.assign({}, Yp, {
                            ea: "nio",
                            T: "nio"
                        })
                    }),
                    m = d.g(Ed(function(x) {
                        return kq(x)
                    }), N(function(x) {
                        return x.target === g.i
                    }), M(function(x) {
                        return {
                            timestamp: new te(x.time, re),
                            value: {
                                ea: "nio",
                                ia: x.rootBounds || ri,
                                X: x.rootBounds || Eo(a, !0),
                                ca: u,
                                T: "nio",
                                V: x.intersectionRect,
                                K: x.boundingClientRect,
                                oa: {
                                    x: 0,
                                    y: 0
                                },
                                isIntersecting: x.isIntersecting,
                                bg: x.isVisible
                            }
                        }
                    }), df(l), ld()).subscribe(h),
                    u = new L,
                    r = u.subscribe(function() {
                        f(e);
                        h.next({
                            timestamp: a.j.now(),
                            value: l.value.value
                        });
                        g.i !== void 0 && (b.unobserve(e, g.i), b.observe(e, g.i))
                    }),
                    t = jq(c, g).subscribe(function() {
                        u.next()
                    }),
                    w = !1,
                    v = g.released.subscribe(function() {
                        return k()
                    });
                return k
            }
        })
    };

    function lq(a, b) {
        var c = a.de().g(M(function() {
            return "b"
        }));
        return Xd(b, c).g(Ue(1), U(a.h, 1))
    };

    function mq(a) {
        return function(b) {
            var c;
            return b.g(kf(function(d) {
                return void(c = d.timestamp)
            }), M(function(d) {
                return d.value
            }), a, M(function(d) {
                return {
                    timestamp: c,
                    value: d
                }
            }))
        }
    };

    function nq(a) {
        return a.V.width * a.V.height / (a.K.width * a.K.height)
    }
    var oq = mq(J(M(function(a) {
            var b;
            return (b = a.ad) != null ? b : nq(a)
        }), M(function(a) {
            return isFinite(a) ? a : 0
        }))),
        pq = mq(J(M(function(a) {
            var b;
            return (b = a.ad) != null ? b : nq(a)
        }), M(function(a) {
            return isFinite(a) ? a : -1
        })));
    var qq = function(a, b) {
        this.a = a;
        this.b = b;
        if (a.clock.timeline !== b.clock.timeline) throw Error();
    };
    qq.prototype.Y = function(a) {
        return a instanceof qq ? this.a.Y(a.a) && this.b.Y(a.b) : !1
    };
    qq.prototype.qa = function(a) {
        var b = this.a.qa(a).value,
            c = this.b.qa(a).value;
        return {
            timestamp: a,
            value: [b, c]
        }
    };
    da.Object.defineProperties(qq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.active || this.b.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.a.clock
            }
        },
        D: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a = this.a.D.timestamp.maximum(this.b.D.timestamp),
                    b = this.a.D.timestamp.equals(a) ? this.a.D.value : this.a.qa(a).value,
                    c = this.b.D.timestamp.equals(a) ? this.b.D.value : this.b.qa(a).value;
                return {
                    timestamp: a,
                    value: [b, c]
                }
            }
        }
    });
    var rq = function(a, b) {
        this.input = a;
        this.nd = b;
        this.D = {
            timestamp: this.input.D.timestamp,
            value: this.nd(this.input.D.value)
        }
    };
    rq.prototype.Y = function(a) {
        return a instanceof rq ? this.input.Y(a.input) && this.nd === a.nd : !1
    };
    rq.prototype.qa = function(a) {
        a = this.input.qa(a);
        return {
            timestamp: a.timestamp,
            value: this.nd(a.value)
        }
    };
    da.Object.defineProperties(rq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.active
            }
        },
        clock: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.input.clock
            }
        }
    });

    function sq(a, b, c) {
        c = c === void 0 ? function(d, e) {
            return d === e
        } : c;
        return a.timestamp.equals(b.timestamp) && c(a.value, b.value)
    };
    var tq = function(a, b, c) {
        this.clock = a;
        this.D = b;
        this.active = c
    };
    tq.prototype.Y = function(a) {
        return a instanceof tq ? this.active === a.active && this.clock.timeline === a.clock.timeline && sq(this.D, a.D) : !1
    };
    tq.prototype.qa = function(a) {
        return {
            timestamp: a,
            value: this.D.value + (this.active ? Math.max(0, ve(a, this.D.timestamp)) : 0)
        }
    };
    var uq = function() {};
    uq.prototype.ja = function() {
        return this.qa(this.clock.now())
    };
    uq.prototype.ra = function(a) {
        var b = this.clock.timeline,
            c, d = (c = a.get(b)) != null ? c : this.clock.now();
        a.set(b, d);
        return this.qa(d)
    };
    uq.prototype.map = function(a) {
        return new vq(this, a)
    };
    uq.prototype.sa = function(a) {
        return new wq(this, a)
    };
    var wq = function() {
        qq.apply(this, arguments);
        this.map = uq.prototype.map;
        this.sa = uq.prototype.sa;
        this.ja = uq.prototype.ja;
        this.ra = uq.prototype.ra
    };
    q(wq, qq);
    var xq = function() {
        tq.apply(this, arguments);
        this.map = uq.prototype.map;
        this.sa = uq.prototype.sa;
        this.ja = uq.prototype.ja;
        this.ra = uq.prototype.ra
    };
    q(xq, tq);
    var vq = function() {
        rq.apply(this, arguments);
        this.map = uq.prototype.map;
        this.sa = uq.prototype.sa;
        this.ja = uq.prototype.ja;
        this.ra = uq.prototype.ra
    };
    q(vq, rq);

    function yq(a, b) {
        a.Ba && (a.pb = a.Ba);
        a.Ba = b;
        a.pb && a.pb.value ? (b = Math.max(0, ve(b.timestamp, a.pb.timestamp)), a.totalTime += b, a.pa += b) : a.pa = 0;
        return a
    }

    function zq(a) {
        return J(gf(yq, {
            totalTime: 0,
            pa: 0
        }), M(function(b) {
            return new xq(a, {
                timestamp: b.Ba.timestamp,
                value: b.totalTime
            }, b.Ba.value)
        }))
    }

    function Aq(a) {
        return J(gf(yq, {
            totalTime: 0,
            pa: 0
        }), M(function(b) {
            return new xq(a, {
                timestamp: b.Ba.timestamp,
                value: b.pa
            }, b.Ba.value)
        }))
    };

    function Bq(a) {
        return J(Aq(a), M(function(b) {
            return b.map(function(c) {
                return Math.round(c)
            })
        }))
    };
    var Cq = function(a, b) {
        this.D = b;
        this.ja = uq.prototype.ja;
        this.ra = uq.prototype.ra;
        this.map = uq.prototype.map;
        this.sa = uq.prototype.sa;
        this.clock = a
    };
    Cq.prototype.Y = function(a) {
        return a.active
    };
    Cq.prototype.qa = function() {
        return this.D
    };
    da.Object.defineProperties(Cq.prototype, {
        active: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return !1
            }
        }
    });

    function Dq(a, b) {
        return b.g(M(function(c) {
            return new Cq(a.j, {
                timestamp: a.j.now(),
                value: c
            })
        }))
    };

    function Eq(a, b) {
        return a >= 1 ? !0 : a <= 0 ? !1 : a >= b
    };

    function Fq(a) {
        return function(b) {
            return b.g(lf(a), M(function(c) {
                var d = y(c);
                c = d.next().value;
                d = d.next().value;
                return {
                    timestamp: c.timestamp,
                    value: Eq(c.value, d)
                }
            }))
        }
    };
    var Gq = M(function(a) {
        if (a.value.ea === "omid") {
            if (a.value.T === "nio") return "omio";
            if (a.value.T === "geo") return "omgeo"
        }
        return a.value.T === "geo" || a.value.T === "nio" ? a.value.ea : a.value.T
    });

    function Hq() {
        return J(N(function(a, b) {
            return b > 0
        }), Iq, P(-1), O())
    }
    var Iq = J(N(function(a) {
        return !isNaN(a)
    }), gf(function(a, b) {
        return isNaN(a) ? b : Math.min(a, b)
    }, NaN), O());
    var Jq = mq(J(M(function(a) {
        return a.V.width * a.V.height / (a.ia.width * a.ia.height)
    }), M(function(a) {
        return isFinite(a) ? Math.min(1, a) : 0
    })));

    function Kq(a, b, c) {
        return a ? zd([b, c]).g(N(function(d) {
            var e = y(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp)
        }), M(function(d) {
            var e = y(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e
        })) : b
    }

    function Lq(a) {
        return function(b) {
            var c = b.g(oq),
                d = b.g(Jq);
            return a instanceof K ? a.g(R(function(e) {
                return Kq(e, c, d)
            })) : Kq(a.value, c, d)
        }
    };
    var Mq = J(mq(M(function(a) {
        a = a.ad ? a.K.width * a.K.height * a.ad / (a.X.width * a.X.height) : a.V.width * a.V.height / (a.X.width * a.X.height);
        return isFinite(a) ? a : 0
    })));

    function Nq(a, b, c, d) {
        var e = d.cd,
            f = d.Yd,
            g = d.Fg,
            h = d.ff,
            k = d.te,
            l = d.dg,
            m = d.gd;
        d = d.Cg;
        b = Oq(a, c, b);
        c = Pq(a, c);
        d = Qq(b, d);
        var u = Rq(a, e, l, b),
            r = u.g(M(function(C) {
                return C.value
            }), O(), U(a, 1), gf(function(C, ea) {
                return Math.max(C, ea)
            }, 0)),
            t = u.g(M(function(C) {
                return C.value
            }), Hq(), U(a, 1)),
            w = b.g(pq, M(function(C) {
                return C.value
            }), Ue(2), O(), U(a, 1));
        g = Sq(a, b, g, h);
        var v = g.g(P(!1), O(), M(function(C) {
            return C ? k : f
        }));
        h = u.g(Fq(v), O(), U(a, 1));
        var x = zd([h, b]).g(N(function(C) {
            var ea = y(C);
            C = ea.next().value;
            ea = ea.next().value;
            return C.timestamp.equals(ea.timestamp)
        }), M(function(C) {
            var ea = y(C);
            C = ea.next().value;
            ea = ea.next().value;
            return {
                visible: C.value,
                geometry: ea.value.K
            }
        }), gf(function(C, ea) {
            return !ea.visible && C.visible ? C : ea
        }, {
            visible: !1,
            geometry: ri
        }), M(function(C) {
            return C.geometry
        }), P(ri), U(a, 1), O(si));
        l = l instanceof K ? l.g(O(), Te()) : Td;
        v = zd([l, v]).g(Te());
        var A = b.g(N(function(C) {
                return C.value.ea !== "ns" && C.value.T !== "ns"
            }), gf(function(C) {
                return C + 1
            }, 0), P(0), U(a, 1)),
            Q = c.g(Te(!0), P(!1), U(a, 1));
        Q = zd([m, Q]).g(M(function(C) {
            var ea =
                y(C);
            C = ea.next().value;
            ea = ea.next().value;
            return C && !ea
        }), U(a, 1));
        var T = b.g(Mq, O()),
            ma = T.g(M(function(C) {
                return C.value
            }), gf(function(C, ea) {
                return Math.max(C, ea)
            }, 0), O(), U(a, 1)),
            H = T.g(M(function(C) {
                return C.value
            }), Hq(), U(a, 1));
        return {
            Ie: l,
            Gc: v,
            wa: {
                pi: b,
                eg: b.g(Gq),
                Xc: x.g(O(si)),
                visible: h.g(O(sq)),
                Me: u.g(O(sq)),
                cg: r,
                bi: t,
                jf: b.g(Sp, O(Nb)),
                Pi: T,
                Vh: ma,
                ai: H,
                bd: c,
                ca: (new V(new L)).S(a),
                Yf: g,
                cd: e,
                gd: m,
                Df: Q,
                Qi: A,
                Sh: w,
                Ad: d
            }
        }
    }

    function Pq(a, b) {
        return b.g(N(function() {
            return !1
        }), M(function(c) {
            return c
        }), Ne(function(c) {
            return (new V(c)).S(a)
        }))
    }

    function Qq(a, b) {
        a = zd([a, b]).g(M(function(e) {
            var f = y(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.bg
        }), O());
        var c = a.g(M(function(e) {
                return e === void 0 ? !0 : e
            }), gf(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(gf(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), M(function(e) {
                return !!e
            }));
        return zd([b, Zd(a, c, d)]).g(M(function(e) {
            var f = y(e);
            e = f.next().value;
            var g = y(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    }

    function Oq(a, b, c) {
        return b.g(Wd(Td), U(a, 1)).g(O(function(d, e) {
            return sq(d, e, Zp)
        }), P({
            timestamp: c.now(),
            value: Yp
        }), U(a, 1))
    }

    function Rq(a, b, c, d) {
        c = d.g(Lq(c), mq(M(function(e) {
            return Math.round(e * 100) / 100
        })), U(a, 1));
        return b instanceof V ? c : zd([c, b]).g(M(function(e) {
            var f = y(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), O(sq), U(a, 10))
    }

    function Sq(a, b, c, d) {
        b = [b.g(M(function(e) {
            return e.value.K.width * e.value.K.height >= 242500
        }))];
        c instanceof K && b.push(c.g(M(function(e) {
            return !!e
        })));
        c = zd(b);
        return d ? c.g(M(function(e) {
            return e.some(function(f) {
                return f
            })
        }), P(!1), O(), U(a, 1)) : (new V(!1)).S(a)
    };
    var Tq = function(a) {
            this.j = a;
            this.ud = null;
            this.timeout = new L
        },
        Vq = function(a, b) {
            Uq(a);
            a.ud = a.j.setTimeout(function() {
                return void a.timeout.next()
            }, b)
        },
        Uq = function(a) {
            a.ud !== null && (a.j.clearTimeout(a.ud), a.ud = null)
        };

    function Wq(a, b, c, d) {
        var e = Xq.yg,
            f = new Tq(b);
        c = c.g(P(void 0), R(function() {
            Uq(f);
            return d
        })).g(M(function(g) {
            Uq(f);
            var h = g.D,
                k = g.active;
            h.value >= e || !k || (k = b.now(), k = Math.max(0, ve(k, h.timestamp)), Vq(f, Math.max(0, e - h.value - k)));
            return g.map(function(l) {
                return l >= e
            })
        }));
        return zd([c, Sd(f.timeout, ad(void 0))]).g(M(function(g) {
            return y(g).next().value
        }), jf(function(g) {
            return !g.ja().value
        }, !0), U(a, 1))
    };

    function Yq(a) {
        var b = new xq(a, {
            timestamp: a.now(),
            value: 0
        }, !1);
        return J(Aq(a), gf(function(c, d) {
            return c.D.value > d.D.value ? new xq(a, c.D, !1) : d
        }, b), M(function(c) {
            return c.map(function(d) {
                return Math.round(d)
            })
        }))
    };

    function Zq(a) {
        return function(b) {
            return J(Fq(ad(b)), Yq(a))
        }
    };

    function $q(a) {
        return function(b) {
            return J(mq(M(function(c) {
                return Eq(c, b)
            })), zq(a), M(function(c) {
                return c.map(function(d) {
                    return Math.round(d)
                })
            }))
        }
    };

    function ar(a) {
        return a.map(function(b) {
            return b.map(function(c) {
                return [c]
            })
        }).reduce(function(b, c) {
            return b.sa(c).map(function(d) {
                return d.flat()
            })
        })
    }

    function br(a, b) {
        return a.sa(b).map(function(c) {
            var d = y(c);
            c = d.next().value;
            d = d.next().value;
            return c - d
        })
    }

    function cr(a, b, c, d, e, f) {
        var g = dr;
        if (g.length > 1)
            for (var h = 0; h < g.length - 1; h++)
                if (g[h] < g[h + 1]) throw Error();
        h = f.g(P(void 0), R(function() {
            return d.g(Bq(a))
        }), O(function(k, l) {
            return k.Y(l)
        }), U(b, 1));
        f = f.g(P(void 0), R(function() {
            return d.g(Yq(a))
        }), O(function(k, l) {
            return k.Y(l)
        }), U(b, 1));
        return {
            wd: e.g(P(void 0), R(function() {
                return c.g(M(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: !0
                    }
                }), zq(a))
            }), O(function(k, l) {
                return k.Y(l)
            }), U(b, 1)),
            xd: e.g(P(void 0), R(function() {
                return c.g(M(function(k) {
                    return {
                        timestamp: k.timestamp,
                        value: k.value === 0
                    }
                }), zq(a))
            }), O(function(k, l) {
                return k.Y(l)
            }), U(b, 1)),
            uc: e.g(P(void 0), R(function() {
                return c.g(Tp(Zq(a), g))
            }), M(ar), O(function(k, l) {
                return k.Y(l)
            }), U(b, 1)),
            Ic: e.g(P(void 0), R(function() {
                return c.g(Tp($q(a), g), M(function(k) {
                    return k.map(function(l, m) {
                        return m > 0 ? br(l, k[m - 1]) : l
                    })
                }))
            }), M(ar), O(function(k, l) {
                return k.Y(l)
            }), U(b, 1)),
            tc: f,
            ab: h.g(O(function(k, l) {
                return k.Y(l)
            }), U(b, 1))
        }
    };

    function er(a) {
        var b;
        if (b = fr(a)) b = !gr(a, "abgcp") && !gr(a, "abgc") && !(typeof a.id === "string" && a.id === "abgb") && !(typeof a.id === "string" && a.id === "mys-abgc") && !gr(a, "cbb");
        return b
    }

    function gr(a, b) {
        return a.classList ? a.classList.contains(b) : (" " + a.className + " ").indexOf(" " + b + " ") > -1
    }

    function fr(a) {
        try {
            var b = a.getBoundingClientRect();
            return b && b.height >= 30 && b.width >= 30
        } catch (c) {
            return !1
        }
    }

    function hr(a, b) {
        if (a.i === void 0 || !a.i.children) return a;
        for (var c = Mb(a.i.children); c.length;) {
            var d = b ? c.filter(er) : c.filter(fr);
            if (d.length === 1) return new Vh(d[0]);
            if (d.length > 1) break;
            c = Pb(c, function(e) {
                return Mb(e.children)
            })
        }
        return a
    }

    function ir(a, b, c, d, e) {
        if (c) return {
            Wc: b,
            qb: ad(null)
        };
        c = b.element.g(M(function(f) {
            a: if (f.i === void 0 || fr(f.i)) f = {
                    od: f,
                    qb: "mue"
                };
                else {
                    var g = hr(f, e);
                    if (g.i !== void 0 && fr(g.i)) f = {
                        od: g,
                        qb: "ie"
                    };
                    else {
                        if (d || a.ie)
                            if (g = a.document.querySelector(".GoogleActiveViewInnerContainer")) {
                                f = {
                                    od: new Vh(g),
                                    qb: "ce"
                                };
                                break a
                            }
                        f = {
                            od: f,
                            qb: "mue"
                        }
                    }
                }return f
        }), hf());
        return {
            Wc: {
                sb: b.sb,
                element: c.g(M(function(f) {
                    return f.od
                }))
            },
            qb: c.g(M(function(f) {
                return f.qb
            }))
        }
    };

    function jr(a, b, c, d) {
        var e = d.cd,
            f = d.Yd,
            g = d.Fg,
            h = d.ff,
            k = d.te,
            l = d.dg,
            m = d.gd;
        d = d.Cg;
        b = kr(a, c, b);
        c = lr(a, c);
        d = mr(b, d);
        var u = nr(a, e, l, b),
            r = u.g(M(function(H) {
                return H.value
            }), O(), U(a, 1), gf(function(H, C) {
                return Math.max(H, C)
            }, 0)),
            t = u.g(M(function(H) {
                return H.value
            }), Hq(), U(a, 1)),
            w = b.g(pq, M(function(H) {
                return H.value
            }), Ue(2), O(), U(a, 1));
        g = or(a, b, g, h);
        var v = g.g(P(!1), O(), M(function(H) {
            return H ? k : f
        }));
        h = u.g(Fq(v), O(), U(a, 1));
        var x = zd([h, b]).g(N(function(H) {
                var C = y(H);
                H = C.next().value;
                C = C.next().value;
                return H.timestamp.equals(C.timestamp)
            }),
            M(function(H) {
                var C = y(H);
                H = C.next().value;
                C = C.next().value;
                return {
                    visible: H.value,
                    geometry: C.value.K
                }
            }), gf(function(H, C) {
                return !C.visible && H.visible ? H : C
            }, {
                visible: !1,
                geometry: ri
            }), M(function(H) {
                return H.geometry
            }), P(ri), U(a, 1), O(si));
        l = l instanceof K ? l.g(O(), Te()) : Td;
        v = zd([l, v]).g(Te());
        var A = b.g(N(function(H) {
                return H.value.ea !== "ns" && H.value.T !== "ns"
            }), gf(function(H) {
                return H + 1
            }, 0), P(0), U(a, 1)),
            Q = c.g(Te(!0), P(!1), U(a, 1));
        Q = zd([m, Q]).g(M(function(H) {
            var C = y(H);
            H = C.next().value;
            C = C.next().value;
            return H &&
                !C
        }), U(a, 1));
        var T = b.g(Mq, O()),
            ma = T.g(M(function(H) {
                return H.value
            }), gf(function(H, C) {
                return Math.max(H, C)
            }, 0), O(), U(a, 1));
        a = T.g(M(function(H) {
            return H.value
        }), Hq(), U(a, 1));
        return {
            Ie: l,
            Gc: v,
            wa: {
                pi: b,
                eg: b.g(Gq),
                Xc: x.g(O(si)),
                visible: h.g(O(sq)),
                Me: u.g(O(sq)),
                cg: r,
                bi: t,
                jf: b.g(Sp, O(Nb)),
                Pi: T,
                Vh: ma,
                ai: a,
                bd: c,
                ca: b.g(M(function(H) {
                    return H.value.ca
                })),
                Yf: g,
                cd: e,
                gd: m,
                Df: Q,
                Qi: A,
                Sh: w,
                Ad: d
            }
        }
    }

    function lr(a, b) {
        return b.g(N(function() {
            return !1
        }), M(function(c) {
            return c
        }), Ne(function(c) {
            return (new V(c)).S(a)
        }))
    }

    function kr(a, b, c) {
        return b.g(Wd(Td), U(a, 1)).g(O(function(d, e) {
            return sq(d, e, Zp)
        }), P({
            timestamp: c.now(),
            value: Yp
        }), U(a, 1))
    }

    function nr(a, b, c, d) {
        c = d.g(Lq(c), mq(M(function(e) {
            return Math.round(e * 100) / 100
        })), U(a, 1));
        return b instanceof V ? c : zd([c, b]).g(M(function(e) {
            var f = y(e);
            e = f.next().value;
            f = f.next().value;
            return {
                timestamp: f.timestamp.maximum(e.timestamp),
                value: f.value ? 0 : e.value
            }
        }), O(sq), U(a, 1))
    }

    function or(a, b, c, d) {
        b = [b.g(M(function(e) {
            return e.value.K.width * e.value.K.height >= 242500
        }))];
        c instanceof K && b.push(c.g(M(function(e) {
            return !!e
        })));
        c = zd(b);
        return d ? c.g(M(function(e) {
            return e.some(function(f) {
                return f
            })
        }), P(!1), O(), U(a, 1)) : (new V(!1)).S(a)
    }

    function mr(a, b) {
        a = zd([a, b]).g(M(function(e) {
            var f = y(e);
            e = f.next().value;
            if (f.next().value && e.value.isIntersecting) return e.value.bg
        }), O());
        var c = a.g(M(function(e) {
                return e === void 0 ? !0 : e
            }), gf(function(e, f) {
                return e || !f
            }, !1)),
            d = a.g(gf(function(e, f) {
                return f === void 0 ? e : f ? !1 : e != null ? e : !0
            }, void 0), M(function(e) {
                return !!e
            }));
        return zd([b, Zd(a, c, d)]).g(M(function(e) {
            var f = y(e);
            e = f.next().value;
            var g = y(f.next().value);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            var k = 0;
            if (!e) return 0;
            if (f === void 0) return 16;
            f && (k |= 1);
            f || (k |= 2);
            h && (k |= 4);
            g && (k |= 8);
            return k
        }))
    };
    var pr = J(Mo("data-google-av-itpl"), M(function(a) {
        return Number(a)
    }), M(function(a) {
        return isNaN(a) ? 1 : a
    }));
    var qr = {
            Wi: "addEventListener",
            gj: "getMaxSize",
            hj: "getScreenSize",
            ij: "getState",
            jj: "getVersion",
            tj: "removeEventListener",
            pj: "isViewable"
        },
        rr = function(a, b) {
            this.ta = null;
            this.Jh = new L;
            b = b || this.Ri;
            var c = a.ie,
                d = !a.kc;
            if (c && d) {
                var e = a.global.top.mraid;
                if (e) {
                    this.Vc = b(e);
                    this.ta = e;
                    this.rb = 3;
                    return
                }
            }(a = a.global.mraid) ? (this.Vc = b(a), this.ta = a, this.rb = c ? d ? 2 : 1 : 0) : (this.rb = -1, this.Vc = 2)
        };
    rr.prototype.addEventListener = function(a, b) {
        return this.Pb("addEventListener", a, b)
    };
    rr.prototype.removeEventListener = function(a, b) {
        return this.Pb("removeEventListener", a, b)
    };
    rr.prototype.Jf = function() {
        var a = this.Pb("getVersion");
        return typeof a === "string" ? a : ""
    };
    rr.prototype.getState = function() {
        var a = this.Pb("getState");
        return typeof a === "string" ? a : ""
    };
    var sr = function(a) {
            a = a.Pb("isViewable");
            return typeof a === "boolean" ? a : !1
        },
        tr = function(a) {
            if (a.ta) return a = a.ta.AFMA_LIDAR, typeof a === "string" ? a : void 0
        };
    rr.prototype.Ri = function(a) {
        return a ? a.IS_GMA_SDK ? Object.values(qr).every(function(b) {
            return typeof a[b] === "function"
        }) ? 0 : 1 : 2 : 1
    };
    rr.prototype.Pb = function(a) {
        var b = B.apply(1, arguments);
        if (this.ta) try {
            return this.ta[a].apply(this.ta, z(b))
        } catch (c) {
            this.Jh.next(a)
        }
    };
    da.Object.defineProperties(rr.prototype, {
        sf: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                if (this.ta) {
                    var a = this.ta.AFMA_LIDAR_EXP_1;
                    return a === void 0 ? void 0 : !!a
                }
            },
            set: function(a) {
                this.ta && (this.ta.AFMA_LIDAR_EXP_1 = a)
            }
        }
    });

    function ur(a, b) {
        return (new rr(a)).rb !== -1 ? (new V(!0)).S(a.h) : b.g(Mo("data-google-av-inapp"), M(function(c) {
            return c !== null
        }), U(a.h, 1))
    };
    var wr = function(a, b) {
            var c = this;
            this.j = a;
            this.ve = this.md = null;
            this.ui = b.g(O()).subscribe(function(d) {
                vr(c);
                c.ve = d
            })
        },
        xr = function(a, b) {
            vr(a);
            a.md = a.j.setTimeout(function() {
                var c;
                return void((c = a.ve) == null ? void 0 : c.next())
            }, b)
        },
        vr = function(a) {
            a.md !== null && a.j.clearTimeout(a.md);
            a.md = null
        };
    wr.prototype.dispose = function() {
        vr(this);
        this.ui.unsubscribe();
        this.ve = null
    };

    function yr(a, b, c, d, e) {
        var f = Xq.yg;
        var g = g === void 0 ? new wr(b, d) : g;
        return (new K(function(h) {
            var k = c.g(P(void 0), R(function() {
                return zr(e)
            })).g(M(function(l) {
                var m = l.value;
                l = l.timestamp;
                var u = m.visible;
                m = m.ab;
                var r = m >= f;
                r || !u ? vr(g) : (l = Math.max(0, ve(b.now(), l)), xr(g, Math.max(0, f - m - l)));
                return r
            }), gf(function(l, m) {
                return m || l
            }, !1), O()).subscribe(h);
            return function() {
                g.dispose();
                k.unsubscribe()
            }
        })).g(jf(function(h) {
            return !h
        }, !0), U(a, 1))
    }

    function zr(a) {
        return Ep([a, a.g(Up())]).g(M(function(b) {
            var c = y(b);
            b = c.next().value;
            c = c.next().value;
            return {
                timestamp: b.timestamp,
                value: {
                    visible: b.value,
                    ab: c.value
                }
            }
        }), O(function(b, c) {
            return sq(b, c, function(d, e) {
                return d.ab === e.ab && d.visible === e.visible
            })
        }))
    };

    function Ar(a, b) {
        return {
            Jd: b.g(Mo("data-google-av-adk")),
            Zb: b.g(Mo("data-google-av-btr"), O(), M(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Sd: b.g(Mo("data-google-av-cpmav"), O(), M(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            Re: b.g(Mo("data-google-av-vrus"), O(), M(function(c) {
                return c === null ? [] : c.split("|").filter(function(d) {
                    return d !== ""
                })
            })),
            gh: rp(a, b),
            flags: b.g(Mo("data-google-av-flags"), O()),
            jb: ur(a, b),
            pe: b.g(Ip("cr", function(c) {
                return c ===
                    "1"
            }), O()),
            Oh: b.g(Ip("omid", function(c) {
                return c === "1"
            }), O()),
            ke: b.g(pr),
            metadata: b.g(Mo("data-google-av-metadata")),
            Ra: b.g(To),
            na: b.g(No),
            Vi: b.g(Ip("la", function(c) {
                return c === "1"
            }), O()),
            kb: b.g(Mo("data-google-av-turtlex"), M(function(c) {
                return c !== null
            }), O()),
            se: b.g(Mo("data-google-av-vattr"), M(function(c) {
                return c !== null
            }), O())
        }
    };

    function Br() {
        return J(Hp(), gf(function(a, b) {
            return Math.max(a, b)
        }, 0), M(function(a) {
            return Math.round(a)
        }))
    };

    function Cr(a) {
        return J(Fq(ad(a)), Br())
    };

    function Dr(a, b, c, d, e) {
        c = c.g(M(function() {
            return !1
        }));
        d = zd([e, d]).g(R(function(f) {
            f = y(f).next().value;
            return Er(b, f)
        }));
        return Sd(ad(!1), c, d).g(O(), U(a.h, 1))
    }

    function Er(a, b) {
        return a.g(M(function(c) {
            return b || c === 0 || c === 2
        }))
    };
    var Fr = [33, 32],
        Gr = J(pr, M(function(a) {
            return Fr.indexOf(a) >= 0
        }), O());

    function Hr(a, b, c, d, e, f) {
        var g = c.g(M(function(k) {
                return k === 9
            })),
            h = b.element.g(Gr);
        c = e.g(N(function(k) {
            return k
        }), R(function() {
            return zd([g, h])
        }), M(function(k) {
            var l = y(k);
            k = l.next().value;
            return !l.next().value || k
        }), O());
        f = zd([c, d.g(O()), f]).g(M(function(k) {
            var l = y(k);
            k = l.next().value;
            var m = l.next().value;
            l = l.next().value;
            return ir(a, b, !k, m, l)
        }), ef(1), ld());
        d = f.g(M(function(k) {
            return k.Wc
        }));
        f = f.g(R(function(k) {
            return k.qb
        }), P(null), O(), U(a.h, 1));
        return {
            Pa: d,
            bc: f
        }
    };

    function Ir(a) {
        var b = b === void 0 ? !1 : b;
        return J(R(function(c) {
            return oi(a.document, c, b)
        }), U(a.h, 1))
    };
    var Jr = function(a, b, c, d, e, f) {
        this.qc = b.element.g(Ir(a), U(a.h, 1));
        this.tg = Dr(a, c, b.element, this.qc, d);
        c = Hr(a, b, e, d, this.tg, f);
        d = c.bc;
        this.Pa = c.Pa;
        this.bc = d;
        this.Se = Sd((new V(1)).S(a.h), b.element.g(Ue(1), M(function() {
            return 2
        }), U(a.h, 1)), this.qc.g(Ue(1), M(function() {
            return 3
        }), U(a.h, 1)), this.tg.g(N(Boolean), Ue(1), M(function() {
            return 0
        }), U(a.h, 1))).g(jf(function(g) {
            return g !== 0
        }, !0), U(a.h, 0))
    };

    function Kr(a, b) {
        return a && b === 0 ? 15 : a || b !== 1 ? null : 14
    }

    function Lr(a, b, c) {
        return b instanceof K ? b.g(R(function(d) {
            return (d = Kr(d, c)) ? bd(new fe(d)) : a
        })) : (b = Kr(b.value, c)) ? bd(new fe(b)) : a
    };

    function Mr(a) {
        var b = new fe(13);
        if (a.length < 1) return {
            chain: Ec,
            Od: Ec
        };
        var c = new L,
            d = a[0];
        return {
            chain: a.slice(1).reduce(function(e, f) {
                return e.g(Ne(function(g) {
                    c.next(g);
                    return f
                }))
            }, d).g(Ne(function(e) {
                c.next(e);
                return bd(b)
            }), df(new L), ld()),
            Od: c
        }
    };
    var Nr = function() {};
    var Or = function(a, b) {
        this.context = a;
        this.Ki = b
    };
    q(Or, Nr);
    Or.prototype.Ya = function(a, b) {
        var c = this.Ki.map(function(f) {
                return f.Ya(a, b)
            }),
            d = Mr(c.map(function(f) {
                return f.fb
            })),
            e = d.Od.g(Pr());
        return {
            fb: d.chain.g(U(this.context.h, 1)),
            Xa: Object.assign.apply(Object, [{
                Ke: e,
                fk: d.Od
            }].concat(z(c.map(function(f) {
                return f.Xa
            }))))
        }
    };
    var Pr = function() {
        return gf(function(a, b) {
            b instanceof fe ? a.push(b.Yh) : a.push(-1);
            return a
        }, [])
    };

    function Qr(a, b) {
        var c = a.g(df(new L), ld());
        return R(function(d) {
            return c.g(b(d))
        })
    };

    function Rr(a, b) {
        if (a.kc) return bd(new fe(6));
        var c = new L;
        return Sd(ad({}), b, c).g(M(function() {
            return {
                timestamp: a.j.now(),
                value: {
                    ea: "geo",
                    ia: Sr(a),
                    X: Eo(a, !0),
                    ca: c,
                    oa: {
                        x: 0,
                        y: 0
                    }
                }
            }
        }), Hh(a.h))
    }

    function Sr(a) {
        var b = Eo(a, !1);
        if (!a.ie || !ph(a.global.parent) || a.global.parent === a.global) return b;
        var c = new Ao(a.global.parent, a.Ca);
        c.I = a.I;
        c = Sr(c);
        a = a.global.frameElement.getBoundingClientRect();
        return ti(ui(ti(c, a), {
            x: b.left - a.left,
            y: b.top - a.top
        }), b)
    };
    var Tr = function(a, b) {
        this.context = a;
        this.ob = b
    };
    q(Tr, Nr);
    Tr.prototype.Ya = function(a, b) {
        var c = Qr(Rr(this.context, this.ob), $p(this.context, b.Ra));
        return {
            fb: Lr(a.Pa.g(c), b.jb, 0),
            Xa: {}
        }
    };
    var Ur = function(a, b, c) {
        c = c === void 0 ? eq(a, b) : c;
        this.context = a;
        this.Mh = c
    };
    q(Ur, Nr);
    Ur.prototype.Ya = function(a, b) {
        var c = this.Mh(b.Dg);
        return {
            fb: Lr(a.Pa.g(c, iq(this.context)), b.jb, 0),
            Xa: {}
        }
    };

    function Vr(a, b, c, d, e) {
        var f = f === void 0 ? new rr(a) : f;
        var g = g === void 0 ? pf(a.j, 500) : g;
        var h = h === void 0 ? pf(a.j, 100) : h;
        e = ad(f).g(Wr(c), kf(function(k) {
            d.next(k.rb)
        }), Xr(a, h), Yr(a), Zr(a, e), ef(1), ld());
        f = new L;
        b = Sd(ad({}), b, f);
        return e.g($r(a, f, b, g, c), U(a.h, 1))
    }

    function Zr(a, b) {
        return J(function(c) {
            return zd([c, b])
        }, Ve(function(c) {
            var d = y(c);
            c = d.next().value;
            return d.next().value !== 9 || sr(c) ? ad(!0) : as(a, c, "viewableChange").g(N(function(e) {
                return y(e).next().value
            }), Ue(1))
        }), M(function(c) {
            return y(c).next().value
        }))
    }

    function Wr(a) {
        return R(function(b) {
            if (b.rb === -1) return a.next("if"), bd(new fe(7));
            if (b.Vc !== 0) switch (b.Vc) {
                case 1:
                    return a.next("mm"), bd(new fe(18));
                case 2:
                    return a.next("ng"), bd(new fe(17));
                default:
                    return a.next("i"), bd(new fe(8))
            }
            return ad(b)
        })
    }

    function Xr(a, b) {
        return Ve(function() {
            var c = a.gg;
            return mi(a.document) === "complete" ? ad(!0) : c.g(Ve(function() {
                return b
            }))
        })
    }

    function Yr(a) {
        return R(function(b) {
            return b.getState() !== "loading" ? ad(b) : as(a, b, "ready").g(M(function() {
                return b
            }))
        })
    }

    function $r(a, b, c, d, e) {
        return R(function(f) {
            var g = tr(f);
            if (typeof g !== "string") return e.next("nc"), bd(new fe(9));
            f.sf !== void 0 && (f.sf = !0);
            g = as(a, f, g, bs);
            var h = {
                version: f.Jf(),
                rb: f.rb
            };
            g = g.g(M(function(l) {
                return cs.apply(null, [a, b, f, h].concat(z(l)))
            }));
            var k = d.g(kf(function() {
                e.next("mt")
            }), R(function() {
                return bd(new fe(10))
            }));
            g = Xd(g, k);
            return zd([g, c]).g(M(function(l) {
                l = y(l).next().value;
                return Object.assign({}, l, {
                    timestamp: a.j.now()
                })
            }))
        })
    }

    function bs(a, b) {
        return (b === null || typeof b === "number") && (a === null || !!a && typeof a.height === "number" && typeof a.width === "number" && typeof a.x === "number" && typeof a.y === "number")
    }

    function cs(a, b, c, d, e, f) {
        e = e ? {
            left: e.x,
            top: e.y,
            width: e.width,
            height: e.height
        } : ri;
        c = c.Pb("getMaxSize");
        var g = c != null && typeof c.width === "number" && typeof c.height === "number" ? c : {
            width: 0,
            height: 0
        };
        c = {
            left: 0,
            top: 0,
            width: -1,
            height: -1
        };
        if (g) {
            var h = Number(String(g.width));
            g = Number(String(g.height));
            c = isNaN(h) || isNaN(g) ? c : {
                left: 0,
                top: 0,
                width: h,
                height: g
            }
        }
        a = {
            value: {
                ia: e,
                X: c,
                ea: "mraid",
                ca: b,
                oa: {
                    x: 0,
                    y: 0
                }
            },
            timestamp: a.j.now()
        };
        return Object.assign({}, a, d, {
            zj: f
        })
    }

    function as(a, b, c, d) {
        d = d === void 0 ? function() {
            return !0
        } : d;
        return (new K(function(e) {
            var f = a.H.Tb(745, function() {
                e.next(B.apply(0, arguments))
            });
            b.addEventListener(c, f);
            return function() {
                b.removeEventListener(c, f)
            }
        })).g(N(function(e) {
            return d.apply(null, z(e))
        }))
    };
    var ds = function(a, b) {
        this.context = a;
        this.ob = b
    };
    q(ds, Nr);
    ds.prototype.Ya = function(a, b) {
        var c = new dd(1),
            d = new dd(1),
            e = Qr(Vr(this.context, this.ob, c, d, b.Ra), $p(this.context, b.Ra));
        return {
            fb: Lr(a.Pa.g(e), b.jb, 1),
            Xa: {
                we: c.g(U(this.context.h, 1)),
                xe: d.g(U(this.context.h, 1))
            }
        }
    };

    function es(a) {
        return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a)
    };

    function fs(a, b) {
        var c = c === void 0 ? null : c;
        var d = new L,
            e = void 0,
            f = a.Cf,
            g = d.g(M(function() {
                return e ? Object.assign({}, e, {
                    timestamp: a.j.now()
                }) : null
            }), N(function(k) {
                return k !== null
            }), M(function(k) {
                return k
            }));
        b = zd([Sd(f, g), b]);
        var h = c;
        return b.g(N(function(k) {
            k = y(k).next().value;
            h === null && (h = k.value.Rg);
            return k.value.Rg === h
        }), kf(function(k) {
            return void(e = y(k).next().value)
        }), M(function(k) {
            var l = y(k);
            k = l.next().value;
            l = l.next().value;
            try {
                var m = k.value.data,
                    u = k.timestamp,
                    r = m.viewport,
                    t, w, v = Object.assign({},
                        r, {
                            width: (t = r == null ? void 0 : r.width) != null ? t : 0,
                            height: (w = r == null ? void 0 : r.height) != null ? w : 0,
                            x: 0,
                            y: 0,
                            Zj: r ? r.width * r.height : 0
                        }),
                    x = gs(v),
                    A = m.adView,
                    Q = A.measuringElement && A.containerGeometry ? gs(A.containerGeometry) : gs(A.geometry),
                    T = gs(A.geometry),
                    ma = A.reasons.some(es),
                    H = ma ? ri : gs(A.onScreenGeometry),
                    C;
                l && (C = A.percentageInView / 100);
                l && ma && (C = 0);
                return {
                    timestamp: u,
                    value: {
                        ea: "omid",
                        ia: Q,
                        X: x,
                        ca: d,
                        T: "omid",
                        K: T,
                        oa: {
                            x: Q.left,
                            y: Q.top
                        },
                        V: H,
                        ad: C
                    }
                }
            } catch (hc) {
                Jg(hc, Sg());
                var ea, Dc;
                m = (Dc = (ea = hc) == null ? void 0 : ea.message) !=
                    null ? Dc : "An unknown error occurred";
                ea = "Error while processing geometryChange event: " + JSON.stringify(k.value) + "; " + m;
                throw Error(ea);
            }
        }), ef(1), ld())
    }

    function gs(a) {
        var b, c, d, e;
        return {
            left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
            top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
            width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
            height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0)
        }
    };

    function hs(a, b, c, d) {
        c = c === void 0 ? Td : c;
        var e = a.h;
        if (b === null) return bd(new fe(20));
        if (!b.validate()) return bd(new fe(21));
        var f;
        d = is(e, b, d).g(M(function(g) {
            var h = g.value;
            g = g.timestamp;
            var k = b.j,
                l = a.j;
            if (k.timeline !== g.timeline) throw new ke;
            g = new te(g.value - k.now().value + l.now().value, l.timeline);
            return f = {
                value: h,
                timestamp: g
            }
        }));
        return Sd(d, c.g(M(function() {
            return f
        }))).g(N(function(g) {
            return g !== void 0
        }), M(function(g) {
            return g
        }), U(a.h, 1))
    }

    function is(a, b, c) {
        return fs(b, c).g(U(a, 1), M(function(d) {
            return {
                timestamp: d.timestamp,
                value: {
                    oa: {
                        x: d.value.K.left,
                        y: d.value.K.top
                    },
                    ia: d.value.V,
                    X: d.value.X,
                    ea: d.value.T,
                    ca: d.value.ca
                }
            }
        }))
    };
    var js = function(a, b, c) {
        this.ma = a;
        this.O = b;
        this.ob = c
    };
    q(js, Nr);
    js.prototype.Ya = function(a, b) {
        var c = b.Ra;
        b = hs(this.O, this.ma, this.ob, b.fg);
        c = Qr(b, $p(this.O, c));
        return {
            fb: a.Pa.g(c),
            Xa: {}
        }
    };
    var ks = function(a, b, c) {
        this.ma = a;
        this.O = b;
        this.rh = c
    };
    q(ks, Nr);
    ks.prototype.Ya = function(a, b) {
        var c = hs(this.O, this.ma, void 0, b.fg);
        b = hq(this.O, b.Dg, this.rh);
        c = Qr(c, b);
        return {
            fb: a.Pa.g(c),
            Xa: {}
        }
    };

    function ls(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function ms(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    };

    function ns(a) {
        return a.document.ki.g(M(function(b) {
            return b === "visible"
        }), O(), U(a.h, 1))
    };
    var os;
    os = ["2025072101"].slice(-1)[0].substring(0, 8);

    function ps(a, b, c) {
        var d;
        return b.g(O(), R(function(e) {
            return c.g(M(function() {
                if (!d) {
                    d = !0;
                    try {
                        e.next()
                    } finally {
                        d = !1
                    }
                }
                return !0
            }))
        }), P(!1), U(a.h, 1))
    };

    function qs(a) {
        return J(mq(M(function(b) {
            return Eq(b, a)
        })), Gp(), M(function(b) {
            return Math.round(b)
        }))
    };

    function rs(a, b, c, d, e) {
        var f = dr;
        if (f.length > 1)
            for (var g = 0; g < f.length - 1; g++)
                if (f[g] < f[g + 1]) throw Error();
        g = e.g(P(void 0), R(function() {
            return c.g(Up())
        }), O(), U(a, 1));
        e = e.g(P(void 0), R(function() {
            return c.g(Br())
        }), O(), U(a, 1));
        return {
            wd: d.g(P(void 0), R(function() {
                return b.g(M(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: !0
                    }
                }), Gp())
            }), O(), U(a, 1)),
            xd: d.g(P(void 0), R(function() {
                return b.g(M(function(h) {
                    return {
                        timestamp: h.timestamp,
                        value: h.value === 0
                    }
                }), Gp())
            }), O(), U(a, 1)),
            uc: d.g(P(void 0), R(function() {
                return b.g(Tp(Cr,
                    f))
            }), O(Nb), U(a, 1)),
            Ic: d.g(P(void 0), R(function() {
                return b.g(Tp(qs, f), M(function(h) {
                    return h.map(function(k, l) {
                        return l > 0 ? k - h[l - 1] : k
                    })
                }))
            }), O(Nb), U(a, 1)),
            tc: e,
            ab: g.g(O(sq), U(a, 1))
        }
    };

    function ss(a, b, c) {
        var d = c.g(M(function(e) {
            return {
                value: e,
                timestamp: a.j.now()
            }
        }), O(sq));
        return b instanceof K ? b.g(O(), R(function(e) {
            return e ? (new V({
                value: !1,
                timestamp: a.j.now()
            })).S(a.h) : d
        })) : b.value === !1 ? d : new V(!1)
    }

    function ts(a, b, c, d, e, f, g) {
        var h = Xq;
        b = b instanceof K ? b.g(P(!1), O()) : b;
        var k = !(fh() || gh());
        c = ss(a, c, d);
        a = g.Pa.g(Dp(a.h));
        return Object.assign({}, h, {
            cd: c,
            Fg: e,
            ff: k,
            dg: b,
            gd: a,
            Cg: f
        })
    };

    function us(a) {
        a = a.global;
        if (typeof a.__google_lidar_ === "undefined") return a.__google_lidar_ = 1, !1;
        a.__google_lidar_ = Number(a.__google_lidar_) + 1;
        var b = a.__google_lidar_adblocks_count_;
        if (typeof b === "number" && b > 0 && (a = a.__google_lidar_radf_, typeof a === "function")) try {
            a()
        } catch (c) {}
        return !0
    }

    function vs(a) {
        var b = a.global;
        b.osdlfm = function() {
            return b.__google_lidar_radf_
        };
        if (b.__google_lidar_radf_ !== void 0) return Ec;
        b.__google_lidar_adblocks_count_ = 1;
        var c = new L;
        b.__google_lidar_radf_ = function() {
            return void c.next(a)
        };
        return c.g(tg(a.H, 743))
    };
    var ws = function(a) {
            var b = this;
            this.re = !1;
            this.Ae = [];
            this.ze = [];
            a(function(c) {
                b.re = !0;
                b.resolution = c;
                b.evaluate()
            }, function(c) {
                b.ri = c;
                b.evaluate()
            })
        },
        xs = function(a) {
            return new ws(function(b, c) {
                var d = [],
                    e = 0;
                a.forEach(function(f, g) {
                    f.then(function(h) {
                        d[g] = h;
                        ++e === a.length && b(d)
                    }).catch(function(h) {
                        c(h)
                    })
                })
            })
        };
    ws.prototype.evaluate = function() {
        var a = this.resolution,
            b = this.ri;
        if (b !== void 0 || this.re) this.re && this.Ae.forEach(function(c) {
            return void c(a)
        }), b !== void 0 && this.ze.forEach(function(c) {
            return void c(b)
        }), this.Ae = [], this.ze = []
    };
    ws.prototype.then = function(a) {
        this.Ae.push(a);
        this.evaluate();
        return this
    };
    ws.prototype.catch = function(a) {
        this.ze.push(a);
        this.evaluate();
        return this
    };
    var ys = function(a) {
        this.children = a;
        this.ne = !1;
        this.Pd = []
    };
    ys.prototype.complete = function() {
        var a = this;
        this.ne = !0;
        this.Pd.forEach(function(b) {
            return void b(a)
        });
        this.Pd.splice(0)
    };
    ys.prototype.onComplete = function(a) {
        this.ne ? a(this) : this.Pd.push(a)
    };
    ys.prototype.Za = function(a) {
        var b = this.children.map(function(c) {
            return c.Za(a)
        });
        return b.find(function(c) {
            return c !== 2
        }) === void 0 ? 2 : this.completed ? 0 : b.some(function(c) {
            return c === 1
        }) ? 1 : 0
    };
    da.Object.defineProperties(ys.prototype, {
        completed: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.ne
            }
        }
    });
    var zs = function() {
        var a = B.apply(0, arguments);
        ys.call(this, a);
        var b = this;
        this.events = a;
        var c = this.events.length;
        this.events.forEach(function(d) {
            d.onComplete(function() {
                --c === 0 && b.complete()
            })
        })
    };
    q(zs, ys);
    zs.prototype.clone = function() {
        return new(Function.prototype.bind.apply(zs, [null].concat(z(this.events.map(function(a) {
            return a.clone()
        })))))
    };
    zs.prototype.Ne = function(a, b) {
        var c = this;
        if (!this.completed) {
            var d = this.events.find(function(e) {
                return e.Za(a) === 1
            });
            d !== void 0 && d.Ne(a, function() {
                c.completed || b()
            })
        }
    };
    var As = function(a, b) {
        ys.call(this, []);
        this.Xd = a;
        this.hd = Symbol(b);
        this.li = a
    };
    q(As, ys);
    As.prototype.clone = function() {
        var a = new As(this.li, this.hd.description);
        a.hd = this.hd;
        return a
    };
    As.prototype.Za = function(a) {
        return a !== this.event ? 2 : this.completed || this.Xd === 0 ? 0 : 1
    };
    As.prototype.Ne = function(a, b) {
        this.Za(a) === 1 && (this.Xd--, b(), this.Xd === 0 && this.complete())
    };
    da.Object.defineProperties(As.prototype, {
        event: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.hd
            }
        }
    });
    var Bs = function(a) {
        As.call(this, 1, a)
    };
    q(Bs, As);
    var Cs = function(a, b, c) {
        var d = B.apply(3, arguments);
        this.Ma = a;
        this.oh = b;
        this.Ud = c;
        this.sc = new Set;
        this.Ib = d;
        if (this.Ma.O) this.context = this.Ma.O;
        else if (this.Ma.ma) this.context = this.Ma.ma;
        else throw Error("Ia");
        var e = d.reduce(function(h, k) {
            k.subscribedEvents.forEach(function(l) {
                return void h.add(l)
            });
            return h
        }, new Set);
        e = y(e.values());
        for (var f = e.next(), g = {}; !f.done; g = {
                wf: void 0
            }, f = e.next()) {
            g.wf = f.value;
            f = d.filter(function(h) {
                return function(k) {
                    return k.controlledEvents.indexOf(h.wf) >= 0
                }
            }(g));
            if (f.length ===
                0) throw Error("Ja");
            if (f.length > 1) throw Error("Ka");
        }
    };
    Cs.prototype.start = function() {
        var a = this;
        this.Ib.forEach(function(b) {
            return void b.start(a.Ma)
        });
        this.Ud.start(this.Ma, this.wh.bind(this), this.Bb.bind(this), function() {})
    };
    Cs.prototype.dispose = function() {
        var a = this;
        this.Ud.dispose();
        this.sc.forEach(function(b) {
            return void a.Bb(b)
        });
        this.Ib.forEach(function(b) {
            return void b.dispose()
        })
    };
    var Ds = function(a, b) {
            b = {
                measuringCreativeIds: [].concat(z(a.sc.values())).map(function(c) {
                    return a.context.dc.getName(c)
                }),
                hasCreativeSourceCompleted: !!a.Ud.td,
                colleagues: a.Ib.map(function(c) {
                    return {
                        name: c.name,
                        controlledEvents: c.controlledEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        }),
                        subscribedEvents: c.subscribedEvents.map(function(d) {
                            var e;
                            return (e = d.description) != null ? e : "n/a"
                        })
                    }
                }),
                ephemeralCreativeStateChanges: b
            };
            b = {
                specMajor: 2,
                specMinor: 0,
                specPatch: 0,
                instanceId: a.context.dc.getName(a.context.sb),
                timestamp: ve(a.context.j.now(), new te(0, a.context.j.timeline)),
                mediatorState: b
            };
            ce(a.context, b)
        },
        Es = function(a, b, c, d, e) {
            var f = {};
            Ds(a, (f[b] = {
                events: [{
                    timestamp: c,
                    description: d,
                    status: e
                }]
            }, f))
        };
    Cs.prototype.wh = function(a, b, c) {
        var d = this;
        if (!this.sc.has(a)) {
            var e = this.oh.clone();
            this.sc.add(a);
            Ds(this, {});
            var f = !1,
                g = [];
            this.Ib.forEach(function(h) {
                var k = function(l, m, u) {
                    var r = d.context.dc.getName(a),
                        t = ve(d.context.j.now(), new te(0, d.context.j.timeline)),
                        w, v = (w = l.description) != null ? w : "n/a";
                    if (h.controlledEvents.indexOf(l) < 0 || e.Za(l) !== 1) return u(!1), Es(d, r, t, v, 1), new ws(function(A) {
                        return void A()
                    });
                    var x = new ws(function(A) {
                        e.Ne(l, function() {
                            d.Ib.filter(function(Q) {
                                return Q.subscribedEvents.indexOf(l) >=
                                    0
                            }).forEach(function(Q) {
                                return void Q.handleEvent(a, l, m)
                            });
                            A()
                        })
                    });
                    return new ws(function(A) {
                        x.then(function() {
                            u(!0);
                            Es(d, r, t, v, 2);
                            A()
                        })
                    })
                };
                h.fe(a, b, c, function(l, m, u) {
                    return f ? k(l, m, u) : new ws(function(r) {
                        g.push(function() {
                            k(l, m, u).then(function() {
                                r()
                            })
                        })
                    })
                }, function(l) {
                    try {
                        d.context.I.J("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=colleague-executed&name=" + l, {
                            ha: "GET"
                        }).sendNow()
                    } catch (m) {}
                })
            });
            f = !0;
            g.forEach(function(h) {
                return void h()
            })
        }
    };
    Cs.prototype.Bb = function(a) {
        this.sc.delete(a);
        this.Ib.forEach(function(b) {
            b.Bb(a)
        });
        Ds(this, {})
    };
    var Fs = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? !1 : b;
            this.valueType = "boolean"
        },
        Gs = function(a, b) {
            this.key = a;
            this.defaultValue = b === void 0 ? 0 : b;
            this.valueType = "number"
        };
    var Hs = {
        considerOmidZOrderOcclusions: [new Fs("100006"), !1],
        extraPings: [new Gs("45362137"), 0],
        extrapolators: [new Fs("45377435"), !1],
        rxlidarStatefulBeacons: [new Fs("45372163"), !1],
        shouldIgnoreAdChoicesIcon: [new Fs("45382077"), !1],
        dedicatedViewableAttributionPing: [new Gs("45389692"), 0],
        useReachIntegrationPolyfill: [new Fs("45407239"), !1],
        useReachIntegrationSharedStorage: [new Fs("45407240", !0), !0],
        sendBrowserIdInsteadOfVPID: [new Fs("45407241"), !1],
        waitForImpressionColleague: [new Fs("45430682"), !1],
        fetchLaterBeacons: [new Fs("45618478"), !1],
        rxInNonrx: [new Fs("45642405"), !1],
        addQueryIdToErrorPing: [new Fs("45653435"), !1],
        shouldSendExplicitDisplayMeasurablePing: [new Fs("45658589"), !1],
        reachUseCreateWorklet: [new Fs("45661569"), !1],
        tosCustomTimeoutMillis: [new Gs("45706257", 36E5), 36E5]
    };

    function Is(a) {
        return Object.entries(Hs).reduce(function(b, c) {
            var d = y(c);
            c = d.next().value;
            var e = y(d.next().value);
            d = e.next().value;
            e = e.next().value;
            var f;
            if (a == null) var g = void 0;
            else a: {
                var h = a.zf[d.key];
                if (d.valueType === "proto") {
                    try {
                        var k = JSON.parse(h);
                        if (Array.isArray(k)) {
                            g = k;
                            break a
                        }
                    } catch (l) {}
                    g = d.defaultValue
                } else g = typeof h === typeof d.defaultValue ? h : d.defaultValue
            }
            b[c] = (f = g) != null ? f : e;
            return b
        }, {})
    };
    var Lm = function(a) {
        fo.call(this, a)
    };
    q(Lm, fo);
    var Js = function(a) {
        return fl(vm(a, 3))
    };
    Lm.prototype.ce = function() {
        return Rm(this, 4, !0)
    };
    var Ks = function(a) {
        return Sk(vm(a, 5))
    };
    Lm.prototype.dd = function() {
        return Sm(this, 6)
    };
    Lm.U = "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
    var Ls = [0, Tn, -2, Sn, -1, Pn];
    Lm.prototype.N = ho(Ls);
    var Ms = function(a) {
        fo.call(this, a)
    };
    q(Ms, fo);
    Ms.prototype.getType = function() {
        var a = a === void 0 ? 0 : a;
        var b = Wk(vm(this, 6));
        return b != null ? b : a
    };
    var Ns = io(Ms);
    Ms.U = "ads.geo.GeoTargetMessage";
    var Os = function(a) {
        fo.call(this, a)
    };
    q(Os, fo);
    n = Os.prototype;
    n.Ef = function() {
        return Tm(this, 2)
    };
    n.Ff = function() {
        return fl(vm(this, 2))
    };
    n.ce = function() {
        return Rm(this, 3, !0)
    };
    n.Gf = function() {
        return Nm(this, Ms, 4)
    };
    n.qg = function(a) {
        return Qm(this, Ms, 4, a)
    };
    n.If = function() {
        return Em(this, 7, Wk, void 0 === Bk ? 2 : 4)
    };
    n.df = function(a) {
        return Ym(this, 7, a)
    };
    n.rg = function(a) {
        return Um(this, 9, a)
    };
    n.dd = function() {
        return Sm(this, 10)
    };
    Os.U = "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
    var Ps = [0, Wn, -4, Yn, Sn, Pn, Ln, Wn, Ln, Wn, Pn, Wn, -1, [0, Pn, -3], Xn, On, Wn, Nn, -1, Pn, -1, Nn, Ln, [0, Nn, Pn, -1, Yn, Ln, Nn], Kn, Wn, [0, Pn]];
    Ms.prototype.N = ho(Ps);
    var Qs = [0, Tn, -1, Sn, Ps, Qn, -1, Zn, Pn, Sn, Pn];
    Os.prototype.N = ho(Qs);
    var Rs = function(a) {
        fo.call(this, a)
    };
    q(Rs, fo);
    Rs.prototype.Ef = function() {
        return Tm(this, 1)
    };
    Rs.prototype.Ff = function() {
        return fl(vm(this, 1))
    };
    Rs.prototype.dd = function() {
        return Sm(this, 2)
    };
    Rs.U = "ads.branding.measurement.client.serving.integrations.shared.SharedMetadata";
    var Ss = [0, Tn, Pn];
    Rs.prototype.N = ho(Ss);
    var Ts = function(a) {
        fo.call(this, a)
    };
    q(Ts, fo);
    var Us = function(a) {
        return Nm(a, Os, 1)
    };
    Ts.U = "ads.branding.measurement.client.serving.IntegratorMetadata";
    var Vs = [0, Qs, Ls, Ss];
    Ts.prototype.N = ho(Vs);
    var Ws = go(Ts, Vs);
    var Xs = function() {
        this.zf = {}
    };
    var Ys = function() {
        this.rf = !1;
        this.nf = new Map
    };
    Ys.prototype.start = function(a, b, c, d) {
        var e = this;
        if (this.td === void 0 && a.O) {
            var f = a.O;
            this.mf = d;
            c = !this.rf && us(f);
            d = this.rf ? Ec : vs(f);
            d = Wo(f, d);
            this.td = (c ? Ec : d.g(M(function(g) {
                var h = h === void 0 ? Symbol() : h;
                return Object.freeze({
                    sb: h,
                    element: (new V(g)).S(f.h)
                })
            }), Oo())).subscribe(function(g) {
                var h = g.sb;
                e.nf.set(h, g);
                g.element.g(Ue(1)).subscribe(function(k) {
                    var l = Lo(k, "data-google-av-flags"),
                        m = new Xs;
                    if (l !== null) try {
                        var u = JSON.parse(l)[0];
                        l = "";
                        for (var r = 0; r < u.length; r++) l += String.fromCharCode(u.charCodeAt(r) ^
                            "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(r % 10));
                        m.zf = JSON.parse(l)
                    } catch (w) {}
                    m = Is(m);
                    k = Lo(k, "data-google-av-ufs-integrator-metadata");
                    a: {
                        if (k !== null) try {
                            var t = Ws(k);
                            break a
                        } catch (w) {}
                        t = new Ts
                    }
                    b(h, t, m)
                })
            });
            c && this.dispose();
            a.ma && Lf(a.ma)
        }
    };
    Ys.prototype.dispose = function() {
        var a, b;
        (a = this.td) == null || (b = a.unsubscribe) == null || b.call(a);
        this.td = void 0;
        var c;
        (c = this.mf) == null || c.call(this);
        this.mf = void 0
    };
    var Zs = function(a) {
        fo.call(this, a)
    };
    q(Zs, fo);
    var $s = function(a, b) {
        return Wm(a, 1, b)
    };
    Zs.U = "contentads.bow.rendering.client.TurtleDoveReportingData";
    Zs.prototype.N = ho([0, Tn, Pn, Tn, -5, Yn, Tn, -4]);

    function at() {
        var a = Wg();
        return a ? Kb("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), function(b) {
            return Ya(a, b)
        }) || Ya(a, "OMI/") && !Ya(a, "XiaoMi/") ? !0 : Ya(a, "Presto") && Ya(a, "Linux") && !Ya(a, "X11") && !Ya(a, "Android") && !Ya(a, "Mobi") : !1
    };
    var Xq = Object.freeze({
            yg: 1E3,
            Yd: .5,
            te: .3
        }),
        dr = Object.freeze([1, .75, Xq.Yd, Xq.te, 0]),
        bt = function(a, b, c, d, e, f, g) {
            this.oi = a;
            this.Hb = b;
            this.Db = c;
            this.Yb = d;
            this.Pc = e;
            this.Qc = f;
            this.Kd = g;
            this.name = "rxlidar";
            this.Wh = new dd;
            this.controlledEvents = [];
            this.subscribedEvents = [];
            this.Vd = new dd;
            this.Fa = new dd;
            this.controlledEvents.push(this.Yb, this.Pc, this.Qc);
            this.subscribedEvents.push(this.Db)
        };
    n = bt.prototype;
    n.start = function(a) {
        if (this.ee === void 0 && a.O) {
            var b;
            if ((b = this.Hb) != null) var c = b;
            else {
                b = a.O;
                var d = (c = a.ma) != null ? c : null;
                c = {
                    nh: .01,
                    Zh: pf(b.j, 36E5),
                    ob: b.j.Ga(100).g(U(b.h, 1)),
                    ma: d
                }
            }
            this.Hb = c;
            a = a.O;
            this.ee = ct(a, this.Vd.g(U(a.h, 1)), this.Hb.nh, this.Hb.Zh, this.Hb.ob, this.Hb.ma, this.Fa.g(P(!1), U(a.h, 1)), this.Yb, this.Pc, this.Qc, this.Kd).subscribe(this.Wh)
        }
    };
    n.dispose = function() {
        this.Vd.complete();
        this.Fa.complete();
        var a;
        (a = this.ee) == null || a.unsubscribe();
        this.ee = void 0
    };
    n.fe = function(a, b, c, d, e) {
        if (!zm(b, Lm, 2) || Nm(b, Lm, 2).ce()) {
            this.Vd.next(Object.assign({}, this.oi.nf.get(a), {
                metadata: b,
                experimentState: c,
                gk: a,
                Na: d
            }));
            var f, g;
            e((g = (f = Nm(b, Lm, 2)) == null ? void 0 : f.dd()) != null ? g : -1)
        }
    };
    n.Bb = function() {};
    n.handleEvent = function(a, b) {
        b === this.Db && (this.Fa.next(!0), this.Fa.complete())
    };

    function ct(a, b, c, d, e, f, g, h, k, l, m) {
        var u = ns(a).g(M(function(t) {
                return !t
            })),
            r = new Or(a, [new Ur(a, dr), new Tr(a, e), new ks(f, a, dr), new js(f, a, e), new ds(a, e)]);
        return Zo(a, b, function(t, w) {
            var v = Ar(t, w.element),
                x = v.Jd,
                A = v.Zb,
                Q = v.Sd,
                T = v.Re,
                ma = v.gh,
                H = v.jb,
                C = v.Oh,
                ea = v.ke,
                Dc = v.pe,
                hc = v.Ra,
                od = v.na,
                La = v.Vi,
                pg = v.kb;
            v = v.se;
            var qg, jb = (qg = Js(Mm(w.metadata))) != null ? qg : "";
            qg = $s(new Zs, atob(jb)).Sa();
            jb = (new V(w.experimentState)).S(t.h);
            var dn = new V(new rf(t, new Gg(t))),
                en = jb.g(M(function(E) {
                        return E.fetchLaterBeacons
                    }),
                    P(!1), O(), U(t.h, 1)),
                Pt = en.g(M(function(E) {
                    return E && (new Cg(t)).L({
                        tf: !0
                    })
                }), kf(function(E) {
                    E && dn.value.J("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&start&control&fle=1&sfl=1").sendNow()
                })),
                xe = jb.g(M(function(E) {
                    return E.shouldIgnoreAdChoicesIcon
                })),
                Ma = H.g(Qe(C), M(function(E) {
                    var kb = y(E);
                    E = kb.next().value;
                    kb = kb.next().value;
                    (E = E || kb) || ((E = Ya(Wg(), "CrKey") && !(Ya(Wg(), "CrKey") && Ya(Wg(), "SmartSpeaker")) || Ya(Wg(), "PlayStation") || Ya(Wg(), "Roku") || at() || Ya(Wg(), "Xbox")) ||
                        (E = Wg(), E = Ya(E, "AppleTV") || Ya(E, "Apple TV") || Ya(E, "CFNetwork") || Ya(E, "tvOS")), E || (E = Wg(), E = Ya(E, "sdk_google_atv_x86") || Ya(E, "Android TV")));
                    return E
                }));
            C = new Jr(t, w, ma, H, hc, xe);
            xe = jb.g(M(function(E) {
                return E.considerOmidZOrderOcclusions
            }));
            var Fc, Ab = (Fc = Ks(Mm(w.metadata))) != null ? Fc : !1;
            Fc = r.Ya(C, {
                jb: H,
                Dg: Ab,
                Ra: hc,
                fg: xe
            });
            var $a = Fc.fb,
                ye = Fc.Xa;
            Fc = ye.we;
            xe = ye.xe;
            ye = ye.Ke;
            Ab = (new V(Ab)).S(t.h);
            var kc = ts(t, Dc, Ma, u, La, Ab, C);
            La = jr(t.h, t.j, $a, kc);
            Ma = rs(t.h, La.wa.Me, La.wa.visible, La.Ie, La.Gc);
            Ab = yr(t.h, t.j,
                La.Gc, La.wa.ca, La.wa.visible);
            $a = Nq(t.h, t.j, $a, kc);
            kc = cr(t.j, t.h, $a.wa.Me, $a.wa.visible, $a.Ie, $a.Gc);
            var Gi = {
                    Qe: Wq(t.h, t.j, $a.Gc, kc.tc)
                },
                Hi = jb.g(M(function(E) {
                    return E.extrapolators
                }), P(!1));
            $a = Cp(t.h, Hi, Object.assign({}, $a.wa, kc, Gi), Object.assign({}, La.wa, {
                Qe: Dq(t, Ab),
                uc: Dq(t, Ma.uc),
                Ic: Dq(t, Ma.Ic),
                tc: Dq(t, Ma.tc),
                ab: Ma.ab.g(M(function(E) {
                    return new Cq(t.j, E)
                })),
                wd: Dq(t, Ma.wd),
                xd: Dq(t, Ma.xd)
            }));
            Ma = lq(t, d.g(Te("t")));
            Ab = (f !== null && f.validate() ? f.Ei : Td).g(U(t.h, 1), Te("u"));
            Ma = Xd(Ma, Ab);
            Ab = ps(t, $a.ca,
                Ma.g(N(function(E) {
                    return E !== null
                })));
            kc = dt(t, C, x);
            Gi = et(t, Ma, w.element);
            Hi = kc.Sg.g(P({
                x: 0,
                y: 0
            }));
            var St = jb.g(M(function(E) {
                    return E.rxlidarStatefulBeacons
                }), P(!1), O(), kf(function(E) {
                    Eh = E
                }), U(t.h, 1)),
                fn = ea.g(M(function(E) {
                    return E === 40 || E === 41 || E === 42
                })),
                Tt = jb.g(M(function(E) {
                    return E.waitForImpressionColleague
                }), P(!1), O(), U(t.h, 1)),
                Ut = b.g(M(function(E) {
                    var kb;
                    return E.experimentState.addQueryIdToErrorPing ? (kb = Nm(E.metadata, Rs, 3)) == null ? void 0 : kb.Ff() : void 0
                }));
            return Object.assign({}, {
                I: new V(t.I),
                Fb: new V("lidar2"),
                Mi: new V("lidartos"),
                Wg: new V(os),
                Kd: new V(m),
                Qd: new V(t.validate() ? null : new ge),
                bh: new V(ni(t.document)),
                W: new V(jp),
                uf: Ma,
                xg: Ma,
                bk: Ab,
                fd: g,
                Ui: Tt,
                Na: new V(w.Na),
                Yb: new V(h),
                Pc: new V(k),
                Qc: new V(l),
                fh: new V(t.kc ? 1 : void 0),
                hh: new V(t.Xg ? 1 : void 0),
                jb: H,
                kb: pg,
                Oe: new V(qg),
                Ob: pg.g(N(function(E) {
                    return E
                }), M(function() {
                    return t.Ob.bind(t)
                })),
                we: Fc.g(U(t.h, 1)),
                xe: xe.g(U(t.h, 1)),
                sh: jb.g(M(function(E) {
                    return E.extraPings
                })),
                Sf: St,
                Ch: en,
                vg: Pt,
                se: v,
                Nh: fn,
                Dh: jb.g(M(function(E) {
                    return E.dedicatedViewableAttributionPing
                })),
                th: dn,
                wg: new V(Eh && (new Dh(t)).L({
                    ha: "GET"
                })),
                Hi: new V(Number(w.experimentState.useReachIntegrationSharedStorage) << 0 + Number(w.experimentState.useReachIntegrationPolyfill) << 1 + Number(w.experimentState.sendBrowserIdInsteadOfVPID) << 2),
                eh: w.element.g(M(function(E) {
                    return E !== null
                })),
                ib: od,
                Ni: od,
                Sd: Q.g(P([])),
                Re: T.g(P([])),
                Ah: Q.g(M(function(E) {
                    return E.length > 0 ? !0 : null
                }), P(null), O()),
                Zb: A.g(P([]), U(t.h, 1)),
                Fj: jb,
                shouldSendExplicitDisplayMeasurablePing: jb.g(M(function(E) {
                    return E.shouldSendExplicitDisplayMeasurablePing
                })),
                Jd: x,
                bc: C.bc,
                ke: ea.g(P(0), U(t.h, 1)),
                Xh: ma,
                Ra: hc.g(P(0), U(t.h, 1)),
                ub: fn.g(M(function(E) {
                    return E ? Ap : ip
                })),
                Ub: new V(Bp),
                pe: Dc,
                Uf: C.qc.g(Dp(t.h)),
                Se: C.Se
            }, $a, {
                Xc: zd([$a.Xc, Hi]).g(M(function(E) {
                    var kb = y(E);
                    E = kb.next().value;
                    kb = kb.next().value;
                    return ui(E, kb)
                }), O(si))
            }, kc, {
                Jc: Sh(t),
                Bh: Gi,
                Ke: ye,
                Ad: La.wa.Ad,
                Yg: new V(new up),
                escapedQueryId: Ut
            })
        }, hp(a, "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=" + m + "&v=" + os, c))
    }

    function dt(a, b, c) {
        var d = d === void 0 ? Ka : d;
        var e, f;
        d = ((e = d.performance) == null ? void 0 : (f = e.timing) == null ? void 0 : f.navigationStart) || 0;
        return Object.assign({}, {
            Qg: new V(d),
            Pg: Rp(a, b)
        }, Qp(a, b, c))
    }

    function et(a, b, c) {
        return b.g(N(function(d) {
            return d !== null
        }), R(function() {
            return c
        }), M(function(d) {
            var e = Qo(a);
            return e.length > 0 && e.indexOf(d) >= 0
        }), M(function(d) {
            return !d
        }))
    };
    var ft = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.Db = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "impression";
        this.he = new Map
    };
    n = ft.prototype;
    n.start = function(a) {
        this.Ma = a
    };
    n.dispose = function() {
        this.he.clear()
    };
    n.fe = function(a, b, c, d) {
        if (b = this.Ma) c = new gt(b, c, this.Db, d), this.he.set(a, c)
    };
    n.Bb = function(a) {
        this.he.delete(a)
    };
    n.handleEvent = function() {};
    var gt = function(a, b, c, d) {
        var e = this;
        this.context = a;
        this.Db = c;
        this.Bg = function() {};
        this.Rf = [];
        this.Pf = "&avradf=1";
        this.Qf = xs([]);
        this.Fa = new dd;
        c = a.ma;
        var f = c !== null && (c == null ? void 0 : c.validate()),
            g, h = (g = a.O) == null ? void 0 : g.h;
        this.Fa.g(P(!b.waitForImpressionColleague), U(h, 1));
        this.Ji = f ? c == null ? void 0 : c.Of.g(Ue(1), Te(!0), P(!1)) : (new V(!0)).S(h);
        this.Bg = function(k, l) {
            e.Fa.next(!0);
            e.Fa.complete();
            zd([e.Fa, e.Ji]).subscribe(function(m) {
                var u = y(m);
                m = u.next().value;
                u = u.next().value;
                if (!u) return Td;
                m && u &&
                    d(e.Db, k, l);
                return !0
            })
        };
        this.init(a.O)
    };
    gt.prototype.init = function(a) {
        var b = this;
        this.yc = a.global.document;
        this.Rf.push(ht(this));
        var c = {};
        this.Qf = xs(this.Rf);
        this.Qf.then(function() {
            b.Pf = "&vis=" + ls(b.yc) + "&uach=0&ms=0";
            c.paramString = b.Pf;
            c.view_type = "DELAYED_IMPRESSION";
            b.Bg(c, function() {})
        })
    };
    var ht = function(a) {
        return new ws(function(b) {
            var c = ms(a.yc);
            if (c)
                if (ls(a.yc) === 3) {
                    var d = function() {
                        var e = a.yc;
                        typeof e.removeEventListener === "function" && e.removeEventListener(c, d, !1);
                        b(!0)
                    };
                    Ah(a.yc, c, d)
                } else b(!0)
        })
    };

    function jt(a) {
        var b = Th(a);
        return b ? b.g(M(function(c) {
            var d;
            c = (d = Pm(c).find(function(f) {
                return fl(vm(f, 1)) === "Google Chrome"
            })) == null ? void 0 : fl(vm(d, 2));
            if (!c) return !1;
            var e;
            return ((e = y(c.split(".").map(function(f) {
                return Number(f)
            })).next().value) != null ? e : 0) >= 121
        })) : Jh.S(a.h)
    };

    function kt(a, b) {
        b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=reach&proto=" + encodeURIComponent(Ph(b.N()));
        a.I.J(b, {
            ha: "GET"
        }).sendNow()
    };

    function lt(a) {
        return [{
            zb: 2,
            Ec: !1,
            cc: !0,
            filterIds: mt(a == null ? void 0 : a.productionFilterIds)
        }, {
            zb: 2,
            Ec: !0,
            cc: !0,
            filterIds: mt(a == null ? void 0 : a.testFilterIds)
        }, {
            zb: 2,
            Ec: !1,
            cc: !1,
            filterIds: mt(a == null ? void 0 : a.testFilterIds)
        }]
    }

    function mt(a) {
        if (a !== void 0 && typeof BigInt === "function") return a.map(function(b) {
            return BigInt(b)
        })
    };
    var nt = function(a) {
        fo.call(this, a)
    };
    q(nt, fo);
    var ot = function(a, b) {
            return Xm(a, 1, b)
        },
        pt = function(a, b) {
            return Wm(a, 2, b)
        },
        qt = function(a, b) {
            return Wm(a, 3, b)
        };
    nt.prototype.Fc = function(a) {
        return Wm(this, 10, a)
    };
    nt.prototype.Gf = function() {
        return Nm(this, Ms, 11)
    };
    nt.prototype.qg = function(a) {
        return Qm(this, Ms, 11, a)
    };
    nt.U = "ads.branding.measurement.client.frontend.integrations.reach.ReachStatusMessage";
    nt.prototype.N = ho([0, Yn, Tn, -1, Yn, -2, Tn, -1, Pn, Tn, Ps, Zn, Pn]);
    var rt = function(a) {
            this.context = a;
            this.points = []
        },
        st = function(a, b) {
            Fa(function(c) {
                if (c.u == 1) return c.va = 0, c.Ea = 2, ta(c, b(), 4);
                if (c.u != 2) return c.return(c.aa);
                wa(c);
                a.flush();
                return xa(c, 0)
            })
        };
    rt.prototype.flush = function() {
        if (!(this.points.length <= 0)) {
            var a = new nt;
            ot(a, 9);
            var b = lt().length;
            xm(a, 13, b == null ? b : Yk(b));
            Ym(a, 12, this.points);
            this.points.splice(0);
            kt(this.context, a)
        }
    };

    function tt() {
        this.blockSize = -1
    };

    function ut(a, b) {
        this.blockSize = -1;
        this.blockSize = 64;
        this.Uc = Ka.Uint8Array ? new Uint8Array(this.blockSize) : Array(this.blockSize);
        this.yd = this.Eb = 0;
        this.B = [];
        this.fi = a;
        this.Tf = b;
        this.Ti = Ka.Int32Array ? new Int32Array(64) : Array(64);
        vt === void 0 && (vt = Ka.Int32Array ? new Int32Array(wt) : wt);
        this.reset()
    }
    Sa(ut, tt);
    for (var xt = [], yt = 0; yt < 63; yt++) xt[yt] = 0;
    var zt = [].concat(128, xt);
    ut.prototype.reset = function() {
        this.yd = this.Eb = 0;
        this.B = Ka.Int32Array ? new Int32Array(this.Tf) : Mb(this.Tf)
    };
    var At = function(a) {
        var b = a.Uc;
        D(b.length == a.blockSize);
        for (var c = a.Ti, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
        for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
        b = a.B[0] | 0;
        d = a.B[1] | 0;
        e = a.B[2] | 0;
        for (var f = a.B[3] | 0, g = a.B[4] | 0, h = a.B[5] | 0, k = a.B[6] | 0, l = a.B[7] | 0, m = 0; m < 64; m++) {
            var u = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                r = (l + ((g >>> 6 | g << 26) ^ (g >>> 11 |
                    g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^ ~g & k) + (vt[m] | 0) | 0) + (c[m] | 0) | 0) | 0;
            l = k;
            k = h;
            h = g;
            g = f + r | 0;
            f = e;
            e = d;
            d = b;
            b = r + u | 0
        }
        a.B[0] = a.B[0] + b | 0;
        a.B[1] = a.B[1] + d | 0;
        a.B[2] = a.B[2] + e | 0;
        a.B[3] = a.B[3] + f | 0;
        a.B[4] = a.B[4] + g | 0;
        a.B[5] = a.B[5] + h | 0;
        a.B[6] = a.B[6] + k | 0;
        a.B[7] = a.B[7] + l | 0
    };
    ut.prototype.update = function(a, b) {
        b === void 0 && (b = a.length);
        var c = 0,
            d = this.Eb;
        if (typeof a === "string")
            for (; c < b;) this.Uc[d++] = a.charCodeAt(c++), d == this.blockSize && (At(this), d = 0);
        else if (Pa(a))
            for (; c < b;) {
                var e = a[c++];
                if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("La");
                this.Uc[d++] = e;
                d == this.blockSize && (At(this), d = 0)
            } else throw Error("Ma");
        this.Eb = d;
        this.yd += b
    };
    ut.prototype.digest = function() {
        var a = [],
            b = this.yd * 8;
        this.Eb < 56 ? this.update(zt, 56 - this.Eb) : this.update(zt, this.blockSize - (this.Eb - 56));
        for (var c = 63; c >= 56; c--) this.Uc[c] = b & 255, b /= 256;
        At(this);
        for (c = b = 0; c < this.fi; c++)
            for (var d = 24; d >= 0; d -= 8) a[b++] = this.B[c] >> d & 255;
        return a
    };
    var wt = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804,
            4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ],
        vt;

    function Bt() {
        ut.call(this, 8, Ct)
    }
    Sa(Bt, ut);
    var Ct = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
    var bo = function(a) {
        fo.call(this, a)
    };
    q(bo, fo);
    bo.U = "EventIdMessage";
    var Dt = function(a) {
        fo.call(this, a)
    };
    q(Dt, fo);
    Dt.prototype.Rb = function(a) {
        return Vm(this, 4, a)
    };
    Dt.prototype.If = function() {
        return Em(this, 8, Wk, void 0 === Bk ? 2 : 4)
    };
    Dt.prototype.df = function(a) {
        return Ym(this, 8, a)
    };
    Dt.prototype.rg = function(a) {
        return Um(this, 9, a)
    };
    Dt.U = "ads.branding.measurement.client.frontend.integrations.reach.ContextIdMessage";
    var Et = [0, Mn, Rn, -1];
    bo.prototype.N = ho(Et);
    Dt.prototype.N = ho([0, Et, Sn, -1, Wn, -3, $n, Sn]);
    var ao = function(a) {
        fo.call(this, a, 1)
    };
    q(ao, fo);
    ao.U = "proto2.bridge.MessageSet";
    var Ft = {};
    ao[Ck] = Ft;
    var Gt = go(bo, Et);
    Ft[4156379] = {
        Ij: new co
    };
    var Ht = function() {
        var a;
        this.message = a = a === void 0 ? new Dt : a
    };
    Ht.prototype.Fc = function(a) {
        var b = this.message;
        a = Gt(Rh(a));
        this.message = Qm(b, bo, 1, a);
        return this
    };
    var It = function(a, b) {
        var c = Um(a.message, 2, b.zb === 2);
        b = Um(c, 3, !b.Ec);
        a.message = b;
        return a
    };
    Ht.prototype.Rb = function(a) {
        this.message = this.message.Rb(Math.max(1, a));
        return this
    };
    var Jt = function(a, b) {
            a.message = a.message.df(b);
            return a
        },
        Kt = function(a) {
            var b = os.match(/m\d{12}/g),
                c = os.match(/\d{8}/g);
            if (b && b.length > 0) {
                b = b[0].slice(1);
                c = a.message;
                var d = Number(b.slice(0, 8));
                c = Vm(c, 5, d);
                d = Number(b.slice(8, 10));
                c = Vm(c, 6, d);
                b = Number(b.slice(10, 12));
                b = Vm(c, 7, b);
                a.message = b;
                return a
            }
            if (c && c.length > 0) return b = Vm(a.message, 5, Number(c[0])), b = xm(b, 6), b = xm(b, 7), a.message = b, a;
            os === "unreleased" && (b = xm(a.message, 5), b = Vm(b, 6, 0), b = xm(b, 7), a.message = b);
            return a
        };
    Ht.prototype.encode = function() {
        var a = this.message,
            b = Ph(a.N());
        b.length > 64 && (a = a.Rb(1), b = Ph(a.N()));
        b.length > 64 && (a = xm(a, 6), b = Ph(a.N()));
        b.length > 64 && (a = xm(a, 7), b = Ph(a.N()));
        b.length > 64 && (a = xm(a, 5), b = Ph(a.N()));
        return b
    };

    function Lt(a, b) {
        if (b === void 0 || b.length === 0) return kt(a, ot(new nt, 7)), [de(0)].filter(function(d) {
            return d !== void 0
        });
        var c = de(-2147483648);
        return c === void 0 ? [] : b.map(function(d) {
            var e = d % c;
            d !== e && kt(a, ot(new nt, 6));
            return e
        })
    };

    function Mt(a, b) {
        var c = c === void 0 ? BigInt(0) : c;
        return {
            bucket: a,
            value: b ? 1 : 16384,
            filteringId: c
        }
    };

    function Nt(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            e < 128 ? b[c++] = e : (e < 2048 ? b[c++] = e >> 6 | 192 : ((e & 64512) == 55296 && d + 1 < a.length && (a.charCodeAt(d + 1) & 64512) == 56320 ? (e = 65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023), b[c++] = e >> 18 | 240, b[c++] = e >> 12 & 63 | 128) : b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
        }
        if (b.length >= 24) throw Error("Na");
        return [96 | b.length].concat(z(b))
    }

    function Ot(a) {
        if (a.length >= 24) throw Error("Oa");
        return [160 | a.length].concat(z(a.sort(Qt).map(function(b) {
            return [].concat(z(b[0]), z(b[1]))
        }).flat()))
    }

    function Rt(a) {
        if (a.length >= 24) throw Error("Pa");
        return [128 | a.length].concat(z(a.flat()))
    }

    function Vt(a, b) {
        for (var c = []; a > 0;) c.push(Number(a % BigInt(255))), a /= BigInt(255);
        for (; c.length < b;) c.push(0);
        return c.reverse()
    }

    function Qt(a, b) {
        a = a[0];
        b = b[0];
        if (a.length !== b.length) return a.length - b.length;
        for (var c = 0; c < a.length; c++)
            if (a[c] !== b[c]) return a[c] - b[c];
        return 0
    };

    function Wt(a, b, c, d) {
        var e = Mt(BigInt(c), d);
        b = {
            shared_info: JSON.stringify({
                api: "shared-storage",
                report_id: "PRE_WORKLET_ERROR",
                reporting_origin: "https://www.googleadservices.com",
                scheduled_report_time: String((new Date).getUTCSeconds()),
                version: "polyfill"
            }),
            aggregation_service_payloads: [],
            context_id: b,
            aggregation_coordinator_origin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com"
        };
        d ? (b.debug_key = "0", b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0",
                debug_cleartext_payload: Xt([e])
            })) :
            b.aggregation_service_payloads.push({
                payload: String(c),
                key_id: "0"
            });
        try {
            var f, g;
            (f = a.global) == null || (g = f.fetch) == null || g.call(f, "https://www.googleadservices.com/.well-known/private-aggregation/report-shared-storage", {
                method: "POST",
                cache: "no-cache",
                keepalive: !0,
                mode: "no-cors",
                headers: {
                    "content-type": "application/json"
                },
                body: JSON.stringify(b)
            }).catch(function() {})
        } catch (h) {}
    }

    function Xt(a) {
        a = Ot([
            [Nt("data"), Rt(a.map(function(b) {
                return Ot([
                    [Nt("value"), [68].concat(z(Vt(BigInt(b.value), 4)))],
                    [Nt("bucket"), [80].concat(z(Vt(b.bucket, 16)))],
                    [Nt("filteringId"), [68].concat(z(Vt(b.filteringId, 4)))]
                ])
            }))],
            [Nt("operation"), Nt("histogram")]
        ]);
        return btoa(String.fromCharCode.apply(String, z(new Uint8Array(a))))
    };
    var Yt = {},
        Zt = (Yt[2] = "prod", Yt[1] = "canary", Yt);

    function $t(a, b, c, d) {
        var e, f, g, h, k, l, m, u;
        return Fa(function(r) {
            switch (r.u) {
                case 1:
                    e = lt(c);
                    f = function(t) {
                        e.forEach(function(w) {
                            var v, x = Kt(It(Jt((new Ht).Fc(c.escapedQueryId), (v = c.trafficTypes) != null ? v : [0]), w)).Rb(-1).encode();
                            Wt(a, x, t, w.cc)
                        })
                    };
                    g = Bo(a);
                    if (g instanceof Error) return f(-16), h = qt(pt(ot(new nt, 8), g.name), g.message), kt(a, h), r.return();
                    d.points.push(7);
                    k = au(a, c, e);
                    return ta(r, c.experimentState.reachUseCreateWorklet ? bu(a, b, f) : cu(a, b, f), 2);
                case 2:
                    return l = r.aa, ta(r, k, 3);
                case 3:
                    return m = r.aa,
                        d.points.push(8), u = e.map(function(t) {
                            var w, v, x;
                            return du(a, l, t, m, (w = c.deviceType) != null ? w : 1, c.escapedQueryId, (v = c.trafficTypes) != null ? v : [0], (x = c.isProductSplitVpidLogsExperiment) != null ? x : !1, function(A) {
                                var Q, T = Kt(It(Jt((new Ht).Fc(c.escapedQueryId), (Q = c.trafficTypes) != null ? Q : [0]).Rb(-1), t)).encode();
                                Wt(a, T, A, t.cc)
                            })
                        }), ta(r, Promise.all(u), 4);
                case 4:
                    d.points.push(9), r.u = 0
            }
        })
    }

    function cu(a, b, c) {
        var d, e, f;
        return Fa(function(g) {
            switch (g.u) {
                case 1:
                    d = a.sharedStorage;
                    if (!d) return g.return(Promise.reject(Error("Qa")));
                    ua(g, 2);
                    return ta(g, d.worklet.addModule(b), 4);
                case 4:
                    g.u = 3;
                    g.va = 0;
                    break;
                case 2:
                    e = va(g), c(-17), f = qt(pt(ot(new nt, 1), e.name), e.message), kt(a, f);
                case 3:
                    return g.return(d)
            }
        })
    }

    function bu(a, b, c) {
        var d, e, f;
        return Fa(function(g) {
            if (g.u == 1) {
                d = a.sharedStorage;
                if (!d) return g.return(Promise.reject(Error("Qa")));
                ua(g, 2);
                return ta(g, d.createWorklet(b, {
                    dataOrigin: "script-origin"
                }), 4)
            }
            if (g.u != 2) return g.return(g.aa);
            e = va(g);
            c(-17);
            f = qt(pt(ot(new nt, 1), e.name), e.message);
            kt(a, f);
            return g.return(Promise.reject(e))
        })
    }

    function au(a, b, c) {
        var d, e, f;
        return Fa(function(g) {
            if (g.u == 1) return d = [].concat(z(new Set(c.map(function(h) {
                return h.zb
            })))), e = d.map(function(h) {
                return eu(a, b, h)
            }), ta(g, Promise.all(e), 2);
            f = g.aa;
            return g.return(new Map(f.map(function(h, k) {
                return [d[k], h]
            })))
        })
    }

    function eu(a, b, c) {
        var d, e, f, g, h, k, l, m, u;
        return Fa(function(r) {
            switch (r.u) {
                case 1:
                    return e = (d = b.clientsideModelFilename) != null ? d : "model_person_country_code_XX_person_region_code_5858.json", f = void 0, g = 1, h = {
                        method: "GET"
                    }, k = 200, l = b.geoTargetMessage ? Ns(b.geoTargetMessage) : void 0, m = (new nt).Fc(b.escapedQueryId).qg(l), ua(r, 2), ta(r, a.global.fetch(fu(c, e), h), 4);
                case 4:
                    f = r.aa;
                    k = f.status;
                    if (f.ok) {
                        r.Ha(5);
                        break
                    }
                    return ta(r, a.global.fetch(fu(c, "model_person_country_code_XX_person_region_code_5858.json"), h), 6);
                case 6:
                    f = r.aa, g = 2;
                case 5:
                    r.u = 3;
                    r.va = 0;
                    break;
                case 2:
                    u = va(r), k = -1, u instanceof Error && qt(pt(m, u.name), u.message);
                case 3:
                    var t = ot(m, 2);
                    xm(t, 9, k == null ? k : Yk(k));
                    if (!f || !f.ok) return t = Xm(m, 4, 4), t = Wm(t, 8, e), Wm(t, 7, ""), kt(a, m), r.return();
                    t = Xm(m, 4, g);
                    Wm(t, 7, g === 1 ? e : "");
                    kt(a, m);
                    return ta(r, f.text(), 7);
                case 7:
                    return r.return(r.aa)
            }
        })
    }

    function fu(a, b) {
        return "https://www.googletagservices.com/agrp/" + Zt[a] + "/" + b
    }

    function du(a, b, c, d, e, f, g, h, k) {
        var l, m, u, r, t, w, v;
        return Fa(function(x) {
            switch (x.u) {
                case 1:
                    l = d.get(c.zb);
                    if (l === void 0) return x.return();
                    var A = de(-2147483648);
                    if (A === void 0) A = -1;
                    else {
                        var Q = Number,
                            T = new Bt;
                        T.update(l);
                        var ma = T.digest();
                        T = BigInt(0);
                        ma = y(ma);
                        for (var H = ma.next(); !H.done; H = ma.next()) T = (T * BigInt(256) + BigInt(H.value)) % A;
                        A = Q(T)
                    }
                    m = A;
                    A = Kt(It(Jt((new Ht).Fc(f), g), c).Rb(m));
                    A.message = A.message.rg(h);
                    u = A.encode();
                    r = {
                        contextId: u,
                        aggregationCoordinatorOrigin: "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
                        filteringIdMaxBytes: 4
                    };
                    t = {
                        modelJson: l,
                        modelHash: m,
                        deviceType: e,
                        enableDebugMode: c.cc,
                        reportBrowserIdInsteadOfVPID: c.Ec,
                        filterIds: Lt(a, c.filterIds)
                    };
                    w = b.run("google_reach", {
                        privateAggregationConfig: r,
                        data: t,
                        keepAlive: !0
                    });
                    if (w === void 0) {
                        x.Ha(2);
                        break
                    }
                    ua(x, 3);
                    return ta(x, w, 5);
                case 5:
                    x.u = 2;
                    x.va = 0;
                    break;
                case 3:
                    v = va(x), k(-18), A = v, ma = qt(pt(ot(new nt, 3), (Q = A == null ? void 0 : A.name) != null ? Q : "unknown"), (T = A == null ? void 0 : A.message) != null ? T : ""), kt(a, ma);
                case 2:
                    A = ot(new nt, 5), A = Xm(A, 5, c.zb === 1 ? 1 : 2), A = Xm(A, 6, c.Ec ?
                        1 : 2), kt(a, A), x.u = 0
            }
        })
    };
    var gu = function(a) {
        var b = b === void 0 ? [] : b;
        var c = c === void 0 ? [a] : c;
        this.Be = a;
        this.subscribedEvents = b;
        this.controlledEvents = c;
        this.name = "reach";
        this.Ac = new Map
    };
    n = gu.prototype;
    n.start = function(a) {
        a.O && (this.context = a.O)
    };
    n.dispose = function() {
        this.Ac.forEach(function(a) {
            return void a.dispose()
        });
        this.Ac.clear()
    };
    n.fe = function(a, b, c, d, e) {
        var f = this,
            g = this.context;
        if (g) {
            var h = new rt(g);
            st(h, function() {
                var k, l, m, u;
                return Fa(function(r) {
                    if (r.u == 1) {
                        h.points.push(1);
                        if (zm(b, Os, 1) && !Us(b).ce()) return r.return();
                        h.points.push(2);
                        return Bo(g) ? ta(r, id(jt(g)), 2) : r.return()
                    }
                    if (r.u != 3) {
                        k = r.aa;
                        if (!k) return r.return();
                        h.points.push(3);
                        l = new hu(g, b, f.Be, c, d, h);
                        f.Ac.set(a, l);
                        return ta(r, l.run(), 3)
                    }
                    e((u = (m = Us(b)) == null ? void 0 : m.dd()) != null ? u : -1);
                    r.u = 0
                })
            })
        }
    };
    n.Bb = function(a) {
        var b;
        (b = this.Ac.get(a)) == null || b.dispose();
        this.Ac.delete(a)
    };
    n.handleEvent = function() {};
    var hu = function(a, b, c, d, e, f) {
        this.context = a;
        this.metadata = b;
        this.Be = c;
        this.experimentState = d;
        this.Na = e;
        this.Rd = f
    };
    hu.prototype.run = function() {
        var a = this,
            b, c;
        return Fa(function(d) {
            if (d.u == 1) return b = {}, ta(d, new Promise(function(e) {
                a.Na(a.Be, b, e)
            }), 2);
            c = d.aa;
            if (!c) return d.return();
            a.Rd.points.push(4);
            return ta(d, iu(a), 0)
        })
    };
    var iu = function(a) {
            var b, c, d, e, f, g, h, k, l, m, u, r, t, w, v, x, A, Q;
            return Fa(function(T) {
                var ma = a.experimentState,
                    H = (l = (b = Us(a.metadata)) == null ? void 0 : b.Ef()) != null ? l : "",
                    C = (m = (c = Us(a.metadata)) == null ? void 0 : c.If()) != null ? m : void 0,
                    ea = (d = Us(a.metadata)) == null ? void 0 : fl(vm(d, 1)),
                    Dc = (u = (e = Us(a.metadata)) == null ? void 0 : (f = e.Gf()) == null ? void 0 : f.Sa()) != null ? u : void 0,
                    hc = (r = (g = Us(a.metadata)) == null ? void 0 : Sm(g, 8)) != null ? r : void 0,
                    od = ju;
                var La = (h = Us(a.metadata)) == null ? void 0 : Em(h, 5, Zk, Bk === Bk ? 2 : 4);
                od = od(a, (t = La) != null ?
                    t : void 0);
                La = ju;
                var pg = (k = Us(a.metadata)) == null ? void 0 : Em(k, 6, Zk, Bk === Bk ? 2 : 4);
                v = {
                    experimentState: ma,
                    escapedQueryId: H,
                    trafficTypes: C,
                    isProductSplitVpidLogsExperiment: !0,
                    clientsideModelFilename: ea,
                    geoTargetMessage: Dc,
                    deviceType: hc,
                    productionFilterIds: od,
                    testFilterIds: La(a, (w = pg) != null ? w : void 0)
                };
                if (a.experimentState.reachUseCreateWorklet) return Q = a.context.Je[2], a.Rd.points.push(10), ta(T, $t(a.context, Q, v, a.Rd), 0);
                x = a.context.Je[0];
                A = btoa(JSON.stringify(v));
                return ta(T, qi(a.context.document, x, A), 0)
            })
        },
        ju = function(a, b) {
            if (b !== void 0) return b.map(function(c) {
                var d;
                return String((d = de(c)) != null ? d : 0)
            })
        };
    hu.prototype.dispose = function() {};
    var ku = If("m202507210101".match(/^m\d{10}$/g) !== null ? "m202507210101" : "current"),
        lu;
    a: {
        try {
            var mu = new lg;
            lu = new Kf(mu, "doubleclickbygoogle.com-omid", void 0, ku);
            break a
        } catch (a) {}
        lu = void 0
    }
    var nu = lu,
        ou = {
            O: new Ao(void 0, void 0, void 0, ku),
            ma: nu
        };
    (function(a) {
        if (a && Ag(a)) {
            var b = zg(a);
            if (b) {
                a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-start2", {
                    method: "GET",
                    cache: "no-cache",
                    keepalive: !0,
                    mode: "no-cors"
                });
                try {
                    b("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-later2", {
                        method: "GET",
                        cache: "no-cache",
                        mode: "no-cors",
                        activateAfter: 96E4
                    })
                } catch (c) {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-fallback2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                }
                a.hg.subscribe(function() {
                    a.global.fetch("https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-pagehide2", {
                        method: "GET",
                        cache: "no-cache",
                        keepalive: !0,
                        mode: "no-cors"
                    })
                })
            }
        }
    })(ou.O);
    (function(a, b, c) {
        var d = new Bs("impression"),
            e = new Bs("begin to render"),
            f = new Bs("unmeasurable"),
            g = new Bs("viewable"),
            h = new Bs("reach vpid"),
            k = new zs(d, h, e, g, f),
            l = new Ys,
            m = new ft(d.event);
        b = new bt(l, c, d.event, e.event, f.event, g.event, b);
        h = new gu(h.event);
        var u = new Cs(a, k, l, m, b, h);
        u.start();
        return {
            dispose: function() {
                return void u.dispose()
            },
            colleagues: {
                Dj: m,
                ek: b,
                ak: h
            }
        }
    })(ou, 7);
}).call(this);