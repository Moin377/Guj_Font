(function(sttc) {
    'use strict';
    var ba, ca = Object.defineProperty,
        ea = globalThis,
        fa = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ha = {},
        ia = {};

    function ja(a, b, c) {
        if (!c || a != null) {
            c = ia[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ka(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in ha ? f = ha : f = ea;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = fa && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ca(ha, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ia[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ia[d] = fa ? ea.Symbol(d) : "$jscp$" + a + "$" + d), ca(f, ia[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var la = Object.create,
        ma = Object.setPrototypeOf;

    function pa(a, b) {
        a.prototype = la(b.prototype);
        a.prototype.constructor = a;
        ma(a, b);
        a.kn = b.prototype
    }
    ka("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    ka("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    ka("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        pa(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    ka("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ha.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    ka("Promise.withResolvers", function(a) {
        return a ? a : function() {
            var b, c;
            return {
                promise: new Promise(function(d, e) {
                    b = d;
                    c = e
                }),
                resolve: b,
                reject: c
            }
        }
    }, "es_next");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var q = this || self;

    function qa(a) {
        a: {
            var b = ["CLOSURE_FLAGS"];
            for (var c = q, d = 0; d < b.length; d++)
                if (c = c[b[d]], c == null) {
                    b = null;
                    break a
                }
            b = c
        }
        a = b && b[a];
        return a != null ? a : !1
    }

    function ra(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function sa(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function ta(a) {
        return Object.prototype.hasOwnProperty.call(a, va) && a[va] || (a[va] = ++wa)
    }
    var va = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        wa = 0;

    function xa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function ya(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function Aa(a, b, c) {
        Aa = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? xa : ya;
        return Aa.apply(null, arguments)
    }

    function Ba(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function Ca(a, b, c) {
        a = a.split(".");
        c = c || q;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Da(a) {
        return a
    }

    function Ea(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.kn = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Xq = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    };
    var Fa = {
        kq: 0,
        jq: 1,
        iq: 2
    };
    var Ga;

    function Ia(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ja(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Ka(a, b) {
        var c = a.length;
        const d = typeof a === "string" ? a.split("") : a;
        for (--c; c >= 0; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function La(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Ma(a, b) {
        const c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Na(a, b) {
        let c = 1;
        Ja(a, function(d, e) {
            c = b.call(void 0, c, d, e, a)
        });
        return c
    }

    function Oa(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Pa(a, b) {
        return Ia(a, b) >= 0
    }

    function Ta(a, b) {
        b = Ia(a, b);
        let c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function Ua(a, b) {
        let c = 0;
        Ka(a, function(d, e) {
            b.call(void 0, d, e, a) && Array.prototype.splice.call(a, e, 1).length == 1 && c++
        })
    }

    function Wa(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Xa(a) {
        const b = a.length;
        if (b > 0) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Za(a, b) {
        for (let d = 1; d < arguments.length; d++) {
            const e = arguments[d];
            var c = ra(e);
            if (c == "array" || c == "object" && typeof e.length == "number") {
                c = a.length || 0;
                const f = e.length || 0;
                a.length = c + f;
                for (let g = 0; g < f; g++) a[c + g] = e[g]
            } else a.push(e)
        }
    }

    function $a(a, b, c) {
        c = c || ab;
        let d = 0,
            e = a.length,
            f;
        for (; d < e;) {
            const g = d + (e - d >>> 1);
            let h;
            h = c(b, a[g]);
            h > 0 ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function ab(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function cb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; c > 0; c--) {
            const d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };
    var db = {
        Fn: "google_adtest",
        Jn: "google_ad_client",
        Sn: "google_ad_intent_query",
        Rn: "google_ad_intent_qetid",
        Qn: "google_ad_intents_format",
        Tn: "google_ad_intent_rs_token",
        Kn: "google_ad_format",
        Mn: "google_ad_height",
        ho: "google_ad_width",
        Un: "google_ad_layout",
        Vn: "google_ad_layout_key",
        Xn: "google_ad_output",
        Yn: "google_ad_region",
        bo: "google_ad_slot",
        eo: "google_ad_type",
        fo: "google_ad_url",
        Po: "google_gl",
        Xo: "google_enable_ose",
        ip: "google_full_width_responsive",
        nq: "google_rl_filtering",
        mq: "google_rl_mode",
        oq: "google_rt",
        lq: "google_rl_dest_url",
        Sp: "google_max_radlink_len",
        Xp: "google_num_radlinks",
        Yp: "google_num_radlinks_per_unit",
        In: "google_ad_channel",
        Rp: "google_max_num_ads",
        Tp: "google_max_responsive_height",
        Co: "google_color_border",
        Wo: "google_enable_content_recommendations",
        Mo: "google_content_recommendation_ui_type",
        Lo: "google_source_type",
        Ko: "google_content_recommendation_rows_num",
        Jo: "google_content_recommendation_columns_num",
        Io: "google_content_recommendation_ad_positions",
        No: "google_content_recommendation_use_square_imgs",
        Eo: "google_color_link",
        Do: "google_color_line",
        Go: "google_color_url",
        Gn: "google_ad_block",
        ao: "google_ad_section",
        Hn: "google_ad_callback",
        zo: "google_captcha_token",
        Fo: "google_color_text",
        uo: "google_alternate_ad_url",
        Pn: "google_ad_host_tier_id",
        Ao: "google_city",
        Nn: "google_ad_host",
        On: "google_ad_host_channel",
        vo: "google_alternate_color",
        Bo: "google_color_bg",
        Yo: "google_encoding",
        gp: "google_font_face",
        kp: "google_hints",
        Dp: "google_image_size",
        Up: "google_mtl",
        Lq: "google_cpm",
        Ho: "google_contents",
        Vp: "google_native_settings_key",
        Oo: "google_country",
        Jq: "google_targeting",
        hp: "google_font_size",
        Uo: "google_disable_video_autoplay",
        Rq: "google_video_product_type",
        Qq: "google_video_doc_id",
        Pq: "google_cust_gender",
        Dq: "google_cust_lh",
        Cq: "google_cust_l",
        Kq: "google_tfs",
        Kp: "google_kw",
        Gq: "google_tag_for_child_directed_treatment",
        Hq: "google_tag_for_under_age_of_consent",
        rq: "google_region",
        Ro: "google_cust_criteria",
        Zn: "google_safe",
        Qo: "google_ctr_threshold",
        tq: "google_resizing_allowed",
        vq: "google_resizing_width",
        uq: "google_resizing_height",
        Oq: "google_cust_age",
        Np: "google_language",
        Lp: "google_kw_type",
        fq: "google_pucrd",
        cq: "google_page_url",
        Iq: "google_tag_partner",
        zq: "google_restrict_data_processing",
        Bn: "google_adbreak_test",
        Ln: "google_ad_frequency_hint",
        Dn: "google_admob_interstitial_slot",
        En: "google_admob_rewarded_slot",
        Cn: "google_admob_ads_only",
        co: "google_ad_start_delay_hint",
        Qp: "google_max_ad_content_rating",
        hq: "google_ad_public_floor",
        gq: "google_ad_private_floor",
        Mq: "google_traffic_source",
        aq: "google_overlays",
        eq: "google_privacy_treatments",
        Eq: "google_special_category_data",
        Sq: "google_wrap_fullscreen_ad",
        Wn: "google_ad_loaded_callback"
    };

    function eb(a) {
        a.cr = !0;
        return a
    };
    var fb = eb(a => typeof a === "number"),
        gb = eb(a => typeof a === "string"),
        hb = eb(a => typeof a === "function"),
        ib = eb(a => !!a && (typeof a === "object" || typeof a === "function"));

    function jb() {
        return lb(eb((a, b) => a === void 0 ? !0 : gb(a, b)))
    }

    function lb(a) {
        a.dm = !0;
        return a
    }
    var mb = eb(a => Array.isArray(a));

    function nb() {
        return eb(a => mb(a) ? a.every(b => fb(b)) : !1)
    };
    let ob, pb = 64;

    function qb() {
        try {
            return ob ? ? (ob = new Uint32Array(64)), pb >= 64 && (crypto.getRandomValues(ob), pb = 0), ob[pb++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };

    function rb(a, b) {
        if (!fb(a.goog_pvsid)) try {
            const c = qb() + (qb() & 2 ** 21 - 1) * 2 ** 32;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (c) {
            b.Na({
                methodName: 784,
                eb: c
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.Na({
            methodName: 784,
            eb: Error(`Invalid correlator, ${a}`)
        });
        return a || -1
    };

    function sb() {
        return !1
    }

    function tb() {
        return !0
    }

    function vb(a) {
        const b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function yb(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function zb(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Ab(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    }

    function Bb(a, b) {
        let c = 0;
        return function(d) {
            q.clearTimeout(c);
            const e = arguments;
            c = q.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function Cb(a, b) {
        function c() {
            e = q.setTimeout(d, 63);
            let h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        let e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };
    var Db = qa(610401301),
        Eb = qa(748402147);

    function Fb(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function Gb(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };

    function Hb() {
        var a = q.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Ib;
    const Jb = q.navigator;
    Ib = Jb ? Jb.userAgentData || null : null;

    function Kb(a) {
        if (!Db || !Ib) return !1;
        for (let b = 0; b < Ib.brands.length; b++) {
            const {
                brand: c
            } = Ib.brands[b];
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function Lb(a) {
        return Hb().indexOf(a) != -1
    };

    function Mb() {
        return Db ? !!Ib && Ib.brands.length > 0 : !1
    }

    function Nb() {
        return Mb() ? !1 : Lb("Opera")
    }

    function Ob() {
        return Lb("Firefox") || Lb("FxiOS")
    }

    function Pb() {
        return Lb("Safari") && !(Qb() || (Mb() ? 0 : Lb("Coast")) || Nb() || (Mb() ? 0 : Lb("Edge")) || (Mb() ? Kb("Microsoft Edge") : Lb("Edg/")) || (Mb() ? Kb("Opera") : Lb("OPR")) || Ob() || Lb("Silk") || Lb("Android"))
    }

    function Qb() {
        return Mb() ? Kb("Chromium") : (Lb("Chrome") || Lb("CriOS")) && !(Mb() ? 0 : Lb("Edge")) || Lb("Silk")
    };

    function Rb() {
        return Db && Ib ? Ib.mobile : !Tb() && (Lb("iPod") || Lb("iPhone") || Lb("Android") || Lb("IEMobile"))
    }

    function Tb() {
        return Db && Ib ? !Ib.mobile && (Lb("iPad") || Lb("Android") || Lb("Silk")) : Lb("iPad") || Lb("Android") && !Lb("Mobile") || Lb("Silk")
    };

    function Ub(a, b) {
        for (const c in a) b.call(void 0, a[c], c, a)
    }

    function Vb(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Wb(a, b) {
        for (const c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function Xb(a) {
        var b = ac;
        a: {
            for (const c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function bc(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function cc(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const dc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function ec(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < dc.length; f++) c = dc[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };

    function fc(a) {
        fc[" "](a);
        return a
    }
    fc[" "] = function() {};

    function hc(a, b) {
        try {
            return fc(a[b]), !0
        } catch (c) {}
        return !1
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let ic = globalThis.trustedTypes,
        jc;

    function kc() {
        let a = null;
        if (!ic) return a;
        try {
            const b = c => c;
            a = ic.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    }

    function lc() {
        jc === void 0 && (jc = kc());
        return jc
    };
    var pc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function qc(a) {
        const b = lc();
        a = b ? b.createScriptURL(a) : a;
        return new pc(a)
    }

    function rc(a) {
        if (a instanceof pc) return a.g;
        throw Error("");
    };
    var sc = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g
            }
        },
        tc = new sc("about:invalid#zClosurez");

    function uc(a) {
        return a instanceof sc
    }

    function vc(a) {
        if (uc(a)) return a.g;
        throw Error("");
    };
    class wc {
        constructor(a) {
            this.hm = a
        }
    }

    function xc(a) {
        return new wc(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const yc = [xc("data"), xc("http"), xc("https"), xc("mailto"), xc("ftp"), new wc(a => /^[^:]*([/?#]|$)/.test(a))];

    function zc(a, b = yc) {
        if (uc(a)) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof wc && d.hm(a)) return new sc(a)
        }
    }
    var Ac = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Bc(a) {
        if (Ac.test(a)) return a
    }

    function Cc(a) {
        return a instanceof sc ? vc(a) : Bc(a)
    };

    function Dc(a, b) {
        b = Cc(b);
        b !== void 0 && (a.href = b)
    };

    function Ec(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    var Fc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Gc(a) {
        const b = lc();
        a = b ? b.createHTML(a) : a;
        return new Fc(a)
    }

    function Hc(a) {
        if (a instanceof Fc) return a.g;
        throw Error("");
    };

    function Kc(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function Lc(a, b) {
        a.src = rc(b);
        (b = Kc(a.ownerDocument)) && a.setAttribute("nonce", b)
    };
    var Mc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Nc(a, b) {
        if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName)) throw Error("");
        a.innerHTML = Hc(b)
    }

    function Oc(a, b, c) {
        var d = [Pc `width`, Pc `height`];
        if (d.length === 0) throw Error("");
        d = d.map(f => {
            if (f instanceof Mc) f = f.g;
            else throw Error("");
            return f
        });
        const e = b.toLowerCase();
        if (d.every(f => e.indexOf(f) !== 0)) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    }

    function Qc(a, b, c) {
        if (a.namespaceURI !== "http://www.w3.org/1999/xhtml") throw Error(`Cannot set attribute '${b}' on '${a.tagName}'.` + "Element is not in the HTML namespace");
        b = b.toLowerCase();
        switch (`${a.tagName} ${b}`) {
            case "A href":
                Dc(a, c);
                break;
            case "AREA href":
                b = Cc(c);
                b !== void 0 && (a.href = b);
                break;
            case "BASE href":
                a.href = rc(c);
                break;
            case "BUTTON formaction":
                b = Cc(c);
                b !== void 0 && (a.formAction = b);
                break;
            case "EMBED src":
                a.src = rc(c);
                break;
            case "FORM action":
                b = Cc(c);
                b !== void 0 && (a.action = b);
                break;
            case "IFRAME src":
                a.src =
                    rc(c).toString();
                break;
            case "IFRAME srcdoc":
                a.srcdoc = Hc(c);
                break;
            case "IFRAME sandbox":
                throw Error("Can't set 'sandbox' on iframe tags. Use setIframeSrcWithIntent or setIframeSrcdocWithIntent instead");
            case "INPUT formaction":
                b = Cc(c);
                b !== void 0 && (a.formAction = b);
                break;
            case "LINK href":
                throw Error("Can't set 'href' attribute on link tags. Use setLinkHrefAndRel instead");
            case "LINK rel":
                throw Error("Can't set 'rel' attribute on link tags. Use setLinkHrefAndRel instead");
            case "OBJECT data":
                a.data = rc(c);
                break;
            case "SCRIPT src":
                Lc(a, c);
                break;
            default:
                if (/^on./.test(b)) throw Error(`Attribute "${b}" looks like an event handler attribute. ` + "Please use a safe alternative like addEventListener instead.");
                a.setAttribute(b, c)
        }
    };
    var Rc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Sc(a) {
        if (a instanceof Rc) return a.g;
        throw Error("");
    };

    function Tc(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };

    function Uc(a, b) {
        const c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        let d;
        d = b ? b.createElement("div") : q.document.createElement("div");
        return a.replace(Vc, function(e, f) {
            let g = c[e];
            if (g) return g;
            f.charAt(0) == "#" && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (Nc(d, Gc(e + " ")), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var Vc = /&([^;\s<&]+);?/g;

    function Wc(a) {
        let b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function Xc(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function $c(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var ad = Mb() ? !1 : Lb("Trident") || Lb("MSIE"),
        bd = Lb("Edge") || ad,
        cd = Lb("Gecko") && !(Gb(Hb(), "WebKit") && !Lb("Edge")) && !(Lb("Trident") || Lb("MSIE")) && !Lb("Edge"),
        dd = Gb(Hb(), "WebKit") && !Lb("Edge");

    function Pc(a) {
        return new Mc(a[0].toLowerCase())
    };

    function ed(a) {
        return new Rc(a[0])
    };

    function fd(a) {
        return a instanceof Fc ? a : Gc(gd(String(a)))
    }

    function gd(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    }

    function hd(a) {
        return id(a)
    }

    function id(a) {
        const b = fd("");
        return Gc(a.map(c => Hc(fd(c))).join(Hc(b).toString()))
    }
    const jd = /^[a-z][a-z\d-]*$/i,
        kd = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var ld = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const md = ["action", "formaction", "href"];

    function nd(a) {
        if (!jd.test(a)) throw Error("");
        if (kd.indexOf(a.toUpperCase()) !== -1) throw Error("");
    }

    function od(a, b, c) {
        nd(a);
        let d = `<${a}`;
        b && (d += td(b));
        Array.isArray(c) || (c = c === void 0 ? [] : [c]);
        ld.indexOf(a.toUpperCase()) !== -1 ? d += ">" : (b = hd(c.map(e => e instanceof Fc ? e : fd(String(e)))), d += ">" + b.toString() + "</" + a + ">");
        return Gc(d)
    }

    function td(a) {
        var b = "";
        const c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!jd.test(d)) throw Error("");
            if (e !== void 0 && e !== null) {
                if (/^on./i.test(d)) throw Error("");
                md.indexOf(d.toLowerCase()) !== -1 && (e = uc(e) ? e.toString() : Bc(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${fd(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function ud(a, ...b) {
        if (b.length === 0) return qc(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return qc(c)
    }

    function vd(a, b) {
        a = rc(a).toString();
        const c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return wd(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function wd(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        let f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return qc(a + b + c)
    };

    function xd(a) {
        try {
            return !!a && a.location.href != null && hc(a, "foo")
        } catch {
            return !1
        }
    }

    function yd(a, b = q) {
        b = zd(b);
        let c = 0;
        for (; b && c++ < 40 && !a(b);) b = zd(b)
    }

    function zd(a) {
        try {
            const b = a.parent;
            if (b && b != a) return b
        } catch {}
        return null
    }

    function Ad(a) {
        return xd(a.top) ? a.top : null
    }

    function Bd(a, b) {
        const c = Cd("SCRIPT", a);
        Lc(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Dd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Ed() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Fd(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Gd(a) {
        const b = [];
        Fd(a, function(c) {
            b.push(c)
        });
        return b
    }
    var Jd = zb(() => Oa(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], Hd) || Math.random() < 1E-4);
    const Hd = a => Hb().indexOf(a) != -1;
    var Kd = /^([0-9.]+)px$/,
        Ld = /^(-?[0-9.]{1,30})$/;

    function Md(a) {
        if (!Ld.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function Nd(a) {
        return (a = Kd.exec(a)) ? +a[1] : null
    }
    var Od = {
        io: "allow-forms",
        jo: "allow-modals",
        ko: "allow-orientation-lock",
        lo: "allow-pointer-lock",
        mo: "allow-popups",
        no: "allow-popups-to-escape-sandbox",
        oo: "allow-presentation",
        po: "allow-same-origin",
        qo: "allow-scripts",
        ro: "allow-top-navigation",
        so: "allow-top-navigation-by-user-activation"
    };
    const Pd = zb(() => Gd(Od));

    function Qd(a) {
        const b = Pd();
        return a.length ? La(b, c => !Pa(a, c)) : b
    }

    function Rd() {
        const a = Cd("IFRAME"),
            b = {};
        Ja(Pd(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var Sd = () => {
            const a = Rd();
            return !(!a["allow-top-navigation-by-user-activation"] || !a["allow-popups-to-escape-sandbox"])
        },
        Td = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        Ud = (a, b) => {
            for (let c = 0; c < 50; ++c) {
                if (Td(a, b)) return a;
                if (!(a = zd(a))) break
            }
            return null
        },
        Vd = zb(() => Rb() ? 2 : Tb() ? 1 : 0),
        r = (a, b) => {
            Fd(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        Xd = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                const c = a.length;
                for (let d = 0; d < c; d++) {
                    const e = a[d];
                    b(a[e], e, a)
                }
            } else a = Wd(a.style.cssText), Fd(a, b)
        },
        Wd = a => {
            const b = {};
            if (a) {
                const c = /\s*:\s*/;
                Ja((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d && e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        Yd = a => {
            const b = /!\s*important/i;
            Xd(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const Zd = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        $d = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        ce = /.*domain\.test$/,
        de = /\.prod\.google\.com(:\d+)?$/;
    var ee = a => Zd[a] || $d.test(a) || ce.test(a) || de.test(a),
        fe = (a, b) => rb(a, {
            Na: ({
                methodName: c,
                eb: d
            }) => void b ? .pa(c, d)
        }),
        ge = (a, b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function Cd(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    }
    var he = a => {
            let b = a;
            for (; a && a != a.parent;) a = a.parent, xd(a) && (b = a);
            return b
        },
        ie = a => {
            var b = Ad(a);
            if (!b) return 1;
            a = Vd() === 0;
            const c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
                d = b.innerWidth;
            b = b.outerWidth;
            if (d === 0) return 1;
            const e = Math.round((b / d + Number.EPSILON) * 100) / 100;
            return e === 1 ? 1 : a || c ? e : Math.round((b / d / .4 + Number.EPSILON) * 100) / 100
        };
    let je;

    function ke(a) {
        return (je || (je = new TextEncoder)).encode(a)
    };

    function le(a) {
        q.setTimeout(() => {
            throw a;
        }, 0)
    };
    var me = {},
        ne = null;

    function oe(a) {
        var b = 3;
        b === void 0 && (b = 0);
        pe();
        b = me[b];
        const c = Array(Math.floor(a.length / 3)),
            d = b[64] || "";
        let e = 0,
            f = 0;
        for (; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function qe(a) {
        const b = [];
        let c = 0;
        for (let d = 0; d < a.length; d++) {
            let e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        return oe(b)
    }

    function re(a) {
        const b = [];
        se(a, function(c) {
            b.push(c)
        });
        return b
    }

    function se(a, b) {
        function c(e) {
            for (; d < a.length;) {
                const f = a.charAt(d++),
                    g = ne[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        pe();
        let d = 0;
        for (;;) {
            const e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function pe() {
        if (!ne) {
            ne = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                const d = a.concat(b[c].split(""));
                me[c] = d;
                for (let e = 0; e < d.length; e++) {
                    const f = d[e];
                    ne[f] === void 0 && (ne[f] = e)
                }
            }
        }
    };
    var te = typeof structuredClone != "undefined";
    let ue = void 0,
        ve;

    function we(a) {
        if (ve) throw Error("");
        ve = b => {
            q.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function xe(a) {
        if (ve) try {
            ve(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function ye() {
        const a = Error();
        Tc(a, "incident");
        ve ? xe(a) : le(a)
    }

    function ze(a) {
        a = Error(a);
        Tc(a, "warning");
        xe(a);
        return a
    }

    function Ae(a, b) {
        if (a != null) {
            var c = ue ? ? (ue = {});
            var d = c[a] || 0;
            d >= b || (c[a] = d + 1, ye())
        }
    };

    function Be(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var Ce = Be(),
        De = Be(),
        Ee = Be(),
        Fe = Be(),
        Ge = Be(),
        He = Be("m_m", !0);
    const v = Be("jas", !0);
    var Ie;
    const Je = [];
    Je[v] = 7;
    Ie = Object.freeze(Je);

    function Ke(a, b) {
        a[v] |= b
    }

    function Le(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function Me(a) {
        Ke(a, 34);
        return a
    }

    function Pe(a) {
        Ke(a, 32);
        return a
    };
    var Qe = {};

    function Re(a, b) {
        return b === void 0 ? a.l !== Se && !!(2 & (a.aa[v] | 0)) : !!(2 & b) && a.l !== Se
    }
    const Se = {};
    class Te {
        constructor(a, b, c) {
            this.g = a;
            this.j = b;
            this.l = c
        }
        next() {
            const a = this.g.next();
            a.done || (a.value = this.j.call(this.l, a.value));
            return a
        }[Symbol.iterator]() {
            return this
        }
    }
    var Ue = Object.freeze({});

    function Ve(a, b, c) {
        const d = b & 128 ? 0 : -1,
            e = a.length;
        var f;
        if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
        const g = e + (f ? -1 : 0);
        for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
        if (f) {
            a = a[e - 1];
            for (const h in a) Object.prototype.hasOwnProperty.call(a, h) && !isNaN(h) && c(+h, a[h])
        }
    }
    var We = {};

    function Xe(a) {
        if (gb(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (fb(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var $e = eb(a => a >= Ye && a <= Ze);
    const Ye = BigInt(Number.MIN_SAFE_INTEGER),
        Ze = BigInt(Number.MAX_SAFE_INTEGER);
    let af = 0,
        bf = 0,
        cf;

    function df(a) {
        const b = a >>> 0;
        af = b;
        bf = (a - b) / 4294967296 >>> 0
    }

    function ef(a) {
        if (a < 0) {
            df(-a);
            a = af;
            var b = bf;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            const [c, d] = [a, b];
            af = c >>> 0;
            bf = d >>> 0
        } else df(a)
    }

    function ff(a, b) {
        const c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : gf(a, b)
    }

    function gf(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function hf() {
        var a = af,
            b = bf,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = gf(a, b);
        return c
    }

    function jf(a) {
        a.length < 16 ? ef(Number(a)) : (a = BigInt(a), af = Number(a & BigInt(4294967295)) >>> 0, bf = Number(a >> BigInt(32) & BigInt(4294967295)))
    };
    const kf = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        lf = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        mf = Number.isSafeInteger,
        nf = Number.isFinite,
        of = Math.trunc;

    function pf(a) {
        if (a != null && typeof a !== "number") throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function qf(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function rf(a) {
        if (typeof a !== "boolean") throw Error(`Expected boolean but got ${ra(a)}: ${a}`);
        return a
    }

    function sf(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    const tf = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function uf(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return nf(a);
            case "string":
                return tf.test(a);
            default:
                return !1
        }
    }

    function vf(a) {
        if (!nf(a)) throw ze("enum");
        return a | 0
    }

    function wf(a) {
        return a == null ? a : nf(a) ? a | 0 : void 0
    }

    function xf(a) {
        if (typeof a !== "number") throw ze("int32");
        if (!nf(a)) throw ze("int32");
        return a | 0
    }

    function yf(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return nf(a) ? a | 0 : void 0
    }

    function zf(a) {
        if (typeof a !== "number") throw ze("uint32");
        if (!nf(a)) throw ze("uint32");
        return a >>> 0
    }

    function Af(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return nf(a) ? a >>> 0 : void 0
    }

    function Bf(a, b = 0) {
        if (!uf(a)) throw ze("int64");
        const c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return Gf(a);
                    case "bigint":
                        return String(kf(64, a));
                    default:
                        return Hf(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return If(a);
                    case "bigint":
                        return Xe(kf(64, a));
                    default:
                        return Jf(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return Gf(a);
                    case "bigint":
                        return Xe(kf(64, a));
                    default:
                        return Kf(a)
                }
            default:
                return Ec(b, "Unknown format requested type for int64")
        }
    }

    function Lf(a) {
        return a == null ? a : Bf(a, 0)
    }

    function Mf(a) {
        if (a[0] === "-") return !1;
        const b = a.length;
        return b < 20 ? !0 : b === 20 && Number(a.substring(0, 6)) < 184467
    }

    function Nf(a) {
        const b = a.length;
        return a[0] === "-" ? b < 20 ? !0 : b === 20 && Number(a.substring(0, 7)) > -922337 : b < 19 ? !0 : b === 19 && Number(a.substring(0, 6)) < 922337
    }

    function Of(a) {
        if (a < 0) {
            ef(a);
            var b = gf(af, bf);
            a = Number(b);
            return mf(a) ? a : b
        }
        b = String(a);
        if (Mf(b)) return b;
        ef(a);
        return ff(af, bf)
    }

    function Kf(a) {
        a = of (a);
        if (!mf(a)) {
            ef(a);
            var b = af,
                c = bf;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = ff(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function Pf(a) {
        a = of (a);
        return a >= 0 && mf(a) ? a : Of(a)
    }

    function Hf(a) {
        a = of (a);
        if (mf(a)) a = String(a);
        else {
            {
                const b = String(a);
                Nf(b) ? a = b : (ef(a), a = hf())
            }
        }
        return a
    }

    function Qf(a) {
        a = of (a);
        if (a >= 0 && mf(a)) a = String(a);
        else {
            {
                const b = String(a);
                Mf(b) ? a = b : (ef(a), a = gf(af, bf))
            }
        }
        return a
    }

    function Gf(a) {
        var b = of (Number(a));
        if (mf(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Nf(a) || (jf(a), a = hf());
        return a
    }

    function If(a) {
        var b = of (Number(a));
        if (mf(b)) return Xe(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Xe(kf(64, BigInt(a)))
    }

    function Jf(a) {
        return mf(a) ? Xe(Kf(a)) : Xe(Hf(a))
    }

    function Rf(a) {
        var b = of (Number(a));
        if (mf(b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Mf(a) || (jf(a), a = gf(af, bf));
        return a
    }

    function Sf(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return $e(a) ? a = Number(a) : (a = kf(64, a), a = $e(a) ? Number(a) : String(a)), a;
        if (uf(a)) return typeof a === "number" ? Kf(a) : Gf(a)
    }

    function Tf(a) {
        const b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Xe(kf(64, a));
        if (uf(a)) return b === "string" ? If(a) : Jf(a)
    }

    function Uf(a, b = 0) {
        if (!uf(a)) throw ze("uint64");
        const c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return Rf(a);
                    case "bigint":
                        return String(lf(64, a));
                    default:
                        return Qf(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return b = of (Number(a)), mf(b) && b >= 0 ? a = Xe(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = Xe(lf(64, BigInt(a)))), a;
                    case "bigint":
                        return Xe(lf(64, a));
                    default:
                        return mf(a) ? Xe(Pf(a)) : Xe(Qf(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Rf(a);
                    case "bigint":
                        return Xe(lf(64, a));
                    default:
                        return Pf(a)
                }
            default:
                return Ec(b,
                    "Unknown format requested type for int64")
        }
    }

    function Vf(a) {
        return a == null ? a : Uf(a, 0)
    }

    function Wf(a) {
        if (a == null) return a;
        const b = typeof a;
        if (b === "bigint") return String(kf(64, a));
        if (uf(a)) {
            if (b === "string") return Gf(a);
            if (b === "number") return Kf(a)
        }
    }

    function Xf(a) {
        if (a == null) return a;
        const b = typeof a;
        if (b === "bigint") return String(lf(64, a));
        if (uf(a)) {
            if (b === "string") return Rf(a);
            if (b === "number") return Pf(a)
        }
    }

    function Yf(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function Zf(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function $f(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function ag(a, b, c, d) {
        if (a != null && a[He] === Qe) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? ((a = b[Ce]) || (a = new b, Me(a.aa), a = b[Ce] = a), b = a) : b = new b : b = void 0, b;
        c = a[v] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[v] = d);
        return new b(a)
    }

    function bg(a, b, c) {
        return b ? Yf(a) : $f(a) ? ? (c ? "" : void 0)
    };

    function cg(a) {
        return a
    };
    const dg = {},
        eg = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function fg(a) {
        return a
    }

    function gg(a) {
        if (a.bd & 2) throw Error("Cannot mutate an immutable Map");
    }
    var kg = class extends eg {
        constructor(a, b, c = fg, d = fg) {
            super();
            this.bd = a[v] | 0;
            this.Tc = b;
            this.qf = c;
            this.ak = this.Tc ? hg : d;
            for (let e = 0; e < a.length; e++) {
                const f = a[e],
                    g = c(f[0], !1, !0);
                let h = f[1];
                b ? h === void 0 && (h = null) : h = d(f[1], !1, !0, void 0, void 0, this.bd);
                super.set(g, h)
            }
        }
        sn() {
            var a = ig;
            if (this.size !== 0) return Array.from(super.entries(), a)
        }
        Wj() {
            return Array.from(super.entries())
        }
        clear() {
            gg(this);
            super.clear()
        }
        delete(a) {
            gg(this);
            return super.delete(this.qf(a, !0, !1))
        }
        entries() {
            if (this.Tc) {
                var a = super.keys();
                a = new Te(a,
                    jg, this)
            } else a = super.entries();
            return a
        }
        values() {
            if (this.Tc) {
                var a = super.keys();
                a = new Te(a, kg.prototype.get, this)
            } else a = super.values();
            return a
        }
        forEach(a, b) {
            this.Tc ? super.forEach((c, d, e) => {
                a.call(b, e.get(d), d, e)
            }) : super.forEach(a, b)
        }
        set(a, b) {
            gg(this);
            a = this.qf(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.ak(b, !0, !0, this.Tc, !1, this.bd))
        }
        has(a) {
            return super.has(this.qf(a, !1, !1))
        }
        get(a) {
            a = this.qf(a, !1, !1);
            const b = super.get(a);
            if (b !== void 0) {
                var c = this.Tc;
                return c ? (c =
                    this.ak(b, !1, !0, c, this.Ok, this.bd), c !== b && super.set(a, c), c) : b
            }
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    kg.prototype.toJSON = void 0;

    function hg(a, b, c, d, e, f) {
        a = ag(a, d, c, f);
        e && (a = lg(a));
        return a
    }

    function jg(a) {
        return [a, this.get(a)]
    }
    let mg;

    function ng() {
        return mg || (mg = new kg(Me([]), void 0, void 0, void 0, dg))
    };

    function og(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        const f = [];
        var g = a.length;
        let h, k = 4294967295,
            l = !1;
        const m = !!(b & 64),
            n = m ? b & 128 ? 0 : -1 : void 0;
        b & 1 || (h = g && a[g - 1], h != null && typeof h === "object" && h.constructor === Object ? (g--, k = g) : h = void 0, !m || b & 128 || e || (l = !0, k = (pg ? ? cg)(k - n, n, a, h, void 0) + n));
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (m && e >= k) {
                    const t = e - n;
                    (b ? ? (b = {}))[t] = p
                } else f[e] = p
        }
        if (h)
            for (let p in h) {
                if (!Object.prototype.hasOwnProperty.call(h, p)) continue;
                a = h[p];
                if (a == null || (a = c(a, d)) ==
                    null) continue;
                g = +p;
                let t;
                m && !Number.isNaN(g) && (t = g + n) < k ? f[t] = a : (b ? ? (b = {}))[p] = a
            }
        b && (l ? f.push(b) : f[k] = b);
        return f
    }

    function ig(a) {
        a[0] = qg(a[0]);
        a[1] = qg(a[1]);
        return a
    }

    function qg(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return $e(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    const b = a[v] | 0;
                    return a.length === 0 && b & 1 ? void 0 : og(a, b, qg)
                }
                if (a != null && a[He] === Qe) return rg(a);
                if (a instanceof kg) return a.sn();
                return
        }
        return a
    }
    var sg = te ? structuredClone : a => og(a, 0, qg);
    let pg;

    function rg(a) {
        a = a.aa;
        return og(a, a[v] | 0, qg)
    };
    let tg, ug;

    function vg(a) {
        switch (typeof a) {
            case "boolean":
                return tg || (tg = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? ug || (ug = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    }

    function wg(a, b, c) {
        return a = xg(a, b[0], b[1], c ? 1 : 2)
    }

    function xg(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -8380417 | (b & 1023) << 13)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[v] | 0;
            if (Eb && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && yg();
            if (e & 256) throw Error("farr");
            if (e & 64) return d !== 0 || e & 2048 || (a[v] = e | 2048), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    const k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in k)
                            if (Object.prototype.hasOwnProperty.call(k,
                                    h))
                                if (f = +h, f < g) c[f + b] = k[h], delete k[h];
                                else break;
                        e = e & -8380417 | (g & 1023) << 13;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -8380417 | (h & 1023) << 13
                }
            }
        }
        e |= 64;
        d === 0 && (e |= 2048);
        a[v] = e;
        return a
    }

    function yg() {
        if (Eb) throw Error("carr");
        Ae(Ge, 5)
    };

    function zg(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[v] | 0;
            return a.length === 0 && c & 1 ? void 0 : Ag(a, c, b)
        }
        if (a != null && a[He] === Qe) return Bg(a);
        if (a instanceof kg) {
            c = a.bd;
            if (c & 2) return a;
            if (a.size) {
                b = Me(a.Wj());
                if (a.Tc)
                    for (a = 0; a < b.length; a++) {
                        const d = b[a];
                        let e = d[1];
                        e == null || typeof e !== "object" ? e = void 0 : e != null && e[He] === Qe ? e = Bg(e) : Array.isArray(e) ? e = Ag(e, e[v] | 0, !!(c & 32)) : e = void 0;
                        d[1] = e
                    }
                return b
            }
        }
    }

    function Ag(a, b, c) {
        if (b & 2) return a;
        !c || 4096 & b || 16 & b ? a = Cg(a, b, !1, c && !(b & 16)) : (Ke(a, 34), b & 4 && Object.freeze(a));
        return a
    }

    function Dg(a, b, c) {
        a = new a.constructor(b);
        c && (a.l = Se);
        a.A = Se;
        return a
    }

    function Bg(a) {
        const b = a.aa,
            c = b[v] | 0;
        return Re(a, c) ? a : Eg(a, b, c) ? Dg(a, b) : Cg(b, c)
    }

    function ah(a) {
        const b = a.aa,
            c = b[v] | 0;
        return Eg(a, b, c) ? Dg(a, b, !0) : new a.constructor(Cg(b, c, !1))
    }

    function Cg(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = og(a, b, zg, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        a[v] = b;
        return a
    }

    function lg(a) {
        const b = a.aa,
            c = b[v] | 0;
        return Re(a, c) ? Eg(a, b, c) ? Dg(a, b, !0) : new a.constructor(Cg(b, c, !1)) : a
    }

    function bh(a) {
        const b = a.aa,
            c = b[v] | 0;
        return Re(a, c) ? a : Eg(a, b, c) ? Dg(a, b) : new a.constructor(Cg(b, c, !0))
    }

    function ch(a) {
        if (a.l !== Se) return !1;
        var b = a.aa;
        b = Cg(b, b[v] | 0);
        Ke(b, 2048);
        a.aa = b;
        a.l = void 0;
        a.A = void 0;
        return !0
    }

    function dh(a) {
        if (!ch(a) && Re(a, a.aa[v] | 0)) throw Error();
    }

    function eh(a, b) {
        b === void 0 && (b = a[v] | 0);
        b & 32 && !(b & 4096) && (a[v] = b | 4096)
    }

    function Eg(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[v] = c | 2, a.l = Se, !0) : !1
    };
    const fh = Xe(0),
        gh = {};

    function w(a, b, c, d, e) {
        b = hh(a.aa, b, c, e);
        if (b !== null || d && a.A !== Se) return b
    }

    function hh(a, b, c, d) {
        if (b === -1) return null;
        const e = b + (c ? 0 : -1),
            f = a.length - 1;
        let g, h;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f)
                if (g = a[f], g != null && typeof g === "object" && g.constructor === Object) c = g[b], h = !0;
                else if (e === f) c = g;
            else return;
            else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function ih(a, b, c) {
        dh(a);
        const d = a.aa;
        jh(d, d[v] | 0, b, c);
        return a
    }

    function jh(a, b, c, d, e) {
        const f = c + (e ? 0 : -1);
        var g = a.length - 1;
        if (g >= 1 + (e ? 0 : -1) && f >= g) {
            const h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && (g = (b ? ? (b = a[v] | 0)) >> 13 & 1023 || 536870912, c >= g ? d != null && (a[g + (e ? 0 : -1)] = {
            [c]: d
        }) : a[f] = d);
        return b
    }

    function kh(a, b, c) {
        a = a.aa;
        return lh(a, a[v] | 0, b, c) !== void 0
    }

    function mh(a, b, c, d) {
        const e = a.aa;
        return lh(e, e[v] | 0, b, nh(a, d, c)) !== void 0
    }

    function oh(a, b, c) {
        return w(a, b, void 0, c, qf)
    }

    function ph(a) {
        return a === Ue ? 2 : 4
    }

    function qh(a, b, c, d, e, f, g) {
        let h = a.aa,
            k = h[v] | 0;
        d = Re(a, k) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && ch(a) && (h = a.aa, k = h[v] | 0);
        let l = rh(h, b, g),
            m = l === Ie ? 7 : l[v] | 0,
            n = sh(m, k);
        var p = n;
        4 & p ? f == null ? a = !1 : (!e && f === 0 && (512 & p || 1024 & p) && (a.constructor[Ee] = (a.constructor[Ee] | 0) + 1) < 5 && ye(), a = f === 0 ? !1 : !(f & p)) : a = !0;
        if (a) {
            4 & n && (l = [...l], m = 0, n = th(n, k), k = jh(h, k, b, l, g));
            let t = p = 0;
            for (; p < l.length; p++) {
                const u = c(l[p]);
                u != null && (l[t++] = u)
            }
            t < p && (l.length = t);
            c = (n | 4) & -513;
            n = c &= -1025;
            f && (n |= f);
            n &= -4097
        }
        n !== m && (l[v] = n, 2 & n && Object.freeze(l));
        return l =
            uh(l, n, h, k, b, g, d, a, e)
    }

    function uh(a, b, c, d, e, f, g, h, k) {
        let l = b;
        g === 1 || (g !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? vh(b) || (b |= !a.length || h && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== l && (a[v] = b), Object.freeze(a)) : (g === 2 && vh(b) && (a = [...a], l = 0, b = th(b, d), d = jh(c, d, e, a, f)), vh(b) || (k || (b |= 16), b !== l && (a[v] = b)));
        2 & b || !(4096 & b || 16 & b) || eh(c, d);
        return a
    }

    function rh(a, b, c) {
        a = hh(a, b, c);
        return Array.isArray(a) ? a : Ie
    }

    function sh(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function vh(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function wh(a) {
        var b = xh;
        let c;
        var d = a.aa;
        var e = d[v] | 0;
        c = Re(a, e);
        a: {!c && ch(a) && (d = a.aa, e = d[v] | 0);
                var f = hh(d, 14);a = !1;
                if (f == null) {
                    if (c) {
                        d = ng();
                        break a
                    }
                    f = []
                } else if (f.constructor === kg)
                    if (f.bd & 2 && !c) f = f.Wj();
                    else {
                        d = f;
                        break a
                    }
                else Array.isArray(f) ? a = !!((f[v] | 0) & 2) : f = [];
                if (c) {
                    if (!f.length) {
                        d = ng();
                        break a
                    }
                    a || (a = !0, Me(f))
                } else if (a) {
                    a = !1;
                    f = [...f];
                    for (let g = 0; g < f.length; g++) {
                        const h = f[g] = [...f[g]];
                        Array.isArray(h[1]) && (h[1] = Me(h[1]))
                    }
                }!a && e & 32 && Pe(f);f = new kg(f, b, bg, void 0);e = jh(d, e, 14, f);a || eh(d, e);d = f
            }!c &&
            b && (d.Ok = !0);
        return d
    }

    function yh(a, b, c, d) {
        dh(a);
        const e = a.aa;
        let f = e[v] | 0;
        if (c == null) return jh(e, f, b), a;
        let g = c === Ie ? 7 : c[v] | 0,
            h = g;
        var k = vh(g);
        let l = k || Object.isFrozen(c);
        k || (g = 0);
        l || (c = [...c], h = 0, g = th(g, f), l = !1);
        g |= 5;
        k = Le(g) ? ? 0;
        for (let m = 0; m < c.length; m++) {
            const n = c[m],
                p = d(n, k);
            Object.is(n, p) || (l && (c = [...c], h = 0, g = th(g, f), l = !1), c[m] = p)
        }
        g !== h && (l && (c = [...c], g = th(g, f)), c[v] = g);
        jh(e, f, b, c);
        return a
    }

    function zh(a, b, c, d) {
        dh(a);
        const e = a.aa;
        jh(e, e[v] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Ah(a, b, c, d) {
        dh(a);
        const e = a.aa;
        var f = e[v] | 0;
        if (d == null) {
            var g = Bh(e);
            if (Ch(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Bh(e);
            const h = Ch(g, e, f, c);
            h !== b && (h && (f = jh(e, f, h)), g.set(c, b))
        }
        jh(e, f, b, d);
        return a
    }

    function nh(a, b, c) {
        return Dh(a, b) === c ? c : -1
    }

    function Dh(a, b) {
        a = a.aa;
        return Ch(Bh(a), a, void 0, b)
    }

    function Bh(a) {
        return a[De] ? ? (a[De] = new Map)
    }

    function Ch(a, b, c, d) {
        let e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            const g = d[f];
            hh(b, g) != null && (e !== 0 && (c = jh(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function lh(a, b, c, d) {
        let e = !1;
        d = hh(a, d, void 0, f => {
            const g = ag(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !Re(d) && eh(a, b), d
    }

    function Eh(a, b, c) {
        a = a.aa;
        (c = lh(a, a[v] | 0, b, c)) || (c = b[Ce]) || (c = new b, Me(c.aa), c = b[Ce] = c);
        return c
    }

    function x(a, b, c) {
        let d = a.aa,
            e = d[v] | 0;
        b = lh(d, e, b, c);
        if (b == null) return b;
        e = d[v] | 0;
        if (!Re(a, e)) {
            const f = lg(b);
            f !== b && (ch(a) && (d = a.aa, e = d[v] | 0), b = f, e = jh(d, e, c, b), eh(d, e))
        }
        return b
    }

    function Fh(a, b, c, d, e, f, g, h, k) {
        var l = Re(a, c);
        f = l ? 1 : f;
        h = !!h || f === 3;
        l = k && !l;
        (f === 2 || l) && ch(a) && (b = a.aa, c = b[v] | 0);
        a = rh(b, e, g);
        var m = a === Ie ? 7 : a[v] | 0,
            n = sh(m, c);
        if (k = !(4 & n)) {
            var p = a,
                t = c;
            const u = !!(2 & n);
            u && (t |= 2);
            let B = !u,
                F = !0,
                R = 0,
                da = 0;
            for (; R < p.length; R++) {
                const J = ag(p[R], d, !1, t);
                if (J instanceof d) {
                    if (!u) {
                        const N = Re(J);
                        B && (B = !N);
                        F && (F = N)
                    }
                    p[da++] = J
                }
            }
            da < R && (p.length = da);
            n |= 4;
            n = F ? n & -4097 : n | 4096;
            n = B ? n | 8 : n & -9
        }
        n !== m && (a[v] = n, 2 & n && Object.freeze(a));
        if (l && !(8 & n || !a.length && (f === 1 || (f !== 4 ? 0 : 2 & n || !(16 & n) && 32 & c)))) {
            vh(n) &&
                (a = [...a], n = th(n, c), c = jh(b, c, e, a, g));
            d = a;
            l = n;
            for (m = 0; m < d.length; m++) p = d[m], n = lg(p), p !== n && (d[m] = n);
            l |= 8;
            n = l = d.length ? l | 4096 : l & -4097;
            a[v] = n
        }
        return a = uh(a, n, b, c, e, g, f, k, h)
    }

    function Gh(a, b, c, d) {
        const e = a.aa;
        return Fh(a, e, e[v] | 0, b, c, d, void 0, !1, !0)
    }

    function Hh(a) {
        a == null && (a = void 0);
        return a
    }

    function y(a, b, c) {
        c = Hh(c);
        ih(a, b, c);
        c && !Re(c) && eh(a.aa);
        return a
    }

    function z(a, b, c, d) {
        d = Hh(d);
        Ah(a, b, c, d);
        d && !Re(d) && eh(a.aa);
        return a
    }

    function Ih(a, b, c) {
        dh(a);
        const d = a.aa;
        let e = d[v] | 0;
        if (c == null) return jh(d, e, b), a;
        let f = c === Ie ? 7 : c[v] | 0,
            g = f;
        const h = vh(f),
            k = h || Object.isFrozen(c);
        let l = !0,
            m = !0;
        for (let p = 0; p < c.length; p++) {
            var n = c[p];
            h || (n = Re(n), l && (l = !n), m && (m = n))
        }
        h || (f = l ? 13 : 5, f = m ? f & -4097 : f | 4096);
        k && f === g || (c = [...c], g = 0, f = th(f, e));
        f !== g && (c[v] = f);
        e = jh(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || eh(d, e);
        return a
    }

    function th(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Jh(a, b, c, d, e, f, g, h) {
        dh(a);
        b = qh(a, b, e, 2, !0, void 0, f);
        e = Le(b === Ie ? 7 : b[v] | 0) ? ? 0;
        if (h)
            if (Array.isArray(d))
                for (g = d.length, h = 0; h < g; h++) b.push(c(d[h], e));
            else
                for (const k of d) b.push(c(k, e));
        else {
            if (g) throw Error();
            b.push(c(d, e))
        }
        return a
    }

    function Kh(a, b, c, d) {
        var e = d;
        dh(a);
        d = a.aa;
        b = Fh(a, d, d[v] | 0, c, b, 2, void 0, !0);
        e = e != null ? e : new c;
        b.push(e);
        const f = c = b === Ie ? 7 : b[v] | 0;
        (e = Re(e)) ? (c &= -9, b.length === 1 && (c &= -4097)) : c |= 4096;
        c !== f && (b[v] = c);
        e || eh(d);
        return a
    }

    function Lh(a, b, c) {
        return Sf(w(a, b, void 0, c))
    }

    function Mh(a, b, c) {
        return Tf(w(a, b, void 0, c))
    }

    function Nh(a) {
        {
            a = w(a, 10);
            const b = typeof a;
            a = a == null ? a : b === "bigint" ? String(lf(64, a)) : uf(a) ? b === "string" ? Rf(a) : Qf(a) : void 0
        }
        return a
    }

    function Oh(a, b, c, d) {
        return sf(w(a, b, c, d))
    }

    function A(a, b) {
        return Oh(a, b) ? ? !1
    }

    function Ph(a, b) {
        return yf(w(a, b)) ? ? 0
    }

    function Qh(a, b) {
        return Mh(a, b) ? ? fh
    }

    function Rh(a, b, c = 0) {
        return oh(a, b) ? ? c
    }

    function C(a, b) {
        return $f(w(a, b)) ? ? ""
    }

    function D(a, b) {
        return wf(w(a, b)) ? ? 0
    }

    function Sh(a, b) {
        return qh(a, b, yf, ph())
    }

    function Th(a, b) {
        return qh(a, b, $f, ph())
    }

    function Uh(a, b) {
        return qh(a, b, wf, ph())
    }

    function Vh(a, b, c, d) {
        return x(a, b, nh(a, d, c))
    }

    function Wh(a, b) {
        return Oh(a, b, void 0, gh)
    }

    function Xh(a, b) {
        return yf(w(a, b, void 0, gh))
    }

    function Yh(a, b) {
        return $f(w(a, b, void 0, gh))
    }

    function Zh(a, b) {
        return wf(w(a, b, void 0, gh))
    }

    function $h(a, b, c) {
        return ih(a, b, c == null ? c : rf(c))
    }

    function ai(a, b, c) {
        return zh(a, b, c == null ? c : rf(c), !1)
    }

    function bi(a, b, c) {
        return ih(a, b, c == null ? c : xf(c))
    }

    function E(a, b, c) {
        return zh(a, b, c == null ? c : xf(c), 0)
    }

    function ci(a, b, c) {
        return ih(a, b, Lf(c))
    }

    function di(a, b, c) {
        return zh(a, b, Lf(c), "0")
    }

    function ei(a, b, c) {
        return zh(a, b, Vf(c), "0")
    }

    function fi(a, b, c) {
        return ih(a, b, Zf(c))
    }

    function gi(a, b, c) {
        return zh(a, b, Zf(c), "")
    }

    function hi(a, b, c) {
        return ih(a, b, c == null ? c : vf(c))
    }

    function G(a, b, c) {
        return zh(a, b, c == null ? c : vf(c), 0)
    }

    function ii(a, b) {
        return $f(w(a, b)) != null
    }

    function ji(a, b) {
        b = nh(a, ki, b);
        return $f(w(a, b)) != null
    };

    function li(a) {
        a = BigInt.asUintN(64, a);
        return new mi(Number(a & BigInt(4294967295)), Number(a >> BigInt(32)))
    }

    function ni(a) {
        if (!a) return oi || (oi = new mi(0, 0));
        if (!/^\d+$/.test(a)) return null;
        jf(a);
        return new mi(af, bf)
    }
    var mi = class {
        constructor(a, b) {
            this.j = a >>> 0;
            this.g = b >>> 0
        }
    };
    let oi;

    function pi(a) {
        a = BigInt.asUintN(64, a);
        return new qi(Number(a & BigInt(4294967295)), Number(a >> BigInt(32)))
    }

    function ri(a) {
        if (!a) return si || (si = new qi(0, 0));
        if (!/^-?\d+$/.test(a)) return null;
        jf(a);
        return new qi(af, bf)
    }
    var qi = class {
        constructor(a, b) {
            this.j = a >>> 0;
            this.g = b >>> 0
        }
    };
    let si;

    function ti(a, b, c) {
        for (; c > 0 || b > 127;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
        a.g.push(b)
    }

    function ui(a, b) {
        for (; b > 127;) a.g.push(b & 127 | 128), b >>>= 7;
        a.g.push(b)
    }

    function vi(a, b) {
        if (b >= 0) ui(a, b);
        else {
            for (let c = 0; c < 9; c++) a.g.push(b & 127 | 128), b >>= 7;
            a.g.push(1)
        }
    }

    function wi(a, b) {
        a.g.push(b >>> 0 & 255);
        a.g.push(b >>> 8 & 255);
        a.g.push(b >>> 16 & 255);
        a.g.push(b >>> 24 & 255)
    }
    var xi = class {
        constructor() {
            this.g = []
        }
        length() {
            return this.g.length
        }
        end() {
            const a = this.g;
            this.g = [];
            return a
        }
    };

    function yi(a, b) {
        b.length !== 0 && (a.l.push(b), a.j += b.length)
    }

    function zi(a, b) {
        yi(a, a.g.end());
        yi(a, b)
    }

    function Ai(a, b, c) {
        ui(a.g, b * 8 + c)
    }

    function Bi(a, b) {
        Ai(a, b, 2);
        b = a.g.end();
        yi(a, b);
        b.push(a.j);
        return b
    }

    function Ci(a, b) {
        var c = b.pop();
        for (c = a.j + a.g.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.j++;
        b.push(c);
        a.j++
    }

    function Di(a) {
        yi(a, a.g.end());
        const b = new Uint8Array(a.j),
            c = a.l,
            d = c.length;
        let e = 0;
        for (let f = 0; f < d; f++) {
            const g = c[f];
            b.set(g, e);
            e += g.length
        }
        a.l = [b];
        return b
    }

    function Ei(a, b, c, d) {
        c != null && (b = Bi(a, b), d(c, a), Ci(a, b))
    }

    function Fi(a, b, c) {
        var d = Gi;
        if (c != null)
            for (let e = 0; e < c.length; e++) {
                const f = Bi(a, b);
                d(c[e], a);
                Ci(a, f)
            }
    }
    var Hi = class {
        constructor() {
            this.l = [];
            this.j = 0;
            this.g = new xi
        }
    };

    function Ii() {
        const a = class {
            constructor() {
                throw Error();
            }
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var Ji = Ii(),
        Ki = Ii(),
        Li = Ii(),
        Mi = Ii(),
        Ni = Ii(),
        Oi = Ii(),
        Pi = Ii(),
        Qi = Ii(),
        Ri = Ii(),
        gj = Ii(),
        hj = Ii();

    function ij(a) {
        return lg(a)
    }

    function jj(a) {
        return JSON.stringify(rg(a))
    }

    function kj(a) {
        return bh(a)
    }
    var H = class {
        constructor(a) {
            this.aa = xg(a)
        }
        toJSON() {
            return rg(this)
        }
    };
    H.prototype[He] = Qe;

    function lj(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(Pe(b))
    };
    var mj = class {
        constructor(a, b) {
            this.g = a;
            a = Da(Ji);
            this.j = !!a && b === a || !1
        }
    };

    function nj(a, b, c, d, e) {
        Ei(a, c, oj(b, d), e)
    }
    const pj = new mj(nj, Ji),
        qj = new mj(nj, Ji);
    var rj = Symbol(),
        sj = Symbol();
    let tj, uj;

    function vj(a) {
        var b = zj,
            c = Aj,
            d = a[rj];
        if (d) return d;
        d = {};
        d.Yq = a;
        d.sj = vg(a[0]);
        var e = a[1];
        let f = 1;
        e && e.constructor === Object && (d.wl = e, e = a[++f], typeof e === "function" && (d.bm = !0, tj ? ? (tj = e), uj ? ? (uj = a[f + 1]), e = a[f += 2]));
        const g = {};
        for (; e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;) {
            for (var h = 0; h < e.length; h++) g[e[h]] = e;
            e = a[++f]
        }
        for (h = 1; e !== void 0;) {
            typeof e === "number" && (h += e, e = a[++f]);
            let m;
            var k = void 0;
            e instanceof mj ? m = e : (m = pj, f--);
            if (m ? .j) {
                e = a[++f];
                k = a;
                var l = f;
                typeof e === "function" && (e =
                    e(), k[l] = e);
                k = e
            }
            e = a[++f];
            l = h + 1;
            typeof e === "number" && e < 0 && (l -= e, e = a[++f]);
            for (; h < l; h++) {
                const n = g[h];
                k ? c(d, h, m, k, n) : b(d, h, m, n)
            }
        }
        return a[rj] = d
    }

    function oj(a, b) {
        if (a instanceof H) return a.aa;
        if (Array.isArray(a)) return wg(a, b, !1)
    };

    function zj(a, b, c) {
        a[b] = c.g
    }

    function Aj(a, b, c, d) {
        let e, f;
        const g = c.g;
        a[b] = (h, k, l) => g(h, k, l, f || (f = vj(d).sj), e || (e = Bj(d)))
    }

    function Bj(a) {
        let b = a[sj];
        if (!b) {
            const c = vj(a);
            b = (d, e) => Cj(d, e, c);
            a[sj] = b
        }
        return b
    }

    function Cj(a, b, c) {
        Ve(a, a[v] | 0, (d, e) => {
            if (e != null) {
                var f = Dj(c, d);
                f ? f(b, e, d) : d < 500 || Ae(Fe, 3)
            }
        })
    }

    function Dj(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.wl)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof mj ? c : [qj, c] : [c, void 0];
                var d = c[0].g;
                if (c = c[1]) {
                    const e = Bj(c),
                        f = vj(c).sj;
                    c = a.bm ? uj(f, e) : (g, h, k) => d(g, h, k, f, e)
                } else c = d;
                return a[b] = c
            }
    };

    function Ej(a, b, c) {
        if (Array.isArray(b)) {
            var d = b[v] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                const g = a(b[e]);
                g != null && (b[f++] = g)
            }
            f < e && (b.length = f);
            c && (b[v] = (d | 5) & -1537, d & 2 && Object.freeze(b));
            return b
        }
    }
    var Fj = (a, b) => {
        const c = new Hi;
        Cj(a.aa, c, vj(b));
        return Di(c)
    };

    function Gj(a, b) {
        return new mj(a, b)
    }

    function Hj(a, b) {
        return new mj(a, b)
    }
    var Ij = new mj(function(a, b, c, d, e) {
        if (b instanceof kg) b.forEach((f, g) => {
            Ei(a, c, wg([g, f], d, !1), e)
        });
        else if (Array.isArray(b))
            for (let f = 0; f < b.length; f++) {
                const g = b[f];
                Array.isArray(g) && Ei(a, c, wg(g, d, !1), e)
            }
    }, Ji);

    function Jj(a, b, c) {
        b = qf(b);
        b != null && (Ai(a, c, 1), a = a.g, c = cf || (cf = new DataView(new ArrayBuffer(8))), c.setFloat64(0, +b, !0), af = c.getUint32(0, !0), bf = c.getUint32(4, !0), wi(a, af), wi(a, bf))
    }

    function Kj(a, b, c) {
        b = qf(b);
        b != null && (Ai(a, c, 5), a = a.g, c = cf || (cf = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), bf = 0, af = c.getUint32(0, !0), wi(a, af))
    }

    function Lj(a, b, c) {
        b = Wf(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    ri(b)
            }
            if (b != null) switch (Ai(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    ef(b);
                    ti(a, af, bf);
                    break;
                case "bigint":
                    c = pi(b);
                    ti(a.g, c.j, c.g);
                    break;
                default:
                    c = ri(b), ti(a.g, c.j, c.g)
            }
        }
    }

    function Mj(a, b, c) {
        b = Ej(Wf, b, !1);
        if (b != null && b.length) {
            c = Bi(a, c);
            for (let e = 0; e < b.length; e++) {
                const f = b[e];
                switch (typeof f) {
                    case "number":
                        var d = a.g;
                        ef(f);
                        ti(d, af, bf);
                        break;
                    case "bigint":
                        d = pi(f);
                        ti(a.g, d.j, d.g);
                        break;
                    default:
                        d = ri(f), ti(a.g, d.j, d.g)
                }
            }
            Ci(a, c)
        }
    }

    function Nj(a, b, c) {
        b = Xf(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    ni(b)
            }
            if (b != null) switch (Ai(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    ef(b);
                    ti(a, af, bf);
                    break;
                case "bigint":
                    c = li(b);
                    ti(a.g, c.j, c.g);
                    break;
                default:
                    c = ni(b), ti(a.g, c.j, c.g)
            }
        }
    }

    function Oj(a, b, c) {
        b = yf(b);
        b != null && b != null && (Ai(a, c, 0), vi(a.g, b))
    }

    function Pj(a, b, c) {
        b = sf(b);
        b != null && (Ai(a, c, 0), a.g.g.push(b ? 1 : 0))
    }

    function Qj(a, b, c) {
        b = $f(b);
        b != null && (b = ke(b), Ai(a, c, 2), ui(a.g, b.length), zi(a, b))
    }

    function Rj(a, b, c, d, e) {
        Ei(a, c, oj(b, d), e)
    }

    function Sj(a, b, c) {
        b = yf(b);
        b != null && (b = parseInt(b, 10), Ai(a, c, 0), vi(a.g, b))
    }
    var Tj = Gj(Jj, gj),
        Uj = Gj(Jj, gj),
        Vj = Gj(Kj, Ri),
        Wj = Gj(Kj, Ri),
        Xj = Hj(Mj, Pi),
        Yj = Gj(Lj, Pi),
        Zj = Hj(Mj, Pi),
        ak = Gj(Lj, Pi),
        bk = Gj(Lj, Pi),
        ck = Gj(Nj, Qi),
        dk = Hj(function(a, b, c) {
            b = Ej(Xf, b, !1);
            if (b != null && b.length) {
                c = Bi(a, c);
                for (let f = 0; f < b.length; f++) {
                    var d = b[f];
                    switch (typeof d) {
                        case "number":
                            var e = a.g;
                            ef(d);
                            ti(e, af, bf);
                            break;
                        case "bigint":
                            e = Number(d);
                            Number.isSafeInteger(e) ? (d = a.g, ef(e), ti(d, af, bf)) : (d = li(d), ti(a.g, d.j, d.g));
                            break;
                        default:
                            d = ni(d), ti(a.g, d.j, d.g)
                    }
                }
                Ci(a, c)
            }
        }, Qi),
        ek = Gj(Nj, Qi),
        fk = Gj(Oj, Mi),
        gk = Hj(function(a,
            b, c) {
            b = Ej(yf, b, !0);
            if (b != null && b.length) {
                c = Bi(a, c);
                for (let d = 0; d < b.length; d++) vi(a.g, b[d]);
                Ci(a, c)
            }
        }, Mi),
        hk = Gj(Oj, Mi),
        ik = Gj(function(a, b, c) {
            b = Af(b);
            b != null && (Ai(a, c, 5), wi(a.g, b))
        }, Oi),
        jk = Gj(Pj, Ki),
        kk = Gj(Pj, Ki),
        lk = Gj(Pj, Ki),
        mk = Gj(Qj, Li),
        nk = Hj(function(a, b, c) {
            b = Ej($f, b, !0);
            if (b != null)
                for (let g = 0; g < b.length; g++) {
                    var d = a,
                        e = c,
                        f = b[g];
                    f != null && (f = ke(f), Ai(d, e, 2), ui(d.g, f.length), zi(d, f))
                }
        }, Li),
        ok = Gj(Qj, Li),
        pk = Gj(Qj, Li),
        qk = function(a, b, c = Ji) {
            return new mj(b, c)
        }(function(a, b, c, d, e) {
            if (a.g() !== 2) return !1;
            var f =
                a.j;
            d = wg(void 0, d, !0);
            var g = b[v] | 0;
            if (g & 2) throw Error();
            const h = g & 128 ? We : void 0;
            let k = rh(b, c, h),
                l = k === Ie ? 7 : k[v] | 0,
                m = sh(l, g);
            if (2 & m || vh(m) || 16 & m) k = [...k], l = 0, m = th(m, g), jh(b, g, c, k, h);
            m &= -13;
            m !== l && (k[v] = m);
            k.push(d);
            f.call(a, d, e);
            return !0
        }, function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (let f = 0; f < b.length; f++) Rj(a, b[f], c, d, e)
        }),
        I = new mj(Rj, Ji),
        rk = Gj(function(a, b, c) {
            b = Af(b);
            b != null && b != null && (Ai(a, c, 0), ui(a.g, b))
        }, Ni),
        sk = Gj(Sj, hj),
        tk = Hj(function(a, b, c) {
            b = Ej(yf, b, !0);
            if (b != null && b.length) {
                c = Bi(a, c);
                for (let d =
                        0; d < b.length; d++) vi(a.g, b[d]);
                Ci(a, c)
            }
        }, hj),
        uk = Gj(Sj, hj);

    function vk(a) {
        return () => {
            var b;
            (b = a[Ce]) || (b = new a, Me(b.aa), b = a[Ce] = b);
            return b
        }
    }

    function wk(a) {
        return b => Fj(b, a)
    }

    function xk(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(Pe(b))
            }
            return b
        }
    };
    ud `https://www.google.com/recaptcha/api2/aframe`;
    let yk = [];

    function zk() {
        const a = yk;
        yk = [];
        for (const b of a) try {
            b()
        } catch {}
    };

    function Ak(a, b) {
        return Math.min(Math.max(a, 0), b)
    }

    function Bk(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function Ck(a) {
        return Bk.apply(null, arguments) / arguments.length
    };

    function Dk(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    ba = Dk.prototype;
    ba.equals = function(a) {
        return a instanceof Dk && (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    };
    ba.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    ba.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    ba.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    ba.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function Ek(a, b) {
        this.width = a;
        this.height = b
    }

    function Fk(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    ba = Ek.prototype;
    ba.aspectRatio = function() {
        return this.width / this.height
    };
    ba.isEmpty = function() {
        return !(this.width * this.height)
    };
    ba.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    ba.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    ba.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    ba.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function Gk(a) {
        return a ? new Hk(Ik(a)) : Ga || (Ga = new Hk)
    }

    function Jk(a, b) {
        Ub(b, function(c, d) {
            d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : Kk.hasOwnProperty(d) ? a.setAttribute(Kk[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
        })
    }
    var Kk = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };

    function Lk(a) {
        a = a.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        return new Ek(a.clientWidth, a.clientHeight)
    }

    function Mk(a) {
        return a.scrollingElement ? a.scrollingElement : dd || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement
    }

    function Nk(a) {
        return a ? a.defaultView : window
    }

    function Ok(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function Pk(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    }

    function Ik(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    }
    var Qk = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        Rk = {
            IMG: " ",
            BR: "\n"
        };

    function Sk(a) {
        const b = [];
        Tk(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        a != " " && (a = a.replace(/^\s*/, ""));
        return a
    }

    function Tk(a, b, c) {
        if (!(a.nodeName in Qk))
            if (a.nodeType == 3) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in Rk) b.push(Rk[a.nodeName]);
        else
            for (a = a.firstChild; a;) Tk(a, b, c), a = a.nextSibling
    }

    function Uk(a, b, c) {
        if (!b && !c) return null;
        const d = b ? String(b).toUpperCase() : null;
        return Vk(a, function(e) {
            return (!d || e.nodeName == d) && (!c || typeof e.className === "string" && Pa(e.className.split(/\s+/), c))
        })
    }

    function Vk(a, b) {
        let c = 0;
        for (; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function Hk(a) {
        this.g = a || q.document || document
    }
    Hk.prototype.j = function(a) {
        var b = this.g;
        return typeof a === "string" ? b.getElementById(a) : a
    };
    Hk.prototype.l = Hk.prototype.j;

    function Wk(a, b) {
        return Ok(a.g, b)
    }

    function Xk(a, b) {
        var c = a.g;
        a = Ok(c, "DIV");
        Nc(a, b);
        if (a.childNodes.length == 1) b = a.removeChild(a.firstChild);
        else
            for (b = c.createDocumentFragment(); a.firstChild;) b.appendChild(a.firstChild);
        return b
    }
    Hk.prototype.xa = function() {
        return this.g.defaultView
    };
    Hk.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };

    function Yk(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    ba = Yk.prototype;
    ba.getWidth = function() {
        return this.right - this.left
    };
    ba.getHeight = function() {
        return this.bottom - this.top
    };

    function Zk(a) {
        return new Yk(a.top, a.right, a.bottom, a.left)
    }
    ba.contains = function(a) {
        return this && a ? a instanceof Yk ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };
    ba.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    ba.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    ba.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    ba.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function $k(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function al(a) {
        return new Yk(a.top, a.left + a.width, a.top + a.height, a.left)
    }

    function bl(a, b) {
        const c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            const e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new $k(c, e, d - c, a - e)
        }
        return null
    }
    ba = $k.prototype;
    ba.contains = function(a) {
        return a instanceof Dk ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    ba.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    ba.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    ba.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    ba.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.width *= a;
        this.top *= b;
        this.height *= b;
        return this
    };

    function cl(a, b, c) {
        if (typeof b === "string")(b = dl(a, b)) && (a.style[b] = c);
        else
            for (const e in b) {
                c = a;
                var d = b[e];
                const f = dl(c, e);
                f && (c.style[f] = d)
            }
    }
    var el = {};

    function dl(a, b) {
        let c = el[b];
        if (!c) {
            var d = Xc(b);
            c = d;
            a.style[d] === void 0 && (d = (dd ? "Webkit" : cd ? "Moz" : null) + $c(d), a.style[d] !== void 0 && (c = d));
            el[b] = c
        }
        return c
    }

    function fl(a, b) {
        const c = a.style[Xc(b)];
        return typeof c !== "undefined" ? c : a.style[dl(a, b)] || ""
    }

    function gl(a, b) {
        a: {
            var c = Ik(a);
            if (c.defaultView && c.defaultView.getComputedStyle && (c = c.defaultView.getComputedStyle(a, null))) {
                c = c[b] || c.getPropertyValue(b) || "";
                break a
            }
            c = ""
        }
        return c || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function hl(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function il(a) {
        const b = Ik(a);
        let c = gl(a, "position"),
            d = c == "fixed" || c == "absolute";
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (a.nodeType == 11 && a.host && (a = a.host), c = gl(a, "position"), d = d && c == "static" && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || c == "fixed" || c == "absolute" || c == "relative")) return a;
        return null
    }

    function jl(a) {
        var b = Ik(a);
        const c = new Dk(0, 0);
        if (a == (b ? Ik(b) : document).documentElement) return c;
        a = hl(a);
        var d = Gk(b).g;
        b = Mk(d);
        d = d.defaultView;
        b = new Dk(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function kl(a) {
        typeof a == "number" && (a = Math.round(a) + "px");
        return a
    }

    function ll(a) {
        var b = ml;
        if (gl(a, "display") != "none") return b(a);
        const c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function ml(a) {
        const b = a.offsetWidth,
            c = a.offsetHeight,
            d = dd && !b && !c;
        return (b === void 0 || d) && a.getBoundingClientRect ? (a = hl(a), new Ek(a.right - a.left, a.bottom - a.top)) : new Ek(b, c)
    };
    var nl = {
            passive: !0
        },
        ol = zb(() => {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                q.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function pl(a) {
        return a ? a.passive && ol() ? a : a.capture || !1 : !1
    }

    function ql(a, b, c, d) {
        return typeof a.addEventListener === "function" ? (a.addEventListener(b, c, pl(d)), !0) : !1
    }

    function rl(a, b, c, d) {
        return typeof a.removeEventListener === "function" ? (a.removeEventListener(b, c, pl(d)), !0) : !1
    }

    function sl(a, b) {
        a.document.readyState === "complete" ? (yk.push(b), yk.length === 1 && (window.Promise ? Promise.resolve().then(zk) : (a = window.setImmediate, typeof a === "function" ? a(zk) : setTimeout(zk, 0)))) : a.addEventListener("load", b)
    };

    function tl(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            const f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            Lc(f, a);
            b.document.readyState !== "complete" ? ql(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };

    function ul() {
        vl || (vl = new wl);
        return vl
    }
    async function xl() {
        try {
            await window.android.webview.getExperimentalMediaIntegrityTokenProvider({
                cloudProjectNumber: 187810013193
            })
        } catch (a) {
            a.mediaIntegrityErrorName || a.code && a.code()
        }
    }
    var wl = class {
            constructor() {
                this.Fb = !1
            }
            j() {
                return window.android && window.android.webview && window.android.webview.getExperimentalMediaIntegrityTokenProvider
            }
        },
        vl;
    async function yl(a) {
        var b = `${a.Sb?"https://ep1.adtrafficquality.google/getconfig/sodar":"https://pagead2.googlesyndication.com/getconfig/sodar"}?sv=${200}&tid=${a.g}` + `&tv=${a.j}&st=` + `${a.Kd}` + `${a.l?"&sde=1":""}`,
            c = void 0;
        try {
            c = await zl(b)
        } catch (g) {}
        if (c) {
            b = a.he || c.sodar_query_id;
            var d = c.rc_enable !== void 0 && a.B ? c.rc_enable : "n",
                e = c.bg_snapshot_delay_ms === void 0 ? "0" : c.bg_snapshot_delay_ms,
                f = c.is_gen_204 === void 0 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename && c.bg_binary) return c = {
                context: a.A,
                Jk: c.bg_hash_basename,
                Ik: c.bg_binary,
                im: a.g + "_" + a.j,
                he: b,
                Kd: a.Kd,
                pf: d,
                Uf: e,
                mf: f,
                Sb: a.Sb
            }, a.Fb ? { ...c,
                Fb: !0
            } : c
        }
    }
    let zl = a => new Promise((b, c) => {
        const d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (d.status >= 200 && d.status < 300 ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function Al(a) {
        if (a.Fb) {
            ul().Fb = !0;
            var b = ul();
            b.j() && b.Fb && xl()
        }
        if (a = await yl(a)) {
            b = window;
            var c = b.GoogleGcLKhOms;
            c && typeof c.push === "function" || (c = b.GoogleGcLKhOms = []);
            const d = {
                _ctx_: a.context,
                _bgv_: a.Jk,
                _bgp_: a.Ik,
                _li_: a.im,
                _jk_: a.he,
                _st_: a.Kd,
                _rc_: a.pf,
                _dl_: a.Uf,
                _g2_: a.mf,
                _atqg_: a.Sb === void 0 ? "0" : a.Sb ? "1" : "0"
            };
            a.Fb ? c.push({ ...d,
                _wvp_: "1"
            }) : c.push(d);
            if (c = b.GoogleDX5YKUSk) b.GoogleDX5YKUSk = void 0, c[1]();
            a = a.Sb ? ud `https://ep2.adtrafficquality.google/sodar/${"sodar2"}.js` : ud `https://tpc.googlesyndication.com/sodar/${"sodar2"}.js`;
            tl(a)
        }
    };
    var Bl = class extends H {
        g() {
            return C(this, 1)
        }
    };
    var Cl = class extends H {};

    function Dl(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            case 8:
                return "afs";
            default:
                return "unk"
        }
    }
    var El = class {
            constructor(a) {
                this.g = a.l;
                this.j = a.B;
                this.A = a.A;
                this.he = a.he;
                this.C = a.xa();
                this.Kd = a.Kd;
                this.pf = a.pf;
                this.Uf = a.Uf;
                this.mf = a.mf;
                this.B = a.j;
                this.Sb = a.Sb;
                this.Fb = a.Fb;
                this.l = a.g
            }
        },
        Fl = class {
            constructor(a, b, c) {
                this.l = a;
                this.B = b;
                this.A = c;
                this.C = window;
                this.Kd = "env";
                this.pf = "n";
                this.Uf = "0";
                this.mf = "1";
                this.j = !0;
                this.g = this.Fb = this.Sb = !1
            }
            xa() {
                return this.C
            }
            build() {
                return new El(this)
            }
        };
    var Gl = class extends H {
            Wa() {
                return C(this, 1)
            }
        },
        ki = [2, 3, 5];

    function Hl() {
        var a = new Il;
        return fi(a, 1, "")
    }

    function Jl(a) {
        return Gh(a, Gl, 2, ph())
    }

    function Kl(a, b) {
        return Ih(a, 2, b)
    }
    var Il = class extends H {};
    var Ll = class extends H {};

    function Ml(a) {
        var b = new Nl;
        return fi(b, 1, a)
    }
    var Nl = class extends H {
        getValue() {
            return C(this, 1)
        }
        getVersion() {
            return D(this, 5)
        }
    };
    var Ol = class extends H {};

    function Pl(a) {
        var b = new im;
        return hi(b, 1, a)
    }
    var im = class extends H {};

    function jm(a) {
        var b = new km;
        return fi(b, 1, a)
    }

    function lm(a) {
        var b = window.Date.now();
        b = Number.isFinite(b) ? Math.round(b) : 0;
        return ci(a, 3, b)
    }
    var km = class extends H {
            Wa() {
                return Yh(this, 1)
            }
            g() {
                return ii(this, 2)
            }
            j() {
                return $f(w(this, 2))
            }
            setError(a) {
                return y(this, 10, a)
            }
        },
        mm = xk(km);
    var nm = class extends H {};
    nm.prototype.g = function(a) {
        return function() {
            return Fj(this, a)
        }
    }([0, qk, [0, 1, [0, ck, -2], -1, mk, -1, jk, [0, 3, sk, mk], Yj, tk, rk], qk, [0, mk, -1, Yj, fk, -2, Yj, Vj, jk, [0, sk], jk]]);
    var om = class extends H {};

    function pm(a, b, c = null, d = !1, e = !1) {
        qm(a, b, c, d, e)
    }

    function qm(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Cd("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                d && Ta(a.google_image_requests, f);
                rl(f, "load", g);
                rl(f, "error", g)
            };
            ql(f, "load", g);
            ql(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function rm(a, b) {
        let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
        Fd(a, (d, e) => {
            if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`
        });
        sm(c)
    }

    function sm(a) {
        var b = window;
        b.fetch ? b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : pm(b, a, void 0, !1, !1)
    };
    let tm = null;
    var um = window;
    var vm = class extends H {};
    var wm = class extends H {
        getCorrelator() {
            return Qh(this, 1)
        }
        setCorrelator(a) {
            return di(this, 1, a)
        }
    };
    var xm = class extends H {};
    let ym = null,
        zm = null;

    function Am() {
        if (ym != null) return ym;
        ym = !1;
        try {
            const a = Ad(q);
            a && a.location.hash.indexOf("google_logging") !== -1 && (ym = !0)
        } catch (a) {}
        return ym
    }

    function Bm() {
        if (zm != null) return zm;
        zm = !1;
        try {
            const a = Ad(q);
            a && a.location.hash.indexOf("auto_ads_logging") !== -1 && (zm = !0)
        } catch (a) {}
        return zm
    }
    var Cm = (a, b = []) => {
        let c = !1;
        q.google_logging_queue || (c = !0, q.google_logging_queue = []);
        q.google_logging_queue.push([a, b]);
        c && Am() && Bd(q.document, ud `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };
    const Dm = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function Em(a = q) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function Fm(a = Em()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function Gm(a = Em()) {
        if (a && a.container) {
            a = a.container.split(",");
            const b = [];
            for (let c = 0; c < a.length; c++) b.push(Dm[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function Hm() {
        var a = Em();
        return a && a.initialIntersection
    }

    function Tm() {
        const a = Hm();
        return a && a.rootBounds && sa(a.rootBounds) ? new Ek(a.rootBounds.width, a.rootBounds.height) : null
    }

    function Um(a = Em()) {
        return a ? xd(a.master) ? a.master : null : null
    }

    function Vm(a, b) {
        const c = a.ampInaboxIframes = a.ampInaboxIframes || [];
        let d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            Ta(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        const f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = g.data === "amp-ini-load";
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized ||
                    g && !/^\d{15,20}$/.test(g) || a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || Bd(a.document, g ? ud `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : ud `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, ql(a, "message", f), d = () => {
            rl(a, "message", f)
        });
        return e
    };

    function Wm(a, b) {
        a = Xm(a);
        if (!a) return b;
        const c = b.slice(-1);
        return b + (c === "?" || c === "#" ? "" : "&") + a
    }

    function Xm(a) {
        const b = {};
        Fd(a, (c, d) => {
            if (c || c === 0 || c === !1) typeof c === "boolean" && (c = c ? 1 : 0), b[d] = c
        });
        return Object.entries(b).map(([c, d]) => `${c}=${encodeURIComponent(String(d))}`).join("&")
    };
    var Ym = a => {
            a = a.google_unique_id;
            return typeof a === "number" ? a : 0
        },
        Zm = a => (a = a.google_ad_format) ? a.indexOf("_0ads") > 0 : !1,
        $m = a => {
            let b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(b > 0 && c > 0)) {
                a: {
                    try {
                        const e = String(a.google_ad_format);
                        if (e && e.match) {
                            const f = e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                const g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (g > 0 && h > 0) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = b > 0 ? b : a.width;c = c > 0 ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        },
        an = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };
    var bn = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function cn(a) {
        return new bn(a, {
            message: dn(a)
        })
    }

    function dn(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        a.stack && (b = en(a.stack, b));
        return b
    }

    function en(a, b) {
        try {
            a.indexOf(b) == -1 && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    };
    const fn = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var gn = class {
            constructor(a, b) {
                this.g = a;
                this.j = b
            }
        },
        hn = class {
            constructor(a, b, c) {
                this.url = a;
                this.C = b;
                this.g = !!c;
                this.depth = null
            }
        };
    let jn = null;

    function kn() {
        var a = window;
        if (jn === null) {
            jn = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    const c = b.match(/\bdeid=([\d,]+)/);
                    jn = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return jn
    };

    function ln() {
        const a = q.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function mn() {
        const a = q.performance;
        return a && a.now ? a.now() : null
    };
    var nn = class {
        constructor(a, b) {
            var c = mn() || ln();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const on = q.performance,
        pn = !!(on && on.mark && on.measure && on.clearMarks),
        qn = zb(() => {
            var a;
            if (a = pn) a = kn(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function rn(a) {
        a && on && qn() && (on.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), on.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function sn(a) {
        a.g = !1;
        a.j !== a.l.google_js_reporting_queue && (qn() && Ja(a.j, rn), a.j.length = 0)
    }
    var tn = class {
        constructor(a) {
            this.j = [];
            this.l = a || q;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.j = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = qn() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new nn(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            on && qn() && on.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (mn() || ln()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                on && qn() && on.mark(b);
                !this.g || this.j.length >
                    2048 || this.j.push(a)
            }
        }
    };

    function un(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function vn(a, b, c, d, e) {
        const f = [];
        Fd(a, (g, h) => {
            (g = wn(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function wn(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(wn(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(vn(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function xn(a) {
        let b = 1;
        for (const c in a.j) c.length > b && (b = c.length);
        return 3997 - b - a.l.length - 1
    }

    function yn(a, b, c, d) {
        b = b + "//" + c + d;
        let e = xn(a) - d.length;
        if (e < 0) return "";
        a.g.sort((f, g) => f - g);
        d = null;
        c = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.j[g];
            for (let k = 0; k < h.length; k++) {
                if (!e) {
                    d = d == null ? g : d;
                    break
                }
                let l = vn(h[k], a.l, ",$");
                if (l) {
                    l = c + l;
                    if (e >= l.length) {
                        e -= l.length;
                        b += l;
                        c = a.l;
                        break
                    }
                    d = d == null ? g : d
                }
            }
        }
        a = "";
        d != null && (a = `${c}${"trn"}=${d}`);
        return b + a
    }
    var zn = class {
        constructor() {
            this.l = "&";
            this.j = {};
            this.B = 0;
            this.g = []
        }
    };
    var An = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Bn(a, b, c) {
        c = c != null ? "=" + encodeURIComponent(String(c)) : "";
        if (b += c) {
            c = a.indexOf("#");
            c < 0 && (c = a.length);
            let d = a.indexOf("?"),
                e;
            d < 0 || d > c ? (d = c, e = "") : e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            a = a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        }
        return a
    }
    var Cn = /#|$/;

    function Dn(a, b) {
        const c = a.search(Cn);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };
    var Gn = class {
        constructor(a = null) {
            this.L = En;
            this.j = a;
            this.g = null;
            this.B = !1;
            this.na = this.pa
        }
        l(a) {
            this.g = a
        }
        A(a) {
            this.B = a
        }
        kc(a, b, c) {
            let d, e;
            try {
                this.j && this.j.g ? (e = this.j.start(a.toString(), 3), d = b(), this.j.end(e)) : d = b()
            } catch (f) {
                b = !0;
                try {
                    rn(e), b = this.na(a, cn(f), void 0, c)
                } catch (g) {
                    this.pa(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        lc(a, b, c, d) {
            return (...e) => this.kc(a, () => b.apply(c, e), d)
        }
        pa(a, b, c, d, e) {
            e = e || "jserror";
            let f = void 0;
            try {
                const N = new zn;
                var g = N;
                g.g.push(1);
                g.j[1] = un("context",
                    a);
                b.error && b.meta && b.id || (b = cn(b));
                g = b;
                if (g.msg) {
                    b = N;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.j[2] = un("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.g) try {
                    this.g(h)
                } catch (za) {}
                if (d) try {
                    d(h)
                } catch (za) {}
                d = N;
                k = [k];
                d.g.push(3);
                d.j[3] = k;
                var l;
                if (!(l = p)) {
                    d = q;
                    k = [];
                    h = null;
                    do {
                        var m = d;
                        if (xd(m)) {
                            var n = m.location.href;
                            h = m.document && m.document.referrer || null
                        } else n = h, h = null;
                        k.push(new hn(n || "", m));
                        try {
                            d = m.parent
                        } catch (za) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let za = 0, Ha = k.length - 1; za <= Ha; ++za) k[za].depth = Ha - za;
                    m = q;
                    if (m.location &&
                        m.location.ancestorOrigins && m.location.ancestorOrigins.length === k.length - 1)
                        for (n = 1; n < k.length; ++n) {
                            const za = k[n];
                            za.url || (za.url = m.location.ancestorOrigins[n - 1] || "", za.g = !0)
                        }
                    l = k
                }
                var p = l;
                let aa = new hn(q.location.href, q, !1);
                l = null;
                const Ya = p.length - 1;
                for (m = Ya; m >= 0; --m) {
                    var t = p[m];
                    !l && fn.test(t.url) && (l = t);
                    if (t.url && !t.g) {
                        aa = t;
                        break
                    }
                }
                t = null;
                const Sb = p.length && p[Ya].url;
                aa.depth !== 0 && Sb && (t = p[Ya]);
                f = new gn(aa, t);
                if (f.j) {
                    p = N;
                    var u = f.j.url || "";
                    p.g.push(4);
                    p.j[4] = un("top", u)
                }
                var B = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    const za =
                        f.g.url.match(An);
                    var F = za[1],
                        R = za[3],
                        da = za[4];
                    u = "";
                    F && (u += F + ":");
                    R && (u += "//", u += R, da && (u += ":" + da));
                    var J = u
                } else J = "";
                F = N;
                B = [B, {
                    url: J
                }];
                F.g.push(5);
                F.j[5] = B;
                Fn(this.L, e, N, this.B, c)
            } catch (N) {
                try {
                    Fn(this.L, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: dn(N),
                        url: f ? .g.url ? ? ""
                    }, this.B, c)
                } catch (aa) {}
            }
            return !0
        }
        Oa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.pa(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var Hn = class extends H {};
    var In = wk([0, uk, ok]);

    function Jn(a, b) {
        try {
            const c = d => [{
                [d.Qb]: d.yf
            }];
            return JSON.stringify([a.filter(d => d.wb).map(c), rg(b), a.filter(d => !d.wb).map(c)])
        } catch (c) {
            return Kn(c, b), ""
        }
    }

    function Ln(a, b) {
        const c = new Hi;
        try {
            const d = a.filter(f => f.wb).map(Mn);
            Fi(c, 1, d);
            Ei(c, 2, In(b), Gi);
            const e = a.filter(f => !f.wb).map(Mn);
            Fi(c, 3, e)
        } catch (d) {
            Kn(d, b)
        }
        return Di(c)
    }

    function Kn(a, b) {
        try {
            rm({
                m: dn(a instanceof Error ? a : Error(String(a))),
                b: D(b, 1) || null,
                v: C(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }

    function Mn(a) {
        const b = new Hi;
        Ei(b, a.Qb, a.Rf, Gi);
        return Di(b)
    }

    function Gi(a, b) {
        zi(b, a.subarray(0, a.length))
    }
    var Nn = class {
        constructor(a, b) {
            var c = new Hn;
            a = G(c, 1, a);
            b = gi(a, 2, b);
            this.j = bh(b)
        }
    };

    function On(a) {
        return Math.round(a)
    };

    function Pn(a, b) {
        return Ah(a, 1, Qn, Zf(b))
    }

    function Rn(a, b) {
        return Ah(a, 2, Qn, Lf(b))
    }

    function Sn(a, b) {
        return Ah(a, 3, Qn, b == null ? b : rf(b))
    }
    var K = class extends H {},
        Qn = [1, 2, 3];

    function Tn(a, b) {
        return Ah(a, 2, Un, Lf(b))
    }

    function Vn(a, b) {
        return Ah(a, 4, Un, pf(b))
    }
    var Wn = class extends H {},
        Un = [2, 4];

    function Xn(a) {
        var b = new Yn;
        return gi(b, 1, a)
    }

    function Zn(a, b) {
        return y(a, 3, b)
    }

    function L(a, b) {
        return Kh(a, 4, K, b)
    }
    var Yn = class extends H {};
    var $n = wk([0, ok, 1, [0, Un, 1, bk, 1, Uj], qk, [0, Qn, pk, bk, lk]]);
    var ao = class extends H {
        j() {
            return C(this, 2)
        }
        getWidth() {
            return C(this, 3)
        }
        getHeight() {
            return C(this, 4)
        }
    };
    var bo = class extends H {};
    var co = class extends H {};
    var eo = class extends H {};
    var fo = class extends H {},
        go = [5, 6];
    var ho = [0, Yj, -1];
    var io = [0, qk, [0, tk, [0, fk, -3]], ho, -1];
    var jo = class extends H {
        getValue() {
            return D(this, 1)
        }
    };

    function ko(a) {
        var b = new lo;
        return hi(b, 1, a)
    }
    var lo = class extends H {
        getValue() {
            return D(this, 1)
        }
    };
    var mo = class extends H {
        getValue() {
            return D(this, 1)
        }
    };
    var no = class extends H {
        getHeight() {
            return Ph(this, 2)
        }
    };

    function oo(a, b) {
        return bi(a, 1, b)
    }

    function po(a, b) {
        return Ih(a, 2, b)
    }
    var qo = class extends H {};
    var ro = class extends H {};
    var so = class extends H {};
    var uo = class extends H {
            setError(a) {
                return z(this, 3, to, a)
            }
        },
        to = [2, 3];

    function vo(a, b) {
        return di(a, 1, b)
    }

    function wo(a, b) {
        return di(a, 2, b)
    }

    function xo(a, b) {
        return di(a, 3, b)
    }

    function yo(a, b) {
        return di(a, 4, b)
    }

    function zo(a, b) {
        return di(a, 5, b)
    }

    function Ao(a, b) {
        return zh(a, 8, pf(b), 0)
    }

    function Bo(a, b) {
        return zh(a, 9, pf(b), 0)
    }
    var Co = class extends H {};

    function Do(a, b) {
        return di(a, 1, b)
    }

    function Eo(a, b) {
        return di(a, 2, b)
    }
    var Fo = class extends H {};

    function Go(a, b) {
        Kh(a, 1, Fo, b)
    }
    var xh = class extends H {};
    var Ho = class extends H {};

    function Io(a, b) {
        return yh(a, 1, b, Yf)
    }

    function Jo(a, b) {
        return yh(a, 12, b, Uf)
    }

    function Ko() {
        var a = new Lo;
        return Jh(a, 2, Yf, "irr", $f)
    }

    function Mo(a, b) {
        return ai(a, 3, b)
    }

    function No(a, b) {
        return ai(a, 4, b)
    }

    function Oo(a, b) {
        return ai(a, 5, b)
    }

    function Po(a, b) {
        return ai(a, 7, b)
    }

    function Qo(a, b) {
        return ai(a, 8, b)
    }

    function Ro(a, b) {
        return di(a, 9, b)
    }

    function So(a, b) {
        return Ih(a, 10, b)
    }

    function To(a, b) {
        return yh(a, 11, b, Bf)
    }
    var Lo = class extends H {};

    function Uo(a) {
        var b = Vo();
        y(a, 1, b)
    }

    function Wo(a, b) {
        return di(a, 2, b)
    }

    function Xo(a, b) {
        return Ih(a, 3, b)
    }

    function Yo(a, b) {
        return Ih(a, 4, b)
    }

    function Zo(a, b) {
        return Kh(a, 4, lo, b)
    }

    function $o(a, b) {
        return Ih(a, 5, b)
    }

    function ap(a, b) {
        return yh(a, 6, b, Yf)
    }

    function bp(a, b) {
        return di(a, 7, b)
    }

    function cp(a, b) {
        return di(a, 8, b)
    }

    function dp(a, b) {
        y(a, 9, b)
    }

    function ep(a, b) {
        return ai(a, 10, b)
    }

    function fp(a, b) {
        return ai(a, 11, b)
    }

    function gp(a, b) {
        return ai(a, 12, b)
    }
    var hp = class extends H {};
    var ip = class extends H {};

    function jp(a, b) {
        return fi(a, 1, b)
    }

    function kp(a, b) {
        return fi(a, 2, b)
    }
    var lp = class extends H {};
    var mp = class extends H {};

    function np(a) {
        var b = new op;
        return G(b, 1, a)
    }
    var op = class extends H {};
    var pp = class extends H {};
    var qp = class extends H {};
    var rp = class extends H {};
    var sp = class extends H {},
        tp = [1, 2];
    var up = class extends H {};
    var vp = class extends H {},
        wp = [1];

    function xp(a) {
        var b = new yp;
        return G(b, 1, a)
    }
    var yp = class extends H {};
    var zp = class extends H {};
    var Ap = class extends H {};
    var Bp = class extends H {};
    var Cp = class extends H {};
    var Dp = class extends H {};
    var Ep = class extends H {};
    var Fp = class extends H {};
    var Gp = class extends H {
        getContentUrl() {
            return C(this, 1)
        }
    };
    var Hp = class extends H {};

    function Ip(a) {
        var b = new Jp;
        return yh(b, 1, a, vf)
    }
    var Jp = class extends H {};
    var Kp = class extends H {};

    function Lp() {
        var a = new Mp,
            b = new Kp;
        return z(a, 1, Np, b)
    }

    function Op() {
        var a = new Mp,
            b = new Kp;
        return z(a, 9, Np, b)
    }

    function Pp() {
        var a = new Mp,
            b = new Kp;
        return z(a, 13, Np, b)
    }

    function Qp(a, b) {
        return z(a, 14, Np, b)
    }
    var Mp = class extends H {},
        Np = [1, 2, 3, 9, 11, 12, 13, 14];
    var Rp = class extends H {};

    function Sp(a, b) {
        return gi(a, 1, b)
    }
    var Tp = class extends H {};
    var Up = class extends H {};
    var Vp = class extends H {};

    function Wp(a, b) {
        return ei(a, 10, b)
    }

    function Xp(a, b) {
        return G(a, 1, b)
    }

    function Yp(a, b) {
        return gi(a, 4, b)
    }
    var Zp = class extends H {};
    var $p = class extends H {};
    var aq = class extends H {};
    var cq = class extends H {
            j() {
                return Vh(this, $p, 4, bq)
            }
            g() {
                return mh(this, $p, 4, bq)
            }
        },
        bq = [4, 5];

    function dq(a) {
        var b = new eq;
        return gi(b, 4, a)
    }

    function fq(a, b) {
        return ih(a, 6, Vf(b))
    }
    var eq = class extends H {};
    var gq = class extends H {};
    var hq = class extends H {
        j() {
            return x(this, gq, 2)
        }
    };
    var iq = class extends H {},
        jq = [1];
    var kq = class extends H {};
    var lq = class extends H {
        j() {
            return x(this, $p, 1)
        }
        g() {
            return kh(this, $p, 1)
        }
    };
    var mq = class extends H {};
    var nq = class extends H {};
    var oq = class extends H {};
    var pq = class extends H {};
    var qq = class extends H {},
        rq = [2, 3];
    var sq = class extends H {},
        tq = [3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 16, 17, 19, 20, 21];

    function uq(a, b) {
        return di(a, 3, b)
    }
    var vq = class extends H {},
        wq = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];
    var xq = [0];
    var yq = [0, ok, nk];
    var zq = [0, 1, qk, [0, uk, ok, -2, hk, -2, [0, ok, 2, hk, -1, ok, [0, hk, -2, Wj], -1], qk, yq, ek, 1, fk]];
    var Aq = [0, Yj, -1];
    var Bq = wk([0, wq, ak, ok, ak, I, [0, ho, -1, [0, sk], ok, kk], I, [0, [0, nk, -1, kk, -5, ak, qk, [0, ok, ak, kk, -1], Zj, dk, ek], ak, qk, [0, sk], qk, [0, sk], qk, [0, sk], nk, ak, -1, [0, ak, -4, 2, Tj, -1], kk, -2, 1, Ij, [!0, mk, [0, qk, [0, ak, -1]]], qk, [0, ok, -2],
        [0, to, 1, I, [0, fk, -2, jk, qk, [0, fk, qk, [0, fk, -1]]], I, [0, sk, -1]]
    ], I, [0, tq, ak, -1, I, [0, bq, [0, ok, -1, kk],
            [0, 1, ok, -1], ak, I, zq, I, [0, qk, [0, Np, I, xq, -2, 5, I, xq, 1, I, xq, -2, I, [0, tk]]],
            [0, fk, -1, rk, -2, fk, -1]
        ], I, [0, 1, ek], I, [0, ak], I, [0, 1, ck, 1, ok], I, [0, ak], I, [0, 1, Yj, -1, ok, 1, ck, Yj, -1], I, [0, rq, ak, I, [0], I, [0]],
        [0, 1,
            hk, Zj
        ], I, [0, uk], I, [0, 1, ok, ek], 1, I, [0, zq, ak], jk, I, [0, ek], I, [0, ak], uk, I, [0, jq, I, [0, ek, [0, hk, -5], yq, -1]], I, [0, ek], I, [0, ak]
    ], ak, I, [0, ok, [0, hk, -1, [0, Tj, -5, kk]], ak, io], I, [0, uk, gk], I, [0, uk, -1, ok, -1], I, [0, wp, I, [0, jk, -1]], I, [0, uk, kk, -9], I, [0, tp, I, [0, [0, uk, ok, -1]], I, [0, hk, -1, ok, [0, hk, -1], -1, kk, tk, hk, -1]], I, [0, [1, 2, 3, 4], I, [0, [0, Yj, -1], Aq, jk, mk], I, [0], I, [0, Aq], I, [0]], I, [0, [3, 4, 5, 6, 7, 8], Yj, [0, Xj], I, [0], I, [0], I, [0], I, [0], I, [0], I, [0, [1, 2, 3, 4, 5], I, [0], -4]], I, [0, go, Yj, -2, [0, mk, -2, jk, [0, mk, -3]], I, [0], I, [0]], I, io, I, [0, mk, -2, Yj], I, [0, mk, -1]]);

    function Cq(a, b) {
        return di(a, 1, b)
    }

    function Dq(a, b) {
        return di(a, 2, b)
    }

    function Eq(a) {
        return G(a, 3, 6)
    }
    var Fq = class extends H {
        getTagSessionCorrelator() {
            return Qh(this, 1)
        }
    };
    var Gq = wk([0, ak, -1, uk]);
    var Hq = class extends H {};

    function Iq() {
        var a = ij(Jq());
        return gi(a, 1, Kq())
    }
    var Lq = class extends H {};
    var Mq = [0, [0, Yj, ik, -1], ok];
    var Nq = class extends H {};
    var Oq = class extends H {
        getTagSessionCorrelator() {
            return Qh(this, 1)
        }
    };
    var Pq = class extends H {},
        Qq = [1, 7],
        Rq = [4, 6, 8];
    var Sq = wk([0, Qq, Rq, I, [0, uk, ok, -1, nk, -1, Mq],
        [0, ak, gk, ok], 1, I, [0, ok, hk, nk], ak, I, [0, ok, -1, mk, [0, gk], 1, uk, ok, -1], I, [0, ok, -1, nk, -1, Mq], I, [0, [1], I, [0, [0, ok, -2, uk, ok]],
            [0, ak, -1]
        ]
    ]);
    class ur {
        constructor(a) {
            this.L = a;
            this.Wf = new vr(this.L)
        }
    }
    class vr {
        constructor(a) {
            this.L = a;
            this.He = new wr(this.L)
        }
    }
    class wr {
        constructor(a) {
            this.L = a;
            this.g = new xr(this.L);
            this.Qj = new yr(this.L)
        }
    }
    class xr {
        constructor(a) {
            this.L = a;
            this.j = new zr(this.L);
            this.g = new Ar(this.L)
        }
    }
    class zr {
        constructor(a) {
            this.L = a
        }
        se(a) {
            this.L.g(Zn(L(Xn("xR0Czf"), Pn(new K, a.status)), Vn(new Wn, a.we)))
        }
    }
    class Ar {
        constructor(a) {
            this.L = a
        }
        se(a) {
            this.L.g(Zn(L(Xn("jM4CPd"), Rn(new K, On(a.rn))), Vn(new Wn, a.we)))
        }
    }
    class yr {
        constructor(a) {
            this.L = a;
            this.sk = new Br(this.L);
            this.tk = new Cr(this.L);
            this.ng = new Dr(this.L);
            this.uk = new Er(this.L);
            this.vk = new Fr(this.L);
            this.wk = new Gr(this.L);
            this.xk = new Hr(this.L);
            this.pg = new Ir(this.L);
            this.Qk = new Jr(this.L);
            this.fl = new Kr(this.L);
            this.gl = new Lr(this.L);
            this.Bl = new Mr(this.L);
            this.Cl = new Nr(this.L);
            this.Km = new Or(this.L)
        }
    }
    class Br {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(Xn("VEDP7d"), Pn(new K, a.language)), Rn(new K, a.Ta)), Tn(new Wn, On(a.ka))))
        }
    }
    class Cr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(Xn("igjuhc"), Pn(new K, a.language)), Rn(new K, a.Ta)), Tn(new Wn, On(a.ka))))
        }
    }
    class Dr {
        constructor(a) {
            this.L = a
        }
        se(a) {
            this.L.g(Zn(L(L(L(L(L(Xn("i3zJEd"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.outcome)), Sn(new K, a.ge)), Sn(new K, a.bh)), Vn(new Wn, a.we)))
        }
    }
    class Er {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(L(L(Xn("JN0hVd"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.outcome)), Sn(new K, a.ge)), Sn(new K, a.bh)), Tn(new Wn, On(a.ka))))
        }
    }
    class Fr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("rmHfOd"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.reason)), Tn(new Wn, On(a.ka))))
        }
    }
    class Gr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("VEyQic"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.format)), Tn(new Wn, On(a.ka))))
        }
    }
    class Hr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("QFcNxc"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.format)), Tn(new Wn, On(a.ka))))
        }
    }
    class Ir {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(L(Xn("SIhp4"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.format)), Sn(new K, a.ge)), Tn(new Wn, On(a.ka))))
        }
    }
    class Jr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("Eeiun"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.format)), Tn(new Wn, On(a.ka))))
        }
    }
    class Kr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(Xn("zGH6sc"), Pn(new K, a.language)), Rn(new K, a.Ta)), Tn(new Wn, On(a.ka))))
        }
    }
    class Lr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("SmbJl"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.type)), Tn(new Wn, On(a.ka))))
        }
    }
    class Mr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("qleBg"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.format)), Tn(new Wn, On(a.ka))))
        }
    }
    class Nr {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(L(Xn("pVNWme"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.Rb)), Rn(new K, a.format)), Tn(new Wn, On(a.ka))))
        }
    }
    class Or {
        constructor(a) {
            this.L = a
        }
        jb(a) {
            this.L.g(Zn(L(L(L(Xn("pYLGPe"), Pn(new K, a.language)), Rn(new K, a.Ta)), Rn(new K, a.type)), Tn(new Wn, On(a.ka))))
        }
    }
    class Pr extends Nn {
        constructor() {
            super(...arguments);
            this.zf = new ur(this)
        }
    }
    var Qr = class extends Pr {
            Pj(...a) {
                this.A(...a.map(b => ({
                    wb: !0,
                    Qb: 3,
                    yf: rg(b)
                })))
            }
            oc(...a) {
                this.A(...a.map(b => ({
                    wb: !0,
                    Qb: 7,
                    yf: rg(b)
                })))
            }
            F(...a) {
                this.A(...a.map(b => ({
                    wb: !0,
                    Qb: 16,
                    yf: rg(b)
                })))
            }
            g(...a) {
                this.A(...a.map(b => ({
                    wb: !1,
                    Qb: 1,
                    yf: rg(b)
                })))
            }
        },
        Sr = class extends Pr {
            Pj(...a) {
                Rr(this, ...a.map(b => ({
                    wb: !0,
                    Qb: 3,
                    Rf: Sq(b)
                })))
            }
            oc(...a) {
                Rr(this, ...a.map(b => ({
                    wb: !0,
                    Qb: 7,
                    Rf: Bq(b)
                })))
            }
            F(...a) {
                Rr(this, ...a.map(b => ({
                    wb: !0,
                    Qb: 16,
                    Rf: Gq(b)
                })))
            }
            g(...a) {
                Rr(this, ...a.map(b => ({
                    wb: !1,
                    Qb: 1,
                    Rf: $n(b)
                })))
            }
        };

    function Tr(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    }
    var Ur = class extends Qr {
            constructor(a) {
                super(2, a);
                this.l = Tr
            }
            A(...a) {
                try {
                    const b = Jn(a, this.j);
                    this.l("https://pagead2.googlesyndication.com/pagead/ping?e=1", b)
                } catch (b) {
                    Kn(b, this.j)
                }
            }
        },
        Vr = class extends Ur {};

    function Wr(a) {
        a.B !== null && (clearTimeout(a.B), a.B = null);
        if (a.l.length) {
            var b = Jn(a.l, a.j);
            a.G("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.l = []
        }
    }
    var Yr = class extends Qr {
            constructor(a, b, c, d, e) {
                super(2, a);
                this.G = Tr;
                this.V = b;
                this.K = c;
                this.T = d;
                this.D = e;
                this.l = [];
                this.B = null;
                this.J = !1
            }
            A(...a) {
                try {
                    this.T && Jn(this.l.concat(a), this.j).length >= 65536 && Wr(this), this.D && !this.J && (this.J = !0, Xr(this.D, () => {
                        Wr(this)
                    })), this.l.push(...a), this.l.length >= this.K && Wr(this), this.l.length && this.B === null && (this.B = setTimeout(() => {
                        Wr(this)
                    }, this.V))
                } catch (b) {
                    Kn(b, this.j)
                }
            }
        },
        Zr = class extends Yr {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };
    var M = a => {
        var b = "Hc";
        if (a.Hc && a.hasOwnProperty(b)) return a.Hc;
        b = new a;
        return a.Hc = b
    };

    function $r(a, b, c) {
        return b[a] || c
    };

    function as(a, b) {
        a.j = (c, d) => $r(2, b, () => [])(c, 1, d);
        a.g = () => $r(3, b, () => [])(1)
    }
    class bs {
        j() {
            return []
        }
        g() {
            return []
        }
    }

    function cs(a, b) {
        return M(bs).j(a, b)
    };

    function Fn(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof zn ? f = c : (f = new zn, Fd(c, (h, k) => {
                var l = f;
                const m = l.B++;
                h = un(k, h);
                l.g.push(m);
                l.j[m] = h
            }));
            const g = yn(f, a.protocol, a.domain, a.path + b + "&");
            g && pm(q, g)
        } catch (f) {}
    }

    function ds(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    var es = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.protocol = "https:";
            this.g = Math.random()
        }
    };
    let En, fs;
    const gs = new tn(window);
    (function(a) {
        En = a ? ? new es;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        ds(En, window.google_srt);
        fs = new Gn(gs);
        fs.l(() => {});
        fs.A(!0);
        window.document.readyState === "complete" ? window.google_measure_js_timing || sn(gs) : gs.g && ql(window, "load", () => {
            window.google_measure_js_timing || sn(gs)
        })
    })();

    function hs(a) {
        fs.Oa(1085, a)
    };
    let is = (new Date).getTime();
    var js = {
        yp: 0,
        xp: 1,
        up: 2,
        mp: 3,
        vp: 4,
        np: 5,
        wp: 6,
        sp: 7,
        tp: 8,
        lp: 9,
        qp: 10,
        zp: 11
    };
    var ks = {
        Bp: 0,
        Cp: 1,
        Ap: 2
    };

    function ls(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function ms(a) {
        a = a.map(b => new Yk(b.top, b.right, b.bottom, b.left));
        a = ns(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function ns(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return a.slice(1).reduce((b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, Zk(a[0]))
    };
    var ac = {
        qq: 0,
        Zo: 1,
        cp: 2,
        ap: 3,
        bp: 4,
        jp: 8,
        Aq: 9,
        Op: 10,
        Pp: 11,
        yq: 16,
        To: 17,
        So: 24,
        Mp: 25,
        xo: 26,
        wo: 27,
        ik: 30,
        Fp: 32,
        Jp: 40,
        Fq: 41,
        Bq: 42
    };
    var os = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        ps = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var qs = 728 * 1.38;

    function rs(a, b = -1) {
        if (a !== a.top) {
            if (b < 0) a = !1;
            else {
                var c = ss(a, !0, !0),
                    d = ts(a, !0);
                a = c > 0 && d > 0 && Math.abs(1 - a.screen.width / c) <= b && Math.abs(1 - a.screen.height / d) <= b
            }
            a = a ? 0 : 512
        } else a = 0;
        return a
    }

    function us(a, b = 420, c = !1, d = !1) {
        return (a = ss(a, c, d)) ? a > b ? 32768 : a < 320 ? 65536 : 0 : 16384
    }

    function vs(a) {
        return Math.max(0, ws(a, !0) - ts(a))
    }

    function Ls(a) {
        a = a.document;
        let b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function ts(a, b = !1) {
        const c = Ls(a).clientHeight;
        return b ? c * (Qb() && Rb() ? ie(a) : 1) : c
    }

    function ss(a, b = !1, c = !1) {
        c = Ls(a).clientWidth ? ? (c ? a.innerWidth : void 0);
        return b ? c * (Qb() && Rb() ? ie(a) : 1) : c
    }

    function ws(a, b) {
        const c = Ls(a);
        return b ? (a = ts(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function Ms(a, b) {
        return Ns(b) || b === 10 || !a.adCount ? !1 : b === 1 || b === 2 ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? a >= 1 : !1
    }

    function Os(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function Ps(a) {
        return a.pageYOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function Qs(a) {
        return a.pageXOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function Rs(a) {
        const b = {};
        let c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                const d = c[a];
                if ("key" in d && "value" in d) {
                    const e = d.value;
                    b[d.key] = e == null ? null : String(e)
                }
            }
        return b
    }

    function Ss(a, b, c, d) {
        Fn(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function Ts(a) {
        const b = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        Ja(Object.keys(b), c => {
            fl(a, c) || cl(a, c, b[c])
        });
        Yd(a)
    }

    function Ns(a) {
        return a === 26 || a === 27 || a === 40 || a === 41
    };

    function Us(a, b) {
        Vs(a).forEach(b, void 0)
    }

    function Vs(a) {
        const b = [],
            c = a.length;
        for (let d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function Ws(a, b) {
        return a.g[Xs(b)] !== void 0
    }

    function Ys(a) {
        const b = [];
        for (const c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.j[c]);
        return b
    }

    function Zs(a) {
        const b = [];
        for (const c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    var $s = class {
        constructor() {
            this.g = {};
            this.j = {}
        }
        set(a, b) {
            const c = Xs(a);
            this.g[c] = b;
            this.j[c] = a
        }
        remove(a) {
            a = Xs(a);
            this.g[a] = void 0;
            this.j[a] = void 0
        }
        get(a, b) {
            a = Xs(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        ee() {
            return Ys(this).length
        }
        clear() {
            this.g = {};
            this.j = {}
        }
    };

    function Xs(a) {
        return a instanceof Object ? String(ta(a)) : a + ""
    };
    var at = class {
        constructor(a) {
            this.g = new $s;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        remove(a) {
            this.g.remove(a)
        }
        contains(a) {
            return Ws(this.g, a)
        }
    };
    const bt = new at("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function ct(a, {
        tc: b,
        dc: c,
        Zc: d
    }) {
        return d && c(b) ? b : (b = b.parentElement) ? dt(a, {
            tc: b,
            dc: c,
            Zc: !0
        }) : null
    }

    function dt(a, {
        tc: b,
        dc: c,
        Zc: d = !1
    }) {
        const e = et({
                tc: b,
                dc: c,
                Zc: d
            }),
            f = a.g.get(e);
        if (f) return f.element;
        b = ct(a, {
            tc: b,
            dc: c,
            Zc: d
        });
        a.g.set(e, {
            element: b
        });
        return b
    }
    var ft = class {
        constructor() {
            this.g = new Map
        }
    };

    function et({
        tc: a,
        dc: b,
        Zc: c
    }) {
        a = ta(a);
        b = ta(b);
        return `${a}:${b}:${c}`
    };

    function gt(a) {
        fc(a.document.body.offsetHeight)
    };

    function ht(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function O() {
        this.B = this.B;
        this.J = this.J
    }
    O.prototype.B = !1;
    O.prototype.dispose = function() {
        this.B || (this.B = !0, this.g())
    };
    O.prototype[ja(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function it(a, b) {
        jt(a, Ba(ht, b))
    }

    function jt(a, b) {
        a.B ? b() : (a.J || (a.J = []), a.J.push(b))
    }
    O.prototype.g = function() {
        if (this.J)
            for (; this.J.length;) this.J.shift()()
    };

    function kt(a) {
        a.j.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function lt(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.j.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.j.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var mt = class extends O {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.j = b
        }
        g() {
            kt(this);
            super.g()
        }
    };

    function nt(a) {
        const b = new P(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function ot(a, b) {
        const c = new P({
            first: a.X,
            second: b.X
        });
        a.listen(() => c.g({
            first: a.X,
            second: b.X
        }));
        b.listen(() => c.g({
            first: a.X,
            second: b.X
        }));
        return c
    }

    function pt(...a) {
        const b = [...a],
            c = () => b.every(f => f.X),
            d = new P(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return qt(d)
    }

    function rt(...a) {
        const b = [...a],
            c = () => b.findIndex(f => f.X) !== -1,
            d = new P(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return qt(d)
    }

    function qt(a, b = st) {
        var c = a.X;
        const d = new P(a.X);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function tt(a, b, c) {
        return a.j(d => {
            d === b && c()
        })
    }

    function ut(a, b, c) {
        if (a.X === b) return c(), () => {};
        const d = {
            Qd: null
        };
        d.Qd = tt(a, b, () => {
            d.Qd && (d.Qd(), d.Qd = null);
            c()
        });
        return d.Qd
    }

    function vt(a, b, c) {
        qt(a).listen(d => {
            d === b && c()
        })
    }

    function wt(a, b) {
        a.B && a.B();
        a.B = b.listen(c => a.g(c), !0)
    }

    function xt(a, b, c, d) {
        const e = new P(!1);
        var f = null;
        a = a.map(d);
        tt(a, !0, () => {
            f === null && (f = b.setTimeout(() => {
                e.g(!0)
            }, c))
        });
        tt(a, !1, () => {
            e.g(!1);
            f !== null && (b.clearTimeout(f), f = null)
        });
        return qt(e)
    }

    function yt(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.X
        }
    }
    var P = class {
        constructor(a) {
            this.X = a;
            this.l = new Map;
            this.D = 1;
            this.B = null
        }
        listen(a, b = !1) {
            const c = this.D++;
            this.l.set(c, a);
            b && a(this.X);
            return () => {
                this.l.delete(c)
            }
        }
        j(a) {
            return this.listen(a, !0)
        }
        A() {
            return this.X
        }
        g(a) {
            this.X = a;
            this.l.forEach(b => {
                b(this.X)
            })
        }
        map(a) {
            const b = new P(a(this.X));
            this.listen(c => b.g(a(c)));
            return b
        }
    };

    function st(a, b) {
        return a == b
    };

    function zt(a) {
        return new At(a)
    }

    function Bt(a, b) {
        Ja(a.g, c => {
            c(b)
        })
    }
    var Ct = class {
        constructor() {
            this.g = []
        }
    };
    class At {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            const b = new Ct;
            this.listen(c => Bt(b, a(c)));
            return zt(b)
        }
        delay(a, b) {
            const c = new Ct;
            this.listen(d => {
                a.setTimeout(() => {
                    Bt(c, d)
                }, b)
            });
            return zt(c)
        }
    }

    function Dt(...a) {
        const b = new Ct;
        a.forEach(c => {
            c.listen(d => {
                Bt(b, d)
            })
        });
        return zt(b)
    };

    function Et(a) {
        return qt(ot(a.g, a.l).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : Ft(c, b)
        }))
    }
    var Ht = class {
        constructor(a) {
            this.j = a;
            this.g = new P(null);
            this.l = new P(null);
            this.B = new Ct;
            this.J = b => {
                this.g.X == null && b.touches.length == 1 && this.g.g(b.touches[0])
            };
            this.A = b => {
                const c = this.g.X;
                c != null && (b = Gt(c, b.changedTouches), b != null && (this.g.g(null), this.l.g(null), Bt(this.B, Ft(c, b))))
            };
            this.D = b => {
                var c = this.g.X;
                c != null && (c = Gt(c, b.changedTouches), c != null && (this.l.g(c), b.preventDefault()))
            }
        }
    };

    function Ft(a, b) {
        return {
            ck: b.pageX - a.pageX,
            dk: b.pageY - a.pageY
        }
    }

    function Gt(a, b) {
        if (b == null) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function It(a) {
        return qt(ot(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : Jt(c, b)
        }))
    }
    var Kt = class {
        constructor(a, b) {
            this.B = a;
            this.A = b;
            this.g = new P(null);
            this.j = new P(null);
            this.l = new Ct;
            this.F = c => {
                this.g.g(c)
            };
            this.D = c => {
                const d = this.g.X;
                d != null && (this.g.g(null), this.j.g(null), Bt(this.l, Jt(d, c)))
            };
            this.J = c => {
                this.g.X != null && (this.j.g(c), c.preventDefault())
            }
        }
    };

    function Jt(a, b) {
        return {
            ck: b.screenX - a.screenX,
            dk: b.screenY - a.screenY
        }
    };
    var Nt = (a, b, c) => {
        const d = new Lt(a, b, c);
        return () => Mt(d)
    };

    function Mt(a) {
        if (a.g) return !1;
        if (a.j == null) return Ot(a), !0;
        const b = a.j + a.A - (new Date).getTime();
        if (b < 1) return Ot(a), !0;
        Pt(a, b);
        return !0
    }

    function Ot(a) {
        a.j = (new Date).getTime();
        a.B()
    }

    function Pt(a, b) {
        a.g = !0;
        a.l.setTimeout(() => {
            a.g = !1;
            Ot(a)
        }, b)
    }
    class Lt {
        constructor(a, b, c) {
            this.l = a;
            this.A = b;
            this.B = c;
            this.j = null;
            this.g = !1
        }
    };

    function Qt(a) {
        return Rt(It(a.g), Et(a.j))
    }

    function St(a) {
        return Dt(zt(a.g.l), zt(a.j.B))
    }
    var Tt = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };

    function Rt(a, b) {
        return ot(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };
    var Ut = class {
        constructor() {
            this.cache = new Map
        }
        getBoundingClientRect(a) {
            var b = this.cache.get(a);
            if (b) return b;
            b = a.getBoundingClientRect();
            this.cache.set(a, b);
            return b
        }
    };

    function Vt(a) {
        a.D == null && (a.D = new P(a.F.getBoundingClientRect()));
        return a.D
    }
    var Wt = class extends O {
        constructor(a, b) {
            super();
            this.l = a;
            this.F = b;
            this.G = !1;
            this.D = null;
            this.A = () => {
                Vt(this).g(this.F.getBoundingClientRect())
            }
        }
        j() {
            this.G || (this.G = !0, this.l.addEventListener("resize", this.A), this.l.addEventListener("scroll", this.A));
            return Vt(this)
        }
        g() {
            this.l.removeEventListener("resize", this.A);
            this.l.removeEventListener("scroll", this.A);
            super.g()
        }
    };

    function Xt(a, b) {
        return new Yt(a, b)
    }

    function Zt(a) {
        a.C.requestAnimationFrame(() => {
            a.B || a.l.g(new Ek(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function $t(a) {
        a.j || (a.j = !0, a.A.observe(a.element));
        return qt(a.l, Fk)
    }
    var Yt = class extends O {
        constructor(a, b) {
            super();
            this.C = a;
            this.element = b;
            this.j = !1;
            this.l = new P(new Ek(this.element.offsetWidth, this.element.offsetHeight));
            this.A = new ResizeObserver(() => {
                Zt(this)
            })
        }
        g() {
            this.A.disconnect();
            super.g()
        }
    };

    function au(a, b) {
        return {
            top: a.g - b,
            right: a.l + a.j,
            bottom: a.g + b,
            left: a.l
        }
    }
    var bu = class {
        constructor(a, b, c) {
            this.l = a;
            this.g = b;
            this.j = c
        }
    };

    function cu(a, b) {
        a = a.getBoundingClientRect();
        return new du(a.top + Ps(b), a.bottom - a.top)
    }

    function eu(a) {
        return new du(Math.round(a.g), Math.round(a.j))
    }
    var du = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
        getHeight() {
            return this.j
        }
    };
    var gu = (a, b) => {
        const c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new at(c);
        b = b.filter(e => !d.contains(e));
        b.length && (fu(a, b), Za(c, b))
    };

    function fu(a, b) {
        for (const d of b) {
            const e = Cd("LINK", a.document);
            e.type = "text/css";
            b = e;
            var c = ud `//fonts.googleapis.com/css?family=${d}`;
            b.href = rc(c).toString();
            b.rel = "stylesheet";
            a.document.head.appendChild(e)
        }
    };

    function hu(a, b) {
        a.G ? b(a.A) : a.l.push(b)
    }

    function iu(a, b) {
        a.G = !0;
        a.A = b;
        a.l.forEach(c => {
            c(a.A)
        });
        a.l = []
    }
    var ju = class extends O {
        constructor(a) {
            super();
            this.j = a;
            this.l = [];
            this.G = !1;
            this.F = this.A = null;
            this.K = Nt(a, 1E3, () => {
                if (this.F != null) {
                    var b = ws(this.j, !0) - this.F;
                    b > 1E3 && iu(this, b)
                }
            });
            this.D = null
        }
        init(a, b) {
            a == null ? (this.F = a = ws(this.j, !0), this.j.addEventListener("scroll", this.K), b != null && b(a)) : this.D = this.j.setTimeout(() => {
                this.init(void 0, b)
            }, a)
        }
        g() {
            this.D != null && this.j.clearTimeout(this.D);
            this.j.removeEventListener("scroll", this.K);
            this.l = [];
            this.A = null;
            super.g()
        }
    };
    var ku = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    var lu = class {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            const a = 48271 * this.g % 2147483647;
            this.g = a * 2147483647 < 0 ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function mu(a, b, c) {
        const d = [];
        for (const e of a.g) b(e) ? d.push(e) : c(e);
        return new nu(d)
    }

    function ou(a) {
        return a.g.slice(0)
    }

    function pu(a, b = 1) {
        a = ou(a);
        const c = new lu(b);
        cb(a, () => c.next());
        return new nu(a)
    }
    var nu = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new nu(La(this.g, a))
        }
        apply(a) {
            return new nu(a(ou(this)))
        }
        sort(a) {
            return new nu(ou(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = ou(this);
            b.push(a);
            return new nu(b)
        }
    };
    var qu = class {
        constructor(a) {
            this.g = new at(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function ru(a) {
        return new su({
            value: a
        }, null)
    }

    function tu(a) {
        return new su(null, a)
    }

    function uu(a) {
        try {
            return ru(a())
        } catch (b) {
            return tu(b)
        }
    }

    function vu(a) {
        return a.j != null
    }

    function wu(a) {
        return vu(a) ? a.getValue() : null
    }

    function xu(a, b) {
        vu(a) && b(a.getValue());
        return a
    }

    function yu(a, b) {
        return vu(a) ? a : tu(b(a.g))
    }

    function zu(a, b) {
        return yu(a, c => Error(`${b}${c.message}`))
    }

    function Au(a, b) {
        vu(a) || b(a.g);
        return a
    }
    var su = class {
        constructor(a, b) {
            this.j = a;
            this.g = b
        }
        getValue() {
            return this.j.value
        }
        map(a) {
            return vu(this) ? (a = a(this.getValue()), a instanceof su ? a : ru(a)) : this
        }
    };
    var Bu = class {
        constructor() {
            this.g = new $s
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new at, this.g.set(a, c));
            c.add(b)
        }
    };

    function Cu(a) {
        return !a
    }

    function Du(a) {
        return b => {
            for (const c of a) c(b)
        }
    };

    function Eu(a) {
        return a !== null
    };
    var Fu = class extends H {
        getId() {
            return Yh(this, 3)
        }
    };
    var Gu = class {
        constructor(a, {
            xi: b,
            qk: c,
            Sl: d,
            Ij: e
        }) {
            this.A = a;
            this.l = c;
            this.B = new nu(b || []);
            this.j = e;
            this.g = d
        }
    };

    function Hu(a) {
        const b = a.length;
        if (b === 0) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    var Iu = a => {
            var b = a.split("~").filter(c => c.length > 0);
            a = new $s;
            for (const c of b) b = c.indexOf("."), b == -1 ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        Ku = a => {
            var b = Ju(a);
            a = [];
            for (let c of b) b = String(c.Td), a.push(c.Rc + "." + (b.length <= 20 ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const Ju = a => {
            const b = [],
                c = a.B;
            c && c.g.length && b.push({
                Rc: "a",
                Td: Lu(c)
            });
            a.l != null && b.push({
                Rc: "as",
                Td: a.l
            });
            a.g != null && b.push({
                Rc: "i",
                Td: String(a.g)
            });
            a.j != null && b.push({
                Rc: "rp",
                Td: String(a.j)
            });
            b.sort(function(d, e) {
                return d.Rc.localeCompare(e.Rc)
            });
            b.unshift({
                Rc: "t",
                Td: Mu(a.A)
            });
            return b
        },
        Mu = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        Lu = a => {
            a = ou(a).map(Nu);
            a = JSON.stringify(a);
            return Hu(a)
        },
        Nu = a => {
            const b = {};
            ii(a, 7) && (b.q = Yh(a, 7));
            yf(w(a, 2)) != null &&
                (b.o = Xh(a, 2));
            yf(w(a, 5)) != null && (b.p = Xh(a, 5));
            return b
        };

    function Ou() {
        var a = new Pu;
        return hi(a, 2, 1)
    }
    var Pu = class extends H {
        setLocation(a) {
            return hi(this, 1, a)
        }
        g() {
            return wf(w(this, 1))
        }
    };

    function Qu(a) {
        const b = [].slice.call(arguments).filter(yb(e => e === null));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Gi || []);
            d = Object.assign(d, e.fe())
        });
        return new Ru(c, d)
    }

    function Su(a) {
        switch (a) {
            case 1:
                return new Ru(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Ru(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Ru(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Ru(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Tu(a) {
        return a == null ? null : new Ru(null, {
            google_ml_rank: a
        })
    }

    function Uu(a) {
        return a == null ? null : new Ru(null, {
            google_placement_id: Ku(a)
        })
    }

    function Vu({
        Yk: a,
        vl: b = null
    }) {
        if (a == null) return null;
        a = {
            google_daaos_ts: a
        };
        b != null && (a.google_erank = b + 1);
        return new Ru(null, a)
    }
    var Ru = class {
        constructor(a, b) {
            this.Gi = a;
            this.g = b
        }
        fe() {
            return this.g
        }
    };
    var Wu = class extends H {};
    var Xu = class extends H {};
    var Yu = class extends H {
        j() {
            return Yh(this, 2)
        }
        g() {
            return Yh(this, 5)
        }
        B() {
            return Gh(this, Xu, 3, ph())
        }
        D() {
            return yf(w(this, 4))
        }
        J() {
            return oh(this, 6)
        }
        F() {
            return kh(this, Wu, 7)
        }
    };
    var Zu = class extends H {};
    var $u = class extends H {
        B() {
            return A(this, 12)
        }
        j() {
            return Mh(this, 13)
        }
        g() {
            return Oh(this, 23)
        }
    };
    var av = class extends H {};

    function bv(a) {
        return oh(a, 1, gh)
    }
    var cv = class extends H {
        g() {
            return Zh(this, 3)
        }
        j() {
            return Wh(this, 6)
        }
    };
    var dv = class extends H {};
    var ev = class extends H {};
    var fv = class extends H {
        ua() {
            return x(this, Fu, 1)
        }
        j() {
            return Zh(this, 2)
        }
    };
    var gv = class extends H {};
    var hv = class extends H {};
    var iv = class extends H {
            getName() {
                return Yh(this, 4)
            }
        },
        jv = [1, 2, 3];
    var kv = class extends H {
        g() {
            return x(this, cv, 10)
        }
    };

    function lv(a) {
        return Wh(a, 1)
    }
    var mv = class extends H {
        g() {
            return Wh(this, 2)
        }
        j() {
            return Wh(this, 3)
        }
    };
    var nv = class extends H {
        g() {
            return Mh(this, 1, gh)
        }
    };
    var ov = class extends H {
        g() {
            return Qh(this, 1)
        }
    };
    var pv = class extends H {
        g() {
            return C(this, 1)
        }
        j() {
            return C(this, 2)
        }
    };
    var qv = class extends H {
        B() {
            return A(this, 1)
        }
        D() {
            return A(this, 3)
        }
        J() {
            return A(this, 7)
        }
        g() {
            return A(this, 4)
        }
        j() {
            return A(this, 5)
        }
    };
    var rv = class extends H {
        g() {
            return x(this, ov, 6)
        }
        B() {
            return A(this, 14)
        }
        j() {
            return x(this, qv, 12)
        }
    };
    var sv = class extends H {};
    var tv = class extends H {};
    var uv = class extends H {};
    var vv = class extends H {
        g() {
            return Gh(this, uv, 1, ph())
        }
    };
    var wv = class extends H {
        setProperty(a) {
            return fi(this, 1, a)
        }
        getValue() {
            return Yh(this, 2)
        }
    };
    var xv = class extends H {};
    var yv = class extends H {};
    var zv = class extends H {
        ua() {
            return x(this, Fu, 1)
        }
        j() {
            return Zh(this, 2)
        }
    };
    var Av = class extends H {},
        Bv = xk(Av);
    var Cv = class extends H {};
    var Dv = class extends H {
        g() {
            return Th(this, 6)
        }
    };
    var Ev = class extends H {
        eh() {
            return kh(this, Cv, 2)
        }
    };
    var Fv = class extends H {
        g() {
            return Qh(this, 1)
        }
    };
    var Gv = class extends H {};
    var Iv = class extends H {
            g() {
                return Vh(this, Gv, 2, Hv)
            }
        },
        Hv = [1, 2];
    var Jv = class extends H {
        g() {
            return x(this, Iv, 3)
        }
    };
    var Kv = class extends H {};
    var Lv = class extends H {
        g() {
            return Gh(this, Kv, 1, ph())
        }
    };
    var Mv = class extends H {
        g() {
            return Th(this, 1)
        }
        j() {
            return x(this, Jv, 3)
        }
    };
    var Nv = xk(class extends H {
        g() {
            return x(this, $u, 15)
        }
    });
    var Ov = class extends H {},
        Pv = xk(Ov);

    function Qv(a) {
        try {
            const b = a.localStorage.getItem("google_ama_settings");
            return b ? Pv(b) : null
        } catch (b) {
            return null
        }
    }

    function Rv(a, b) {
        if (a.Kg !== void 0) {
            var c = Qv(b);
            c || (c = new Ov);
            a.Kg !== void 0 && $h(c, 2, a.Kg);
            a = Date.now() + 864E5;
            Number.isFinite(a) && ci(c, 1, Math.round(a));
            c = jj(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else {
            if (c = a = Qv(b)) c = Qh(a, 1), c = BigInt(c) < Date.now();
            if (c) try {
                b.localStorage.removeItem("google_ama_settings")
            } catch (d) {}
        }
    };
    var Sv = {
            od: "ama_success",
            mc: .1,
            Gc: !0,
            ud: !0
        },
        Tv = {
            od: "ama_failure",
            mc: .1,
            Gc: !0,
            ud: !0
        },
        Uv = {
            od: "ama_coverage",
            mc: .1,
            Gc: !0,
            ud: !0
        },
        Vv = {
            od: "ama_opt",
            mc: .1,
            Gc: !0,
            ud: !1
        },
        Wv = {
            od: "ama_auto_rs",
            mc: 1,
            Gc: !0,
            ud: !1
        },
        Xv = {
            od: "ama_constraints",
            mc: 0,
            Gc: !0,
            ud: !0
        };

    function Yv(a) {
        if (a != null) return Zv(a)
    }

    function $v(a) {
        return a == null ? null : Zv(a)
    }

    function Zv(a) {
        return $e(a) ? Number(a) : String(a)
    };

    function aw(a, b) {
        bw(a.ia, Wv, { ...b,
            evt: "place",
            vh: ts(a.C),
            eid: Yv(a.g.g() ? .g()) || 0,
            hl: x(a.g, pv, 5) ? .g() || ""
        })
    }

    function cw(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && en(c.stack, "") || "");
        aw(a, b)
    }
    var dw = class {
        constructor(a, b, c) {
            this.C = a;
            this.ia = b;
            this.g = c
        }
    };
    const ew = ["-webkit-text-fill-color"];

    function fw(a, b) {
        if (bd) {
            {
                const d = Dd(a.document.body, a);
                if (d) {
                    a = {};
                    var c = d.length;
                    for (let e = 0; e < c; ++e) a[d[e]] = "initial";
                    a = gw(a)
                } else a = hw()
            }
        } else a = hw();
        r(b, a)
    }

    function hw() {
        const a = {
            all: "initial"
        };
        Ja(ew, b => {
            a[b] = "unset"
        });
        return a
    }

    function gw(a) {
        Ja(ew, b => {
            delete a[b]
        });
        return a
    };
    var iw = class {
        constructor(a) {
            this.g = a
        }
        ac(a) {
            const b = a.document.createElement("div");
            fw(a, b);
            r(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            const c = a.document.createElement("div");
            fw(a, c);
            r(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };

    function jw(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function kw(a) {
        return Vs(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };

    function lw(a, b) {
        a = Wk(new Hk(a), "DIV");
        const c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function mw(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    let d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        jw(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function nw(a) {
        if (a && a.parentNode) {
            const b = a.parentNode;
            b.removeChild(a);
            jw(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var Q = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        S = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        ow = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        pw = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        },
        qw = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var rw = new Q(785426718),
        sw = new S(619278254, 10),
        tw = new S(45696523, 100),
        uw = new S(1386),
        vw = new pw(1385),
        ww = new S(1359),
        xw = new S(1358),
        yw = new Q(1360),
        zw = new S(1357),
        Aw = new Q(1345),
        Bw = new pw(1387),
        Cw = new Q(687716473),
        Dw = new Q(1377),
        Ew = new Q(676894296, !0),
        Fw = new Q(45693370),
        Gw = new Q(682658313, !0),
        Hw = new Q(745713445),
        Iw = new S(1130, 100),
        Jw = new Q(786317779),
        Kw = new S(1340, .2),
        Lw = new S(1338, .3),
        Mw = new S(1339, .3),
        Nw = new Q(1337),
        Ow = new S(1032, 200),
        Pw = new Q(736254284),
        Qw = new ow(14),
        Rw = new S(766318165, -1),
        Sw = new S(1224,
            .01),
        Tw = new Q(45714120),
        Uw = new S(1346, 6),
        Vw = new S(1347, 3),
        Ww = new Q(1342),
        Xw = new Q(1344),
        Yw = new S(1343, 300),
        Zw = new Q(1260),
        $w = new Q(316),
        ax = new Q(1290),
        bx = new Q(1389),
        cx = new Q(1390),
        dx = new Q(334),
        ex = new Q(1383),
        fx = new S(1263, -1),
        gx = new S(1388),
        hx = new S(54),
        ix = new S(1323, -1),
        jx = new S(1265, -1),
        kx = new S(1264, -1),
        lx = new Q(1291),
        mx = new Q(1267, !0),
        nx = new Q(1266),
        ox = new Q(313),
        px = new S(66, -1),
        qx = new S(65, -1),
        rx = new Q(1256),
        sx = new Q(369),
        tx = new Q(1241, !0),
        ux = new Q(368),
        vx = new Q(1300, !0),
        wx = new pw(1273, ["en",
            "de", "fr", "es", "ja"
        ]),
        xx = new pw(1261, ["44786015", "44786016"]),
        yx = new Q(1361),
        zx = new Q(1372, !0),
        Ax = new Q(290),
        Bx = new S(770241922),
        Cx = new Q(1354),
        Dx = new Q(1341),
        Ex = new Q(1350),
        Fx = new Q(1356),
        Gx = new Q(626390500),
        Hx = new Q(758110037),
        Ix = new Q(45701676),
        Jx = new Q(566279275),
        Kx = new Q(622128248),
        Lx = new Q(566279276),
        Mx = new Q(768003785, !0),
        Nx = new Q(767123927),
        Ox = new Q(786713001),
        Px = new Q(775242544),
        Qx = new Q(786713003),
        Rx = new Q(786713002),
        Sx = new Q(786713004),
        Tx = new qw(635821288, ["29_18", "30_19"]),
        Ux = new ow(780033902,
            "calc(<DH> - 74px)"),
        Vx = new Q(45701765),
        Wx = new ow(716722045, "calc(<DH> - 30px)"),
        Xx = new S(758110038),
        Yx = new S(666400580, 22),
        Zx = new S(760535703),
        $x = new pw(712458671, " ar bn en es fr hi id ja ko mr pt ru sr te th tr uk vi zh".split(" ")),
        ay = new S(751018117),
        by = new qw(683929765),
        cy = new Q(742688665, !0),
        dy = new Q(767072600),
        ey = new ow(45701677, "763856898"),
        fy = new Q(683614711),
        gy = new Q(763847817),
        hy = new Q(747408261),
        iy = new Q(759602315),
        jy = new Q(506914611),
        ky = new Q(786277223),
        ly = new S(775999093, 1),
        my = new qw(630330362),
        ny = new S(717888910, .5423),
        oy = new S(9604, .5423),
        py = new S(643258048, .1542),
        qy = new S(9601, .1542),
        ry = new S(643258049, .16),
        sy = new S(9602, .16),
        ty = new S(618163195, 14141),
        uy = new S(624950166, 15E3),
        vy = new S(623405755, 300),
        wy = new S(508040914, 622),
        xy = new S(547455356, 49),
        yy = new S(717888911, .7),
        zy = new S(9605, .5799),
        Ay = new S(717888912, .5849),
        By = new S(9606, .65),
        Cy = new S(727864505, 3),
        Dy = new S(652486359, 9),
        Ey = new S(626062006, 670),
        Fy = new S(748662193, 4),
        Gy = new S(9603, 4),
        Hy = new S(688905693, 2),
        Iy = new S(650548030, 3),
        Jy =
        new S(650548032, 300),
        Ky = new S(650548031, 1),
        Ly = new S(655966487, 300),
        My = new S(655966486, 250),
        Ny = new S(687270738, 500),
        Oy = new S(469675170, 68040),
        Py = new Q(760801919, !0),
        Qy = new Q(675298507),
        Ry = new Q(644381219),
        Sy = new Q(644381220),
        Ty = new Q(676460084),
        Uy = new Q(710737579),
        Vy = new Q(772174848, !0),
        Wy = new Q(45712203),
        Xy = new Q(776685355),
        Yy = new S(684147713, -1),
        Zy = new Q(570863962, !0),
        $y = new ow(570879859, "control_1\\.\\d"),
        az = new S(570863961, 50),
        bz = new Q(570879858, !0),
        cz = new Q(732272249),
        dz = new ow(754933823, "1-0-45"),
        ez = new S(63, 30),
        fz = new Q(1134, !0),
        gz = new Q(781693592),
        hz = new Q(751557128, !0),
        iz = new Q(562874197),
        jz = new S(550718588, 250),
        kz = new S(624290870, 50),
        lz = new Q(506738118),
        mz = new Q(77),
        nz = new Q(78),
        oz = new Q(83),
        pz = new Q(80),
        qz = new Q(76),
        rz = new Q(84),
        sz = new Q(188),
        tz = new Q(485990406);
    var uz = class {
        constructor() {
            const a = {};
            this.l = (b, c) => a[b] != null ? a[b] : c;
            this.B = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.D = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.j = () => {}
        }
    };

    function T(a) {
        return M(uz).l(a.g, a.defaultValue)
    }

    function U(a) {
        return M(uz).B(a.g, a.defaultValue)
    }

    function vz(a) {
        return M(uz).A(a.g, a.defaultValue)
    }

    function wz(a) {
        return M(uz).D(a.g, a.defaultValue)
    };
    var yz = (a, b, c, d = 0) => {
            var e = xz(b, c, d);
            if (e.init) {
                for (c = b = e.init; c = e.df(c);) b = c;
                e = {
                    anchor: b,
                    position: e.Gf
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            mw(a, e.anchor, e.position)
        },
        zz = (a, b, c, d = 0) => {
            T(ox) ? yz(a, b, c, d) : mw(a, b, c)
        };

    function xz(a, b, c) {
        const d = f => {
                f = Az(f);
                return f == null ? !1 : c < f
            },
            e = f => {
                f = Az(f);
                return f == null ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    init: Bz(a.previousSibling, d),
                    df: f => Bz(f.previousSibling, d),
                    Gf: 0
                };
            case 2:
                return {
                    init: Bz(a.lastChild, d),
                    df: f => Bz(f.previousSibling, d),
                    Gf: 0
                };
            case 3:
                return {
                    init: Bz(a.nextSibling, e),
                    df: f => Bz(f.nextSibling, e),
                    Gf: 3
                };
            case 1:
                return {
                    init: Bz(a.firstChild, e),
                    df: f => Bz(f.nextSibling, e),
                    Gf: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Az(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Bz(a, b) {
        return a && b(a) ? a : null
    };
    var Cz = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };

    function Dz(a, b) {
        do {
            const c = Dd(a, b);
            if (c && c.position == "fixed") return !1
        } while (a = a.parentElement);
        return !0
    };

    function Ez(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            const f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = Nd(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function Fz(a, b) {
        return !((Ld.test(b.google_ad_width) || Kd.test(a.style.width)) && (Ld.test(b.google_ad_height) || Kd.test(a.style.height)))
    }

    function Gz(a, b) {
        return (a = Hz(a, b)) ? a.y : 0
    }

    function Hz(a, b) {
        try {
            const c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function Iz(a, b) {
        const c = a.google_reactive_ad_format === 40,
            d = a.google_reactive_ad_format === 16;
        return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
    }

    function Jz(a, b, c, d, e) {
        if (a !== a.top) return Ad(a) ? 3 : 16;
        if (!(ss(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        const f = ss(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = ss(a); c; c = c.parentElement)
                    if ((d = Dd(c, a)) && (e = Nd(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function Kz(a, b, c, d) {
        const e = Jz(b, c, a, U(Mw), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || Dz(c, b) ? (b = ss(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function Lz(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function Mz(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = Dd(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function Nz(a, b, c) {
        a = Hz(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function Oz(a, b) {
        b = b.parentElement;
        return b ? (a = Dd(b, a)) ? a.direction : "" : ""
    }

    function Pz(a, b, c) {
        if (Nz(a, b, c) !== 0) {
            Lz(b, c, "0px");
            var d = Nz(a, b, c);
            Lz(b, c, `${-1*d}px`);
            a = Nz(a, b, c);
            a !== 0 && a !== d && Lz(b, c, `${d/(a-d)*d}px`)
        }
    }

    function Qz(a, b) {
        const c = Oz(a, b);
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            Lz(b, c, "0px");
            d.width = `${ss(a)}px`;
            Pz(a, b, c);
            d.zIndex = "30"
        }
    };

    function Rz(a, b, c) {
        let d;
        return a.style && !!a.style[c] && Nd(a.style[c]) || (d = Dd(a, b)) && !!d[c] && Nd(d[c]) || null
    }

    function Sz(a, b) {
        const c = Ym(a) === 0;
        return b && c ? Math.max(250, 2 * ts(a) / 3) : 250
    }

    function Tz(a, b) {
        let c;
        return a.style && a.style.zIndex || (c = Dd(a, b)) && c.zIndex || null
    }

    function Uz(a) {
        return b => b.g <= a
    }

    function Vz(a, b, c, d) {
        const e = a && Wz(c, b),
            f = Sz(b, d);
        return g => !(e && g.height() >= f)
    }

    function Xz(a) {
        return b => b.height() <= a
    }

    function Wz(a, b) {
        a = Gz(a, b);
        b = ts(b);
        return a < b - 100
    }

    function Yz(a, b) {
        var c = Rz(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = Rz(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && Nd(b.style.height)) && (c = Math.min(c, d)), (d = Rz(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };
    const Zz = RegExp("(^| )adsbygoogle($| )");

    function $z(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = Xc(d.property);
            a[e] = d.value
        }
    }

    function aA(a, b, c, d, e, f) {
        a = bA(a, e);
        a.Ra.setAttribute("data-ad-format", d ? d : "auto");
        cA(a, b, c, f);
        return a
    }

    function dA(a, b, c = null) {
        a = bA(a, {});
        cA(a, b, null, c);
        return a
    }

    function cA(a, b, c, d) {
        var e = [];
        if (d = d && d.Gi) a.Ec.className = d.join(" ");
        a = a.Ra;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function bA(a, b) {
        const c = lw(a, b.clearBoth || !1);
        var d = c.style;
        d.textAlign = "center";
        b.Ff && $z(d, b.Ff);
        a = Wk(new Hk(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.hi && (d.marginTop = b.hi);
        b.sg && (d.marginBottom = b.sg);
        b.Od && $z(d, b.Od);
        c.appendChild(a);
        return {
            Ec: c,
            Ra: a
        }
    }

    function eA(a, b, c) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        const d = {
            element: b
        };
        c = c && c.fe();
        if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (e) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (d.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(d)
    }

    function fA(a) {
        const b = kw(a.document);
        Ja(b, function(c) {
            const d = gA(a, c);
            var e;
            if (e = d) {
                e = Gz(c, a);
                const f = ts(a);
                e = !(e < f)
            }
            e && (c.setAttribute("data-pub-vars", JSON.stringify(d)), c.removeAttribute("height"), c.style.removeProperty("height"), c.removeAttribute("width"), c.style.removeProperty("width"), eA(a, c))
        })
    }

    function gA(a, b) {
        b = b.getAttribute("google_element_uid");
        a = a.google_sv_map;
        if (!b || !a || !a[b]) return null;
        a = a[b];
        b = {};
        for (let c in db) a[db[c]] && (b[db[c]] = a[db[c]]);
        return b
    };
    var iA = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement;
        const e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; d < 10 && b;) {
            if (b == c) return !0;
            if (hA(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const hA = (a, b) => {
        if (b.nodeType == 3) return b.nodeType == 3 ? (b = b.data, a = b.indexOf("&") != -1 ? Uc(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (b.nodeType == 1) {
            var c = a.getComputedStyle(b);
            if (c.opacity == "0" || c.display == "none" || c.visibility == "hidden") return !1;
            if ((c = b.tagName) && bt.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (hA(a, b[c])) return !0
        }
        return !1
    };
    var jA = a => {
        if (a >= 460) return a = Math.min(a, 1200), Math.ceil(a < 800 ? a / 4 : 200);
        a = Math.min(a, 600);
        return a <= 420 ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    var kA = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        j(a, b, c, d) {
            return aA(d.document, a, null, null, this.g, b)
        }
        l(a) {
            return jA(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };

    function lA(a) {
        const b = [];
        Us(a.getElementsByTagName("p"), function(c) {
            mA(c) >= 100 && b.push(c)
        });
        return b
    }

    function mA(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        let b = 0;
        Us(a.childNodes, function(c) {
            b += mA(c)
        });
        return b
    }

    function nA(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function oA(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function pA(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.B)
        } catch (d) {}
        if (!c.length) return [];
        b = Xa(c);
        b = oA(a, b);
        typeof a.j === "number" && (c = a.j, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.l === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                const e = lA(b[d]);
                let f = a.l;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var qA = class {
        constructor(a, b, c, d) {
            this.B = a;
            this.j = b;
            this.l = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.B,
                occurrenceIndex: this.j,
                paragraphIndex: this.l,
                ignoreMode: this.g
            })
        }
    };
    var rA = class {
        constructor() {
            this.g = ud `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        pa(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            b.error && b.meta && b.id || (b = new bn(b, {
                context: a,
                id: d
            }));
            q.google_js_errors = q.google_js_errors || [];
            q.google_js_errors.push(b);
            q.error_rep_loaded || (Bd(q.document, this.g), q.error_rep_loaded = !0);
            return !1
        }
        kc(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.pa(a, c, .01, "jserror")) throw c;
            }
        }
        lc(a, b, c) {
            return (...d) => this.kc(a, () => b.apply(c, d))
        }
        Oa(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.pa(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function sA(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function tA(a, b, c, d, e = !1) {
        const f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            const k = mn();
            let l, m = 3;
            try {
                l = b.apply(this, h)
            } catch (n) {
                m = 13;
                if (!c) throw n;
                c(a, n)
            } finally {
                f.google_measure_js_timing && k && sA({
                    label: a.toString(),
                    value: k,
                    duration: (mn() || 0) - k,
                    type: m,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return l
        }
    }

    function uA(a, b) {
        return tA(754, a, (c, d) => {
            (new rA).pa(c, d)
        }, b, !0)
    };

    function vA(a, b, c) {
        return tA(a, b, void 0, c, !0).apply()
    }

    function wA(a, b) {
        return uA(a, b).apply()
    }

    function xA(a) {
        if (!a) return null;
        var b = Yh(a, 7);
        if (Yh(a, 1) || a.getId() || Th(a, 4).length > 0) {
            var c = a.getId(),
                d = Yh(a, 1),
                e = Th(a, 4);
            b = Xh(a, 2);
            var f = Xh(a, 5);
            a = yA(Zh(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + nA(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + nA(e[c]);
            b = (e = g) ? new qA(e, b, f, a) : null
        } else b = b ? new qA(b, Xh(a, 2), Xh(a, 5), yA(Zh(a, 6))) : null;
        return b
    }
    const zA = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function yA(a) {
        return a == null ? a : zA[a]
    }

    function AA(a) {
        const b = [];
        for (let c = 0; c < a.length; c++) {
            const d = Yh(a[c], 1),
                e = a[c].getValue();
            d && e != null && b.push({
                property: d,
                value: e
            })
        }
        return b
    }

    function BA(a, b) {
        const c = {};
        a && (c.hi = Yh(a, 1), c.sg = Yh(a, 2), c.clearBoth = !!Wh(a, 3));
        b && (c.Ff = AA(Gh(b, wv, 3, ph()).map(d => lg(d))), c.Od = AA(Gh(b, wv, 4, ph()).map(d => lg(d))));
        return c
    }
    const CA = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        DA = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    var EA = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            return aA(d.document, a, null, null, this.g, b)
        }
        l() {
            return null
        }
    };
    var FA = class {
        constructor(a) {
            this.j = a
        }
        g(a) {
            a = Math.floor(a.j);
            const b = jA(a);
            return new Ru(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.j,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    var GA = class {
        constructor(a, b) {
            this.B = a;
            this.l = b
        }
        g() {
            return this.B
        }
        j() {
            return this.l
        }
    };
    var HA = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            var e = Gh(this.g, xv, 9, ph()).length > 0 ? Gh(this.g, xv, 9, ph())[0] : null,
                f = BA(Eh(this.g, yv, 3), e);
            if (!e) return null;
            if (e = Yh(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = Wk(new Hk(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                g == "A" && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.Ff && $z(c.style, f.Ff);
                d = Wk(new Hk(d), "INS");
                f.Od && $z(d.style, f.Od);
                c.appendChild(d);
                f = {
                    Ec: c,
                    Ra: d
                };
                f.Ra.setAttribute("data-ad-type", "text");
                f.Ra.setAttribute("data-native-settings-key",
                    e);
                cA(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        l() {
            var a = Gh(this.g, xv, 9, ph()).length > 0 ? Gh(this.g, xv, 9, ph())[0] : null;
            if (!a) return null;
            a = Gh(a, wv, 3, ph());
            for (let b = 0; b < a.length; b++) {
                const c = a[b];
                if (Yh(c, 1) == "height" && parseInt(c.getValue(), 10) > 0) return parseInt(c.getValue(), 10)
            }
            return null
        }
    };
    var IA = class {
        constructor(a) {
            this.g = a
        }
        j(a, b, c, d) {
            if (!this.g) return null;
            const e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    const k = c.item(h);
                    k !== "width" && k !== "height" && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    Od: g
                }
            } else c = {};
            a = aA(d.document, a, f, e, c, b);
            a.Ra.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        l() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        fe() {
            return this.g
        }
    };
    var JA = class {
        constructor(a) {
            this.j = a
        }
        g() {
            return new Ru([], {
                google_ad_type: this.j,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    var KA = class {
        constructor(a, b) {
            this.B = a;
            this.l = b
        }
        j() {
            return this.l
        }
        g(a) {
            a = pA(this.B, a.document);
            return a.length > 0 ? a[0] : null
        }
    };

    function LA(a, b, c) {
        const d = [];
        for (let p = 0; p < a.length; p++) {
            a: {
                var e = a[p];
                var f = p,
                    g = b,
                    h = c,
                    k = e.ua();
                if (!k) {
                    e = null;
                    break a
                }
                var l = xA(k);
                if (!l) {
                    e = null;
                    break a
                }
                var m = e.j();m = CA[m];
                var n = m === void 0 ? null : m;
                if (n === null) {
                    e = null;
                    break a
                }
                m = (m = x(e, yv, 3)) ? Wh(m, 3) : null;l = new KA(l, n);n = Uh(e, 10).slice(0);yf(w(k, 5)) != null && n.push(1);k = Xh(e, 12);
                const t = kh(e, Pu, 4) ? x(e, Pu, 4) : null;wf(w(e, 8)) == 1 ? (h = h && h.Gk || null, e = new MA(l, new EA(BA(x(e, yv, 3), null)), h, m, 0, n, t, g, f, k, e)) : e = wf(w(e, 8)) == 2 ? new MA(l, new HA(e), h && h.Tl || new JA("text"),
                    m, 1, n, t, g, f, k, e) : null
            }
            e !== null && d.push(e)
        }
        return d
    }

    function NA(a) {
        return a.B
    }

    function OA(a) {
        return a.Fa
    }

    function PA(a) {
        return a.D instanceof IA ? a.D.fe() : null
    }

    function QA(a, b, c) {
        Ws(a.T, b) || a.T.set(b, []);
        a.T.get(b).push(c)
    }

    function RA(a) {
        return a.D.l(a.g)
    }

    function SA(a, b = null, c = null) {
        return new MA(a.F, b || a.D, c || a.V, a.G, a.yd, a.ie, a.Qf, a.g, a.la, a.J, a.l, a.A, a.ba)
    }
    var MA = class {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.F = a;
            this.D = b;
            this.V = c;
            this.G = d;
            this.yd = e;
            this.ie = f;
            this.Qf = g ? g : new Pu;
            this.g = h;
            this.la = k;
            this.J = l;
            this.l = m;
            (a = !m) || ((a = !m.ua()) || (m = m.ua(), a = yf(w(m, 5)) == null), a = !!a);
            this.Fa = !a;
            this.A = n;
            this.ba = p;
            this.K = [];
            this.B = !1;
            this.T = new $s
        }
        xa() {
            return this.g
        }
        j() {
            return this.F.j()
        }
    };

    function TA(a, b, c, d, e, f) {
        const g = Ou();
        return new MA(new GA(c, e), new kA, new FA(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function UA(a, b, c, d, e) {
        const f = Ou();
        return new MA(new GA(b, d), new EA({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var VA = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.C = c
        }
        xa() {
            return this.C
        }
        A(a) {
            return TA(a, this.articleStructure, this.element, this.C, 3, null)
        }
        l() {
            return UA(this.articleStructure, this.element, this.C, 3, null)
        }
    };
    const WA = {
        TABLE: {
            Yd: new qu([1, 2])
        },
        THEAD: {
            Yd: new qu([0, 3, 1, 2])
        },
        TBODY: {
            Yd: new qu([0, 3, 1, 2])
        },
        TR: {
            Yd: new qu([0, 3, 1, 2])
        },
        TD: {
            Yd: new qu([0, 3])
        }
    };

    function XA(a, b, c, d) {
        const e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (const f of c) c = Ia(e, f), c < 0 || b.push(new YA(a, [f], c, f, 3, Sk(f).trim(), d));
        return b
    }

    function ZA(a, b, c) {
        let d = [];
        const e = [],
            f = b.childNodes,
            g = f.length;
        let h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (l.nodeType == 1 || l.nodeType == 3) {
                if (l.nodeType != 1) var m = null;
                else l.tagName == "BR" ? m = l : (m = c.getComputedStyle(l).getPropertyValue("display"), m = m == "inline" || m == "inline-block" ? null : l);
                m ? (d.length && k && e.push(new YA(a, d, n - 1, m, 0, k, c)), d = [], h = n + 1, k = "") : (d.push(l), l = Sk(l).trim(), k += l && k ? " " + l : l)
            }
        }
        d.length && k && e.push(new YA(a, d, h, b, 2, k, c));
        return e
    }

    function $A(a, b) {
        return a.g - b.g
    }
    var YA = class {
        constructor(a, b, c, d, e, f, g) {
            this.B = a;
            this.Pe = b.slice(0);
            this.g = c;
            this.Yf = d;
            this.Zf = e;
            this.D = f;
            this.j = g
        }
        xa() {
            return this.j
        }
        A(a) {
            return TA(a, this.B, this.Yf, this.j, this.Zf, this.g)
        }
        l() {
            return UA(this.B, this.Yf, this.j, this.Zf, this.g)
        }
    };

    function aB(a) {
        return Wa(a.D ? ZA(a.g, a.l, a.j) : [], a.A ? XA(a.g, a.A, a.l, a.j) : []).filter(b => {
            var c = b.Yf.tagName;
            c ? (c = WA[c.toUpperCase()], b = c != null && c.Yd.contains(b.Zf)) : b = !1;
            return !b
        })
    }
    var bB = class {
        constructor(a, b, c) {
            this.l = a;
            this.A = b.Le;
            this.D = b.Wi;
            this.g = b.articleStructure;
            this.j = c;
            this.B = b.wi
        }
    };

    function cB(a, b) {
        if (!b) return !1;
        const c = ta(b),
            d = a.g.get(c);
        if (d != null) return d;
        if (b.nodeType == 1 && (b.tagName == "UL" || b.tagName == "OL") && a.j.getComputedStyle(b).getPropertyValue("list-style-type") != "none") return a.g.set(c, !0), !0;
        b = cB(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function dB(a, b) {
        return Oa(b.Pe, c => cB(a, c))
    }
    var eB = class {
        constructor(a) {
            this.g = new $s;
            this.j = a
        }
    };
    var fB = class {
        constructor(a, b) {
            this.B = a;
            this.g = [];
            this.j = [];
            this.l = b
        }
    };
    var hB = (a, {
            hj: b = !1,
            Zh: c = !1,
            tj: d = c ? 2 : 3,
            Yh: e = null
        } = {}) => {
            a = aB(a);
            return gB(a, {
                hj: b,
                Zh: c,
                tj: d,
                Yh: e
            })
        },
        gB = (a, {
            hj: b = !1,
            Zh: c = !1,
            tj: d = c ? 2 : 3,
            Yh: e = null
        } = {}) => {
            if (d < 2) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort($A);
            a = [];
            b = new fB(b, e);
            for (const g of f) {
                e = {
                    Hf: g,
                    lf: g.D.length < 51 ? !1 : b.l != null ? !dB(b.l, g) : !0
                };
                if (b.B || e.lf) b.g.length ? (f = b.g[b.g.length - 1].Hf, f = iA(f.xa(), f.Pe[f.Pe.length - 1], e.Hf.Pe[0])) : f = !0, f ? (b.g.push(e), e.lf && b.j.push(e.Hf)) : (b.g = [e], b.j = e.lf ? [e.Hf] : []);
                if (b.j.length >=
                    d) {
                    e = b;
                    f = c ? 0 : 1;
                    if (f < 0 || f >= e.j.length) e = null;
                    else {
                        for (f = e.j[f]; e.g.length && !e.g[0].lf;) e.g.shift();
                        e.g.shift();
                        e.j.shift();
                        e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var jB = (a, b, c = !1) => {
            a = iB(a, b);
            const d = new eB(b);
            return ku(a, e => hB(e, {
                Zh: c,
                Yh: d
            }))
        },
        kB = (a, b) => {
            a = iB(a, b);
            const c = new eB(b);
            return ku(a, d => {
                if (d.B) {
                    var e = d.g;
                    var f = d.j;
                    d = d.l.querySelectorAll(d.B);
                    var g = [];
                    for (var h of d) g.push(new VA(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        const m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if (l.name.toLowerCase() === "style" && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k =
                            h.element.tagName;k = k === "IMG" || k === "SVG"
                        }(k || h.element.textContent.length > 1) && !cB(c, f.element) && iA(m.xa(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        iB = (a, b) => {
            const c = new $s;
            a.forEach(d => {
                var e = xA(Eh(d, Fu, 1));
                if (e) {
                    var f = e.toString();
                    Ws(c, f) || c.set(f, {
                        articleStructure: d,
                        Ak: e,
                        Le: null,
                        Wi: !1,
                        wi: null
                    });
                    e = c.get(f);
                    (f = (f = x(d, Fu, 2)) ? Yh(f, 7) : null) ? e.Le = e.Le ? e.Le + "," + f : f: e.Wi = !0;
                    d = x(d, Fu, 4);
                    e.wi = d ? Yh(d, 7) : null
                }
            });
            return Zs(c).map(d => {
                const e = pA(d.Ak, b.document);
                return e.length ? new bB(e[0],
                    d, b) : null
            }).filter(d => d != null)
        };
    var lB = a => a ? .google_ad_slot ? ru(new Gu(1, {
            qk: a.google_ad_slot
        })) : tu(Error("Missing dimension when creating placement id")),
        nB = a => {
            switch (a.yd) {
                case 0:
                case 1:
                    var b = a.l;
                    b == null ? a = null : (a = b.ua(), a == null ? a = null : (b = b.j(), a = b == null ? null : new Gu(0, {
                        xi: [a],
                        Ij: b
                    })));
                    return a != null ? ru(a) : tu(Error("Missing dimension when creating placement id"));
                case 2:
                    return a = mB(a), a != null ? ru(a) : tu(Error("Missing dimension when creating placement id"));
                default:
                    return tu(Error("Invalid type: " + a.yd))
            }
        };
    const mB = a => {
        if (a == null || a.A == null) return null;
        const b = x(a.A, Fu, 1),
            c = x(a.A, Fu, 2);
        if (b == null || c == null) return null;
        const d = a.ba;
        if (d == null) return null;
        a = a.j();
        return a == null ? null : new Gu(0, {
            xi: [b, c],
            Sl: d,
            Ij: DA[a]
        })
    };

    function oB(a) {
        const b = PA(a.qa);
        return (b ? lB(b) : nB(a.qa)).map(c => Ku(c))
    }

    function pB(a) {
        a.g = a.g || oB(a);
        return a.g
    }

    function qB(a, b) {
        if (a.qa.B) throw Error("AMA:AP:AP");
        zz(b, a.ua(), a.qa.j());
        a = a.qa;
        a.B = !0;
        b != null && a.K.push(b)
    }
    const rB = class {
        constructor(a, b, c) {
            this.qa = a;
            this.j = b;
            this.Aa = c;
            this.g = null
        }
        ua() {
            return this.j
        }
        fill(a, b) {
            var c = this.qa;
            (a = c.D.j(a, b, this.j, c.g)) && qB(this, a.Ec);
            return a
        }
    };

    function sB(a, b) {
        return wA(() => {
            const c = [],
                d = [];
            try {
                var e = [];
                for (var f = 0; f < a.length; f++) {
                    var g = a[f],
                        h = g.F.g(g.g);
                    h && e.push({
                        Ej: g,
                        anchorElement: h
                    })
                }
                for (g = 0; g < e.length; g++) {
                    f = d;
                    var k = f.push; {
                        var l = e[g];
                        const u = l.anchorElement,
                            B = l.Ej;
                        var m = B.G;
                        const F = B.g.document.createElement("div");
                        F.className = "google-auto-placed";
                        const R = F.style;
                        R.textAlign = "center";
                        R.width = "100%";
                        R.height = "0px";
                        R.clear = m ? "both" : "none";
                        h = F;
                        try {
                            zz(h, u, B.j());
                            var n = h
                        } catch (da) {
                            throw nw(h), da;
                        }
                    }
                    k.call(f, n)
                }
                const p = Ps(b),
                    t = Qs(b);
                for (k =
                    0; k < d.length; k++) {
                    const u = d[k].getBoundingClientRect(),
                        B = e[k];
                    c.push(new rB(B.Ej, B.anchorElement, new bu(u.left + t, u.top + p, u.right - u.left)))
                }
            } finally {
                for (e = 0; e < d.length; e++) nw(d[e])
            }
            return c
        }, b)
    };
    const tB = {
            1: "0.5vp",
            2: "300px"
        },
        uB = {
            1: 700,
            2: 1200
        },
        vB = {
            [1]: {
                Uj: "3vp",
                ai: "1vp",
                Tj: "0.3vp"
            },
            [2]: {
                Uj: "900px",
                ai: "300px",
                Tj: "90px"
            }
        };

    function wB(a, b, c) {
        var d = xB(a),
            e = ts(a) || uB[d],
            f = void 0;
        c && (f = (c = (c = yB(Gh(c, Yu, 2, ph()), d)) ? x(c, Wu, 7) : void 0) ? zB(c, e) : void 0);
        c = f;
        f = xB(a);
        a = ts(a) || uB[f];
        const g = AB(vB[f].ai, a);
        a = g === null ? BB(f, a) : new CB(g, g, DB(g, 8), 8, .3, c);
        c = AB(vB[d].Uj, e);
        f = AB(vB[d].ai, e);
        d = AB(vB[d].Tj, e);
        e = a.l;
        c && d && f && b !== void 0 && (e = b <= .5 ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) * (f - d));
        d = new CB(e, e, DB(e, a.j), a.j, a.D, a.g);
        return EB(d, null, b ? ? null)
    }

    function FB(a, b) {
        const c = Lh(a, 4, gh),
            d = oh(a, 5, gh);
        return c == null || d == null ? b : EB(new CB(d, 0, [], c, 1), a, null)
    }

    function GB(a, b) {
        const c = xB(a);
        a = ts(a) || uB[c];
        if (!b) return BB(c, a);
        if (b = yB(Gh(b, Yu, 2, ph()), c))
            if (b = HB(b, a)) return b;
        return BB(c, a)
    }

    function IB(a) {
        const b = xB(a);
        a = ts(a) || uB[b];
        return BB(b, a)
    }

    function JB() {
        return T(ax) ? new CB(0, null, [], 8, .3) : new CB(0, null, [], 3, null)
    }

    function EB(a, b, c) {
        b = KB(b, c);
        return b == null ? a : new CB(a.l, a.A, a.B, a.j, b, a.g)
    }

    function LB(a, b) {
        let c = {
            pe: a.l,
            Lc: a.A
        };
        for (let d of a.B) d.adCount <= b && (c = d.Be);
        return c
    }

    function KB(a, b) {
        const c = U(gx);
        if (c <= 0) return null;
        if (T(bx)) return c;
        if (!T(cx) || !a && !b) return null;
        if (a && a.g() === 2) a = String(Mh(a, 4, gh)) === "8" && oh(a, 5, gh) === 530;
        else {
            if (!b) return null;
            a = b === .5
        }
        return a ? c : null
    }

    function MB(a, b, c) {
        var d = Wh(b, 2);
        b = x(b, Yu, 1);
        var e = xB(c);
        var f = ts(c) || uB[e];
        c = AB(b ? .j(), f) ? ? a.l;
        e = AB(b ? .g(), f) ? ? a.A;
        d = d ? [] : NB(b ? .B(), f) ? ? a.B;
        const g = b ? .D() ? ? a.j,
            h = b ? .J() ? ? a.D;
        a = (b ? .F() ? zB(x(b, Wu, 7), f) : null) ? ? a.g;
        return new CB(c, e, d, g, h, a)
    }

    function OB(a, b) {
        var c = xB(b);
        const d = new Zu,
            e = new Yu;
        let f = !1;
        var g = U(fx);
        g >= 0 && (bi(e, 4, g), f = !0);
        g = null;
        c === 1 ? (c = U(kx), c >= 0 && (g = c + "vp")) : (c = U(jx), c >= 0 && (g = c + "px"));
        c = U(ix);
        c >= 0 && (g = c + "px");
        g !== null && (fi(e, 2, g), f = !0);
        c = T(mx) ? "0px" : null;
        c !== null && (fi(e, 5, c), f = !0);
        if (T(nx)) $h(d, 2, !0), f = !0;
        else if (c !== null || g !== null) {
            const m = [];
            for (const n of a.B) {
                var h = m,
                    k = h.push;
                var l = new Xu;
                l = bi(l, 1, n.adCount);
                l = fi(l, 3, c ? ? n.Be.Lc + "px");
                l = fi(l, 2, g ? ? n.Be.pe + "px");
                k.call(h, l)
            }
            Ih(e, 3, m)
        }
        return f ? (y(d, 1, e), MB(a, d, b)) : a
    }
    var CB = class {
        constructor(a, b, c, d, e, f) {
            this.l = a;
            this.A = b;
            this.B = c.sort((g, h) => g.adCount - h.adCount);
            this.j = d;
            this.D = e;
            this.g = f
        }
    };

    function yB(a, b) {
        for (let c of a)
            if (wf(w(c, 1)) == b) return c;
        return null
    }

    function NB(a, b) {
        if (a === void 0) return null;
        const c = [];
        for (let d of a) {
            a = Xh(d, 1);
            const e = AB(Yh(d, 2), b),
                f = AB(Yh(d, 3), b);
            if (typeof a !== "number" || e === null) return null;
            c.push({
                adCount: a,
                Be: {
                    pe: e,
                    Lc: f
                }
            })
        }
        return c
    }

    function HB(a, b) {
        const c = AB(a.j(), b),
            d = AB(a.g(), b);
        if (c === null) return null;
        const e = Xh(a, 4);
        if (e == null) return null;
        var f = a.B();
        f = NB(f, b);
        if (f === null) return null;
        const g = x(a, Wu, 7);
        b = g ? zB(g, b) : void 0;
        return new CB(c, d, f, e, oh(a, 6, gh), b)
    }

    function BB(a, b) {
        a = AB(tB[a], b);
        return T(ax) ? new CB(a === null ? Infinity : a, null, [], 8, .3) : new CB(a === null ? Infinity : a, null, [], 3, null)
    }

    function AB(a, b) {
        if (!a) return null;
        const c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function xB(a) {
        a = ss(a) >= 900;
        return Rb() && !a ? 1 : 2
    }

    function DB(a, b) {
        if (b < 4) return [];
        const c = Math.ceil(b / 2);
        return [{
            adCount: c,
            Be: {
                pe: a * 2,
                Lc: a * 2
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            Be: {
                pe: a * 3,
                Lc: a * 3
            }
        }]
    }

    function zB(a, b) {
        const c = AB(Yh(a, 2), b) || 0,
            d = Xh(a, 3) || 1;
        a = AB(Yh(a, 1), b) || 0;
        return {
            uj: c,
            qj: d,
            Rd: a
        }
    };

    function PB(a, b, c) {
        return ls({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function QB(a) {
        if (!a.length) return null;
        const b = ms(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.j, 0);
        return new RB(b, a)
    }
    var RB = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };

    function Kq() {
        return "m202507280101"
    };
    var SB = vk(Hq);
    var Jq = vk(Lq);

    function TB(a, b) {
        return b(a) ? a : void 0
    }

    function UB(a, b, c, d, e) {
        c = c instanceof bn ? c.error : c;
        var f = new Pq;
        const g = new Oq;
        try {
            var h = fe(window);
            di(g, 1, h)
        } catch (p) {}
        try {
            var k = M(bs).g();
            yh(g, 2, k, xf)
        } catch (p) {}
        try {
            gi(g, 3, window.document.URL)
        } catch (p) {}
        h = y(f, 2, g);
        k = new Nq;
        b = G(k, 1, b);
        try {
            var l = gb(c ? .name) ? c.name : "Unknown error";
            gi(b, 2, l)
        } catch (p) {}
        try {
            var m = gb(c ? .message) ? c.message : `Caught ${c}`;
            gi(b, 3, m)
        } catch (p) {}
        try {
            var n = gb(c ? .stack) ? c.stack : Error().stack;
            n && yh(b, 4, n.split(/\n\s*/), Yf)
        } catch (p) {}
        l = z(h, 1, Qq, b);
        if (e) {
            m = 0;
            switch (e.errSrc) {
                case "LCC":
                    m =
                        1;
                    break;
                case "PVC":
                    m = 2
            }
            n = Iq();
            b = TB(e.shv, gb);
            n = gi(n, 2, b);
            m = G(n, 6, m);
            n = ij(SB());
            b = TB(e.es, nb());
            n = yh(n, 1, b, xf);
            n = bh(n);
            m = y(m, 4, n);
            n = TB(e.client, gb);
            m = fi(m, 3, n);
            n = TB(e.slotname, gb);
            m = gi(m, 7, n);
            e = TB(e.tag_origin, gb);
            e = gi(m, 8, e);
            e = bh(e)
        } else e = kj(Iq());
        e = z(l, 6, Rq, e);
        d = di(e, 5, d ? ? 1);
        a.Pj(d)
    };
    var WB = class {
        constructor() {
            this.j = VB
        }
        g(a) {
            var b = this.j();
            return a > 0 && b.vm * a <= b.al
        }
    };

    function VB() {
        return {
            vm: qb() + (qb() & 2 ** 21 - 1) * 2 ** 32,
            al: Number.MAX_SAFE_INTEGER
        }
    };
    var ZB = class {
        constructor(a = !1) {
            var b = XB;
            this.L = YB;
            this.j = a;
            this.B = b;
            this.g = null;
            this.na = this.pa
        }
        l(a) {
            this.g = a
        }
        A() {}
        kc(a, b, c) {
            let d;
            try {
                d = b()
            } catch (e) {
                b = this.j;
                try {
                    b = this.na(a, cn(e), void 0, c)
                } catch (f) {
                    this.pa(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        lc(a, b, c, d) {
            return (...e) => this.kc(a, () => b.apply(c, e), d)
        }
        Oa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.pa(a, d instanceof Error ? d : Error(d), void 0, c)
            })
        }
        pa(a, b, c, d) {
            try {
                const f = c === void 0 ? 1 / this.B : c === 0 ? 0 : 1 / c;
                if ((new WB).g(f)) {
                    var e =
                        this.L;
                    c = {};
                    if (this.g) try {
                        this.g(c)
                    } catch (g) {}
                    if (d) try {
                        d(c)
                    } catch (g) {}
                    UB(e, a, b, f, c)
                }
            } catch (f) {}
            return this.j
        }
    };
    var $B = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, $B) : this.stack = Error().stack || ""
        }
    };
    let YB, aC, bC, cC, XB;
    const dC = new tn(q);
    (function(a, b, c = !0) {
        ({
            Lm: XB,
            Fl: bC
        } = eC());
        aC = a || new es;
        ds(aC, bC);
        YB = b || new Zr(Kq(), 1E3);
        cC = new ZB(c);
        q.document.readyState === "complete" ? q.google_measure_js_timing || sn(dC) : dC.g && ql(q, "load", () => {
            q.google_measure_js_timing || sn(dC)
        })
    })();

    function fC(a, b, c) {
        return cC.kc(a, b, c)
    }

    function gC(a, b) {
        return cC.lc(a, b)
    }

    function hC(a, b, c) {
        cC.Oa(a, b, c)
    }

    function iC(a, b, c = .01) {
        const d = M(bs).g();
        !b.eid && d.length && (b.eid = d.toString());
        Fn(aC, a, b, !0, c)
    }

    function jC(a, b, c = XB, d) {
        return cC.pa(a, b, c, d, void 0)
    }

    function eC() {
        let a, b;
        typeof q.google_srt === "number" ? (b = q.google_srt, a = q.google_srt === 0 ? 1 : .01) : (b = Math.random(), a = .01);
        return {
            Lm: a,
            Fl: b
        }
    };

    function kC(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };

    function lC(a, b) {
        var c = mC(b, ".google-auto-placed");
        const d = nC(b),
            e = oC(b),
            f = pC(b),
            g = qC(b),
            h = rC(b),
            k = mC(b, "div.googlepublisherpluginad"),
            l = mC(b, "html > ins.adsbygoogle");
        let m = [].concat(...mC(b, "iframe[id^=aswift_],iframe[id^=google_ads_frame]"), ...mC(b, "body ins.adsbygoogle"));
        b = [];
        for (const [n, p] of [
                [a.kf, c],
                [a.rd, d],
                [a.Ql, e],
                [a.rh, f],
                [a.sh, g],
                [a.Nl, h],
                [a.Pl, k],
                [a.Rl, l]
            ]) n === !1 ? b = b.concat(p) : m = m.concat(p);
        a = sC(m);
        c = sC(b);
        a = a.slice(0);
        for (const n of c)
            for (c = 0; c < a.length; c++)(n.contains(a[c]) || a[c].contains(n)) &&
                a.splice(c, 1);
        return a
    }

    function tC(a) {
        return !!a.className && a.className.indexOf("google-auto-placed") != -1
    }

    function uC(a) {
        const b = kC(a);
        return b ? La(Ma(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
    }

    function mC(a, b) {
        return Xa(a.document.querySelectorAll(b))
    }

    function nC(a) {
        return mC(a, "ins.adsbygoogle[data-anchor-status]")
    }

    function oC(a) {
        return mC(a, "ins.adsbygoogle[data-ad-format=autorelaxed]")
    }

    function pC(a) {
        return (uC(a) || mC(a, "div[id^=div-gpt-ad]")).concat(mC(a, "iframe[id^=google_ads_iframe]"))
    }

    function qC(a) {
        return mC(a, "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")
    }

    function rC(a) {
        return mC(a, "ins.adsbygoogle-ablated-ad-slot")
    }

    function sC(a) {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };
    var vC = gC(453, lC),
        wC = gC(454, function(a, b) {
            const c = mC(b, ".google-auto-placed"),
                d = nC(b),
                e = oC(b),
                f = pC(b),
                g = qC(b),
                h = rC(b),
                k = mC(b, "div.googlepublisherpluginad");
            b = mC(b, "html > ins.adsbygoogle");
            return sC([...(a.kf === !0 ? c : []), ...(a.rd === !0 ? d : []), ...(a.Ql === !0 ? e : []), ...(a.rh === !0 ? f : []), ...(a.sh === !0 ? g : []), ...(a.Nl === !0 ? h : []), ...(a.Pl === !0 ? k : []), ...(a.Rl === !0 ? b : [])])
        });

    function xC(a, b, c) {
        const d = yC(a);
        b = zC(d, b, c);
        return new AC(a, d, b)
    }

    function BC(a) {
        return (a.bottom - a.top) * (a.right - a.left) > 1
    }

    function CC(a) {
        return a.g.map(b => b.box)
    }

    function DC(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    var AC = class {
        constructor(a, b, c) {
            this.l = a;
            this.g = b.slice(0);
            this.B = c.slice(0);
            this.j = null
        }
    };

    function yC(a) {
        const b = vC({
                rd: !1
            }, a),
            c = Qs(a),
            d = Ps(a);
        return b.map(e => {
            const f = e.getBoundingClientRect();
            return (e = tC(e)) || BC(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                Tq: e ? 1 : 0
            } : null
        }).filter(yb(e => e === null))
    }

    function zC(a, b, c) {
        return b != void 0 && a.length <= (c != void 0 ? c : 8) ? EC(a, b) : Ma(a, d => new RB(d.box, 1))
    }

    function EC(a, b) {
        a = Ma(a, d => new RB(d.box, 1));
        const c = [];
        for (; a.length > 0;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (PB(d, a[f], b)) {
                        d = QB([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function FC(a, b, c) {
        const d = au(c, b);
        return !Oa(a, e => ls(e, d))
    }

    function GC(a, b, c, d, e) {
        e = e.Aa;
        const f = au(e, b),
            g = au(e, c),
            h = au(e, d);
        return !Oa(a, k => ls(k, g) || ls(k, f) && !ls(k, h))
    }

    function HC(a, b, c, d) {
        const e = CC(a);
        if (FC(e, b, d.Aa)) return !0;
        if (!GC(e, b, c.uj, c.Rd, d)) return !1;
        const f = new RB(au(d.Aa, 0), 1);
        a = La(a.B, g => PB(g, f, c.Rd));
        b = Na(a, (g, h) => g + h.j);
        return a.length === 0 || b > c.qj ? !1 : !0
    };
    var IC = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function JC(a, b) {
        const c = new Bu,
            d = new at;
        b.forEach(e => {
            if (Vh(e, gv, 1, jv)) {
                e = Vh(e, gv, 1, jv);
                if (x(e, fv, 1) && x(e, fv, 1).ua() && x(e, fv, 2) && x(e, fv, 2).ua()) {
                    const g = KC(a, x(e, fv, 1).ua()),
                        h = KC(a, x(e, fv, 2).ua());
                    if (g && h)
                        for (var f of IC({
                                anchor: g,
                                position: x(e, fv, 1).j()
                            }, {
                                anchor: h,
                                position: x(e, fv, 2).j()
                            })) c.set(ta(f.anchor), f.position)
                }
                x(e, fv, 3) && x(e, fv, 3).ua() && (f = KC(a, x(e, fv, 3).ua())) && c.set(ta(f), x(e, fv, 3).j())
            } else Vh(e, hv, 2, jv) ? LC(a, Vh(e, hv, 2, jv), c) : Vh(e, ev, 3, jv) && MC(a, Vh(e, ev, 3, jv), d)
        });
        return new NC(c, d)
    }
    var NC = class {
        constructor(a, b) {
            this.j = a;
            this.g = b
        }
    };
    const LC = (a, b, c) => {
            x(b, fv, 2) ? (b = x(b, fv, 2), (a = KC(a, b.ua())) && c.set(ta(a), b.j())) : x(b, Fu, 1) && (a = OC(a, x(b, Fu, 1))) && a.forEach(d => {
                d = ta(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        MC = (a, b, c) => {
            x(b, Fu, 1) && (a = OC(a, x(b, Fu, 1))) && a.forEach(d => {
                c.add(ta(d))
            })
        },
        KC = (a, b) => (a = OC(a, b)) && a.length > 0 ? a[0] : null,
        OC = (a, b) => (b = xA(b)) ? pA(b, a) : null;
    var PC = class {
        constructor() {
            var a = Math.random;
            this.g = Math.floor(a() * 2 ** 52);
            this.j = 0
        }
    };

    function QC(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (RC(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function SC(a) {
        a = TC(a);
        return a.has("all") || a.has("after")
    }

    function UC(a) {
        a = TC(a);
        return a.has("all") || a.has("before")
    }

    function TC(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function RC(a) {
        const b = TC(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var VC = class {
        constructor() {
            this.g = new Set;
            this.j = new PC
        }
    };

    function WC(a) {
        return function(b) {
            return sB(b, a)
        }
    }

    function XC(a) {
        const b = ts(a);
        return b ? Ba(YC, b + Ps(a)) : sb
    }

    function ZC(a, b, c) {
        if (a < 0) throw Error("ama::ead:nd");
        if (a === Infinity) return sb;
        const d = CC(c || xC(b));
        return e => FC(d, a, e.Aa)
    }

    function $C(a, b, c, d) {
        if (a < 0 || b.uj < 0 || b.qj < 0 || b.Rd < 0) throw Error("ama::ead:nd");
        return a === Infinity ? sb : e => HC(d || xC(c, b.Rd), a, b, e)
    }

    function aD(a) {
        if (!a.length) return sb;
        const b = new qu(a);
        return c => b.contains(c.yd)
    }

    function bD(a) {
        return function(b) {
            for (let c of b.ie)
                if (a.indexOf(c) > -1) return !1;
            return !0
        }
    }

    function cD(a) {
        return a.length ? function(b) {
            const c = b.ie;
            return a.some(d => c.indexOf(d) > -1)
        } : tb
    }

    function dD(a, b) {
        if (a <= 0) return tb;
        const c = Ls(b).scrollHeight - a;
        return function(d) {
            return d.Aa.g <= c
        }
    }

    function eD(a) {
        const b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[Zh(c.Qf, 2) || 0]
        }
    }

    function fD(a) {
        return a.length ? b => a.includes(Zh(b.Qf, 1) || 0) : tb
    }

    function gD(a, b) {
        const c = JC(a, b);
        return function(d) {
            var e = d.ua();
            d = d.qa.j();
            d = DA[d];
            var f = c.j,
                g = ta(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(ta(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(ta(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function hD() {
        const a = new VC;
        return function(b) {
            var c = b.ua();
            b = b.qa.j();
            var d = DA[b];
            a: switch (d) {
                case 1:
                    b = SC(c.previousElementSibling) || UC(c);
                    break a;
                case 4:
                    b = SC(c) || UC(c.nextElementSibling);
                    break a;
                case 2:
                    b = UC(c.firstElementChild);
                    break a;
                case 3:
                    b = SC(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = QC(a, c, d);
            d = a.j;
            iC("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.j++,
                dvc: Vd()
            }, .1);
            return !(b || c)
        }
    }
    const YC = (a, b) => b.Aa.g >= a,
        iD = (a, b, c) => {
            c = c.Aa.j;
            return a <= c && c <= b
        };

    function jD(a, b, c, d, e) {
        var f = kD(lD(a, b), a);
        if (f.length === 0) {
            var g = !!x(b, vv, 6) ? .g() ? .length;
            f = x(b, rv, 28) ? .j() ? .j() && g ? kD(mD(a, b), a) : f
        }
        if (f.length === 0) return cw(d, "pfno"), [];
        b = f;
        a = e.Ue ? nD(a, b, c) : {
            zc: b,
            Ye: null
        };
        const {
            zc: h,
            Ye: k
        } = a;
        f = h;
        return f.length === 0 && k ? (cw(d, k), []) : [f[e.xn ? 0 : e.un ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function nD(a, b, c) {
        c = c ? Gh(c, iv, 5, ph()) : [];
        const d = gD(a.document, c),
            e = hD();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            zc: [],
            Ye: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            zc: [],
            Ye: "pfet"
        } : {
            zc: b,
            Ye: null
        }
    }

    function oD(a, b) {
        return a.Aa.g - b.Aa.g
    }

    function lD(a, b) {
        const c = x(b, vv, 6);
        if (!c) return [];
        b = x(b, rv, 28) ? .j();
        return (b ? .g() ? kB(c.g(), a) : jB(c.g(), a, !!b ? .B())).map(d => d.l())
    }

    function mD(a, b) {
        b = Gh(b, zv, 1, ph()) || [];
        return LA(b, a, {}).filter(c => !c.ie.includes(6))
    }

    function kD(a, b) {
        a = sB(a, b);
        const c = XC(b);
        a = a.filter(d => c(d));
        return a.sort(oD)
    };
    var pD = {},
        qD = {},
        rD = {},
        sD = {},
        tD = {};

    function uD() {
        throw Error("Do not instantiate directly");
    }
    uD.prototype.Ii = null;
    uD.prototype.ac = function() {
        return this.content
    };
    uD.prototype.toString = function() {
        return this.content
    };

    function vD(a) {
        if (a.Ji !== pD) throw Error("Sanitized content was not of kind HTML.");
        return Gc(a.toString())
    }

    function wD() {
        uD.call(this)
    }
    Ea(wD, uD);
    wD.prototype.Ji = pD;

    function xD(a) {
        if (a != null) switch (a.Ii) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function yD(a) {
        return zD(a, pD) ? a : a instanceof Fc ? AD(Hc(a).toString()) : AD(String(String(a)).replace(BD, CD), xD(a))
    }
    var AD = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            d !== void 0 && (c.Ii = d);
            return c
        }
    }(wD);

    function DD(a) {
        return ED(String(a), () => "").replace(FD, "&lt;")
    }
    const GD = RegExp.prototype.hasOwnProperty("sticky"),
        HD = new RegExp((GD ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", GD ? "gy" : "g");

    function ED(a, b) {
        const c = [],
            d = a.length;
        let e = 0,
            f = [],
            g, h, k = 0;
        for (; k < d;) {
            switch (e) {
                case 0:
                    var l = a.indexOf("<", k);
                    if (l < 0) {
                        if (c.length === 0) return a;
                        c.push(a.substring(k));
                        k = d
                    } else c.push(a.substring(k, l)), h = l, k = l + 1, GD ? (HD.lastIndex = k, l = HD.exec(a)) : (HD.lastIndex = 0, l = HD.exec(a.substring(k))), l ? (f = ["<", l[0]], g = l[1], e = 1, k += l[0].length) : c.push("<");
                    break;
                case 1:
                    l = a.charAt(k++);
                    switch (l) {
                        case "'":
                        case '"':
                            let m = a.indexOf(l, k);
                            m < 0 ? k = d : (f.push(l, a.substring(k, m + 1)), k = m + 1);
                            break;
                        case ">":
                            f.push(l);
                            c.push(b(f.join(""),
                                g));
                            e = 0;
                            f = [];
                            h = g = null;
                            break;
                        default:
                            f.push(l)
                    }
                    break;
                default:
                    throw Error();
            }
            e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
        }
        return c.join("")
    }

    function ID(a, b) {
        a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
        return b ? a.replace(/{/g, " \\{").replace(/}/g, " \\}").replace(/\/\*/g, "/ *").replace(/\\$/, "\\ ") : a
    }

    function V(a) {
        zD(a, pD) ? (a = DD(a.ac()), a = String(a).replace(JD, CD)) : a = String(a).replace(BD, CD);
        return a
    }

    function KD(a) {
        a = String(a);
        const b = (d, e, f) => {
            const g = Math.min(e.length - f, d.length);
            for (let k = 0; k < g; k++) {
                var h = e[f + k];
                if (d[k] !== ("A" <= h && h <= "Z" ? h.toLowerCase() : h)) return !1
            }
            return !0
        };
        for (var c = 0;
            (c = a.indexOf("<", c)) != -1;) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function LD(a) {
        if (a == null) return " null ";
        if (zD(a, qD)) return a.ac();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(MD, ND) + "'"
        }
    }
    const OD = /['()]/g;

    function PD(a) {
        return "%" + a.charCodeAt(0).toString(16)
    }

    function QD(a) {
        return String(a).replace(RD, SD)
    }

    function W(a) {
        return zD(a, tD) ? ID(a.ac(), !1) : a == null ? "" : a instanceof Rc ? ID(Sc(a), !1) : ID(String(a), !0)
    }

    function zD(a, b) {
        return a != null && a.Ji === b
    }

    function TD(a, b) {
        a.g !== void 0 ? a.g.push(b) : a.content += b;
        return a
    }

    function UD(a, b) {
        a.g !== void 0 ? a.g.push(b) : b instanceof VD ? b.content !== void 0 ? a.content += b.ac() : (a.g = [a.content, b], a.content = void 0) : a.content += b;
        return a
    }
    class VD extends wD {
        ac() {
            if (this.content !== void 0) return this.content;
            let a = "";
            for (const b of this.g) a += b;
            return a
        }
        toString() {
            return this.ac()
        }
    }
    const WD = (() => {
            function a() {
                this.content = ""
            }
            a.prototype = VD.prototype;
            return function() {
                return new a
            }
        })(),
        XD = {
            "\x00": "&#0;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\v": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            " ": "&#32;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "-": "&#45;",
            "/": "&#47;",
            "<": "&lt;",
            "=": "&#61;",
            ">": "&gt;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        };

    function CD(a) {
        return XD[a]
    }
    const YD = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function ND(a) {
        return YD[a]
    }
    const ZD = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function SD(a) {
        return ZD[a]
    }
    const BD = /[\x00\x22\x26\x27\x3c\x3e]/g,
        JD = /[\x00\x22\x27\x3c\x3e]/g,
        MD = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        RD = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        $D = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        aE = /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i,
        bE = /^[a-zA-Z0-9+\/_-]+={0,2}$/;

    function cE(a) {
        a = String(a);
        return bE.test(a) ? a : "zSoyz"
    }
    const FD = /</g;
    /* 
     
     
     Copyright Mathias Bynens <http://mathiasbynens.be/> 
     
     Permission is hereby granted, free of charge, to any person obtaining 
     a copy of this software and associated documentation files (the 
     "Software"), to deal in the Software without restriction, including 
     without limitation the rights to use, copy, modify, merge, publish, 
     distribute, sublicense, and/or sell copies of the Software, and to 
     permit persons to whom the Software is furnished to do so, subject to 
     the following conditions: 
     
     The above copyright notice and this permission notice shall be 
     included in all copies or substantial portions of the Software. 
     
     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
     EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
     MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
     NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
     LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
     OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
     WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
    */
    const dE = Math.floor;
    var eE = /^xn--/,
        fE = /[\x2E\u3002\uFF0E\uFF61]/g;
    const gE = {
        Zp: "Overflow: input needs wider integers to process",
        Wp: "Illegal input >= 0x80 (not a basic code point)",
        Ip: "Invalid input"
    };

    function hE(a) {
        throw RangeError(gE[a]);
    }

    function iE(a, b) {
        const c = a.split("@");
        let d = "";
        c.length > 1 && (d = c[0] + "@", a = c[1]);
        a = a.replace(fE, ".");
        a = a.split(".").map(b).join(".");
        return d + a
    }

    function jE(a) {
        return iE(a, b => {
            if (eE.test(b) && b.length > 4) {
                b = b.slice(4).toLowerCase();
                const h = [],
                    k = b.length;
                let l = 0,
                    m = 128;
                var c = 72,
                    d = b.lastIndexOf("-");
                d < 0 && (d = 0);
                for (var e = 0; e < d; ++e) b.charCodeAt(e) >= 128 && hE("Illegal input >= 0x80 (not a basic code point)"), h.push(b.charCodeAt(e));
                for (d = d > 0 ? d + 1 : 0; d < k;) {
                    e = l;
                    for (let n = 1, p = 36;; p += 36) {
                        d >= k && hE("Invalid input");
                        var f = b.charCodeAt(d++);
                        f = f - 48 < 10 ? f - 22 : f - 65 < 26 ? f - 65 : f - 97 < 26 ? f - 97 : 36;
                        (f >= 36 || f > dE((2147483647 - l) / n)) && hE("Overflow: input needs wider integers to process");
                        l += f * n;
                        var g = p <= c ? 1 : p >= c + 26 ? 26 : p - c;
                        if (f < g) break;
                        f = 36 - g;
                        n > dE(2147483647 / f) && hE("Overflow: input needs wider integers to process");
                        n *= f
                    }
                    f = h.length + 1;
                    c = l - e;
                    g = 0;
                    c = e == 0 ? dE(c / 700) : c >> 1;
                    for (c += dE(c / f); c > 455; g += 36) c = dE(c / 35);
                    c = dE(g + 36 * c / (c + 38));
                    dE(l / f) > 2147483647 - m && hE("Overflow: input needs wider integers to process");
                    m += dE(l / f);
                    l %= f;
                    h.splice(l++, 0, m)
                }
                b = String.fromCodePoint.apply(null, h)
            }
            return b
        })
    };

    function kE(a, b, c) {
        var d = a.O.contentWindow;
        a.Nd ? (b = {
            action: "search",
            searchTerm: b,
            rsToken: c
        }, b.experimentId = a.sb, a.alwaysSetAdSafeHigh && (b.alwaysSetAdSafeHigh = "1"), a.postMessage(d, b)) : (d = d.google.search.cse.element.getElement(a.hd), c = {
            rsToken: c,
            hostName: a.host
        }, a.Md || typeof a.sb !== "number" || (c.afsExperimentId = a.sb), d.execute(b, void 0, c))
    }
    var lE = class {
        constructor(a) {
            this.O = a.O;
            this.qb = a.qb;
            this.hd = a.hd;
            this.Hb = a.Hb;
            this.Ee = a.Ee;
            this.host = a.location.host;
            this.origin = a.location.origin;
            this.language = a.language;
            this.xd = a.xd;
            this.sb = a.sb;
            this.re = a.re || !1;
            this.Nd = a.Nd;
            this.Mc = a.Mc;
            this.ze = a.ze || !1;
            this.Md = a.Md || !1;
            this.Sf = !!a.Sf;
            this.alwaysSetAdSafeHigh = !!a.alwaysSetAdSafeHigh
        }
        postMessage(a, b) {
            a ? .postMessage(b, "https://www.gstatic.com")
        }
        init() {
            this.O.setAttribute("id", "prose-iframe");
            this.O.setAttribute("width", "100%");
            this.O.setAttribute("height",
                "100%");
            this.O.style.cssText = "box-sizing:border-box;border:unset;";
            var a = "https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(this.host);
            var b = zc(a, yc) || tc;
            var c = jE(this.host.startsWith("www.") ? this.host.slice(4) : this.host),
                d = {};
            a = this.hd;
            var e = this.Hb,
                f = this.Ee;
            const g = this.host;
            c = this.xd.replace("${website}", c);
            var h = this.re;
            const k = this.ze,
                l = this.Sf,
                m = d && d.Vd,
                n = d && d.Wk;
            d = WD();
            h = "<style" + (m ? ' nonce="' + V(cE(m)) + '"' : "") + ">.cse-favicon {display: block; float: left; height: 16px; position: absolute; left: 15px; width: 16px;}.cse-header {font-size: 16px; font-family: Arial; margin-left: 35px; margin-top: 6px; margin-bottom: unset; line-height: 16px;}.gsc-search-box {max-width: 520px !important;}.gsc-input {padding-right: 0 !important;}.gsc-input-box {border-radius: 16px 0 0 16px !important;}.gsc-search-button-v2 {border-left: 0 !important; border-radius: 0 16px 16px 0 !important; min-height: 30px !important; margin-left: 0 !important;}.gsc-cursor-page, .gsc-cursor-next-page, .gsc-cursor-numbered-page {color: #1a73e8 !important;}.gsc-cursor-chevron {fill: #1a73e8 !important;}.gsc-cursor-box {text-align: center !important;}.gsc-cursor-current-page {color: #000 !important;}.gcsc-find-more-on-google-root, .gcsc-find-more-on-google {display: none !important;}.prose-container {max-width: 652px;}#prose-empty-serp-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 52px; position: relative; width: 248px; height: 259px; margin: auto; top: 100px;}#prose-empty-serp-icon-image {display: flex; flex-direction: row; justify-content: center; align-items: center; padding: 30px; gap: 10px; width: 124px; height: 124px; border-radius: 62px; flex: none; order: 1; flex-grow: 0; position: absolute; top: 0;}#prose-empty-serp-text-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 19px; width: 248px; height: 83px; flex: none; order: 2; align-self: stretch; flex-grow: 0; position: absolute; top: 208px;}#prose-empty-serp-text-div {display: flex; flex-direction: column; align-items: flex-start; padding: 0; gap: 11px; width: 248px; height: 83px; flex: none; order: 0; align-self: stretch; flex-grow: 0;}#prose-empty-serp-supporting-text {width: 248px; height: 40px; font-family: 'Arial'; font-style: normal; font-weight: 400; font-size: 14px; line-height: 20px; text-align: center; letter-spacing: 0.2px; color: #202124; flex: none; order: 1; align-self: stretch; flex-grow: 0;}</style>" +
                (h ? "<script" + (n ? ' nonce="' + V(cE(n)) + '"' : "") + '>window.__gcse={initializationCallback:function(){top.postMessage({action:"init",adChannel:"' + String(f).replace(MD, ND) + '"},top.location.origin);}};\x3c/script>' : "") + '<div class="prose-container"><img class="cse-favicon" src="';
            zD(b, rD) || zD(b, sD) ? b = String(b).replace(RD, SD) : uc(b) ? b = QD(vc(b)) : b instanceof pc ? b = QD(rc(b).toString()) : (b = String(b), b = aE.test(b) ? b.replace(RD, SD) : "about:invalid#zSoyz");
            a = TD(UD(TD(d, h + V(b) + '" alt="' + V(g) + ' icon"><p class="cse-header"><strong>'),
                yD(c)), "</strong></p>" + (l ? '<div class="gcse-searchresults-only" data-gname="' + V(a) + '" data-adclient="' + V(e) + '" data-adchannel="' + V(f) + '" data-as_sitesearch="' + V(g) + '" data-personalizedAds="false" data-disableAds="true"></div>' : '<div class="gcse-search" data-gname="' + V(a) + '" data-adclient="' + V(e) + '" data-adchannel="' + V(f) + '" data-as_sitesearch="' + V(g) + '" data-personalizedAds="false"></div>') + "</div>" + (k ? "<div id=\"prose-empty-serp-container\"><img id='prose-empty-serp-icon-image' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI0IiBoZWlnaHQ9IjEyNCIgdmlld0JveD0iMCAwIDEyNCAxMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjQiIGhlaWdodD0iMTI0IiByeD0iNjIiIGZpbGw9IiNGMUYzRjQiLz4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02OS4zNiA2NS4zODY3TDg0LjY0IDgwLjY2NjdMODAuNjY2NyA4NC42NEw2NS4zODY3IDY5LjM2QzYyLjUzMzMgNzEuNDEzMyA1OS4wOTMzIDcyLjY2NjcgNTUuMzMzMyA3Mi42NjY3QzQ1Ljc2IDcyLjY2NjcgMzggNjQuOTA2NyAzOCA1NS4zMzMzQzM4IDQ1Ljc2IDQ1Ljc2IDM4IDU1LjMzMzMgMzhDNjQuOTA2NyAzOCA3Mi42NjY3IDQ1Ljc2IDcyLjY2NjcgNTUuMzMzM0M3Mi42NjY3IDU5LjA5MzMgNzEuNDEzMyA2Mi41MzMzIDY5LjM2IDY1LjM4NjdaTTU1LjMzMzMgNDMuMzMzM0M0OC42OTMzIDQzLjMzMzMgNDMuMzMzMyA0OC42OTMzIDQzLjMzMzMgNTUuMzMzM0M0My4zMzMzIDYxLjk3MzMgNDguNjkzMyA2Ny4zMzMzIDU1LjMzMzMgNjcuMzMzM0M2MS45NzMzIDY3LjMzMzMgNjcuMzMzMyA2MS45NzMzIDY3LjMzMzMgNTUuMzMzM0M2Ny4zMzMzIDQ4LjY5MzMgNjEuOTczMyA0My4zMzMzIDU1LjMzMzMgNDMuMzMzM1oiIGZpbGw9IiM5QUEwQTYiLz4KPC9zdmc+Cg==' alt=''><div id='prose-empty-serp-text-container'><div id='prose-empty-serp-text-div'><div id='prose-empty-serp-supporting-text'>Search this website by entering a keyword.</div></div></div></div>" :
                ""));
            a = vD(a);
            this.Nd ? (a = this.O, e = ud `https://www.gstatic.com/prose/protected/${this.Mc||"558153351"}/iframe.html?cx=${this.qb}&host=${this.host}&hl=${this.language}&lrh=${this.xd}&client=${this.Hb}&origin=${this.origin}`, e = this.Sf && T(Tw) ? vd(e, {
                soo: 1
            }) : e, a.src = rc(e).toString()) : (e = new Map([
                ["cx", this.qb],
                ["language", this.language]
            ]), this.Md && (f = [], Array.isArray(this.sb) ? f.push(...this.sb) : typeof this.sb === "number" && f.push(this.sb), f.length && e.set("fexp", f.join())), e = vd(ud `https://cse.google.com/cse.js`,
                e), e = rc(e).toString(), e = Gc(`<script src="${gd(e)}"` + ">\x3c/script>"), a = od("body", {
                style: "margin:0;"
            }, [a, e]), this.O.srcdoc = Hc(a))
        }
    };

    function mE(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = [])) : a.google_reactive_ads_global_state = new nE;
        return a.google_reactive_ads_global_state
    }
    var nE = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new oE;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.g =
                    null;
                this.clickTriggeredInterstitialMayBeDisplayed = !1
            }
        },
        oE = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };

    function pE(a, b) {
        return new qE(a, b)
    }

    function rE(a) {
        const b = sE(a);
        Ja(a.floatingAdsStacking.maxZIndexListeners, c => c(b))
    }

    function sE(a) {
        a = Gd(a.floatingAdsStacking.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function tE(a, b) {
        Ua(a.floatingAdsStacking.maxZIndexListeners, c => c === b)
    }
    var uE = class {
        constructor(a) {
            this.floatingAdsStacking = mE(a).floatingAdsStacking
        }
    };

    function vE(a) {
        if (a.g == null) {
            var b = a.controller,
                c = a.Jc;
            const d = b.floatingAdsStacking.nextRestrictionId++;
            b.floatingAdsStacking.maxZIndexRestrictions[d] = c;
            rE(b);
            a.g = d
        }
    }

    function wE(a) {
        if (a.g != null) {
            var b = a.controller;
            delete b.floatingAdsStacking.maxZIndexRestrictions[a.g];
            rE(b);
            a.g = null
        }
    }
    var qE = class {
        constructor(a, b) {
            this.controller = a;
            this.Jc = b;
            this.g = null
        }
    };

    function xE(a) {
        a = a.activeElement;
        const b = a ? .shadowRoot;
        return b ? xE(b) || a : a
    }

    function yE(a, b) {
        return zE(b, a.document.body).flatMap(c => AE(c))
    }

    function zE(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = ((e = c.mode && c.host ? c : null) == null ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function AE(a) {
        const b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function BE(a) {
        a.state !== null && (a.state.pl.forEach(b => {
            b.inert = !1
        }), a.state.Jm ? .focus(), a.state = null)
    }

    function CE(a, b) {
        BE(a);
        const c = xE(a.C.document);
        b = yE(a.C, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.state = {
            Jm: c,
            pl: b
        }
    }
    var DE = class {
        constructor(a) {
            this.C = a;
            this.state = null
        }
        Xf() {
            BE(this)
        }
    };

    function EE(a) {
        return new FE(a, new mt(a, a.document.body), new mt(a, a.document.documentElement), new mt(a, a.document.documentElement))
    }

    function GE(a) {
        lt(a.l, "scroll-behavior", "auto");
        var b = HE(a.C);
        b.activePageScrollPreventers.add(a);
        b.previousWindowScroll === null && (b.previousWindowScroll = a.C.scrollY);
        lt(a.g, "position", "fixed");
        lt(a.g, "top", `${-b.previousWindowScroll}px`);
        lt(a.g, "width", "100%");
        lt(a.g, "overflow-x", "hidden");
        lt(a.g, "overflow-y", "hidden");
        b = getComputedStyle(a.C.document.documentElement);
        IE(b.overflowX) && lt(a.j, "overflow-x", "unset");
        IE(b.overflowY) && lt(a.j, "overflow-y", "unset")
    }

    function IE(a) {
        return a === "scroll" || a === "auto"
    }

    function JE(a) {
        kt(a.g);
        kt(a.j);
        const b = HE(a.C);
        b.activePageScrollPreventers.delete(a);
        b.activePageScrollPreventers.size === 0 && (a.C.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        kt(a.l)
    }
    var FE = class {
        constructor(a, b, c, d) {
            this.C = a;
            this.g = b;
            this.j = c;
            this.l = d
        }
    };

    function HE(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function KE(a) {
        return a.googPageScrollPreventerInfo && a.googPageScrollPreventerInfo.activePageScrollPreventers.size > 0 ? !0 : !1
    };

    function LE(a, b) {
        return ME(`#${a}`, b)
    }

    function NE(a, b) {
        return ME(`.${a}`, b)
    }

    function ME(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function OE(a, b) {
        const c = a.document.createElement("div");
        fw(a, c);
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            qc: c,
            shadowRoot: a
        }
    };

    function PE(a, b) {
        b = OE(a, b);
        a.document.body.appendChild(b.qc);
        return b
    }

    function QE(a, b) {
        const c = new P(b.X);
        vt(b, !0, () => void c.g(!0));
        vt(b, !1, () => {
            a.setTimeout(() => {
                b.X || c.g(!1)
            }, 700)
        });
        return qt(c)
    };

    function RE(a) {
        var b = {},
            c = a.bf,
            d = a.Wh,
            e = a.Xe;
        const f = a.Oe,
            g = a.Ai,
            h = a.zIndex,
            k = a.mg;
        a = a.Lb;
        b = b && b.Vd;
        c = "<style" + (b ? ' nonce="' + V(cE(b)) + '"' : "") + ">#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + W(h) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            W(c) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ";
        d = d ? a ? 20 : 16 : 0;
        c += W(d) + "px; transition: transform " + W(k) + "s ease-in-out;" + (e ? "left: 0; border-top-right-radius: " + W(d) + "px; border-bottom-right-radius: " + W(d) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + W(d) + "px; border-bottom-left-radius: " + W(d) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {" + (a ?
                "height: 24px;" : "padding: 5px;") + "}.hd-control-button {border: none; background: none; cursor: pointer;" + (a ? "" : "padding: 5px;") + "}#hd-back-arrow-button {" + (e ? "float: right;" : "float: left;") + "}#hd-close-button {" + (e ? "float: left;" : "float: right;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' +
            V(g) + '">';
        e = a ? "#5F6368" : "#444746";
        c += '<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + V(e) + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button><button id="hd-close-button" class="hd-control-button" aria-label="' + V(f) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + V(e) + '"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button></div><div id="hd-content-container"></div></div></div>';
        return AD(c)
    };

    function SE(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && b.pushState && typeof b.pushState === "function" ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new TE(a, b);
        b.init();
        return b ? a.googNavStack = b : null
    }

    function UE(a, b) {
        return b ? b.googNavStackId === a.j ? b : null : null
    }

    function VE(a, b) {
        for (let c = b.length - 1; c >= 0; --c) {
            const d = c === 0;
            a.P.requestAnimationFrame(() => void b[c].Wm({
                isFinal: d
            }))
        }
    }

    function UF(a, b) {
        b = $a(a.stack, b, (c, d) => c - d.fj.googNavStackStateId);
        if (b >= 0) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class TE extends O {
        constructor(a, b) {
            super();
            this.P = a;
            this.history = b;
            this.stack = [];
            this.j = Math.random() * 1E9 >>> 0;
            this.A = 0;
            this.l = c => {
                (c = UE(this, c.state)) ? VE(this, UF(this, c.googNavStackStateId + .5)): VE(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            const a = {
                    googNavStackId: this.j,
                    googNavStackStateId: this.A++
                },
                b = new Promise(c => {
                    this.stack.push({
                        Wm: c,
                        fj: a
                    })
                });
            this.history.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    const c = UF(this, a.googNavStackStateId);
                    var d;
                    if (d = c.length >
                        0) {
                        d = c[0].fj;
                        const e = UE(this, this.history.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.history.go(-c.length);
                    VE(this, c)
                }
            }
        }
        init() {
            this.P.addEventListener("popstate", this.l)
        }
        g() {
            this.P.removeEventListener("popstate", this.l);
            super.g()
        }
    };

    function VF(a) {
        return (a = SE(a)) ? new WF(a) : null
    }

    function XF(a) {
        if (!a.j) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.A.pushEvent();
            a.j = c;
            b.then(() => {
                a.j && !a.B && (a.j = null, Bt(a.l))
            })
        }
    }
    var WF = class extends O {
        constructor(a) {
            super();
            this.A = a;
            this.l = new Ct;
            this.j = null
        }
    };

    function YF(a, b, c) {
        var d = c.Ig ? null : new DE(a);
        const e = pE(new uE(a), c.zIndex - 1);
        b = ZF(a, b, c);
        d = new $F(a, b, d, c.ce, EE(a), e);
        d.init();
        (c.Qi || c.Qi === void 0) && aG(d);
        c.Zd && ((a = VF(a)) ? bG(d, a, c.Ih) : c.Ih ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function aG(a) {
        a.D = b => {
            b.key === "Escape" && a.j.X && a.collapse()
        };
        a.C.document.body.addEventListener("keydown", a.D)
    }

    function bG(a, b, c) {
        vt(a.j, !0, () => {
            try {
                XF(b)
            } catch (d) {
                c ? .(d)
            }
        });
        vt(a.j, !1, () => {
            try {
                b.j && (b.j(), b.j = null)
            } catch (d) {
                c ? .(d)
            }
        });
        zt(b.l).listen(() => void a.collapse());
        it(a, b)
    }

    function cG(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.F
    }

    function dG(a) {
        a.C.setTimeout(() => {
            a.j.X && cG(a).rb.focus()
        }, 500)
    }

    function eG(a) {
        const {
            Hh: b,
            Rk: c
        } = cG(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function fG(a) {
        vt(a.l, !1, () => {
            cG(a).rb.classList.add("hd-hidden")
        })
    }
    var $F = class extends O {
        constructor(a, b, c, d = !0, e, f) {
            super();
            this.C = a;
            this.F = b;
            this.A = c;
            this.ce = d;
            this.j = new P(!1);
            this.l = QE(a, this.j);
            vt(this.l, !0, () => {
                GE(e);
                vE(f)
            });
            vt(this.l, !1, () => {
                JE(e);
                wE(f)
            })
        }
        show({
            Oi: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            cG(this).rb.classList.remove("hd-hidden");
            gt(this.C);
            cG(this).rb.classList.add("hd-revealed");
            this.j.g(!0);
            this.A && (CE(this.A, cG(this).sc.qc), this.ce && dG(this));
            a && vt(this.l, !1, () => {
                this.dispose()
            })
        }
        collapse() {
            cG(this).rb.classList.remove("hd-revealed");
            this.j.g(!1);
            this.A ? .Xf()
        }
        isVisible() {
            return this.l
        }
        init() {
            eG(this);
            fG(this)
        }
        g() {
            this.D && this.C.document.body.removeEventListener("keydown", this.D);
            const a = this.F.sc.qc,
                b = a.parentNode;
            b && b.removeChild(a);
            this.A ? .Xf();
            super.g()
        }
    };

    function ZF(a, b, c) {
        const d = PE(a, c.Jg),
            e = d.shadowRoot;
        e.appendChild(Xk(new Hk(a.document), vD(RE({
            bf: c.bf,
            Wh: c.Wh ? ? !0,
            Xe: c.Xe || !1,
            Oe: c.Oe,
            Ai: c.Ai || "",
            zIndex: c.zIndex,
            mg: .5,
            Lb: c.Lb || !1
        }))));
        const f = LE("hd-drawer-container", e);
        c.Pg ? .j(g => {
            f.setAttribute("aria-label", g)
        });
        c = LE("hd-content-container", e);
        c.appendChild(b);
        gt(a);
        return {
            rb: f,
            Hh: LE("hd-modal-background", e),
            yg: c,
            Rk: LE("hd-close-button", e),
            Wq: LE("hd-back-arrow-button", e),
            sc: d
        }
    };

    function gG(a) {
        var b = {};
        const c = a.Dm,
            d = a.El;
        var e = a.zIndex,
            f = a.mg;
        a = a.Lb;
        b = b && b.Vd;
        e = TD(WD(), "<style" + (b ? ' nonce="' + V(cE(b)) + '"' : "") + ">#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + W(e) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
            W(d) + "%; transition: transform " + W(f) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round ");
        f = a ? 20 : 28;
        TD(UD(TD(UD(TD(e, W(f) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
                W(c / d * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + W((d - c) / d * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
                W(c / d * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + W(c / d * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + W(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
                W(f) + "px " + W(f) + "px 0 0; background: white; display: flex; height: " + W(30) + "px; justify-content: center; cursor: grab;}.ved-handle-icon {" + (a ? "background: #dadce0; width: 50px;" : "background: #747775; opacity: 0.4; width: 32px;") + 'border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">'),
            hG("ved-moving-handle")), '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">'), hG("ved-fixed-handle")), "</div></div></div>");
        return e
    }

    function hG(a) {
        return AD('<div class="ved-handle" id="' + V(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function iG(a) {
        return Qt(a.g).map(b => b ? jG(a, b) : 0)
    }

    function jG(a, b) {
        switch (a.direction) {
            case 0:
                return kG(-b.dk);
            case 1:
                return kG(-b.ck);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function lG(a) {
        return St(a.g).map(b => jG(a, b))
    }
    var mG = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function kG(a) {
        return a === 0 ? 0 : a
    };

    function nG(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.F
    }

    function oG(a) {
        a.C.setTimeout(() => {
            a.j.X && nG(a).rb.focus()
        }, 500)
    }

    function pG(a) {
        nG(a).rb.classList.remove("ved-hidden");
        gt(a.C);
        const {
            Ga: b,
            jc: c
        } = nG(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || qG(a);
        nG(a).rb.classList.add("ved-revealed");
        a.j.g(!0);
        a.l && (CE(a.l, nG(a).sc.qc), a.ce && oG(a))
    }

    function rG(a) {
        return QE(a.C, a.j)
    }

    function sG(a, b) {
        const c = new P(b());
        zt(a.K).listen(() => void c.g(b()));
        return qt(c)
    }

    function tG(a) {
        const {
            Ga: b,
            Ef: c
        } = nG(a);
        return sG(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function uG(a) {
        const {
            Ga: b,
            Ef: c
        } = nG(a);
        return sG(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function vG(a) {
        const {
            Ga: b
        } = nG(a);
        return sG(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function wG(a) {
        return rt(tG(a), vG(a))
    }

    function xG(a) {
        const {
            Ga: b,
            jc: c
        } = nG(a);
        return sG(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function qG(a) {
        nG(a).jc.classList.add("ved-snap-point-top");
        var b = yG(a, nG(a).jc);
        nG(a).Ga.scrollTop = b;
        zG(a)
    }

    function AG(a) {
        tt(tG(a), !0, () => {
            const {
                Yi: b,
                ye: c
            } = nG(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        tt(tG(a), !1, () => {
            const {
                Yi: b,
                ye: c
            } = nG(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function BG(a) {
        const b = Xt(a.C, nG(a).yg);
        $t(b).j(() => void CG(a));
        it(a, b)
    }

    function DG(a) {
        tt(EG(a), !0, () => {
            nG(a).Bj.classList.remove("ved-hidden")
        });
        tt(EG(a), !1, () => {
            nG(a).Bj.classList.add("ved-hidden")
        })
    }

    function FG(a) {
        const b = () => void Bt(a.G),
            {
                Hh: c,
                jc: d,
                Dl: e
            } = nG(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        vt(GG(a), !0, b)
    }

    function HG(a) {
        vt(rG(a), !1, () => {
            qG(a);
            nG(a).rb.classList.add("ved-hidden")
        })
    }

    function zG(a) {
        ut(a.A, !1, () => void Bt(a.K))
    }

    function CG(a) {
        if (!a.A.X) {
            var {
                Ki: b,
                yg: c
            } = nG(a), d = c.getBoundingClientRect().height;
            d = Math.max(IG(a), d);
            a.A.g(!0);
            var e = JG(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.C.requestAnimationFrame(() => {
                a.C.requestAnimationFrame(() => {
                    a.A.g(!1)
                })
            })
        }
    }

    function EG(a) {
        const {
            Ga: b,
            jc: c
        } = nG(a);
        return sG(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function GG(a) {
        return pt(a.D.map(Cu), KG(a))
    }

    function KG(a) {
        return sG(a, () => nG(a).Ga.scrollTop === 0)
    }

    function yG(a, b) {
        ({
            ye: a
        } = nG(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function LG(a, b) {
        a.D.g(!0);
        const {
            ye: c,
            Ga: d
        } = nG(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void MG(a, b)
    }

    function MG(a, b) {
        const {
            ye: c,
            Ga: d
        } = nG(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        nG(a).Ga.scrollTop = b;
        zG(a);
        a.D.g(!1)
    }

    function JG(a) {
        const b = nG(a).Ga.scrollTop;
        LG(a, b);
        return () => void MG(a, b)
    }

    function IG(a) {
        const {
            Ga: b,
            Ef: c,
            Ki: d,
            jc: e
        } = nG(a);
        a = b.getBoundingClientRect();
        const f = c.getBoundingClientRect();
        var g = d.getBoundingClientRect();
        const h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var NG = class extends O {
        constructor(a, b, c, d, e = !0) {
            super();
            this.C = a;
            this.F = b;
            this.T = c;
            this.l = d;
            this.ce = e;
            this.G = new Ct;
            this.K = new Ct;
            this.j = new P(!1);
            this.D = new P(!1);
            this.A = new P(!1)
        }
        init() {
            qG(this);
            AG(this);
            BG(this);
            DG(this);
            FG(this);
            HG(this);
            nG(this).Ga.addEventListener("scroll", () => void zG(this))
        }
        g() {
            const a = this.F.sc.qc,
                b = a.parentNode;
            b && b.removeChild(a);
            this.l ? .Xf();
            super.g()
        }
    };

    function OG(a, b, c) {
        const d = PE(a, c.Jg),
            e = d.shadowRoot;
        e.appendChild(Xk(new Hk(a.document), vD(gG({
            Dm: c.Cj * 100,
            El: c.Zi * 100,
            zIndex: c.zIndex,
            mg: .5,
            Lb: c.Lb || !1
        }))));
        const f = LE("ved-drawer-container", e);
        c.Pg ? .j(g => {
            f.setAttribute("aria-label", g)
        });
        c = LE("ved-content-container", e);
        c.appendChild(b);
        gt(a);
        return {
            rb: f,
            Hh: LE("ved-modal-background", e),
            Yj: LE("ved-ui-revealer", e),
            Ga: LE("ved-scroller", e),
            ye: LE("ved-scrolled-stack", e),
            Dl: LE("ved-fully-closed-anchor", e),
            jc: LE("ved-partially-extended-anchor", e),
            Ki: LE("ved-content-sizer",
                e),
            yg: c,
            dr: LE("ved-moving-handle", e),
            Ef: LE("ved-moving-handle-holder", e),
            Al: LE("ved-fixed-handle", e),
            Yi: LE("ved-fixed-handle-holder", e),
            Bj: LE("ved-over-scroll-block", e),
            sc: d
        }
    };

    function PG(a, b, c) {
        var d = pE(new uE(a), c.zIndex - 1);
        b = OG(a, b, c);
        const e = c.Ig ? null : new DE(a);
        var f = b.Al;
        f = new Tt(new Kt(a, f), new Ht(f));
        var g = f.g;
        g.A.addEventListener("mousedown", g.F);
        g.B.addEventListener("mouseup", g.D);
        g.B.addEventListener("mousemove", g.J, {
            passive: !1
        });
        g = f.j;
        g.j.addEventListener("touchstart", g.J);
        g.j.addEventListener("touchend", g.A);
        g.j.addEventListener("touchmove", g.D, {
            passive: !1
        });
        b = new NG(a, b, new mG(f), e, c.ce);
        b.init();
        d = new QG(a, b, EE(a), d);
        it(d, b);
        d.init();
        c.Zd && ((a = VF(a)) ? RG(d,
            a, c.Ih) : c.Ih ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function RG(a, b, c) {
        vt(a.j.j, !0, () => {
            try {
                XF(b)
            } catch (d) {
                c ? .(d)
            }
        });
        vt(a.j.j, !1, () => {
            try {
                b.j && (b.j(), b.j = null)
            } catch (d) {
                c ? .(d)
            }
        });
        zt(b.l).listen(() => void a.collapse());
        it(a, b)
    }

    function SG(a) {
        vt(pt(wG(a.j), xG(a.j)), !0, () => {
            nG(a.j).jc.classList.remove("ved-snap-point-top")
        });
        tt(uG(a.j), !0, () => {
            nG(a.j).Ga.classList.add("ved-no-snap")
        });
        tt(uG(a.j), !1, () => {
            nG(a.j).Ga.classList.remove("ved-no-snap")
        });
        vt(uG(a.j), !1, () => {
            var b = a.j;
            var c = nG(b).Ef;
            c = LG(b, yG(b, c));
            b.C.setTimeout(c, 100)
        })
    }

    function TG(a) {
        const b = a.j.T;
        iG(b).listen(c => {
            c = -c;
            if (c > 0) {
                const {
                    Yj: d
                } = nG(a.j);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                Yj: c
            } = nG(a.j)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        lG(b).listen(c => {
            -c > 30 && a.collapse()
        })
    }
    var QG = class extends O {
        constructor(a, b, c, d) {
            super();
            this.C = a;
            this.j = b;
            vt(rG(b), !0, () => {
                GE(c);
                vE(d)
            });
            vt(rG(b), !1, () => {
                JE(c);
                wE(d)
            })
        }
        show({
            Oi: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            pG(this.j);
            a && vt(rG(this.j), !1, () => {
                this.dispose()
            })
        }
        collapse() {
            var a = this.j;
            nG(a).rb.classList.remove("ved-revealed");
            a.j.g(!1);
            a.l ? .Xf()
        }
        isVisible() {
            return rG(this.j)
        }
        init() {
            zt(this.j.G).listen(() => {
                this.collapse()
            });
            SG(this);
            TG(this);
            gt(this.C)
        }
    };

    function UG(a, b) {
        return Vd() === 2 ? PG(a.C, b, {
            Cj: .95,
            Zi: .95,
            zIndex: 2147483645,
            Zd: !0,
            Lb: !0
        }) : YF(a.C, b, {
            bf: "min(65vw, 768px)",
            Oe: "",
            Xe: !1,
            zIndex: 2147483645,
            Zd: !0,
            Wh: !1,
            Lb: !0
        })
    }

    function VG(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.C, "_googCsa");
        const b = a.Qe.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.Hb,
                styleId: "5134551505",
                hl: a.language,
                fexp: a.A.join(","),
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.T.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.qb
            };
        a.G && (c.adLoadedCallback = a.K.bind(a));
        a.C._googCsa("relatedsearch", c, b)
    }

    function WG(a) {
        a.C.addEventListener("message", b => {
            b.origin === "https://www.gstatic.com" && b.data.action === "resize" && (a.j.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var XG = class extends O {
        constructor(a) {
            super();
            this.C = a.C;
            this.Qe = a.Qe;
            this.Eb = a.Eb;
            this.Oh = a.Oh ? ? (() => {});
            this.language = a.oj ? .g() || "en";
            this.G = T(tx);
            this.Hb = a.ob.replace("ca", "partner");
            this.D = new Hk(this.C.document);
            this.j = Wk(this.D, "IFRAME");
            this.qb = a.ek.g ? a.ek.qb : "9d449ff4a772956c6";
            this.A = M(bs).g().concat(a.experimentId);
            const b = a.oj ? .j() || "Search results from ${website}";
            this.l = new lE({
                O: this.j,
                qb: this.qb,
                hd: "auto-rs-prose",
                Hb: this.Hb,
                Ee: "AutoRsVariant",
                location: this.C.location,
                language: this.language,
                xd: b,
                sb: this.A,
                Nd: !0,
                Mc: a.Mc,
                re: !1,
                ze: !1,
                Md: !0,
                alwaysSetAdSafeHigh: a.alwaysSetAdSafeHigh
            });
            this.F = UG(this, this.j);
            it(this, this.F)
        }
        init() {
            this.Qe.length !== 0 && (this.G || vA(1075, () => {
                this.l.init()
            }, this.C), vA(1076, () => {
                const a = Wk(this.D, "SCRIPT");
                Lc(a, ud `https://www.google.com/adsense/search/async-ads.js`);
                this.C.document.head.appendChild(a)
            }, this.C), VG(this), aw(this.Eb, {
                sts: "ok"
            }), WG(this))
        }
        K(a, b) {
            b ? vA(1075, () => {
                this.l.init()
            }, this.C) : (this.Oh(), cw(this.Eb, "pfns"))
        }
        T(a, b) {
            kE(this.l, a, b);
            this.F.show()
        }
    };
    var YG = class {
        constructor(a, b) {
            this.g = a;
            this.qb = b
        }
    };
    var ZG = class {
        constructor(a, b, c) {
            this.A = a;
            this.j = b;
            this.D = c;
            this.B = "autors-widget";
            this.g = null;
            this.l = new P(null)
        }
        init() {
            var a = this.j.qa;
            a = lw(a.g.document, a.G || !1);
            const b = this.D.ac(this.A);
            a.appendChild(b);
            this.B && (a.className = this.B);
            this.g = a;
            qB(this.j, this.g);
            this.l.g(b)
        }
        remove() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.l.g(null)
        }
    };
    async function $G(a) {
        await new Promise(b => {
            setTimeout(() => {
                a.run();
                b()
            })
        })
    }

    function aH(a) {
        if ((!a.Ue || !bH(a.config, a.ma, a.Eb)) && cH(x(a.g, pv, 5), a.Eb)) {
            var b = a.g.j();
            b = jD(a.C, a.config, a.ma, a.Eb, {
                xn: !!b ? .D(),
                Ue: a.Ue,
                er: !!b ? .g(),
                un: !!b ? .J()
            });
            b = dH(b, a.C);
            var c = Object.keys(b),
                d = Object.values(b),
                e = Yv(a.g.g() ? .g()) || 0,
                f = eH(a.g),
                g = String(C(a.g, 13));
            b = x(a.config, mv, 25) ? .g() || !1;
            var h = a.g ? .B() || !1;
            if (!b) {
                var k = () => {
                    d.forEach(l => {
                        l.remove()
                    })
                };
                vA(1074, () => {
                    const l = {
                        C: a.C,
                        Qe: c,
                        ob: a.ob,
                        oj: x(a.g, pv, 5),
                        Eb: a.Eb,
                        experimentId: e,
                        ek: f,
                        Mc: g,
                        Oh: k,
                        alwaysSetAdSafeHigh: h
                    };
                    (new XG(l)).init()
                }, a.C)
            }
        }
    }
    var fH = class {
        constructor(a, b, c, d, e) {
            this.C = a;
            this.config = c;
            this.ob = d;
            this.ma = e;
            this.Ue = !0;
            this.g = x(this.config, rv, 28);
            this.Eb = new dw(a, b, this.g)
        }
        run() {
            try {
                aH(this)
            } catch (a) {
                cw(this.Eb, "pfere", a)
            }
        }
    };

    function bH(a, b, c) {
        a = Yv(x(a, rv, 28) ? .g() ? .g()) || 0;
        const d = wz(xx);
        return d && d.includes(a.toString()) ? !1 : (b ? Uh(b, 2) : []).length === 0 ? (cw(c, "pfeu"), !0) : !1
    }

    function cH(a, b) {
        const c = wz(wx);
        a = a ? .g() || "";
        return c && c.length !== 0 && !c.includes(a.toString()) ? (cw(b, "pflna"), !1) : !0
    }

    function dH(a, b) {
        const c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            const f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new ZG(b, d, new iw(g));
            d.init();
            c[f] = d
        }
        return c
    }

    function eH(a) {
        const b = A(a, 11) || !1;
        a = C(a, 8) || "";
        return new YG(b, a)
    };
    var gH = (a, b) => {
        const c = [];
        x(a, Av, 18) && c.push(2);
        b.ma && c.push(0);
        if (b = x(a, rv, 28)) b = x(a, rv, 28), b = D(b, 1) == 1;
        b && c.push(1);
        if (b = x(a, Ev, 34)) a = x(a, Ev, 34), b = A(a, 3);
        b && c.push(7);
        return c
    };
    var hH = a => a.googlefc = a.googlefc || {},
        iH = a => {
            a = a.googlefc = a.googlefc || {};
            return a.__fcusi = a.__fcusi || {}
        },
        jH = a => {
            a = a.googlefc = a.googlefc || {};
            if (!a.getFloatingToolbarTranslatedMessages) return null;
            if (a = a.getFloatingToolbarTranslatedMessages()) {
                var b = new sv;
                b = fi(b, 1, a.defaultFloatingToolbarToggleExpansionText);
                b = fi(b, 2, a.defaultFloatingToolbarTogglePrivacySettings);
                a = fi(b, 3, a.defaultFloatingToolbarDismissPrivacySettings);
                a = bh(a)
            } else a = null;
            return a
        };

    function kH(a, b) {
        b = b.filter(c => x(c, Pu, 4) ? .g() === 5 && wf(w(c, 8)) === 1);
        b = LA(b, a);
        a = sB(b, a);
        a.sort((c, d) => d.Aa.g - c.Aa.g);
        return a[0] || null
    };

    function lH({
        bi: a,
        Rg: b,
        Jh: c,
        ci: d,
        Sg: e,
        Kh: f
    }) {
        const g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (k === 0 ? 0 : h / k) * (b - a),
                    y: d + (m === 0 ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function mH(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function nH(a, b) {
        var c = lH({
            bi: b.left,
            Rg: b.right,
            Jh: 10,
            ci: b.top,
            Sg: b.bottom,
            Kh: 10
        });
        b = new Set;
        for (const d of c)(c = oH(a, d)) && b.add(c);
        return b
    }

    function pH(a, b, c = !1) {
        for (const d of b)
            if ((b = oH(a, d)) && !b.hasAttribute("google-allow-overlap")) {
                if (c) {
                    const e = b.getBoundingClientRect();
                    if (e.width >= a.P.innerWidth && e.height >= a.P.innerHeight) continue
                }
                return b
            }
        return null
    }

    function qH(a, b, c = !1) {
        return pH(a, b, c) != null
    }

    function rH(a, b, c) {
        if (gl(b, "position") !== "fixed") return null;
        var d = b.getAttribute("class") === "GoogleActiveViewInnerContainer" || ll(b).width <= 1 && ll(b).height <= 1 || a.g.ml && !a.g.ml(b) ? !0 : !1;
        a.g.Xi && a.g.Xi(b, c, d);
        return d ? null : b
    }

    function oH(a, b) {
        var c = mH(a.P.document, b);
        if (c) {
            var d;
            if (!(d = rH(a, c, b))) a: {
                d = a.P.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    const e = rH(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    }
    var sH = class {
        constructor(a, b = {}) {
            this.P = a;
            this.g = b
        }
    };
    var tH = class {
        constructor(a, b, c) {
            this.position = a;
            this.Vc = b;
            this.gh = c
        }
    };

    function uH(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    };

    function vH(a, b, c) {
        var d = ts(a);
        d = new tH(b.Id.vj(b.Bc), b.Vc + 2 * b.Bc, Math.min(d, b.vf) - b.Id.cf() + 2 * b.Bc);
        d = d.position.Li(a, d.Vc, d.gh);
        var e = ss(a),
            f = ts(a);
        c = wH(a, new Yk(Ak(d.top, f - 1), Ak(d.right, e - 1), Ak(d.bottom, f - 1), Ak(d.left, e - 1)), c);
        f = xH(c);
        let g = d.top;
        e = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && e.push(new uH(g, f[h].start)), g = f[h].end;
        g < d.bottom && e.push(new uH(g, d.bottom));
        a = ts(a);
        d = [];
        for (f = e.length - 1; f >= 0; f--) d.push(new uH(a - e[f].end, a - e[f].start));
        a: {
            for (const h of d)
                if (a = h.start + b.Bc, a > b.Id.cf() +
                    b.Ah ? a = null : (d = Math.min(h.end - b.Bc, b.vf) - a, a = d < b.Gh ? null : {
                        position: b.Id.bk(a),
                        ne: d
                    }), a) {
                    b = a;
                    break a
                }
            b = null
        }
        return {
            rg: b,
            Vq: c
        }
    }

    function wH(a, b, c) {
        const d = nH(new sH(a), b);
        c.forEach(e => void d.delete(e));
        return d
    }

    function xH(a) {
        return [...a].map(yH).sort((b, c) => b.start - c.start)
    }

    function yH(a) {
        a = a.getBoundingClientRect();
        return new uH(a.top, a.bottom)
    };

    function zH({
        sa: a,
        kb: b
    }) {
        return new AH(a, b)
    }
    var AH = class {
        constructor(a, b) {
            this.sa = a;
            this.kb = b
        }
        vj(a) {
            return new AH(this.sa - a, this.kb - a)
        }
        Li(a, b, c) {
            a = ts(a) - this.sa - c;
            return new Yk(a, this.kb + b, a + c, this.kb)
        }
        yi(a) {
            a.bottom = `${this.sa}px`;
            a.left = `${this.kb}px`;
            a.right = ""
        }
        aj() {
            return 0
        }
        cf() {
            return this.sa
        }
        bk(a) {
            return new AH(a, this.kb)
        }
    };

    function BH({
        sa: a,
        zb: b
    }) {
        return new CH(a, b)
    }
    var CH = class {
        constructor(a, b) {
            this.sa = a;
            this.zb = b
        }
        vj(a) {
            return new CH(this.sa - a, this.zb - a)
        }
        Li(a, b, c) {
            var d = ss(a);
            a = ts(a) - this.sa - c;
            d = d - this.zb - b;
            return new Yk(a, d + b, a + c, d)
        }
        yi(a) {
            a.bottom = `${this.sa}px`;
            a.right = `${this.zb}px`;
            a.left = ""
        }
        aj() {
            return 1
        }
        cf() {
            return this.sa
        }
        bk(a) {
            return new CH(a, this.zb)
        }
    };

    function DH(a) {
        var b = {};
        const c = a.ul,
            d = a.Tk,
            e = a.Lk,
            f = a.cn,
            g = a.Mk;
        a = a.Kk;
        b = b && b.Vd;
        return AD('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (b ? ' nonce="' + V(cE(b)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500,700" rel="stylesheet"' + (b ? ' nonce="' + V(cE(b)) + '"' : "") + "><style" + (b ? ' nonce="' + V(cE(b)) + '"' : "") + ">.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: " +
            W(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " + W(e) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + W(a) + "px; border-radius: " + W(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " +
            W(a) + "px; margin: 0; border-radius: " + W(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            W(e) + "px; height: " + W(e) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + W(e) + "px; margin-bottom: " + W(g) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + W(e) + "px; width: " + W(e) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            W(e - 6) + "px; width: " + W(e - 6) + "px; border-radius: " + W(e / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            W(f) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + W(e) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            W(16) + "px; max-width: calc(90vw - " + W(e * 2) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + W(e + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + W(e + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            W(e * 2) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0; text-align: start;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            V(c) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + V(d) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function EH(a) {
        const b = a.googleIconName,
            c = a.backgroundColorCss,
            d = a.iconColorCss;
        return AD('<div class="ft-button ft-collapsible ft-collapsed ft-last-button"><button class="ft-styless-button" aria-label="' + V(a.ariaLabel) + '" style="background-color: ' + V(W(c)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + V(W(d)) + '" aria-hidden="true">' + yD(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const FH = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function GH(a, b) {
        a = new HH(a, b, IH(a, b));
        a.init();
        return a
    }

    function JH() {
        ({
            Sd: a
        } = {
            Sd: 2
        });
        var a;
        return a > 1 ? 50 : 120
    }

    function KH(a, b, c) {
        LH(a) === 0 && b.classList.remove("ft-collapsed");
        MH(b, c);
        gt(a.C);
        b.classList.remove("ft-collapsed");
        NH(a);
        return () => void OH(a, b, c)
    }

    function PH(a) {
        QH(a.j.wa.oe).length === 0 ? (a.A.X ? .Pm(), a.A.g(null), a.j.wa.eh.g(!1), a.j.wa.jj.g(!1), a.j.wa.uh.g(!1)) : (a.j.wa.eh.g(!0), RH(a))
    }

    function SH(a, {
        rk: b = 0,
        Uq: c = 0
    }) {
        b = Math.max(QH(a.j.dd).length + b, 0);
        c = Math.max(QH(a.j.Ac).length + c, 0);
        const d = b + c;
        let e = d * 50;
        b > 0 && c > 0 && (e += 11);
        e += Math.max(0, d - 1) * 10;
        d >= a.l.Sd && (e += 60);
        d > 1 && (e += 10);
        return e
    }

    function LH(a) {
        const b = a.j.Ac;
        return QH(a.j.dd).length + QH(b).length
    }

    function NH(a) {
        const b = a.j.Ac,
            c = a.j.separator;
        QH(a.j.dd).length > 0 && QH(b).length > 0 ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        LH(a) >= a.l.Sd ? a.j.ij.g(!0) : a.j.ij.g(!1);
        LH(a) > 1 ? a.j.ej.g(!0) : a.j.ej.g(!1);
        LH(a) > 0 ? a.j.isVisible.g(!0) : a.j.isVisible.g(!1);
        TH(a);
        UH(a)
    }

    function OH(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), NH(a), a.C.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function TH(a) {
        const b = QH(a.j.dd).concat(QH(a.j.Ac));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        LH(a) >= a.l.Sd || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function UH(a) {
        const b = QH(a.j.dd).concat(QH(a.j.Ac)).filter(c => !c.classList.contains("ft-reg-button"));
        a.G.g(b.length > 0)
    }

    function VH(a) {
        Us(a.j.wa.oe.children, b => {
            const c = a.j.wa.te;
            OH(a, b, a.j.wa.oe);
            const d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        PH(a)
    }

    function RH(a) {
        if (!a.A.X) {
            var b = WH(a.C, {
                googleIconName: "verified_user",
                ariaLabel: C(a.l.Mb, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.j.wa.jj.g(!a.j.wa.isVisible.X);
                    for (const [, c] of a.j.wa.te) c.lj = !0;
                    a.j.wa.uh.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.Ke.classList.add("ft-reg-button");
            KH(a, b.Ke, a.j.Ac);
            wt(b.am, a.j.wa.isVisible);
            a.A.g({
                Zq: b,
                Pm: () => void OH(a, b.Ke, a.j.Ac)
            })
        }
    }

    function XH(a) {
        var b = a.j.wa.uh,
            c = b.g;
        a: {
            for ([, d] of a.j.wa.te)
                if (a = d, a.showUnlessUserInControl && !a.lj) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function YH(a) {
        a.j.wa.Sk.listen(() => {
            VH(a)
        })
    }
    var HH = class extends O {
        constructor(a, b, c) {
            super();
            this.C = a;
            this.l = b;
            this.j = c;
            this.A = new P(null);
            this.G = new P(!1)
        }
        addButton(a) {
            a = WH(this.C, a);
            return KH(this, a.Ke, this.j.dd)
        }
        addRegulatoryMessage(a) {
            const b = this.j.wa.oe,
                c = ZH(this.C, a);
            MH(c.Eh, b);
            this.j.wa.te.set(c.Eh, c);
            PH(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    XH(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    XH(this)
                },
                isDismissed: yt(c.isDismissed),
                removeCallback: () => {
                    var d = c.Eh;
                    const e = this.j.wa.oe;
                    d.parentNode === e && e.removeChild(d);
                    this.j.wa.te.delete(d);
                    PH(this)
                }
            }
        }
        K() {
            return qt(this.A.map(a => a != null))
        }
        F() {
            return qt(this.G)
        }
        D() {
            return [this.j.container]
        }
        g() {
            const a = this.j.sc.qc;
            a.parentNode ? .removeChild(a);
            super.g()
        }
        init() {
            gu(this.C, FH);
            wt(this.j.An, this.l.Jc);
            this.C.document.body.appendChild(this.j.sc.qc);
            YH(this)
        }
    };

    function IH(a, b) {
        const c = OE(a),
            d = c.shadowRoot;
        d.appendChild(Xk(new Hk(a.document), vD(DH({
            ul: C(b.Mb, 1),
            Tk: C(b.Mb, 3),
            Lk: 50,
            cn: 11,
            Mk: 10,
            Kk: 5
        }))));
        const e = NE("ft-container", d),
            f = NE("ft-expand-toggle", d),
            g = NE("ft-expand-toggle-container", d),
            h = new P(null);
        h.j(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        const k = new P(!0);
        tt(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        tt(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.X)
            });
        const l = new P(!1);
        tt(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        tt(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        const m = new P(!1);
        tt(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        tt(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.j(p => {
            if (p) {
                p.yi(e.style);
                p = p.aj();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                gt(a)
            }
        });
        const n = new P(!1);
        b = pt($H(a, d), n, b.position.map(p => p !== null));
        tt(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        tt(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = aI(a, NE("ft-reg-bubble", d));
        return {
            container: e,
            dd: NE("ft-button-holder", d),
            Ac: NE("ft-bottom-button-holder", d),
            separator: NE("ft-separator", d),
            sc: c,
            An: h,
            wh: k,
            ij: l,
            ej: m,
            isVisible: n,
            wa: b
        }
    }

    function aI(a, b) {
        const c = new P(!1),
            d = new P(!1),
            e = rt(c, d);
        tt(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        tt(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        const f = new P(!1);
        tt(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        tt(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        const g = NE("ft-reg-bubble-close", b),
            h = new Ct;
        g.addEventListener("click", () => {
            Bt(h)
        });
        const k = NE("ft-reg-message-holder", b);
        $t(Xt(a, k)).j(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            oe: k,
            jj: c,
            uh: d,
            isVisible: e,
            eh: f,
            te: new Map,
            Sk: zt(h)
        }
    }

    function WH(a, b) {
        const c = Xk(new Hk(a.document), vD(EH({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043"
        })));
        b.buttonExtension ? .styleSheet && c.appendChild(b.buttonExtension.styleSheet);
        if (b.cornerNumber !== void 0) {
            const d = Ak(Math.round(b.cornerNumber), 99);
            NE("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick &&
            ME("BUTTON", c).addEventListener("click", b.onClick);
        a = new P(!1);
        tt(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        tt(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            Ke: c,
            am: a
        }
    }

    function ZH(a, b) {
        a = new Hk(a.document);
        var c = AD('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = Xk(a, vD(c));
        c = NE("ft-reg-message-button", a);
        b.regulatoryMessage.actionButton ? (c.appendChild(b.regulatoryMessage.actionButton.buttonText), c.addEventListener("click", b.regulatoryMessage.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = NE("ft-reg-message-info", a);
        b.regulatoryMessage.informationText ? c.appendChild(b.regulatoryMessage.informationText) :
            c.classList.add("ft-display-none");
        a.orderingIndex = b.orderingIndex;
        return {
            Eh: a,
            showUnlessUserInControl: !1,
            lj: !1,
            isDismissed: new P(!1)
        }
    }

    function MH(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function QH(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function $H(a, b) {
        const c = new P(!1),
            d = NE("ft-symbol-font-load-test", b);
        b = NE("ft-symbol-reference", d);
        const e = NE("ft-text-reference", d),
            f = Xt(a, b);
        ut($t(f).map(g => g.width > 0 && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.dispose()
        });
        return c
    };

    function bI(a) {
        const b = new Ct,
            c = Nt(a, 2500, () => void Bt(b));
        return new cI(a, () => void dI(a, () => void c()), zt(b))
    }

    function eI(a) {
        const b = new MutationObserver(() => {
            a.j()
        });
        b.observe(a.C.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        jt(a, () => void b.disconnect())
    }

    function fI(a) {
        a.C.addEventListener("resize", a.j);
        jt(a, () => void a.C.removeEventListener("resize", a.j))
    }
    var cI = class extends O {
        constructor(a, b, c) {
            super();
            this.C = a;
            this.j = b;
            this.A = c;
            this.l = !1
        }
    };

    function dI(a, b) {
        b();
        a.setTimeout(b, 1500)
    };

    function gI(a) {
        return a.g[a.g.length - 1]
    }
    var iI = class {
        constructor() {
            this.l = hI;
            this.g = [];
            this.j = new Set
        }
        add(a) {
            if (this.j.has(a)) return !1;
            const b = $a(this.g, a, this.l);
            this.g.splice(b >= 0 ? b : -b - 1, 0, a);
            this.j.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.j.has(a)
        }
        delete(a) {
            Ua(this.g, b => b === a);
            return this.j.delete(a)
        }
        clear() {
            this.j.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function jI(a) {
        var b = a.ne.X;
        let c;
        for (; a.l.Xk() > b && (c = a.j.first());) {
            var d = a,
                e = c;
            kI(d, e);
            d.g.add(e)
        }
        for (;
            (d = gI(a.g)) && a.l.Jl() <= b;) lI(a, d);
        for (;
            (d = gI(a.g)) && (c = a.j.first()) && d.priority > c.priority;) b = a, e = c, kI(b, e), b.g.add(e), lI(a, d)
    }

    function lI(a, b) {
        a.g.delete(b);
        a.j.add(b) && (b.ii = a.l.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function kI(a, b) {
        b.ii && b.ii();
        b.ii = void 0;
        a.j.delete(b);
        b.isInToolbar.g(!1)
    }
    var mI = class {
        constructor(a, b) {
            this.ne = a;
            this.l = b;
            this.g = new iI;
            this.j = new iI;
            this.B = 0;
            this.ne.listen(() => void jI(this))
        }
        addButton(a) {
            const b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                mi: this.B++,
                isInToolbar: new P(!1)
            };
            this.g.add(b);
            jI(this);
            return {
                isInToolbar: yt(qt(b.isInToolbar)),
                removeCallback: () => {
                    kI(this, b);
                    this.g.delete(b);
                    jI(this)
                }
            }
        }
    };

    function hI(a, b) {
        return a.priority === b.priority ? b.mi - a.mi : a.priority - b.priority
    };

    function nI(a) {
        if (!KE(a.C)) {
            if (a.l.X) {
                const b = Ps(a.C);
                if (b > a.j + 100 || b < a.j - 100) a.l.g(!1), a.j = vs(a.C)
            }
            a.A && a.C.clearTimeout(a.A);
            a.A = a.C.setTimeout(() => void oI(a), 200)
        }
    }

    function oI(a) {
        if (!KE(a.C)) {
            var b = vs(a.C);
            a.j && a.j > b && (a.j = b);
            b = Ps(a.C);
            b >= a.j - 100 && (a.j = Math.max(a.j, b), a.l.g(!0))
        }
    }
    var pI = class extends O {
        constructor(a) {
            super();
            this.C = a;
            this.l = new P(!1);
            this.j = 0;
            this.A = null;
            this.D = () => void nI(this)
        }
        init() {
            this.C.addEventListener("scroll", this.D);
            this.j = vs(this.C);
            oI(this)
        }
        g() {
            this.C.removeEventListener("scroll", this.D);
            this.l.g(!1);
            super.g()
        }
    };

    function qI(a) {
        if (!a.j) {
            var b = new pI(a.C);
            b.init();
            a.j = qt(b.l);
            it(a, b)
        }
        return a.j
    }

    function rI(a, b, c) {
        const d = a.l.addRegulatoryMessage(b.messageSpec);
        b.messageSpec.regulatoryMessage.disableFloatingToolbarAutoShow || sI(a, d, c);
        ut(c, !0, () => {
            d.removeCallback()
        })
    }

    function sI(a, b, c) {
        a = qI(a);
        const d = tt(a, !0, () => void b.showUnlessUserInControl()),
            e = tt(a, !1, () => void b.hideUnlessUserInControl());
        tt(nt(b.isDismissed), !0, () => {
            d();
            e()
        });
        ut(c, !0, () => {
            d();
            e()
        })
    }
    var tI = class extends O {
        constructor(a, b) {
            super();
            this.C = a;
            this.l = b;
            this.j = null
        }
        addRegulatoryMessage(a) {
            const b = new P(!1),
                c = ut(qI(this), !0, () => {
                    rI(this, a, b)
                });
            return {
                removeCallback: () => {
                    b.g(!0);
                    c()
                }
            }
        }
    };

    function uI(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new vI(a, b));
        return a.googFloatingToolbarManager
    }

    function wI(a) {
        a.j || (a.j = xI(a.C, a.l, a.Jc), it(a, a.j.md), it(a, a.j.Hj), yI(a), zI(a, a.j.md));
        return a.j
    }

    function AI(a) {
        a.Jc.X === null && a.j ? .position.g(BI(a))
    }

    function CI(a) {
        a.C.requestAnimationFrame(() => void AI(a))
    }

    function BI(a) {
        var b = [];
        a.j ? .md ? .F().A() ? (b.push(() => DI(a)), b.push(() => EI(a))) : (b.push(() => EI(a)), b.push(() => DI(a)));
        a.j ? .md ? .K() ? .A() && b.push(() => {
            const c = ts(a.C);
            return {
                position: zH({
                    sa: Math.floor(c / 3),
                    kb: 10
                }),
                ne: 0
            }
        });
        for (const c of b)
            if (b = c()) return b;
        return null
    }

    function yI(a) {
        a.C.googFloatingToolbarManagerAsyncPositionUpdate ? CI(a) : AI(a)
    }

    function zI(a, b) {
        const c = bI(a.C);
        c.l || (eI(c), fI(c), c.l = !0);
        c.A.listen(() => void yI(a));
        it(a, c);
        b.K().listen(() => void yI(a));
        b.F().listen(() => void yI(a));
        a.Jc.listen(() => void yI(a))
    }

    function DI(a) {
        var b = a.C;
        const c = ts(a.C);
        return vH(b, {
            Id: BH({
                sa: 50,
                zb: 10
            }),
            Ah: Math.floor(c / 3),
            Vc: 60,
            Gh: JH(),
            vf: Math.floor(c / 2),
            Bc: 20
        }, [...(a.j ? .md.D() ? ? []), a.C.document.body]).rg
    }

    function EI(a) {
        var b = a.C;
        const c = ts(a.C);
        return vH(b, {
            Id: zH({
                sa: 50,
                kb: 10
            }),
            Ah: Math.floor(c / 3),
            Vc: 60,
            Gh: JH(),
            vf: Math.floor(c / 2),
            Bc: 40
        }, [...(a.j ? .md.D() ? ? []), a.C.document.body]).rg
    }
    class vI extends O {
        constructor(a, b) {
            super();
            this.C = a;
            this.l = b;
            this.j = null;
            this.Jc = FI(this.C, this)
        }
        addButton(a) {
            return wI(this).um.addButton(a)
        }
        addRegulatoryMessage(a) {
            return wI(this).Hj.addRegulatoryMessage(a)
        }
    }

    function xI(a, b, c) {
        const d = new P(null),
            e = GH(a, {
                Sd: 2,
                position: d.map(f => f ? .position ? ? null),
                Mb: b,
                Jc: c
            });
        b = new mI(d.map(f => f ? .ne || 0), {
            addButton: f => e.addButton(f),
            Xk: () => SH(e, {}),
            Jl: () => SH(e, {
                rk: 1
            })
        });
        a = new tI(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            md: e,
            position: d,
            um: b,
            Hj: a
        }
    }

    function FI(a, b) {
        const c = new uE(a),
            d = new P(null),
            e = f => void d.g(f);
        jt(b, () => {
            tE(c, e)
        });
        c.floatingAdsStacking.maxZIndexListeners.push(e);
        e(sE(c));
        return d
    };
    const GI = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function HI(a, b, c, d, e) {
        a = new II(a, b, c, d, e);
        if (a.A) {
            gu(a.C, GI);
            var f = a.C;
            b = a.message;
            c = OE(f);
            e = c.shadowRoot;
            d = e.appendChild;
            f = new Hk(f.document);
            var g = (g = {}, g.Vd);
            g = AD('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (g ? ' nonce="' + V(cE(g)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500" rel="stylesheet"' + (g ? ' nonce="' + V(cE(g)) + '"' : "") + "><style" + (g ? ' nonce="' + V(cE(g)) + '"' :
                "") + '>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(e, Xk(f, vD(g)));
            d = NE("ipr-container", e);
            e = NE("ipr-button", d);
            b.actionButton ? (e.appendChild(b.actionButton.buttonText), e.addEventListener("click", b.actionButton.onClick)) : e.classList.add("ipr-display-none");
            d = NE("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.j = c.qc;
            qB(a.A, a.j);
            a.l && a.l(xp(1));
            JI(a)
        } else KI(a);
        return a
    }

    function JI(a) {
        const b = new ju(a.C);
        b.init(2E3);
        it(a, b);
        hu(b, () => {
            LI(a);
            KI(a);
            b.dispose()
        })
    }

    function KI(a) {
        const b = uI(a.C, a.D).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        jt(a, () => void b.removeCallback());
        a.l && a.l(xp(2))
    }

    function LI(a) {
        a.j && (a.j.parentNode ? .removeChild(a.j), a.j = null)
    }
    var II = class extends O {
        constructor(a, b, c, d, e) {
            super();
            this.C = a;
            this.A = b;
            this.message = c;
            this.D = d;
            this.l = e;
            this.j = null
        }
        g() {
            LI(this);
            super.g()
        }
    };
    var NI = (a, b, c, d) => MI(a, b, c, d);

    function MI(a, b, c, d) {
        const e = HI(a, kH(a, d), {
            actionButton: {
                buttonText: a.document.createTextNode(b),
                onClick: c
            }
        }, OI(a));
        return () => e.dispose()
    }

    function OI(a) {
        if (a = jH(a)) return a;
        jC(1234, Error("No messages"));
        return kj(new sv)
    };

    function PI(a, b) {
        b && (a.g = NI(a.j, b.localizedDnsText, () => QI(a, b), a.B))
    }

    function RI(a) {
        const b = hH(a.j);
        b.callbackQueue = b.callbackQueue || [];
        iH(a.j).overrideDnsLink = !0;
        b.callbackQueue.push({
            INITIAL_US_STATES_DATA_READY: c => PI(a, c)
        })
    }

    function QI(a, b) {
        vE(a.l);
        b.openConfirmationDialog(c => {
            c && a.g && (a.g(), a.g = null);
            wE(a.l)
        })
    }
    var SI = class {
        constructor(a, b, c) {
            this.j = a;
            this.l = pE(b, 2147483643);
            this.B = c;
            this.g = null
        }
    };

    function TI(a) {
        UI(a.l, b => {
            var c = a.j,
                d = b.revocationText,
                e = b.attestationText,
                f = b.showRevocationMessage;
            b = kH(c, a.B);
            d = {
                actionButton: {
                    buttonText: c.document.createTextNode(d),
                    onClick: f
                },
                informationText: c.document.createTextNode(e)
            };
            e = jH(c);
            e || (jC(1233, Error("No messages")), e = kj(new sv));
            HI(c, b, d, e)
        }, () => {
            wE(a.g);
            VI(a)
        })
    }

    function WI(a) {
        vE(a.g);
        TI(a)
    }

    function VI(a) {
        a.j.__tcfapi ? a.j.__tcfapi("addEventListener", 2, (b, c) => {
            c && b.eventStatus == "cmpuishown" ? vE(a.g) : wE(a.g)
        }) : jC(1250, Error("No TCF API function"))
    }
    var XI = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.g = pE(b, 2147483643);
            this.B = c;
            this.l = d
        }
    };
    var YI = a => {
            if (!a || wf(w(a, 1)) == null) return !1;
            a = D(a, 1);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoConsentUiStatus: " + a);
            }
        },
        ZI = a => {
            if (!a || wf(w(a, 3)) == null) return !1;
            a = D(a, 3);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + a);
            }
        },
        $I = a => a ? A(a, 5) === !0 : !1;

    function aJ(a) {
        let b = a.location.href;
        if (a === a.top) return {
            url: b,
            yh: !0
        };
        let c = !1;
        const d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && b.indexOf(a) === -1 && (c = !1, b = a);
        return {
            url: b,
            yh: c
        }
    };

    function bJ(a, b) {
        Fd(a, (c, d) => {
            b[d] = c
        })
    }

    function cJ(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && xd(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function dJ() {
        if (eJ) return eJ;
        const a = Um() || window,
            b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? eJ = b : a.google_persistent_state_async = eJ = new fJ
    }

    function gJ(a, b, c) {
        b = hJ[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function iJ(a, b, c) {
        return gJ(a, b, () => c)
    }

    function jJ(a, b, c) {
        return a.S[hJ[b] || `google_ps_${b}`] = c
    }

    function kJ(a, b) {
        return jJ(a, b, iJ(a, b, 0) + 1)
    }

    function lJ() {
        var a = dJ();
        return iJ(a, 20, {})
    }

    function mJ() {
        var a = dJ();
        const b = iJ(a, 23, !1);
        b || jJ(a, 23, !0);
        return !b
    }

    function nJ() {
        var a = dJ();
        const b = iJ(a, 41, !1);
        b || jJ(a, 41, !0);
        return !b
    }

    function oJ(a) {
        return iJ(a, 24)
    }

    function pJ() {
        var a = dJ();
        return iJ(a, 26)
    }

    function qJ() {
        var a = dJ();
        return iJ(a, 28, [])
    }
    var fJ = class {
            constructor() {
                this.S = {}
            }
        },
        eJ = null;
    const hJ = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function rJ(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function sJ(a, b) {
        a = rJ(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        const c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function tJ(a) {
        return a.google_ad_client ? String(a.google_ad_client) : rJ(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };

    function Xr(a, b) {
        a.j.size > 0 || uJ(a);
        const c = a.j.get(0);
        c ? c.push(b) : a.j.set(0, [b])
    }

    function vJ(a, b, c, d) {
        ql(b, c, d);
        jt(a, () => rl(b, c, d))
    }

    function wJ(a, b) {
        a.state !== 1 && (a.state = 1, a.j.size > 0 && xJ(a, b))
    }

    function uJ(a) {
        a.C.document.visibilityState ? vJ(a, a.C.document, "visibilitychange", b => {
            a.C.document.visibilityState === "hidden" && wJ(a, b);
            a.C.document.visibilityState === "visible" && (a.state = 0)
        }) : "onpagehide" in a.C ? (vJ(a, a.C, "pagehide", b => {
            wJ(a, b)
        }), vJ(a, a.C, "pageshow", () => {
            a.state = 0
        })) : vJ(a, a.C, "beforeunload", b => {
            wJ(a, b)
        })
    }

    function xJ(a, b) {
        for (let c = 9; c >= 0; c--) a.j.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var yJ = class extends O {
        constructor(a) {
            super();
            this.C = a;
            this.state = 0;
            this.j = new Map
        }
    };
    async function zJ(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} ${200}`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function AJ(a) {
        const b = a.state.pc;
        return b !== null && b !== 0 ? b : a.state.pc = fe(a.C)
    }

    function BJ(a) {
        const b = a.state.wpc;
        return b !== null && b !== "" ? b : a.state.wpc = tJ(a.C)
    }

    function CJ(a, b) {
        var c = new vq;
        var d = AJ(a);
        c = di(c, 1, d);
        d = BJ(a);
        c = gi(c, 2, d);
        c = uq(c, a.state.sd);
        return di(c, 7, Math.round(b || a.C.performance.now()))
    }

    function DJ(a, b, c) {
        b(a.L.zf.Wf.He).jb(c)
    }

    function EJ(a, b, c) {
        b(a.L.zf.Wf.He).se(c)
    }
    async function FJ(a) {
        await zJ(a.C, () => !(!AJ(a) || !BJ(a)))
    }

    function GJ(a) {
        var b = M(HJ);
        if (b.g) {
            var c = b.l;
            a(c);
            b.state.cc = rg(c)
        }
    }
    async function IJ(a, b, c) {
        if (a.g && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.C.performance.now();
            await FJ(a);
            var e = a.L,
                f = e.oc;
            a = CJ(a, d);
            d = new ip;
            b = G(d, 1, b);
            c = yh(b, 2, c, xf);
            c = z(a, 9, wq, c);
            f.call(e, c)
        }
    }
    async function JJ(a, b) {
        await FJ(a);
        var c = CJ(a);
        b = z(c, 5, wq, b);
        a.g && !a.state.le.includes(2) && (a.state.le.push(2), a.L.oc(b))
    }
    async function KJ(a, b, c) {
        await FJ(a);
        var d = a.L,
            e = d.oc;
        a = uq(CJ(a, c), 1);
        b = z(a, 6, wq, b);
        e.call(d, b)
    }
    async function LJ(a, b, c) {
        await FJ(a);
        DJ(a, d => b(d.Qj), c)
    }
    async function MJ(a, b, c) {
        await FJ(a);
        EJ(a, d => b(d.Qj), c)
    }
    async function NJ(a, b) {
        await FJ(a);
        var c = a.L,
            d = c.oc;
        a = uq(CJ(a), 1);
        b = z(a, 13, wq, b);
        d.call(c, b)
    }
    async function OJ(a, b) {
        if (a.g) {
            await FJ(a);
            var c = a.L,
                d = c.oc;
            a = CJ(a);
            b = z(a, 11, wq, b);
            d.call(c, b)
        }
    }
    async function PJ(a, b) {
        await FJ(a);
        var c = a.L,
            d = c.oc;
        a = uq(CJ(a), 1);
        b = z(a, 16, wq, b);
        d.call(c, b)
    }
    async function QJ(a, b) {
        await FJ(a);
        var c = a.L,
            d = c.oc;
        a = uq(CJ(a), 1);
        b = z(a, 19, wq, b);
        d.call(c, b)
    }
    var HJ = class {
        constructor(a, b) {
            this.C = Um() || window;
            this.j = b ? ? new yJ(this.C);
            this.L = a ? ? new Zr(Kq(), 100, 100, !0, this.j);
            this.state = gJ(dJ(), 33, () => {
                const c = U(Iw);
                return {
                    sd: c,
                    ssp: c > 0 && Ed() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get g() {
            return this.state.ssp
        }
        get Dc() {
            return this.state.cu
        }
        set Dc(a) {
            this.state.cu = a
        }
        get l() {
            return fC(1227, () => lj(mp, sg(this.state.cc || []))) || new mp
        }
    };
    var RJ = class {
        constructor(a, b, c, d, e) {
            this.j = a;
            this.l = b;
            this.g = c;
            this.A = d;
            this.B = e || null
        }
        run() {
            if (this.j.adsbygoogle_ama_fc_has_run !== !0) {
                var a = YI(this.g),
                    b = ZI(this.g),
                    c = !1;
                a && (WI(new XI(this.j, this.A, this.B || Gh(this.g, zv, 4, ph()), this.l)), c = !0);
                b && (RI(new SI(this.j, this.A, this.B || Gh(this.g, zv, 4, ph()))), c = !0);
                GJ(d => {
                    d = ai(d, 9, !0);
                    d = ai(d, 10, a);
                    ai(d, 11, b)
                });
                $I(this.g) && (c = !0);
                c && (this.l.start(!0), this.j.adsbygoogle_ama_fc_has_run = !0)
            }
        }
    };

    function SJ(a, b, c, d, e, f) {
        try {
            const g = a.g,
                h = Cd("SCRIPT", g);
            h.async = !0;
            Lc(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                c > 0 ? SJ(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function TJ(a, b, c = () => {}, d = () => {}) {
        SJ(Gk(a), b, 0, !1, c, d)
    };

    function UJ(a = null) {
        a = a || q;
        return a.googlefc || (a.googlefc = {})
    };
    bc(js).map(a => Number(a));
    bc(ks).map(a => Number(a));
    const VJ = q.URL;

    function WJ(a) {
        const b = c => encodeURIComponent(c).replace(/[!()~']|(%20)/g, d => ({
            "!": "%21",
            "(": "%28",
            ")": "%29",
            "%20": "+",
            "'": "%27",
            "~": "%7E"
        })[d]);
        return Array.from(a, c => b(c[0]) + "=" + b(c[1])).join("&")
    };

    function XJ(a) {
        var b = (new VJ(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return b === "alwaysshow" ? b : a === "alwaysshow" ? a : null
    }

    function YJ(a) {
        const b = "ab gdpr consent gdpr_transparency ccpa monetization usnat usfl".split(" ");
        return (a = (new VJ(a.location.href)).searchParams.get("fctype")) && b.indexOf(a) !== -1 ? a : null
    }

    function ZJ(a) {
        var b = new VJ(a),
            c = {
                search: "",
                hash: ""
            };
        a = {};
        b && (a.protocol = b.protocol, a.username = b.username, a.password = b.password, a.hostname = b.hostname, a.port = b.port, a.pathname = b.pathname, a.search = b.search, a.hash = b.hash);
        Object.assign(a, c);
        if (a.port && a.port[0] === ":") throw Error("port should not start with ':'");
        a.hash && a.hash[0] != "#" && (a.hash = "#" + a.hash);
        c.search ? c.search[0] != "?" && (a.search = "?" + c.search) : c.searchParams && (a.search = "?" + WJ(c.searchParams), a.searchParams = void 0);
        b = "";
        a.protocol && (b += a.protocol +
            "//");
        c = a.username;
        var d = a.password;
        b = b + (c && d ? c + ":" + d + "@" : c ? c + "@" : d ? ":" + d + "@" : "") + (a.hostname || "");
        a.port && (b += ":" + a.port);
        b += a.pathname || "";
        b += a.search || "";
        b += a.hash || "";
        a = (new VJ(b)).toString();
        a.charAt(a.length - 1) === "/" && (a = a.substring(0, a.length - 1));
        return a.toString().length <= 1E3 ? a : null
    };

    function $J(a, b) {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Cd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var aK = xk(class extends H {});

    function bK(a) {
        if (a.j) return a.j;
        a.T && a.T(a.l) ? a.j = a.l : a.j = Ud(a.l, a.V);
        return a.j ? ? null
    }

    function cK(a) {
        a.A || (a.A = b => {
            try {
                var c = a.K ? a.K(b) : void 0;
                if (c) {
                    var d = c.Ph,
                        e = a.G.get(d);
                    e && (e.Gm || a.G.delete(d), e.Ed ? .(e.bl, c.payload))
                }
            } catch (f) {}
        }, ql(a.l, "message", a.A))
    }

    function dK(a, b, c) {
        if (bK(a))
            if (a.j === a.l)(b = a.F.get(b)) && b(a.j, c);
            else {
                var d = a.D.get(b);
                if (d && d.ke) {
                    cK(a);
                    var e = ++a.ba;
                    a.G.set(e, {
                        Ed: d.Ed,
                        bl: d.sf(c),
                        Gm: b === "addEventListener"
                    });
                    a.j.postMessage(d.ke(c, e), "*")
                }
            }
    }
    var eK = class extends O {
        constructor(a, b, c, d) {
            super();
            this.V = b;
            this.T = c;
            this.K = d;
            this.F = new Map;
            this.ba = 0;
            this.D = new Map;
            this.G = new Map;
            this.A = void 0;
            this.l = a
        }
        g() {
            delete this.j;
            this.F.clear();
            this.D.clear();
            this.G.clear();
            this.A && (rl(this.l, "message", this.A), delete this.A);
            delete this.l;
            delete this.K;
            super.g()
        }
    };
    const fK = (a, b) => {
            const c = {
                cb: d => {
                    d = aK(d);
                    b.Db({
                        Ud: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        gK = {
            sf: a => a.Db,
            ke: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            Ed: (a, b) => {
                a({
                    Ud: b
                })
            }
        };

    function hK(a) {
        a = aK(a.data.__fciReturn);
        return {
            payload: a,
            Ph: Zv(Qh(a, 1))
        }
    }

    function iK(a, b = !1) {
        if (b) return !1;
        a.l || (a.j = !!bK(a.caller), a.l = !0);
        return a.j
    }

    function jK(a) {
        return new Promise(b => {
            iK(a) && dK(a.caller, "getDataWithCallback", {
                command: "loaded",
                Db: c => {
                    b(c.Ud)
                }
            })
        })
    }

    function kK(a, b) {
        iK(a) && dK(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: jj(b),
            Db: () => {}
        })
    }
    var lK = class extends O {
        constructor(a) {
            super();
            this.j = this.l = !1;
            this.caller = new eK(a, "googlefcPresent", void 0, hK);
            this.caller.F.set("getDataWithCallback", fK);
            this.caller.D.set("getDataWithCallback", gK)
        }
        g() {
            this.caller.dispose();
            super.g()
        }
    };

    function mK(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function nK(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = mK(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (rm({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function oK(a, b = {}) {
        return nK(a) ? a.gdprApplies === !1 ? !0 : a.tcString === "tcunavailable" ? !b.idpcApplies : (b.idpcApplies || a.gdprApplies !== void 0 || b.ar) && (b.idpcApplies || typeof a.tcString === "string" && a.tcString.length) ? pK(a, "1", 0) : !0 : !1
    }

    function pK(a, b, c) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var d = a.publisher.restrictions[b];
                if (d !== void 0) {
                    d = d["755"];
                    break a
                }
            }
            d = void 0
        }
        if (d === 0) return !1;
        let e = c;c === 2 ? (e = 0, d === 2 && (e = 1)) : c === 3 && (e = 1, d === 1 && (e = 0));
        if (e === 0) a = a.purpose && a.vendor ? (c = qK(a.vendor.consents, "755")) && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : c && qK(a.purpose.consents, b) : !0;
        else {
            var f;
            e === 1 ? f = a.purpose && a.vendor ? qK(a.purpose.legitimateInterests, b) && qK(a.vendor.legitimateInterests, "755") : !0 : f = !0;
            a = f
        }
        return a
    }

    function qK(a, b) {
        return !(!a || !a[b])
    }

    function rK(a, b, c) {
        return a.gdprApplies === !1 ? !0 : b.every(d => pK(a, d, c))
    }

    function sK(a) {
        if (a.j) return a.j;
        a.j = Ud(a.l, "__tcfapiLocator");
        return a.j
    }

    function tK(a) {
        return typeof a.l.__tcfapi === "function" || sK(a) != null
    }

    function uK(a, b, c, d) {
        c || (c = () => {});
        var e = a.l;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : sK(a) ? (vK(a), e = ++a.K, a.F[e] = c, a.j && a.j.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function wK(a, b) {
        let c = {
            internalErrorState: 0,
            internalBlockOnErrors: a.D
        };
        const d = Ab(() => b(c));
        let e = 0;
        a.G !== -1 && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.G));
        uK(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = mK(c), c.internalBlockOnErrors = a.D, nK(c) ? (c.internalErrorState !== 0 && (c.tcString = "tcunavailable"), uK(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : (c.cmpStatus === "error" || c.internalErrorState !== 0) && (f = e) && clearTimeout(f))
        })
    }

    function vK(a) {
        if (!a.A) {
            var b = c => {
                try {
                    var d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.F[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.A = b;
            ql(a.l, "message", b)
        }
    }
    var xK = class extends O {
        constructor(a, b = {}) {
            super();
            this.j = null;
            this.F = {};
            this.K = 0;
            this.A = null;
            this.l = a;
            this.G = b.timeoutMs ? ? 500;
            this.D = b.Hk ? ? !1
        }
        g() {
            this.F = {};
            this.A && (rl(this.l, "message", this.A), delete this.A);
            delete this.F;
            delete this.l;
            delete this.j;
            super.g()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.D
            };
            const c = Ab(() => a(b));
            let d = 0;
            this.G !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.G));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState =
                    mK(b), b.internalBlockOnErrors = this.D, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                uK(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && uK(this, "removeEventListener", null, a.listenerId)
        }
    };

    function UI(a, b, c) {
        const d = UJ(a.C);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                const e = UJ(a.C),
                    f = new xK(a.C);
                tK(f) && wK(f, g => {
                    g.cmpId === 300 && g.tcString && g.tcString !== "tcunavailable" && g.gdprApplies && b({
                        revocationText: (0, e.getDefaultConsentRevocationText)(),
                        closeText: (0, e.getDefaultConsentRevocationCloseText)(),
                        attestationText: (0, e.getDefaultConsentRevocationAttestationText)(),
                        showRevocationMessage: () => {
                            (0, e.showRevocationMessage)()
                        }
                    })
                });
                c()
            }
        })
    }

    function yK(a, b = !1, c) {
        const d = {};
        try {
            const f = XJ(a.C),
                g = YJ(a.C);
            d.fc = f;
            d.fctype = g
        } catch (f) {}
        let e;
        try {
            e = ZJ(a.C.location.href)
        } catch (f) {}
        b && e && (d.href = e);
        b = zK(a.g, d);
        TJ(a.C, b, () => {}, () => {});
        c && kK(new lK(a.C), c)
    }
    var AK = class {
        constructor(a, b) {
            this.C = a;
            this.g = b;
            this.ia = null
        }
        start(a = !1, b) {
            if (this.C === this.C.top) try {
                $J(this.C, "googlefcPresent"), yK(this, a, b)
            } catch (c) {}
        }
    };

    function zK(a, b) {
        a = ud `https://fundingchoicesmessages.google.com/i/${a}`;
        return vd(a, { ...b,
            ers: 2
        })
    };
    const BK = new Set(["ARTICLE", "SECTION"]);
    var CK = class {
        constructor(a) {
            this.g = a
        }
    };

    function DK(a, b) {
        return Array.from(b.classList).map(c => `${a}=${c}`)
    }

    function EK(a) {
        return a.classList.length > 0
    }

    function FK(a) {
        return BK.has(a.tagName)
    };
    var GK = class {
        constructor(a, b) {
            this.g = a;
            this.j = b
        }
    };

    function HK(a) {
        return sa(a) && a.nodeType == 1 && a.tagName == "FIGURE" ? a : (a = a.parentNode) ? HK(a) : null
    };
    var IK = a => {
        var b = a.src;
        const c = a.getAttribute("data-src") || a.getAttribute("data-lazy-src");
        (b && b.startsWith("data:") && c ? c : b || c) ? (a.getAttribute("srcset"), b = (b = HK(a)) ? (b = b.getElementsByTagName("figcaption")[0]) ? b.textContent : null : null, a = new GK(a, b || a.getAttribute("alt") || null)) : a = null;
        return a
    };
    var JK = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            const c = this.map.get(a);
            return c ? (b = c.delete(b), c.size === 0 && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            let c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            let a = 0;
            for (const b of this.map.values()) a += b.size;
            return a
        }
        values() {
            const a = this.map;
            return function() {
                return function*() {
                    for (const b of a.values()) yield* b
                }()
            }()
        }[Symbol.iterator]() {
            const a =
                this.map;
            return function() {
                return function*() {
                    for (const [b, c] of a) {
                        const d = b,
                            e = c;
                        for (const f of e) yield [d, f]
                    }
                }()
            }()
        }
    };

    function KK(a) {
        return [a[0],
            [...a[1]]
        ]
    };

    function LK(a) {
        return Array.from(MK(a).map.values()).filter(b => b.size >= 3).map(b => [...b])
    }

    function NK(a, b) {
        return b.every(c => {
            var d = a.g.getBoundingClientRect(c.g);
            if (d = d.height >= 50 && d.width >= a.A) {
                var e = a.g.getBoundingClientRect(c.g);
                d = a.B;
                e = new uH(e.left, e.right);
                d = Math.max(d.start, e.start) <= Math.min(d.end, e.end)
            }
            return d && dt(a.l, {
                tc: c.g,
                dc: OK,
                Zc: !0
            }) === null
        })
    }

    function PK(a) {
        return LK(a).sort(QK).find(b => NK(a, b)) || []
    }

    function MK(a) {
        return RK(Array.from(a.C.document.getElementsByTagName("IMG")).map(IK).filter(Eu), b => {
            var c = [...DK("CLASS_NAME", b.g)],
                d = b.g.parentElement;
            d = [...(d ? DK("PARENT_CLASS_NAME", d) : [])];
            var e = b.g.parentElement ? .parentElement;
            e = [...(e ? DK("GRANDPARENT_CLASS_NAME", e) : [])];
            var f = (f = dt(a.j.g, {
                tc: b.g,
                dc: EK
            })) ? DK("NEAREST_ANCESTOR_CLASS_NAME", f) : [];
            return [...c, ...d, ...e, ...f, ...(b.j ? ["HAS_CAPTION=true"] : []), ...(dt(a.j.g, {
                tc: b.g,
                dc: FK
            }) ? ["ARTICLE_LIKE_ANCESTOR=true"] : [])]
        })
    }
    var SK = class {
        constructor(a, b, c, d, e) {
            var f = new Ut;
            this.C = a;
            this.B = b;
            this.A = c;
            this.g = f;
            this.l = d;
            this.j = e
        }
    };

    function RK(a, b) {
        const c = new JK;
        for (const d of a)
            for (const e of b(d)) c.add(e, d);
        return c
    }

    function OK(a) {
        return a.tagName === "A" && a.hasAttribute("href")
    }

    function QK(a, b) {
        return b.length - a.length
    };

    function TK(a) {
        const b = a.A.parentNode;
        if (!b) throw Error("Image not in the DOM");
        const c = UK(a.l),
            d = VK(a.l);
        c.appendChild(d);
        b.insertBefore(c, a.A.nextSibling);
        a.D.j().j(e => {
            var f = a.l;
            const g = d.getBoundingClientRect(),
                h = g.top - e.top,
                k = g.left - e.left,
                l = g.width - e.width;
            e = g.height - e.height;
            Math.abs(h) < 1 && Math.abs(k) < 1 && Math.abs(l) < 1 && Math.abs(e) < 1 || (f = f.getComputedStyle(d), r(d, {
                top: parseInt(f.top, 10) - h + "px",
                left: parseInt(f.left, 10) - k + "px",
                width: parseInt(f.width, 10) - l + "px",
                height: parseInt(f.height, 10) - e + "px"
            }))
        });
        return d
    }

    function WK(a) {
        a.j || (a.j = TK(a));
        return a.j
    }
    var XK = class extends O {
        constructor(a, b, c) {
            super();
            this.l = a;
            this.A = b;
            this.D = c;
            this.j = null
        }
        g() {
            if (this.j) {
                var a = this.j;
                const b = a.parentNode;
                b && b.removeChild(a);
                this.j = null
            }
            super.g()
        }
    };

    function VK(a) {
        const b = a.document.createElement("div");
        fw(a, b);
        r(b, {
            position: "absolute",
            left: "0",
            top: "0",
            width: "0",
            height: "0",
            "pointer-events": "none"
        });
        return b
    }

    function UK(a) {
        const b = a.document.createElement("div");
        fw(a, b);
        r(b, {
            position: "relative",
            width: "0",
            height: "0"
        });
        return b
    };

    function YK(a) {
        const b = new P(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return qt(b)
    };
    const ZK = ["Google Material Icons", "Roboto"];

    function $K({
        C: a,
        Ya: b,
        Ml: c,
        ob: d,
        Mb: e,
        Z: f
    }) {
        const g = new Wt(a, c);
        c = new XK(a, c, g);
        it(c, g);
        a = new aL(a, d, e, b, c, f);
        it(a, c);
        a.init()
    }
    var aL = class extends O {
        constructor(a, b, c, d, e, f) {
            super();
            this.C = a;
            this.ob = b;
            this.Mb = c;
            this.Ya = d;
            this.l = e;
            this.Z = f;
            this.j = new P(!1)
        }
        init() {
            const a = bL(this.C, this.ob, this.Mb);
            WK(this.l).appendChild(a.nl);
            eA(this.C, a.Ra);
            YK(a.Ra).j(b => {
                if (b !== null) {
                    switch (b) {
                        case "unfilled":
                            this.dispose();
                            break;
                        case "filled":
                            this.j.g(!0);
                            break;
                        default:
                            this.Z ? .reportError("Unhandled AdStatus: " + String(b)), this.dispose()
                    }
                    this.Z ? .Sm(this.Ya, b)
                }
            });
            ut(this.j, !0, () => void a.Vl.g(!0));
            a.jl.listen(() => void this.dispose());
            a.il.listen(() =>
                void this.Z ? .Qm(this.Ya))
        }
    };

    function bL(a, b, c) {
        const d = new P(!1),
            e = a.document.createElement("div");
        fw(a, e);
        r(e, {
            position: "absolute",
            top: "50%",
            left: "0",
            transform: "translateY(-50%)",
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "background-color": "rgba(0, 0, 0, 0.75)",
            opacity: "0",
            transition: "opacity 0.25s ease-in-out",
            "box-sizing": "border-box",
            padding: "40px 5px 5px 5px"
        });
        tt(d, !0, () => void r(e, {
            opacity: "1"
        }));
        tt(d, !1, () => void r(e, {
            opacity: "0"
        }));
        const f = a.document.createElement("div");
        fw(a, f);
        r(f, {
            display: "block",
            width: "100%",
            height: "100%"
        });
        e.appendChild(f);
        const {
            Ia: g,
            Ul: h
        } = cL(a, b);
        f.appendChild(g);
        e.appendChild(dL(a, C(c, 1)));
        b = eL(a, C(c, 2));
        e.appendChild(b.Nk);
        b.xg.listen(() => void d.g(!1));
        return {
            Vl: d,
            nl: e,
            Ra: h,
            il: b.xg,
            jl: b.xg.delay(a, 450)
        }
    }

    function dL(a, b) {
        const c = a.document.createElement("div");
        fw(a, c);
        r(c, {
            position: "absolute",
            top: "10px",
            width: "100%",
            color: "white",
            "font-family": "Roboto",
            "font-size": "12px",
            "line-height": "16px",
            "text-align": "center"
        });
        c.appendChild(a.document.createTextNode(b));
        return c
    }

    function eL(a, b) {
        const c = a.document.createElement("button");
        c.setAttribute("aria-label", b);
        fw(a, c);
        r(c, {
            position: "absolute",
            top: "10px",
            right: "10px",
            display: "block",
            cursor: "pointer",
            width: "24px",
            height: "24px",
            "font-size": "24px",
            "user-select": "none",
            color: "white"
        });
        b = a.document.createElement("gm-icon");
        b.className = "google-material-icons";
        b.appendChild(a.document.createTextNode("close"));
        c.appendChild(b);
        const d = new Ct;
        c.addEventListener("click", () => void Bt(d));
        return {
            Nk: c,
            xg: zt(d)
        }
    }

    function cL(a, b) {
        a = aA(a.document, b, null, null, {});
        return {
            Ia: a.Ec,
            Ul: a.Ra
        }
    };

    function fL({
        target: a,
        threshold: b = 0
    }) {
        const c = new gL;
        c.init(a, b);
        return c
    }
    var gL = class extends O {
        constructor() {
            super();
            this.j = new P(!1)
        }
        init(a, b) {
            const c = new IntersectionObserver(d => {
                for (const e of d)
                    if (e.target === a) {
                        this.j.g(e.isIntersecting);
                        break
                    }
            }, {
                threshold: b
            });
            c.observe(a);
            jt(this, () => void c.disconnect())
        }
    };

    function hL(a) {
        const b = iL(a.C, yf(w(a.g, 2)) ? ? 250, yf(w(a.g, 3)) ? ? 300);
        let c = 1;
        return PK(a.B).map(d => ({
            Ya: c++,
            image: d,
            uc: b(d)
        }))
    }

    function jL(a, b) {
        const c = fL({
            target: b.image.g,
            threshold: oh(a.g, 4) ? ? .8
        });
        a.l.push(c);
        ut(xt(c.j, a.C, yf(w(a.g, 5)) ? ? 3E3, d => d), !0, () => {
            if (a.j < (yf(w(a.g, 1)) ? ? 1)) {
                $K({
                    C: a.C,
                    Ya: b.Ya,
                    Ml: b.image.g,
                    ob: a.ob,
                    Mb: a.Mb,
                    Z: a.Z
                });
                a.j++;
                if (!(a.j < (yf(w(a.g, 1)) ? ? 1)))
                    for (; a.l.length;) a.l.pop() ? .dispose();
                a.Z ? .Rm(b.Ya)
            }
        })
    }
    var lL = class {
        constructor(a, b, c, d, e, f) {
            this.C = a;
            this.ob = b;
            this.g = c;
            this.Mb = d;
            this.B = e;
            this.Z = f;
            this.l = [];
            this.j = 0
        }
        run() {
            const a = hL(this);
            a.filter(kL).forEach(b => void jL(this, b));
            this.Z ? .Tm(a.map(b => ({
                Ya: b.Ya,
                uc: b.uc
            })))
        }
    };

    function kL(a) {
        return a.uc.rejectionReasons.length === 0
    }

    function iL(a, b, c) {
        const d = ts(a);
        return e => {
            e = e.g.getBoundingClientRect();
            const f = [];
            e.width < b && f.push(1);
            e.height < c && f.push(2);
            e.top <= d && f.push(3);
            return {
                Vc: e.width,
                gh: e.height,
                kl: e.top - d,
                rejectionReasons: f
            }
        }
    };

    function mL(a, b) {
        a.Ya = b;
        return a
    }
    var nL = class {
        constructor(a, b, c, d, e) {
            this.A = a;
            this.ob = b;
            this.hostname = c;
            this.l = d;
            this.B = e;
            this.errorMessage = this.j = this.Ya = this.g = null
        }
    };

    function oL(a, b) {
        return new nL(b, a.ob, a.hostname, a.j, a.B)
    }

    function pL(a, b, c) {
        var d = a.l++;
        a.g === null ? (a.g = ln(), a = 0) : a = ln() - a.g;
        var e = b.A,
            f = b.ob,
            g = b.hostname,
            h = b.l,
            k = b.B.map(encodeURIComponent).join(",");
        if (b.g) {
            var l = {
                imcnt: b.g.length
            };
            var m = Math.min(b.g.length, 10);
            for (let n = 0; n < m; n++) {
                const p = `im${n}`;
                l[`${p}_id`] = b.g[n].Ya;
                l[`${p}_s_w`] = b.g[n].uc.Vc;
                l[`${p}_s_h`] = b.g[n].uc.gh;
                l[`${p}_s_dbf`] = b.g[n].uc.kl;
                b.g[n].uc.rejectionReasons.length > 0 && (l[`${p}_s_rej`] = b.g[n].uc.rejectionReasons.join(","))
            }
        } else l = null;
        iC("abg::imovad", {
            typ: e,
            wpc: f,
            hst: g,
            pvsid: h,
            peid: k,
            rate: c,
            num: d,
            tim: a,
            ...(b.Ya === null ? {} : {
                imid: b.Ya
            }),
            ...(b.j === null ? {} : {
                astat: b.j
            }),
            ...(b.errorMessage === null ? {} : {
                errm: b.errorMessage
            }),
            ...l
        }, c)
    }
    var qL = class {
        constructor(a, b, c, d) {
            this.ob = a;
            this.hostname = b;
            this.j = c;
            this.B = d;
            this.l = 0;
            this.g = null
        }
        Tm(a) {
            var b = oL(this, "fndi");
            b.g = a;
            pL(this, b, a.length > 0 ? 1 : .1)
        }
        Rm(a) {
            a = mL(oL(this, "adpl"), a);
            pL(this, a, 1)
        }
        Sm(a, b) {
            a = mL(oL(this, "adst"), a);
            a.j = b;
            pL(this, a, 1)
        }
        Qm(a) {
            a = mL(oL(this, "adis"), a);
            pL(this, a, 1)
        }
        reportError(a) {
            var b = oL(this, "err");
            b.errorMessage = a;
            pL(this, b, .1)
        }
    };

    function rL(a, b, c) {
        return (a = a.g()) && Wh(a, 11) ? c.map(d => d.l()) : c.map(d => d.A(b))
    };
    const sL = new Set([7, 1]);
    var tL = class {
        constructor() {
            this.l = new JK;
            this.B = []
        }
        g(a, b) {
            sL.has(b) || Au(xu(pB(a), c => void this.l.add(c, b)), c => void this.B.push(c))
        }
        j(a, b) {
            for (const c of a) this.g(c, b)
        }
    };

    function uL(a) {
        return new Ru(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    var vL = class {
        g(a) {
            return uL(Math.floor(a.j))
        }
    };
    var wL = class extends H {};

    function xL(a, b) {
        var c = b.adClient;
        if (typeof c !== "string" || !c) return !1;
        a.bg = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        sa(c) && (a.I = c);
        if (Array.isArray(b.fillMessage) && b.fillMessage.length > 0) {
            a.B = {};
            for (const d of b.fillMessage) a.B[d.key] = d.value
        }
        a.Xc = b.adWidth;
        a.Wc = b.adHeight;
        typeof a.Xc === "number" && a.Xc > 0 && typeof a.Wc === "number" && a.Wc > 0 || iC("rctnosize", b);
        return !0
    }
    var yL = class {
        constructor() {
            this.B = this.I = this.j = this.bg = null;
            this.Wc = this.Xc = 0
        }
        A() {
            return !0
        }
    };

    function zL(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            const b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return b === "__storage_test__"
        } catch (b) {
            return !1
        }
    }

    function AL(a, b = []) {
        const c = Date.now();
        return La(b, d => c - d < a * 1E3)
    }

    function BL(a, b, c) {
        try {
            const d = a.getItem(c);
            if (!d) return [];
            let e;
            try {
                e = JSON.parse(d)
            } catch (f) {}
            if (!Array.isArray(e) || Oa(e, f => !Number.isInteger(f))) return a.removeItem(c), [];
            e = AL(b, e);
            e.length || a ? .removeItem(c);
            return e
        } catch (d) {
            return null
        }
    }

    function CL(a, b, c) {
        return b <= 0 || a == null || !zL(a) ? null : BL(a, b, c)
    };

    function DL(a, b, c) {
        let d = 0;
        try {
            var e = d |= rs(a);
            const h = ss(a),
                k = a.innerWidth;
            var f = h && k ? h / k : 0;
            d = e | (f ? f > 1.05 ? 262144 : f < .95 ? 524288 : 0 : 131072);
            d |= us(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var g;
            if (g = b) g = CL(c, 3600, "__lsv__") ? .length !== 0;
            g && (d |= 134217728)
        } catch (h) {
            d |= 32
        }
        return d
    };
    var EL = class extends yL {
        constructor() {
            super(...arguments);
            this.l = !1;
            this.g = null
        }
        A(a) {
            this.l = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = Nv(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    var FL = {};

    function GL(a, b, c) {
        let d = HL(a, c, b);
        if (!d) return !0;
        const e = c.J.j;
        for (; d.Gd && d.Gd.length;) {
            const f = d.Gd.shift(),
                g = RA(f.qa);
            if (g && !(typeof d.cd === "number" && g <= d.cd)) c.D ? .g(f, 18);
            else if (IL(c, f, {
                    tf: d.cd
                })) {
                if (d.Ge.g.length + 1 >= e) return c.D ? .j(d.Gd, 19), !0;
                d = HL(a, c, b);
                if (!d) return !0
            }
        }
        return c.l
    }
    const HL = (a, b, c) => {
        var d = b.J.j,
            e = b.J.D,
            f = b.J;
        f = xC(b.xa(), f.g ? f.g.Rd : void 0, d);
        if (f.g.length >= d) return b.D ? .j(JL(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.j || (f.j = Ls(f.l).scrollHeight || null), e = !d || d < 0 ? -1 : d * e - DC(f)) : e = void 0;
        const g = (d = e == null || e >= 50) ? JL(b, f, {
            types: a
        }, c) : null;
        d || b.D ? .j(JL(b, f, {
            types: a
        }, c), 18);
        return {
            Ge: f,
            cd: e,
            Gd: g
        }
    };
    FL[2] = Ba(function(a, b) {
        a = JL(b, xC(b.xa()), {
            types: a,
            yc: IB(b.xa())
        }, 2);
        if (a.length == 0) return !0;
        for (let c = 0; c < a.length; c++)
            if (IL(b, a[c])) return !0;
        return b.l ? (b.B.push(11), !0) : !1
    }, [0]);
    FL[5] = Ba(GL, [0], 5);
    FL[10] = Ba(function(a, b) {
        a = [];
        const c = b.Ub;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && a.push(1);
        return GL(a, 10, b)
    }, 10);
    FL[3] = function(a) {
        if (!a.l) return !1;
        const b = JL(a, xC(a.xa()), {
            types: [0],
            yc: IB(a.xa())
        }, 3);
        if (b.length == 0) return !0;
        for (let c = b.length - 1; c >= 0; c--)
            if (IL(a, b[c])) return !0;
        a.B.push(11);
        return !0
    };
    const LL = a => {
            const b = a.xa().document.body.getBoundingClientRect().width;
            KL(a, uL(b))
        },
        NL = (a, b) => {
            var c = {
                types: [0],
                yc: JB(),
                Vm: [5]
            };
            c = JL(a, xC(a.xa()), c, 8);
            ML(a, c.reverse(), b)
        },
        ML = (a, b, c) => {
            for (const d of b)
                if (b = c.g(d.Aa), IL(a, d, {
                        cg: b
                    })) return !0;
            return !1
        };
    FL[8] = function(a) {
        var b = a.xa().document;
        if (b.readyState != "complete") return b.addEventListener("readystatechange", () => FL[8](a), {
            once: !0
        }), !0;
        if (!a.l) return !1;
        if (!a.nf()) return !0;
        b = {
            types: [0],
            yc: JB(),
            Uh: [2, 4, 5]
        };
        b = JL(a, xC(a.xa()), b, 8);
        const c = new vL;
        if (ML(a, b, c)) return !0;
        if (a.A.Ri) switch (a.A.Dj || 0) {
            case 1:
                NL(a, c);
                break;
            default:
                LL(a)
        }
        return !0
    };
    FL[6] = Ba(GL, [2], 6);
    FL[7] = Ba(GL, [1], 7);
    FL[9] = function(a) {
        const b = HL([0, 2], a, 9);
        if (!b || !b.Gd) return a.B.push(17), a.l;
        for (var c of b.Gd) {
            var d = a.A.ah || null;
            d == null ? d = null : (d = SA(c.qa, new OL, new PL(d, a.xa())), d = new rB(d, c.ua(), c.Aa));
            if (!d) continue;
            const e = RA(d.qa);
            if (e !== null && !(typeof b.cd === "number" && e > b.cd) && IL(a, d, {
                    tf: b.cd,
                    ug: !0
                })) return a = d.qa.K, c = c.qa, a = a.length > 0 ? a[0] : null, c.B = !0, a != null && c.K.push(a), !0
        }
        a.B.push(17);
        return a.l
    };
    var OL = class {
        j(a, b, c, d) {
            return dA(d.document, a, b)
        }
        l(a) {
            return ts(a) || 0
        }
    };
    var QL = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.Ge = c
        }
        ib(a) {
            return this.g ? $C(this.j, this.g, a, this.Ge) : ZC(this.j, a, this.Ge)
        }
        Xa() {
            return this.g ? 16 : 9
        }
    };
    var RL = class {
        constructor(a) {
            this.dg = a
        }
        ib(a) {
            return gD(a.document, this.dg)
        }
        Xa() {
            return 11
        }
    };
    var SL = class {
        constructor(a) {
            this.Lc = a
        }
        ib(a) {
            return dD(this.Lc, a)
        }
        Xa() {
            return 13
        }
    };
    var TL = class {
        ib(a) {
            return XC(a)
        }
        Xa() {
            return 12
        }
    };
    var UL = class {
        constructor(a) {
            this.be = a
        }
        ib() {
            return bD(this.be)
        }
        Xa() {
            return 2
        }
    };
    var VL = class {
        constructor(a) {
            this.g = a
        }
        ib() {
            return eD(this.g)
        }
        Xa() {
            return 3
        }
    };
    var WL = class {
        ib() {
            return hD()
        }
        Xa() {
            return 17
        }
    };
    var XL = class {
        constructor(a) {
            this.g = a
        }
        ib() {
            return aD(this.g)
        }
        Xa() {
            return 1
        }
    };
    var YL = class {
        ib() {
            return yb(NA)
        }
        Xa() {
            return 7
        }
    };
    var ZL = class {
        constructor(a) {
            this.Uh = a
        }
        ib() {
            return cD(this.Uh)
        }
        Xa() {
            return 6
        }
    };
    var $L = class {
        constructor(a) {
            this.g = a
        }
        ib() {
            return fD(this.g)
        }
        Xa() {
            return 5
        }
    };
    var aM = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        ib() {
            return Ba(iD, this.minWidth, this.maxWidth)
        }
        Xa() {
            return 10
        }
    };
    var bM = class {
        constructor(a) {
            this.B = a.j.slice(0);
            this.j = a.g.slice(0);
            this.l = a.l;
            this.A = a.B;
            this.g = a.A
        }
    };

    function cM(a) {
        var b = new dM;
        b.A = a;
        b.j.push(new XL(a));
        return b
    }

    function eM(a, b) {
        a.j.push(new ZL(b));
        return a
    }

    function fM(a, b) {
        a.j.push(new UL(b));
        return a
    }

    function gM(a, b) {
        a.j.push(new $L(b));
        return a
    }

    function hM(a, b) {
        a.j.push(new VL(b));
        return a
    }

    function iM(a) {
        a.j.push(new YL);
        return a
    }

    function jM(a) {
        a.g.push(new TL);
        return a
    }

    function kM(a, b = 0, c, d) {
        a.g.push(new QL(b, c, d));
        return a
    }

    function lM(a, b = 0, c = Infinity) {
        a.g.push(new aM(b, c));
        return a
    }

    function mM(a) {
        a.g.push(new WL);
        return a
    }

    function nM(a, b = 0) {
        a.g.push(new SL(b));
        return a
    }

    function oM(a, b) {
        a.l = b;
        return a
    }
    var dM = class {
        constructor() {
            this.l = 0;
            this.B = !1;
            this.j = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new bM(this)
        }
    };
    var PL = class {
        constructor(a, b) {
            this.j = a;
            this.l = b
        }
        g() {
            var a = this.j,
                b = this.l;
            const c = a.I || {};
            c.google_ad_client = a.bg;
            c.google_ad_height = ts(b) || 0;
            c.google_ad_width = ss(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new wL;
            b = $h(b, 1, a.l);
            a.g && y(b, 2, a.g);
            c.google_rasc = jj(b);
            a.j && (c.google_adtest = "on");
            return new Ru(["fsi_container"], c)
        }
    };
    var pM = Ku(new Gu(0, {})),
        qM = Ku(new Gu(1, {})),
        rM = a => a === pM || a === qM;

    function sM(a, b, c) {
        Ws(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    var tM = class {
        constructor() {
            this.g = new $s
        }
    };

    function uM(a, b) {
        a.J.wpc = b;
        return a
    }

    function vM(a, b) {
        for (let c = 0; c < a.A.length; c++)
            if (a.A[c] == b) return a;
        a.A.push(b);
        return a
    }

    function wM(a, b) {
        for (let c = 0; c < b.length; c++) vM(a, b[c]);
        return a
    }

    function xM(a, b) {
        a.l = a.l ? a.l : b;
        return a
    }
    var yM = class {
        constructor(a) {
            this.J = {};
            this.J.c = a;
            this.A = [];
            this.l = null;
            this.D = [];
            this.F = 0
        }
        B(a) {
            const b = cc(this.J);
            this.F > 0 && (b.t = this.F);
            b.err = this.A.join();
            b.warn = this.D.join();
            this.l && (b.excp_n = this.l.name, b.excp_m = this.l.message && this.l.message.substring(0, 512), b.excp_s = this.l.stack && en(this.l.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };

    function zM(a, b) {
        b && (a.g.apv = Yh(b, 4), kh(b, nv, 23) && (a.g.sat = "" + x(b, nv, 23).g()));
        return a
    }

    function AM(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var BM = class extends yM {
        constructor(a) {
            super(a);
            this.g = {}
        }
        B(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.B(a);
            ec(a, this.g);
            return a
        }
    };

    function CM(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function DM(a, b, c, d = 30) {
        c.length <= d ? a[b] = EM(c) : (a[b] = EM(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function EM(a) {
        const b = a.length > 0 && typeof a[0] === "string";
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ja(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function FM(a) {
        return a == null ? "null" : typeof a === "string" ? a : typeof a === "boolean" ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function GM(a, b) {
        a.j.op = FM(b)
    }

    function HM(a, b, c) {
        DM(a.j, "fap", b);
        a.j.fad = FM(c)
    }

    function IM(a, b, c) {
        DM(a.j, "fmp", b);
        a.j.fmd = FM(c)
    }

    function JM(a, b, c) {
        DM(a.j, "vap", b);
        a.j.vad = FM(c)
    }

    function KM(a, b, c) {
        DM(a.j, "vmp", b);
        a.j.vmd = FM(c)
    }

    function LM(a, b, c) {
        DM(a.j, "pap", b);
        a.j.pad = FM(c)
    }

    function MM(a, b, c) {
        DM(a.j, "pmp", b);
        a.j.pmd = FM(c)
    }

    function NM(a, b) {
        DM(a.j, "psq", b)
    }
    var OM = class extends BM {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.j = {};
            this.errors = []
        }
        B(a) {
            a = super.B(a);
            Object.assign(a, this.j);
            this.errors.length > 0 && (a.e = EM(this.errors));
            return a
        }
    };

    function PM(a, b, c) {
        const d = b.qa;
        Ws(a.g, d) || a.g.set(d, new QM(wu(pB(b)) ? ? ""));
        c(a.g.get(d))
    }

    function RM(a, b) {
        PM(a, b, c => {
            c.g = !0
        })
    }

    function SM(a, b) {
        PM(a, b, c => {
            c.j = !0
        })
    }

    function TM(a, b) {
        PM(a, b, c => {
            c.l = !0
        });
        a.T.push(b.qa)
    }

    function UM(a, b, c) {
        PM(a, b, d => {
            d.zd = c
        })
    }

    function VM(a, b, c) {
        const d = [];
        let e = 0;
        for (const f of c.filter(b)) rM(f.zd ? ? "") ? ++e : (b = a.j.get(f.zd ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            Bd: e
        }
    }

    function WM(a, b) {
        GM(b, a.j.ee());
        var c = Zs(a.g).filter(f => (f.Pc.startsWith(pM) ? 0 : 1) === 0),
            d = Zs(a.g).filter(f => (f.Pc.startsWith(pM) ? 0 : 1) === 1),
            e = VM(a, f => f.g, c);
        HM(b, e.list, e.Bd);
        e = VM(a, f => f.g, d);
        IM(b, e.list, e.Bd);
        e = VM(a, f => f.j, c);
        JM(b, e.list, e.Bd);
        e = VM(a, f => f.j, d);
        KM(b, e.list, e.Bd);
        c = VM(a, f => f.l, c);
        LM(b, c.list, c.Bd);
        d = VM(a, f => f.l, d);
        MM(b, d.list, d.Bd);
        NM(b, a.T.map(f => a.g.get(f) ? .zd).map(f => a.j.get(f) ? ? null))
    }

    function Vo() {
        var a = M(XM);
        if (!a.A) return Ko();
        const b = To(So(Ro(Qo(Po(Oo(No(Mo(Jo(Io(new Lo, a.A ? ? []), a.K ? ? []), a.D), a.F), a.G), a.V), a.ba), a.J ? ? 0), Zs(a.g).map(c => {
            var d = new Ho;
            d = gi(d, 1, c.Pc);
            var e = a.j.get(c.zd ? ? "", -1);
            d = di(d, 2, e);
            d = ai(d, 3, c.g);
            return ai(d, 4, c.j)
        })), a.T.map(c => a.g.get(c) ? .zd).map(c => a.j.get(c) ? ? -1));
        a.l != null && ai(b, 6, a.l);
        a.B != null && ei(b, 13, a.B);
        return b
    }
    var XM = class {
        constructor() {
            this.B = this.K = this.A = null;
            this.G = this.F = !1;
            this.l = null;
            this.ba = this.D = this.V = !1;
            this.J = null;
            this.j = new $s;
            this.g = new $s;
            this.T = []
        }
    };
    class QM {
        constructor(a) {
            this.l = this.j = this.g = !1;
            this.zd = null;
            this.Pc = a
        }
    };
    var YM = class {
        constructor(a) {
            this.j = a;
            this.g = -1
        }
    };

    function ZM(a) {
        let b = 0;
        for (; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function $M(a, b) {
        const c = a.K.filter(d => Ys(d.Re).every(e => d.Re.get(e) === b.get(e)));
        return c.length === 0 ? (a.j.push(19), null) : c.reduce((d, e) => d.Re.ee() > e.Re.ee() ? d : e, c[0])
    }

    function aN(a, b) {
        b = pB(b);
        if (!vu(b)) return a.j.push(18), null;
        b = b.getValue();
        if (Ws(a.l, b)) return a.l.get(b);
        var c = Iu(b);
        c = $M(a, c);
        a.l.set(b, c);
        return c
    }
    var bN = class {
        constructor(a) {
            this.g = a;
            this.l = new $s;
            this.K = (x(a, Lv, 2) ? .g() || []).map(b => {
                const c = Iu(C(b, 1)),
                    d = Zv(Qh(b, 2));
                return {
                    Re: c,
                    Fj: d,
                    Pc: C(b, 1)
                }
            });
            this.j = []
        }
        G() {
            const a = M(XM);
            var b = this.B();
            a.A = b;
            b = this.D();
            a.K = b;
            b = this.A();
            b != null && (a.B = b);
            b = !!this.g.j() ? .g() ? .g();
            a.G = b;
            b = new $s;
            for (const c of x(this.g, Lv, 2) ? .g() ? ? []) b.set(C(c, 1), Zv(Qh(c, 2)));
            a.j = b
        }
        J() {
            return [...this.j]
        }
        B() {
            return [...this.g.g()]
        }
        D() {
            return [...qh(this.g, 4, Tf, 1, void 0, 1024).map(Zv)]
        }
        A() {
            return Yv(x(this.g, Fv, 5) ? .g()) ? ? null
        }
        F(a) {
            const b =
                aN(this, a);
            b ? .Pc != null && UM(M(XM), a, b.Pc)
        }
        T(a) {
            return a.length == 0 ? !0 : .75 <= (new nu(a)).filter(b => {
                b = aN(this, b) ? .Pc || "";
                return b != "" && !(b === pM || b === qM)
            }).g.length / a.length
        }
    };

    function cN(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => (aN(a.g, c) ? .Fj ? ? Number.MAX_VALUE) - (aN(a.g, d) ? .Fj ? ? Number.MAX_VALUE))
    }

    function dN(a, b) {
        var c = b.Aa.g,
            d = Math,
            e = d.min;
        const f = b.ua(),
            g = b.qa.j();
        c += 200 * e.call(d, 20, g == 0 || g == 3 ? ZM(f.parentElement) : ZM(f));
        a = a.j;
        a.g < 0 && (a.g = Ls(a.j).scrollHeight || 0);
        a = a.g - b.Aa.g;
        a = c + (a > 1E3 ? 0 : 2 * (1E3 - a));
        b.ua();
        return a
    }

    function eN(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => dN(a, c) - dN(a, d))
    }

    function fN(a, b) {
        return b.sort((c, d) => {
            const e = c.qa.J,
                f = d.qa.J;
            var g;
            e == null || f == null ? g = e == null && f == null ? dN(a, c) - dN(a, d) : e == null ? 1 : -1 : g = e - f;
            return g
        })
    }
    var gN = class {
        constructor(a, b = null) {
            this.j = new YM(a);
            this.g = b && new bN(b)
        }
    };

    function hN(a, b, c = 0, d) {
        var e = a.j;
        for (var f of b.B) e = mu(e, f.ib(a.l), iN(f.Xa(), c));
        f = e = e.apply(WC(a.l));
        for (const g of b.j) f = mu(f, g.ib(a.l), Du([jN(g.Xa(), c), h => {
            d ? .g(h, g.Xa())
        }]));
        switch (b.l) {
            case 1:
                f = eN(a.g, f);
                break;
            case 2:
                f = fN(a.g, f);
                break;
            case 3:
                const g = M(XM);
                f = cN(a.g, f);
                e.forEach(h => {
                    RM(g, h);
                    a.g.g ? .F(h)
                });
                f.forEach(h => SM(g, h))
        }
        b.A && (f = pu(f, Wc(a.l.location.href + a.l.localStorage.google_experiment_mod)));
        b.g ? .length === 1 && sM(a.B, b.g[0], {
            zc: e.g.length,
            Zj: f.g.length
        });
        return ou(f)
    }
    var kN = class {
        constructor(a, b, c = null) {
            this.j = new nu(a);
            this.g = new gN(b, c);
            this.l = b;
            this.B = new tM
        }
    };
    const iN = (a, b) => c => QA(c, b, a),
        jN = (a, b) => c => QA(c.qa, b, a);

    function lN(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = mN(nN(c), a);
                    break a;
                case 3:
                    a = mN(c, a);
                    break a;
                case 2:
                    const e = c.lastChild;
                    a = mN(e ? e.nodeType == 1 ? e : nN(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && b == 2 && !oN(c))) b = b == 1 || b == 2 ? c : c.parentNode,
        d = !(b && !jw(b) && b.offsetWidth <= 0);
        return d
    }

    function mN(a, b) {
        if (!a) return !1;
        a = Dd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function nN(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function oN(a) {
        return !!a.nextSibling || !!a.parentNode && oN(a.parentNode)
    };
    const pN = !ad && !Pb();

    function qN(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (pN && a.dataset) {
            if (!(!Lb("Android") || Qb() || Ob() || Nb() || Lb("Silk") || "adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };

    function rN(a, b, c) {
        if (!b) return null;
        const d = Cd("INS");
        d.id = "google_pedestal_container";
        d.style.width = "100%";
        d.style.zIndex = "-1";
        if (c) {
            var e = a.getComputedStyle(c),
                f = "";
            if (e && e.position !== "static") {
                var g = c.parentNode.lastElementChild;
                for (f = e.position; g && g !== c;) {
                    if (a.getComputedStyle(g).display !== "none") {
                        f = a.getComputedStyle(g).position;
                        break
                    }
                    g = g.previousElementSibling
                }
            }
            if (c = f) d.style.position = c
        }
        b.appendChild(d);
        if (d) {
            var h = a.document;
            f = h.createElement("div");
            f.style.width = "100%";
            f.style.height = "2000px";
            c = ts(a);
            e = h.body.scrollHeight;
            a = a.innerHeight;
            g = h.body.getBoundingClientRect().bottom;
            d.appendChild(f);
            var k = f.getBoundingClientRect().top;
            h = h.body.getBoundingClientRect().top;
            d.removeChild(f);
            f = e;
            e <= a && c > 0 && g > 0 && (f = g - h);
            a = k - h >= .8 * f
        } else a = !1;
        return a ? d : (b.removeChild(d), null)
    }

    function sN(a) {
        const b = a.document.body;
        var c = rN(a, b, null);
        if (c) return c;
        if (a.document.body) {
            c = Math.floor(a.document.body.getBoundingClientRect().width);
            for (var d = [{
                    element: a.document.body,
                    depth: 0,
                    height: 0
                }], e = -1, f = null; d.length > 0;) {
                const h = d.pop(),
                    k = h.element;
                var g = h.height;
                h.depth > 0 && g > e && (e = g, f = k);
                if (h.depth < 5)
                    for (g = 0; g < k.children.length; g++) {
                        const l = k.children[g],
                            m = l.getBoundingClientRect().width;
                        (m == null || c == null ? 0 : m >= c * .9 && m <= c * 1.01) && d.push({
                            element: l,
                            depth: h.depth + 1,
                            height: l.getBoundingClientRect().height
                        })
                    }
            }
            c =
                f
        } else c = null;
        return c ? rN(a, c.parentNode || b, c) : null
    }

    function tN(a) {
        let b = 0;
        try {
            b |= rs(a), Rb() || (b |= 1048576), Math.floor(a.document.body.getBoundingClientRect().width) <= 1200 || (b |= 32768), uN(a) && (b |= 33554432)
        } catch (c) {
            b |= 32
        }
        return b
    }

    function uN(a) {
        a = a.document.getElementsByClassName("adsbygoogle");
        for (let b = 0; b < a.length; b++)
            if (qN(a[b]) === "autorelaxed") return !0;
        return !1
    };

    function vN(a) {
        const b = ws(a, !0),
            c = Ls(a).scrollWidth,
            d = Ls(a).scrollHeight;
        let e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = Ps(a);
        const g = [];
        var h = [];
        const k = [],
            l = [];
        var m = [],
            n = [],
            p = [];
        let t = 0,
            u = 0,
            B = Infinity,
            F = Infinity,
            R = null;
        var da = lC({
            rd: !1
        }, a);
        for (var J of da) {
            da = J.getBoundingClientRect();
            const Ya = b - (da.bottom + f);
            var N = void 0,
                aa = void 0;
            if (J.className && J.className.indexOf("adsbygoogle-ablated-ad-slot") != -1) {
                N = J.getAttribute("google_element_uid");
                aa = a.google_sv_map;
                if (!N || !aa || !aa[N]) continue;
                N = (aa = $m(aa[N])) ? aa.height : 0;
                aa = aa ? aa.width : 0
            } else if (N = da.bottom - da.top, aa = da.right - da.left, N <= 1 || aa <= 1) continue;
            g.push(N);
            k.push(aa);
            l.push(N * aa);
            tC(J) ? (u += 1, J.className && J.className.indexOf("pedestal_container") != -1 && (R = N)) : (B = Math.min(B, Ya), n.push(da), t += 1, h.push(N), m.push(N * aa));
            F = Math.min(F, Ya);
            p.push(da)
        }
        B = B === Infinity ? null : B;
        F = F === Infinity ? null : F;
        f = wN(n);
        p = wN(p);
        h = xN(b, h);
        n = xN(b, g);
        m = xN(b * c, m);
        J = xN(b * c, l);
        return new yN(a, {
            ll: e,
            Nh: b,
            Cm: c,
            Am: d,
            jm: t,
            Bk: u,
            Ek: zN(g),
            Fk: zN(k),
            Dk: zN(l),
            sm: f,
            rm: p,
            qm: B,
            pm: F,
            Gg: h,
            Fg: n,
            zk: m,
            yk: J,
            Em: R
        })
    }

    function AN(a, b, c, d) {
        const e = Rb() && !(ss(a.C) >= 900);
        d = La(d, f => Pa(a.j, f)).join(",");
        b = {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.ll ? ? null,
            pg_h: BN(a.g.Nh),
            pg_w: BN(a.g.Cm),
            pg_hs: BN(a.g.Am),
            c: BN(a.g.jm),
            aa_c: BN(a.g.Bk),
            av_h: BN(a.g.Ek),
            av_w: BN(a.g.Fk),
            av_a: BN(a.g.Dk),
            s: BN(a.g.sm),
            all_s: BN(a.g.rm),
            b: BN(a.g.qm),
            all_b: BN(a.g.pm),
            d: BN(a.g.Gg),
            all_d: BN(a.g.Fg),
            ard: BN(a.g.zk),
            all_ard: BN(a.g.yk),
            pd_h: BN(a.g.Em),
            dt: e ? "m" : "d"
        };
        c = {};
        for (const f of Object.keys(b)) b[f] !== null && (c[f] = b[f]);
        return c
    }
    var yN = class {
        constructor(a, b) {
            this.j = "633794002 633794005 21066126 21066127 21065713 21065714 21065715 21065716 42530887 42530888 42530889 42530890 42530891 42530892 42530893".split(" ");
            this.C = a;
            this.g = b
        }
    };

    function zN(a) {
        return Ck.apply(null, La(a, b => b > 0)) || null
    }

    function xN(a, b) {
        return a <= 0 ? null : Bk.apply(null, b) / a
    }

    function wN(a) {
        let b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                c > 0 && (b = Math.min(c, b))
            }
        return b !== Infinity ? b : null
    }

    function BN(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function CN(a) {
        var b = vC({
            rd: !1,
            kf: !1
        }, a);
        a = (ts(a) || 0) - Ps(a);
        let c = 0;
        for (let d = 0; d < b.length; d++) {
            const e = b[d].getBoundingClientRect();
            BC(e) && e.top <= a && (c += 1)
        }
        return c > 0
    }

    function DN(a) {
        const b = {};
        var c = vC({
            rd: !1,
            kf: !1,
            rh: !1,
            sh: !1
        }, a).map(d => d.getBoundingClientRect()).filter(BC);
        b.ni = c.length;
        c = wC({
            rh: !0
        }, a).map(d => d.getBoundingClientRect()).filter(BC);
        b.Pi = c.length;
        c = wC({
            sh: !0
        }, a).map(d => d.getBoundingClientRect()).filter(BC);
        b.wj = c.length;
        c = wC({
            kf: !0
        }, a).map(d => d.getBoundingClientRect()).filter(BC);
        b.ti = c.length;
        c = (ts(a) || 0) - Ps(a);
        c = vC({
            rd: !1
        }, a).map(d => d.getBoundingClientRect()).filter(BC).filter(Aa(EN, null, c));
        b.oi = c.length;
        a = vN(a);
        c = a.g.Gg != null ? a.g.Gg : null;
        c !=
            null && (b.pj = c);
        a = a.g.Fg != null ? a.g.Fg : null;
        a != null && (b.ri = a);
        return b
    }

    function IL(a, b, {
        tf: c,
        cg: d,
        ug: e
    } = {}) {
        return vA(997, () => FN(a, b, {
            tf: c,
            cg: d,
            ug: e
        }), a.g)
    }

    function JL(a, b, c, d) {
        var e = c.yc ? c.yc : a.J;
        const f = LB(e, b.g.length);
        e = a.A.si ? e.g : void 0;
        const g = mM(nM(jM(lM(kM(iM(gM(hM(eM(fM(cM(c.types), a.Fa), c.Uh || []), a.la), c.Vm || [])), f.pe || void 0, e, b), c.minWidth, c.maxWidth)), f.Lc || void 0));
        a.ba && g.g.push(new RL(a.ba));
        b = 1;
        a.Ic() && (b = 3);
        oM(g, b);
        a.A.Rj && (g.B = !0);
        return vA(995, () => hN(a.j, g.build(), d, a.D || void 0), a.g)
    }

    function KL(a, b) {
        const c = sN(a.g);
        if (c) {
            const d = Qu(a.V, b),
                e = aA(a.g.document, a.G, null, null, {}, d);
            e && (zz(e.Ec, c, 2, 256), vA(996, () => GN(a, e, d), a.g))
        }
    }

    function HN(a) {
        return a.K ? a.K : a.K = a.g.google_ama_state
    }

    function FN(a, b, {
        tf: c,
        cg: d,
        ug: e
    } = {}) {
        const f = b.qa;
        if (f.B) return !1;
        var g = b.ua(),
            h = f.j();
        if (!lN(a.g, h, g, a.l)) return !1;
        h = null;
        f.ie ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new Ru(null, {
            google_max_responsive_height: c == null ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = c == null ? null : new Ru(null, {
            google_max_responsive_height: c
        });
        c = Su(Zh(f.Qf, 2) || 0);
        g = Tu(f.J);
        const k = IN(a, f),
            l = JN(a),
            m = Qu(a.V, f.V ? f.V.g(b.Aa) : null, h, d || null, c, g, k, l),
            n = b.fill(a.G, m);
        if (e && !KN(a, n, m) || !vA(996,
                () => GN(a, n, m), a.g)) return !1;
        Cm(9, [f.J, f.yd]);
        a.Ic() && TM(M(XM), b);
        return !0
    }

    function IN(a, b) {
        return wu(Au(nB(b).map(Uu), () => {
            a.B.push(18)
        }))
    }

    function JN(a) {
        if (!a.Ic()) return null;
        var b = a.j.g.g ? .D();
        if (b == null) return null;
        b = b.join("~");
        a = a.j.g.g ? .A() ? ? null;
        return Vu({
            Yk: b,
            vl: a
        })
    }

    function KN(a, b, c) {
        if (!b) return !1;
        var d = b.Ra;
        const e = d.style.width;
        d.style.width = "100%";
        const f = d.offsetWidth;
        d.style.width = e;
        if (Kz(f, a.g, b.Ra, c && c.fe() || {})) return Qz(a.g, b.Ra), !0;
        nw(b.Ec);
        return !1
    }

    function GN(a, b, c) {
        if (!b) return !1;
        try {
            eA(a.g, b.Ra, c)
        } catch (d) {
            return nw(b.Ec), a.B.push(6), !1
        }
        return !0
    }
    var LN = class {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.j = a;
            this.G = b;
            this.g = c;
            this.J = d.yc;
            this.Fa = d.be || [];
            this.V = d.xl || null;
            this.la = d.el || [];
            this.ba = d.dg || [];
            this.A = e;
            this.l = !1;
            this.F = [];
            this.B = [];
            this.T = this.K = void 0;
            this.Ub = f;
            this.D = g ? new tL : null
        }
        xa() {
            return this.g
        }
        Ic() {
            if ((this.j.g.g ? .B().length ? ? 0) == 0) return !1;
            if (this.T === void 0) {
                const a = oM(jM(iM(cM([0, 1, 2]))), 1).build(),
                    b = vA(995, () => hN(this.j, a), this.g);
                this.T = this.j.g.g ? .T(b) || !1
            }
            return this.T
        }
        xh() {
            return !!this.A.Lj
        }
        nf() {
            return !uN(this.g)
        }
        bb() {
            return this.D
        }
    };
    const EN = (a, b) => b.top <= a;

    function MN(a, b, c, d, e, f = 0, g = 0) {
        this.Xb = a;
        this.Jf = f;
        this.If = g;
        this.errors = b;
        this.Uc = c;
        this.g = d;
        this.j = e
    };
    var NN = (a, {
        nf: b = !1,
        xh: c = !1,
        Xm: d = !1,
        Ic: e = !1
    } = {}) => {
        const f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2);
            const g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function ON(a, b, c) {
        a = NN(a, {
            nf: b.nf(),
            xh: b.xh(),
            Xm: !!b.A.ah,
            Ic: b.Ic()
        });
        return new PN(a, b, c)
    }

    function QN(a, b) {
        const c = FL[b];
        return c ? vA(998, () => c(a.g), a.A) : (a.g.F.push(12), !0)
    }

    function RN(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(QN(a, b))
            })
        })
    }

    function SN(a) {
        a.g.l = !0;
        return Promise.all(a.j.map(b => RN(a, b))).then(b => {
            b.includes(!1) && a.g.F.push(5);
            a.j.splice(0, a.j.length)
        })
    }
    var PN = class {
        constructor(a, b, c) {
            this.B = a.slice(0);
            this.j = a.slice(0);
            this.l = Ta(this.j, 1);
            this.g = b;
            this.A = c
        }
    };
    var TN = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function UN(a) {
        return SN(a).then(() => {
            var b = a.g.j.j.filter(NA).g.length;
            var c = a.g.F.slice(0);
            var d = a.g;
            d = [...d.B, ...(d.j.g.g ? .J() || [])];
            b = new MN(b, c, d, a.g.j.j.g.length, a.g.j.B.g, a.g.j.j.filter(NA).filter(OA).g.length, a.g.j.j.filter(OA).g.length);
            return new TN(b)
        })
    };
    var VN = class {
        g() {
            return new Ru([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    var WN = class {
        g() {
            return new Ru(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function XN(a) {
        return kw(a.g.document).map(b => {
            const c = new GA(b, 3);
            b = new IA(gA(a.g, b));
            return new MA(c, b, a.j, !1, 0, [], null, a.g, null)
        })
    }
    var YN = class {
        constructor(a) {
            var b = new WN;
            this.g = a;
            this.j = b || null
        }
    };
    const ZN = {
        hi: "10px",
        sg: "10px"
    };

    function $N(a) {
        return Vs(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new MA(new GA(b, 1), new EA(ZN), a.j, !1, 0, [], null, a.g, null))
    }
    var aO = class {
        constructor(a, b) {
            this.g = a;
            this.j = b || null
        }
    };

    function bO(a, b) {
        const c = [];
        b.forEach((d, e) => {
            c.push(ja(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        DM(a.g, "cnstr", c, 80)
    }
    var cO = class extends yM {
        constructor() {
            super(-1);
            this.g = {}
        }
        B(a) {
            a = super.B(a);
            Object.assign(a, this.g);
            return a
        }
    };
    var dO = class extends Error {
        constructor(a, b, c) {
            super(a);
            this.g = b;
            this.j = c
        }
    };

    function eO(a, b, c) {
        return a == null ? new dO(b + "ShouldNotBeNull", 2, c) : a == 0 ? new dO(b + "ShouldNotBeZero", 3, c) : a < -1 ? new dO(b + "ShouldNotBeLessMinusOne", 4, c) : null
    }

    function fO(a, b, c) {
        const d = eO(c.de, "gapsMeasurementWindow", 1) || eO(c.nd, "gapsPerMeasurementWindow", 2) || eO(c.Dd, "maxGapsToReport", 3);
        return d != null ? tu(d) : c.fg || c.nd != -1 || c.Dd != -1 ? ru(new gO(a, b, c)) : tu(new dO("ShouldHaveLimits", 1, 0))
    }

    function hO(a) {
        return HN(a.l) && HN(a.l).placed || []
    }

    function iO(a) {
        return hO(a).map(b => eu(cu(b.element, a.g)))
    }

    function jO(a) {
        return hO(a).map(b => b.index)
    }

    function kO(a, b) {
        const c = b.qa;
        return !a.D && c.l && wf(w(c.l, 8)) != null && Zh(c.l, 8) == 1 ? [] : c.B ? (c.K || []).map(d => eu(cu(d, a.g))) : [eu(new du(b.Aa.g, 0))]
    }

    function lO(a) {
        a.sort((e, f) => e.g - f.g);
        const b = [];
        let c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.j;
            f <= c ? c = Math.max(c, d) : (b.push(new du(c, f - c)), c = d)
        }
        return b
    }

    function mO(a, b) {
        b = b.map(c => {
            var d = new no;
            d = bi(d, 1, c.g);
            c = c.getHeight();
            return bi(d, 2, c)
        });
        return po(oo(new qo, a), b)
    }

    function nO(a) {
        const b = Gh(a, no, 2, ph()).map(c => `G${Ph(c,1)}~${c.getHeight()}`);
        return `W${Ph(a,1)}${b.join("")}`
    }

    function oO(a, b) {
        const c = [];
        let d = 0;
        for (const e of Ys(b)) {
            const f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.G || f.splice(a.A, f.length);
            !a.J && d + f.length > a.j && f.splice(a.j - d, f.length);
            c.push(mO(e, f));
            d += f.length;
            if (!a.J && d >= a.j) break
        }
        return c
    }

    function pO(a) {
        const b = Gh(a, qo, 5, ph()).map(c => nO(c));
        return `M${Ph(a,1)}H${Ph(a,2)}C${Ph(a,3)}B${Number(!!A(a,4))}${b.join("")}`
    }

    function qO(a) {
        var b = sB(ou(a.l.j.j), a.g),
            c = iO(a),
            d = new at(jO(a));
        for (var e = 0; e < b.length; ++e)
            if (!d.contains(e)) {
                var f = kO(a, b[e]);
                c.push(...f)
            }
        c.push(new du(0, 0));
        c.push(eu(new du(Ls(a.g).scrollHeight, 0)));
        b = lO(c);
        c = new $s;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.F ? 0 : Math.floor(e.g / a.B), Ws(c, f) || c.set(f, []), c.get(f).push(e);
        b = oO(a, c);
        c = new ro;
        c = bi(c, 1, a.j);
        c = bi(c, 2, a.B);
        c = bi(c, 3, a.A);
        a = $h(c, 4, a.D);
        return Ih(a, 5, b)
    }

    function rO(a) {
        a = qO(a);
        return pO(a)
    }
    var gO = class {
        constructor(a, b, c) {
            this.F = c.de == -1;
            this.B = c.de;
            this.G = c.nd == -1;
            this.A = c.nd;
            this.J = c.Dd == -1;
            this.j = c.Dd;
            this.D = c.qh;
            this.l = b;
            this.g = a
        }
    };

    function bw(a, b, c) {
        let d = b.mc;
        b.ud && T(rx) && (d = 1, "r" in c && (c.r += "F"));
        d <= 0 || (!b.Gc || "pvc" in c || (c.pvc = fe(a.g)), iC(b.od, c, d))
    }

    function sO(a, b, c) {
        c = c.B(a.g);
        b.Gc && (c.pvc = fe(a.g));
        0 <= b.mc && (c.r = b.mc, bw(a, b, c))
    }
    var tO = class {
        constructor(a) {
            this.g = a
        }
    };
    const uO = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function vO(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        iC("ama", b, .01)
    }

    function wO(a) {
        const b = {};
        Fd(uO, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function xO(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function yO(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function zO(a, b) {
        a = Uh(a, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function AO(a, b) {
        a = yO(xO(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = Hu(a),
            d = BO(a);
        return b.find(e => {
            if (kh(e, dv, 7)) {
                var f = x(e, dv, 7);
                f = Af(w(f, 1, void 0, gh))
            } else f = Af(w(e, 1, void 0, gh));
            kh(e, dv, 7) ? (e = x(e, dv, 7), e = Zh(e, 2)) : e = 2;
            if (typeof f !== "number") return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function BO(a) {
        const b = {};
        for (;;) {
            b[Hu(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function CO(a, b) {
        try {
            b.removeItem("google_ama_config")
        } catch (c) {
            vO(a, {
                lserr: 1
            })
        }
    };
    var EO = (a, b, c, d, e = null, f = null) => {
            DO(a, new tO(a), b, c, d, e, f)
        },
        DO = (a, b, c, d, e, f = null, g = null) => {
            if (c)
                if (d) {
                    var h = gH(d, e);
                    try {
                        const k = new FO(a, b, c, d, e, h, f, g);
                        ii(d, 35) && c !== Yh(d, 35) ? QJ(M(HJ), kj(jp(kp(new lp, Yh(d, 35)), c))) : vA(990, () => GO(k), a)
                    } catch (k) {
                        Bm() && Cm(15, [k]), sO(b, Tv, xM(vM(uM(AM(zM(new BM(0), d), h), c), 1), k)), JJ(M(HJ), Zo(new hp, ko(1)))
                    }
                } else sO(b, Tv, vM(uM(new BM(0), c), 8)), JJ(M(HJ), Zo(new hp, ko(8)));
            else sO(b, Tv, vM(new BM(0), 9)), JJ(M(HJ), Zo(new hp, ko(9)))
        };

    function GO(a) {
        a.K.forEach(b => {
            switch (b) {
                case 0:
                    vA(991, () => HO(a), a.g);
                    break;
                case 1:
                    vA(1073, () => {
                        $G(new fH(a.g, a.D, a.B, a.A, a.j.ma))
                    }, a.g);
                    break;
                case 2:
                    IO(a);
                    break;
                case 7:
                    vA(1203, () => {
                        var c = x(a.B, Ev, 34);
                        if (c) {
                            var d = a.g,
                                e = a.A,
                                f = bh(c);
                            c = d.location.hostname;
                            var g = x(f, Dv, 1) ? .g() ? ? [];
                            c = new qL(e, c, fe(q), g);
                            if (g = x(f, Dv, 1))
                                if (f = x(f, Cv, 2)) {
                                    gu(d, ZK);
                                    const l = new ft;
                                    var h = d.innerWidth;
                                    var k = .375 * h;
                                    h = new uH(k, h - k);
                                    k = d.innerWidth;
                                    k = ss(d) >= 900 ? .2 * k : .5 * k;
                                    (new lL(d, e, g, f, new SK(d, h, k, l, new CK(l)), c)).run()
                                } else c.reportError("No messages");
                            else c.reportError("No settings")
                        }
                    }, a.g)
            }
        })
    }

    function HO(a) {
        var b = T(ax) ? void 0 : a.j.Hm;
        let c = null;
        c = T(ax) ? IB(a.g) : GB(a.g, b);
        if (a.j.ma && kh(a.j.ma, cv, 10)) {
            var d = bv(a.j.ma.g());
            d !== null && d !== void 0 && (c = wB(a.g, d, b));
            T(vx) && (b = a.j.ma.g(), b ? .g() === 2 && (c = FB(b, c)))
        }
        kh(a.B, Zu, 26) && (c = MB(c, x(a.B, Zu, 26), a.g));
        c = OB(c, a.g);
        b = a.j.ma ? Uh(a.j.ma, 6) : [];
        d = a.j.ma ? Gh(a.j.ma, iv, 5, ph()) : [];
        const e = a.j.ma ? Uh(a.j.ma, 2) : [],
            f = vA(993, () => {
                var g = a.B,
                    h = Gh(g, zv, 1, ph()),
                    k = a.j.ma && zO(a.j.ma, 1) ? "text_image" : "text",
                    l = new VN,
                    m = LA(h, a.g, {
                        Gk: l,
                        Tl: new JA(k)
                    });
                h.length != m.length &&
                    a.G.push(13);
                m = m.concat($N(new aO(a.g, l)));
                h = T(sx);
                l = x(g, Mv, 24) ? .j() ? .g() ? .g() || !1;
                if (h || l) h = XN(new YN(a.g)), l = M(XM), m = m.concat(h), l.V = !0, l.J = h.length, a.F === "n" && (a.F = x(g, Mv, 24) ? .g() ? .length ? "o" : "p");
                h = T(vx) && a.j.ma.g() ? .g() === 2 && a.j.ma.g() ? .j();
                h = T(Zw) || h;
                a: {
                    if (l = x(g, vv, 6))
                        for (n of l.g())
                            if (kh(n, Fu, 4)) {
                                var n = !0;
                                break a
                            }
                    n = !1
                }
                h && n ? (n = m.concat, h = a.g, (l = x(g, vv, 6)) ? (h = kB(l.g(), h), k = rL(g, k, h)) : k = [], k = n.call(m, k)) : (n = m.concat, h = a.g, (l = x(g, vv, 6)) ? (h = jB(l.g(), h), k = rL(g, k, h)) : k = [], k = n.call(m, k));
                m = k;
                g = x(g,
                    Mv, 24);
                return new kN(m, a.g, g)
            }, a.g);
        a.l = new LN(f, a.A, a.g, {
            yc: c,
            xl: a.V,
            be: a.j.be,
            el: b,
            dg: d
        }, JO(a), e, T(rx));
        HN(a.l) ? .optimization ? .ablatingThisPageview && !a.l.Ic() && (fA(a.g), M(XM).D = !0, a.F = "f");
        a.J = ON(e, a.l, a.g);
        vA(992, () => UN(a.J), a.g).then(vA(994, () => a.la.bind(a), a.g), a.ba.bind(a))
    }

    function IO(a) {
        const b = x(a.B, Av, 18);
        b && (new RJ(a.g, new AK(a.g, a.A), b, new uE(a.g), Gh(a.B, zv, 1, ph()))).run()
    }

    function JO(a) {
        const b = T(ux);
        if (!a.B.g()) return {
            Rj: b,
            Ri: !1,
            Lj: !1,
            Fm: 0,
            Dj: 0,
            si: KO(a),
            ah: a.T
        };
        const c = a.B.g();
        return {
            Rj: b || A(c, 14),
            Ri: A(c, 5),
            Lj: A(c, 6),
            Fm: Rh(c, 8),
            Dj: Zh(c, 10),
            si: KO(a),
            ah: a.T
        }
    }

    function KO(a) {
        return T(lx) || T(vx) && a.j.ma ? .g() ? .g() === 2 ? !1 : a.j.ma && kh(a.j.ma, cv, 10) ? (bv(a.j.ma.g()) || 0) >= .5 : !0
    }

    function LO(a, b) {
        var c = new BM(b.Xb);
        c.g.pp = b.If;
        c.g.ppp = b.Jf;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.Wd;
        c.g.eatfAbg = b.Xd;
        c.g.reatf = b.pd;
        c.g.a = a.J.B.slice(0).join(",");
        c = AM(zM(c, a.B), a.K);
        var d = b.pb;
        d && (c.g.as_count = d.ni, c.g.d_count = d.Pi, c.g.ng_count = d.wj, c.g.am_count = d.ti, c.g.atf_count = d.oi, c.g.mdns = CM(d.pj), c.g.alldns = CM(d.ri));
        d = b.Fd;
        d != null && (c.g.allp = d);
        if (d = b.af) {
            var e = [];
            for (var f of Ys(d))
                if (d.get(f).length > 0) {
                    var g = d.get(f)[0];
                    e.push("(" + [f, g.zc, g.Zj].join() + ")")
                }
            c.g.fd = e.join(",")
        }
        f =
            b.Nh;
        f != null && (c.g.pgh = f);
        c.g.abl = b.dj;
        c.g.rr = a.F;
        a = wM(wM(uM(c, a.A), b.errors), a.G);
        c = b.Uc;
        for (e = 0; e < c.length; e++) a: {
            f = a;d = c[e];
            for (g = 0; g < f.D.length; g++)
                if (f.D[g] == d) break a;f.D.push(d)
        }
        b.exception !== void 0 && vM(xM(a, b.exception), 1);
        return a
    }

    function MO(a, b) {
        var c = LO(a, b);
        sO(a.D, b.errors.length > 0 || a.G.length > 0 || b.exception !== void 0 ? Tv : Sv, c);
        if (x(a.B, Mv, 24)) {
            a.l.j.g.g ? .G();
            b = HN(a.l);
            const d = M(XM);
            d.l = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.F = !0);
            d.ba = !!b ? .optimization ? .availableAbg;
            b = M(XM);
            c = new OM(c);
            b.A ? (c.j.sl = EM(b.A ? ? []), c.j.daaos = EM(b.K ? ? []), c.j.ab = FM(b.F), c.j.rr = FM(b.V), c.j.oab = FM(b.G), b.l != null && (c.j.sab = FM(b.l)), b.D && (c.j.fb = FM(b.D)), c.j.ls = FM(b.ba), GM(c, b.j.ee()), b.J != null && (c.j.rp = FM(b.J)),
                b.B != null && (c.j.expl = FM(b.B)), WM(b, c)) : c.errors.push("irr");
            sO(a.D, Vv, c)
        }
        c = a.l ? .bb();
        T(rx) && c != null && (c = new Map([...c.l.map.entries()].map(KK)), b = new cO, bO(b, c), sO(a.D, Xv, b))
    }

    function NO(a, b) {
        if (T(ex) && a.l != null) {
            var c = fO(a.g, a.l, {
                de: U(qx),
                nd: U(px),
                Dd: U(hx),
                qh: !0,
                fg: !1
            });
            if (vu(c)) a = new uo, c = qO(c.getValue()), a = z(a, 2, to, c), y(b, 16, a);
            else {
                var d = c.g;
                a = new uo;
                c = a.setError;
                var e = new so;
                e = hi(e, 2, d.j);
                d = hi(e, 1, d.g);
                a = c.call(a, d);
                y(b, 16, a)
            }
        }
    }

    function OO(a, b) {
        const c = M(HJ);
        if (c.g) {
            var d = new hp,
                e = b.Uc.filter(g => g !== null),
                f = a.G.concat(b.errors, b.exception ? [1] : []).filter(g => g !== null);
            dp(ap(gp(fp(ep(cp(bp(Wo(Yo($o(Xo(d, a.J.B.slice(0).map(g => {
                var h = new jo;
                return hi(h, 1, g)
            })), e.map(g => {
                var h = new mo;
                return hi(h, 1, g)
            })), f.map(g => ko(g))), x(a.B, nv, 23) ? .g()), b.Xb), b.Fd), b.pd), b.Wd), b.Xd), a.K.map(g => g.toString())), Bo(Ao(zo(yo(xo(wo(vo(new Co, b.pb ? .ni), b.pb ? .Pi), b.pb ? .wj), b.pb ? .ti), b.pb ? .oi), b.pb ? .pj), b.pb ? .ri));
            if (b.af)
                for (let g of Ys(b.af)) {
                    e = new xh;
                    for (let h of b.af.get(g)) Go(e, Eo(Do(new Fo, h.zc), h.Zj));
                    wh(d).set(g.toString(), e)
                }
            x(a.B, Mv, 24) && Uo(d);
            NO(a, d);
            JJ(c, d)
        }
    }

    function PO(a, b, c) {
        {
            var d = HN(a.l),
                e = b.g;
            const f = e.g,
                g = e.If;
            let h = e.Xb,
                k = e.Jf,
                l = e.errors.slice(),
                m = e.Uc.slice(),
                n = b.exception;
            const p = rJ(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.J.l && m.push(13), d.exception !== void 0 && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                Xb: h,
                If: g,
                Jf: k,
                Fd: f,
                errors: e.errors.slice(),
                Uc: m,
                exception: n,
                pd: c,
                Wd: !!d.eatf,
                Xd: !!d.eatfAbg,
                dj: p
            }) : (m.push(12), a.J.l && m.push(13), c = {
                Xb: h,
                If: g,
                Jf: k,
                Fd: f,
                errors: l,
                Uc: m,
                exception: n,
                pd: c,
                Wd: !1,
                Xd: !1,
                dj: p
            })
        }
        c.pb = DN(a.l.g);
        if (b = b.g.j) c.af = b;
        c.Nh = Ls(a.g).scrollHeight;
        if (Bm() || x(a.B, mv, 25) ? .j()) {
            d = ou(a.l.j.j);
            b = [];
            for (const f of d) {
                d = {};
                e = f.T;
                for (const g of Ys(e)) d[g] = e.get(g);
                d = {
                    anchorElement: f.F.g(f.g),
                    position: f.j(),
                    clearBoth: f.G,
                    locationType: f.yd,
                    placed: f.B,
                    placementProto: f.l ? rg(f.l) : null,
                    articleStructure: f.A ? rg(f.A) : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            Cm(14, [{
                placementIdentifiers: b
            }, a.l.G, c.pb])
        }
        return c
    }

    function QO(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.Fd;
        c.numAutoAdsPlaced = b.Xb;
        c.hasAtfAd = b.pd;
        b.exception !== void 0 && (c.exception = b.exception);
        if (a.l != null)
            if (a = fO(a.g, a.l, {
                    de: -1,
                    nd: -1,
                    Dd: -1,
                    qh: !0,
                    fg: !0
                }), vu(a)) c.placementPositionDiffs = rO(a.getValue()), b = qO(a.getValue()), a = new uo, a = z(a, 2, to, b), c.placementPositionDiffsReport = jj(a);
            else {
                c.placementPositionDiffs = "E" + a.g.message;
                var d = a.g;
                a = new uo;
                b = a.setError;
                var e = new so;
                e = hi(e, 2, d.j);
                d = hi(e,
                    1, d.g);
                a = b.call(a, d);
                c.placementPositionDiffsReport = jj(a)
            }
    }

    function RO(a, b) {
        MO(a, {
            Xb: 0,
            Fd: void 0,
            errors: [],
            Uc: [],
            exception: b,
            pd: void 0,
            Wd: void 0,
            Xd: void 0,
            pb: void 0
        });
        OO(a, {
            Xb: 0,
            Fd: void 0,
            errors: [],
            Uc: [],
            exception: b,
            pd: void 0,
            Wd: void 0,
            Xd: void 0,
            pb: void 0
        })
    }
    var FO = class {
        constructor(a, b, c, d, e, f, g, h) {
            this.g = a;
            this.D = b;
            this.A = c;
            this.B = d;
            this.j = e;
            this.K = f;
            this.V = g || null;
            this.G = [];
            this.T = h;
            this.F = "n"
        }
        la(a) {
            try {
                const b = CN(this.l.g) || void 0;
                Rv({
                    Kg: b
                }, this.g);
                const c = PO(this, a, CN(this.l.g));
                kh(this.B, mv, 25) && lv(x(this.B, mv, 25)) && QO(this, c);
                MO(this, c);
                OO(this, c);
                gC(753, () => {
                    if (T(dx) && this.l != null) {
                        var d = fO(this.g, this.l, {
                                de: U(qx),
                                nd: U(px),
                                Dd: U(hx),
                                qh: !0,
                                fg: !1
                            }),
                            e = cc(c);
                        vu(d) ? (d = rO(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" + d.g.message;
                        e = LO(this, e);
                        sO(this.D, Uv, e)
                    }
                })()
            } catch (b) {
                RO(this, b)
            }
        }
        ba(a) {
            RO(this, a)
        }
    };

    function SO(a) {
        if (TO(a) && (a = a.data.height, a !== null && !isNaN(a))) return {
            height: Number(a)
        }
    }

    function TO({
        origin: a,
        data: b
    }) {
        return a === "https://www.gstatic.com" && b.action === "resize"
    };
    var UO = class extends H {},
        VO = xk(UO);

    function WO(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? uu(() => VO(c)) : ru(null)
    };

    function XO(a) {
        this.g = a || {
            cookie: ""
        }
    }

    function YO() {
        var a = ZO;
        if (!q.navigator.cookieEnabled) return !1;
        if (!a.isEmpty()) return !0;
        a.set("TESTCOOKIESENABLED", "1", {
            me: 60
        });
        if (a.get("TESTCOOKIESENABLED") !== "1") return !1;
        a.remove("TESTCOOKIESENABLED");
        return !0
    }
    ba = XO.prototype;
    ba.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        typeof c === "object" && (h = c.Nj, g = c.Pf || !1, f = c.domain || void 0, e = c.path || void 0, d = c.me);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        d === void 0 && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (d < 0 ? "" : d == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + d * 1E3)).toUTCString()) + (g ? ";secure" : "") + (h != null ? ";samesite=" + h : "")
    };
    ba.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = Fb(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    ba.remove = function(a, b, c) {
        const d = this.get(a) !== void 0;
        this.set(a, "", {
            me: 0,
            path: b,
            domain: c
        });
        return d
    };
    ba.isEmpty = function() {
        return !this.g.cookie
    };
    ba.ee = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    ba.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [],
            c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = Fb(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; a >= 0; a--) this.remove(b[a])
    };
    var ZO = new XO(typeof document == "undefined" ? null : document);

    function $O(a, b = window) {
        if (a.ca()) try {
            return b.localStorage
        } catch {}
        return null
    }
    let aP;

    function bP(a) {
        return aP ? aP : a.origin === "null" ? aP = !1 : aP = cP(a)
    }

    function cP(a) {
        if (!a.navigator.cookieEnabled) return !1;
        const b = new XO(a.document);
        if (!b.isEmpty()) return !0;
        b.set("TESTCOOKIESENABLED", "1", {
            me: 60,
            Nj: a.isSecureContext ? "none" : void 0,
            Pf: a.isSecureContext || void 0
        });
        if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
        b.remove("TESTCOOKIESENABLED");
        return !0
    }

    function dP(a, b) {
        b = b.origin !== "null" ? b.document.cookie : null;
        return b === null ? null : (new XO({
            cookie: b
        })).get(a) || ""
    }

    function eP(a, b, c, d) {
        d.origin !== "null" && (d.isSecureContext && (c = { ...c,
            Nj: "none",
            Pf: !0
        }), (new XO(d.document)).set(a, b, c))
    };

    function fP(a, b) {
        return $h(a, 5, b)
    }

    function gP(a, b) {
        return $h(a, 8, b)
    }

    function hP(a, b) {
        return $h(a, 12, b)
    }

    function iP(a, b) {
        return $h(a, 16, b)
    }
    var jP = class extends H {
        B() {
            return ii(this, 1)
        }
        j() {
            return ii(this, 2)
        }
        g() {
            return A(this, 3)
        }
        ca() {
            return A(this, 5)
        }
    };
    var nP = ({
            Db: a,
            C: b,
            Ma: c,
            hf: d = !1,
            jf: e = !1
        }) => {
            kP({
                C: b,
                Ma: c,
                hf: d,
                jf: e
            }) ? (b = (b = oJ(dJ())) ? lP(b) : void 0) ? a(ru(b)) : mP().then(f => f.map(lP)).then(a) : a(ru(fP(new jP, !0)))
        },
        pP = ({
            C: a,
            Ma: b,
            hf: c = !1,
            jf: d = !1
        }) => kP({
            C: a,
            Ma: b,
            hf: c,
            jf: d
        }) ? (b = oJ(dJ())) ? oP(a, lP(b)) : tu(Error("tcunav")) : oP(a, fP(new jP, !0));

    function kP({
        C: a,
        Ma: b,
        hf: c,
        jf: d
    }) {
        if (!(d = !d && tK(new xK(a)))) {
            if (c = !c) {
                if (b) {
                    a = WO(a);
                    if (vu(a))
                        if ((a = a.getValue()) && wf(w(a, 1)) != null) b: switch (a = D(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else jC(806, a.g), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function mP() {
        return (new Promise(a => {
            var b = dJ();
            a = {
                resolve: a
            };
            const c = iJ(b, 25, []);
            c.push(a);
            jJ(b, 25, c)
        })).then(qP)
    }

    function qP(a) {
        return a ? ru(a) : tu(Error("tcnull"))
    }

    function lP(a) {
        return fP(new jP, oK(a))
    }

    function oP(a, b) {
        return (a = $O(b, a)) ? ru(a) : tu(Error("unav"))
    };

    function rP(a, b, c, d, e) {
        return new sP(a, b, c, d, e)
    }

    function tP(a) {
        a.j = !0;
        return a
    }
    var sP = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.A = b;
            this.B = c;
            this.j = !1;
            this.l = d;
            this.D = e
        }
        run() {
            const a = this.B;
            if (this.j) {
                var b = this.g;
                if (this.l && !YI(a)) {
                    var c = new UO;
                    c = hi(c, 1, 1)
                } else c = null;
                if (c) {
                    c = jj(c);
                    try {
                        b.localStorage.setItem("google_auto_fc_cmp_setting", c)
                    } catch (d) {}
                }
            }
            b = YI(a) && (this.l || this.D);
            a && b && (new RJ(this.g, new AK(this.g, this.A), a, new uE(this.g))).run()
        }
    };
    var uP = class extends H {
        getName() {
            return D(this, 1)
        }
        getVersion() {
            return C(this, 3)
        }
    };
    var vP = [0, sk, -1, mk];
    var wP = class extends H {
        Gl() {
            return D(this, 3)
        }
    };
    const xP = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var yP = class extends H {
        getVersion() {
            return Ph(this, 2)
        }
    };

    function zP(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function AP(a) {
        return re(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function BP(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function CP(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function DP(a, b) {
        a = AP(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function EP(a) {
        var b = AP(a),
            c = BP(b.slice(0, 6));
        a = BP(b.slice(6, 12));
        var d = new yP;
        c = E(d, 1, c);
        a = E(c, 2, a);
        b = b.slice(12);
        c = BP(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = BP(e[0]) === 0;
            e = e.slice(1);
            var g = FP(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = CP(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = FP(e, b);
                g = CP(f);
                for (let l = 0; l <= g; l++) d.push(h + l);
                e = e.slice(f.length)
            }
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return yh(a, 3, d, xf)
    }

    function FP(a, b) {
        const c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var GP = class extends H {
        g() {
            return D(this, 1)
        }
        j() {
            return D(this, 2)
        }
    };
    var HP = class extends H {};
    var IP = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    var JP = class extends H {};

    function KP(a) {
        var b = new LP;
        return y(b, 1, a)
    }
    var LP = class extends H {};
    const MP = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        NP = 6 + MP.reduce((a, b) => a + b);
    var OP = class extends H {};
    var PP = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    var QP = class extends H {};

    function RP(a) {
        var b = new SP;
        return y(b, 1, a)
    }
    var SP = class extends H {};
    const TP = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        UP = 6 + TP.reduce((a, b) => a + b);
    var VP = class extends H {
        g() {
            return D(this, 1)
        }
        j() {
            return D(this, 2)
        }
        B() {
            return D(this, 3)
        }
    };
    var WP = class extends H {};
    var XP = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    var YP = class extends H {};

    function ZP(a) {
        var b = new $P;
        return y(b, 1, a)
    }
    var $P = class extends H {};
    const aQ = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        bQ = 6 + aQ.reduce((a, b) => a + b);
    var cQ = class extends H {
        g() {
            return D(this, 1)
        }
        j() {
            return D(this, 2)
        }
        B() {
            return D(this, 3)
        }
    };
    var dQ = class extends H {};
    var eQ = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    const fQ = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        gQ = 6 + fQ.reduce((a, b) => a + b);
    var hQ = class extends H {
        j() {
            return D(this, 1)
        }
        B() {
            return D(this, 2)
        }
        g() {
            return D(this, 3)
        }
    };
    var iQ = class extends H {};

    function jQ(a) {
        var b = new kQ;
        return E(b, 1, a)
    }
    var kQ = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    var lQ = class extends H {};

    function mQ(a) {
        var b = new nQ;
        return y(b, 1, a)
    }
    var nQ = class extends H {};
    const oQ = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        pQ = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        qQ = 6 + pQ.reduce((a, b) => a + b);

    function rQ(a, b = [1]) {
        if (a.length === 0) throw Error("Cannot decode empty USNat section string.");
        var c = a.split(".");
        if (c.length > 2) throw Error(`Expected at most 2 segments but got ${c.length} when decoding ${a}.`);
        a = sQ(c[0], b);
        if (c.length === 1) a = mQ(a);
        else {
            a = mQ(a);
            c = c[1];
            if (c.length === 0) throw Error("Cannot decode empty GPC segment string.");
            b = DP(c, 3);
            c = BP(b.slice(0, 2));
            if (c < 0 || c > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${c}.`);
            c += 1;
            b = BP(b.charAt(2));
            var d = new lQ;
            c = G(d, 2,
                c);
            c = ai(c, 1, !!b);
            a = y(a, 2, c)
        }
        return a
    }

    function sQ(a, b = [1]) {
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        let c = DP(a, qQ);
        const d = BP(c.slice(0, 6));
        c = c.slice(6);
        if (!b.includes(d)) throw Error("Unable to decode unsupported USNat Section specification version " + `${d} - only ` + `version${b.length>1?"s":""} ` + `${b.join(", ")} ` + `${b.length>1?"are":"is"} supported.`);
        let e = 0;
        const f = [],
            g = d === 1 ? oQ : pQ;
        for (let Si = 0; Si < g.length; Si++) {
            const Ql = g[Si];
            f.push(BP(c.slice(e, e + Ql)));
            e += Ql
        }
        if (d === 1) {
            var h = jQ(d),
                k = f.shift();
            var l =
                G(h, 2, k);
            var m = f.shift();
            var n = G(l, 3, m);
            var p = f.shift();
            var t = G(n, 4, p);
            var u = f.shift();
            var B = G(t, 5, u);
            var F = f.shift();
            var R = G(B, 6, F);
            var da = f.shift();
            var J = G(R, 7, da);
            var N = f.shift();
            var aa = G(J, 8, N);
            var Ya = f.shift();
            var Sb = G(aa, 9, Ya);
            var za = f.shift();
            var Ha = G(Sb, 10, za);
            var Yc = new iQ,
                Ic = f.shift();
            var Jc = G(Yc, 1, Ic);
            var Id = f.shift();
            var ua = G(Jc, 2, Id);
            var pd = f.shift();
            var Ne = G(ua, 3, pd);
            var Fg = f.shift();
            var Gg = G(Ne, 4, Fg);
            var Hg = f.shift();
            var Ig = G(Gg, 5, Hg);
            var Jg = f.shift();
            var Kg = G(Ig, 6, Jg);
            var Lg = f.shift();
            var Mg = G(Kg, 7, Lg);
            var Ng = f.shift();
            var Og = G(Mg, 8, Ng);
            var Pg = f.shift();
            var Ti = G(Og, 9, Pg);
            var Ui = f.shift();
            var Vi = G(Ti, 10, Ui);
            var Wi = f.shift();
            var Xi = G(Vi, 11, Wi);
            var Yi = f.shift();
            var Cf = G(Xi, 12, Yi);
            var Zi = y(Ha, 11, Cf);
            var Qg = new hQ,
                $i = f.shift();
            var Df = G(Qg, 1, $i);
            var aj = f.shift();
            var bj = G(Df, 2, aj);
            var mc = y(Zi, 12, bj);
            var cj = f.shift();
            var dj = G(mc, 13, cj);
            var ej = f.shift();
            var Rg = G(dj, 14, ej);
            var Sg = f.shift();
            var Tg = G(Rg, 15, Sg);
            var Ug = f.shift();
            var Yb = G(Tg, 16, Ug)
        } else {
            var qd = jQ(d),
                Qa = f.shift();
            var Zb = G(qd,
                2, Qa);
            var Vg = f.shift();
            var ae = G(Zb, 3, Vg);
            var Oe = f.shift();
            var nc = G(ae, 4, Oe);
            var $b = f.shift();
            var Zc = G(nc, 5, $b);
            var rd = f.shift();
            var ub = G(Zc, 6, rd);
            var oc = f.shift();
            var Wg = G(ub, 7, oc);
            var fj = f.shift();
            var Xg = G(Wg, 8, fj);
            var sd = f.shift();
            var Yg = G(Xg, 9, sd);
            var Ef = f.shift();
            var Ff = G(Yg, 10, Ef);
            var be = new iQ,
                Zg = f.shift();
            var $g = G(be, 1, Zg);
            var Tq = f.shift();
            var Uq = G($g, 2, Tq);
            var Vq = f.shift();
            var Wq = G(Uq, 3, Vq);
            var Xq = f.shift();
            var Yq = G(Wq, 4, Xq);
            var Zq = f.shift();
            var $q = G(Yq, 5, Zq);
            var ar = f.shift();
            var br = G($q,
                6, ar);
            var cr = f.shift();
            var dr = G(br, 7, cr);
            var er = f.shift();
            var fr = G(dr, 8, er);
            var gr = f.shift();
            var hr = G(fr, 9, gr);
            var ir = f.shift();
            var jr = G(hr, 10, ir);
            var kr = f.shift();
            var lr = G(jr, 11, kr);
            var mr = f.shift();
            var nr = G(lr, 12, mr);
            var or = f.shift();
            var pr = G(nr, 13, or);
            var qr = f.shift();
            var rr = G(pr, 14, qr);
            var Rl = f.shift();
            var Sl = G(rr, 15, Rl);
            var Tl = f.shift();
            var Ul = G(Sl, 16, Tl);
            var Vl = y(Ff, 11, Ul);
            var Wl = new hQ,
                Xl = f.shift();
            var Yl = G(Wl, 1, Xl);
            var Zl = f.shift();
            var $l = G(Yl, 2, Zl);
            var am = f.shift();
            var bm = G($l, 3, am);
            var cm =
                y(Vl, 12, bm);
            var dm = f.shift();
            var em = G(cm, 13, dm);
            var fm = f.shift();
            var gm = G(em, 14, fm);
            var hm = f.shift();
            var sr = G(gm, 15, hm);
            var tr = f.shift();
            Yb = G(sr, 16, tr)
        }
        return Yb
    };
    var tQ = class extends H {};
    var uQ = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    const vQ = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        wQ = 6 + vQ.reduce((a, b) => a + b);
    var xQ = class extends H {};

    function yQ(a, b) {
        return yh(a, 1, b, vf)
    }

    function zQ(a, b) {
        return yh(a, 2, b, vf)
    }

    function AQ(a, b) {
        return yh(a, 3, b, xf)
    }

    function BQ(a, b) {
        yh(a, 4, b, xf)
    }
    var CQ = class extends H {};

    function DQ(a, b) {
        return di(a, 1, b)
    }

    function EQ(a) {
        var b = Number; {
            var c = w(a, 1);
            const d = typeof c;
            c = c == null ? c : d === "bigint" ? String(kf(64, c)) : uf(c) ? d === "string" ? Gf(c) : Hf(c) : void 0
        }
        b = b(c ? ? "0");
        a = Ph(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var FQ = class extends H {};

    function GQ(a, b) {
        return E(a, 1, b)
    }

    function HQ(a, b) {
        return y(a, 2, b)
    }

    function IQ(a, b) {
        return y(a, 3, b)
    }

    function JQ(a, b) {
        return E(a, 4, b)
    }

    function KQ(a, b) {
        return E(a, 5, b)
    }

    function LQ(a, b) {
        return E(a, 6, b)
    }

    function MQ(a, b) {
        return gi(a, 7, b)
    }

    function NQ(a, b) {
        return E(a, 8, b)
    }

    function OQ(a, b) {
        return E(a, 9, b)
    }

    function PQ(a, b) {
        return ai(a, 10, b)
    }

    function QQ(a, b) {
        return ai(a, 11, b)
    }

    function RQ(a, b) {
        return yh(a, 12, b, vf)
    }

    function SQ(a, b) {
        return yh(a, 13, b, vf)
    }

    function TQ(a, b) {
        return yh(a, 14, b, vf)
    }

    function UQ(a, b) {
        return ai(a, 15, b)
    }

    function VQ(a, b) {
        return gi(a, 16, b)
    }

    function WQ(a, b) {
        return yh(a, 17, b, xf)
    }

    function XQ(a, b) {
        return yh(a, 18, b, xf)
    }

    function YQ(a, b) {
        return Ih(a, 19, b)
    }
    var ZQ = class extends H {
        getVersion() {
            return Ph(this, 1)
        }
    };
    var $Q = class extends H {};
    var aR = "a".charCodeAt(),
        bR = bc(js),
        cR = bc(ks);

    function dR(a, b) {
        if (a.g + b > a.j.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.j.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function eR(a) {
        a = dR(a, 36);
        var b = DQ(new FQ, Math.floor(a / 10));
        return E(b, 2, a % 10 * 1E8)
    }

    function fR(a) {
        return String.fromCharCode(aR + dR(a, 6)) + String.fromCharCode(aR + dR(a, 6))
    }

    function gR(a) {
        let b = dR(a, 12);
        const c = [];
        for (; b--;) {
            var d = !!dR(a, 1) === !0,
                e = dR(a, 16);
            if (d)
                for (d = dR(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function hR(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (dR(a, 1)) {
                const f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function iR(a) {
        const b = dR(a, 16);
        return !!dR(a, 1) === !0 ? (a = gR(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : hR(a, b)
    }

    function jR(a) {
        const b = [];
        let c = dR(a, 12);
        for (; c--;) {
            const k = dR(a, 6);
            var d = dR(a, 2),
                e = gR(a),
                f = b,
                g = f.push;
            var h = new xQ;
            h = G(h, 1, k);
            d = G(h, 2, d);
            e = yh(d, 3, e, xf);
            g.call(f, e)
        }
        return b
    }
    var kR = class {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.j = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var lR = a => {
        try {
            const b = re(a).map(f => f.toString(2).padStart(8, "0")).join(""),
                c = new kR(b);
            if (dR(c, 3) !== 3) return null;
            const d = zQ(yQ(new CQ, hR(c, 24, bR)), hR(c, 24, bR)),
                e = dR(c, 6);
            e !== 0 && BQ(AQ(d, hR(c, e)), hR(c, e));
            return d
        } catch (b) {
            return null
        }
    };
    var mR = a => {
        try {
            const b = re(a).map(d => d.toString(2).padStart(8, "0")).join(""),
                c = new kR(b);
            return YQ(XQ(WQ(VQ(UQ(TQ(SQ(RQ(QQ(PQ(OQ(NQ(MQ(LQ(KQ(JQ(IQ(HQ(GQ(new ZQ, dR(c, 6)), eR(c)), eR(c)), dR(c, 12)), dR(c, 12)), dR(c, 6)), fR(c)), dR(c, 12)), dR(c, 6)), !!dR(c, 1)), !!dR(c, 1)), hR(c, 12, cR)), hR(c, 24, bR)), hR(c, 24, bR)), !!dR(c, 1)), fR(c)), iR(c)), iR(c)), jR(c))
        } catch (b) {
            return null
        }
    };
    var oR = a => {
        if (!a) return null;
        a = a.split(".");
        if (a.length > 4) return null;
        var b = mR(a[0]);
        if (!b) return null;
        var c = new $Q;
        b = y(c, 1, b);
        a.shift();
        for (const d of a) switch (nR(d)) {
            case 1:
            case 2:
                break;
            case 3:
                a = lR(d);
                if (!a) return null;
                y(b, 2, a);
                break;
            default:
                return null
        }
        return b
    };
    const nR = a => {
        try {
            const b = re(a).map(c => c.toString(2).padStart(8, "0")).join("");
            return dR(new kR(b), 3)
        } catch (b) {
            return -1
        }
    };
    const pR = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var rR = (a, b) => {
        try {
            var c = re(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new kR(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = b;
            d.skip(78);
            c.cmpId = dR(d, 12);
            c.cmpVersion = dR(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = dR(d, 6);
            c.isServiceSpecific = !!dR(d, 1);
            c.useNonStandardStacks = !!dR(d, 1);
            c.specialFeatureOptins = qR(hR(d, 12, cR), cR);
            c.purpose = {
                consents: qR(hR(d, 24, bR), bR),
                legitimateInterests: qR(hR(d, 24, bR), bR)
            };
            c.purposeOneTreatment = !!dR(d, 1);
            c.publisherCC = fR(d);
            c.vendor = {
                consents: qR(iR(d), null),
                legitimateInterests: qR(iR(d), null)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const qR = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };

    function Rr(a, ...b) {
        try {
            const c = encodeURIComponent(oe(Ln(b, a.j)));
            a.l(`${"https://pagead2.googlesyndication.com/pagead/ping"}?e=${4}&d=${c}`)
        } catch (c) {
            Kn(c, a.j)
        }
    }
    var sR = class extends Sr {
        constructor(a) {
            super(7, Kq());
            this.l = a
        }
    };
    var tR = class extends H {
        g() {
            return ii(this, 2)
        }
    };
    var uR = class extends H {
        B() {
            return ii(this, 2)
        }
    };
    var vR = class extends H {
        j() {
            return ii(this, 1)
        }
    };
    var wR = xk(class extends H {});

    function xR(a) {
        a = yR(a);
        try {
            var b = a ? wR(a) : null
        } catch (c) {
            b = null
        }
        return b ? x(b, vR, 4) || null : null
    }

    function yR(a) {
        a = (new XO(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function zR(a) {
        a.__tcfapiPostMessageReady || AR(new BR(a))
    }

    function AR(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.C.__tcfapi)(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.C.addEventListener("message", a.g);
        a.C.__tcfapiPostMessageReady = !0
    }
    var BR = class {
        constructor(a) {
            this.C = a
        }
    };

    function CR(a) {
        a.__uspapiPostMessageReady || DR(new ER(a))
    }

    function DR(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.C.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.C.addEventListener("message", a.g);
        a.C.__uspapiPostMessageReady = !0
    }
    var ER = class {
        constructor(a) {
            this.C = a;
            this.g = null
        }
    };
    var FR = class extends H {};
    var GR = xk(class extends H {
        g() {
            return ii(this, 1)
        }
    });

    function HR(a, b) {
        function c(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 4));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function d(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function e(n) {
            if (n.length < 12) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(8, 12));
            n = l(n);
            return "1" + p + n + "N"
        }

        function f(n) {
            if (n.length < 18) return null;
            var p = h(n.slice(0, 8));
            p = k(p);
            n = h(n.slice(12, 18));
            n = l(n);
            return "1" + p + n + "N"
        }

        function g(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function h(n) {
            const p = [];
            let t = 0;
            for (let u = 0; u < n.length / 2; u++) p.push(BP(n.slice(t, t + 2))), t += 2;
            return p
        }

        function k(n) {
            return n.every(p => p === 1) ? "Y" : "N"
        }

        function l(n) {
            return n.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = AP(a[0]);
        const m = BP(a.slice(0, 6));
        a = a.slice(6);
        if (m !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function IR(a, b) {
        var c = T(Wy);
        a !== a.top || !c && (a.__uspapi || a.frames.__uspapiLocator) || (a = new JR(a, b), KR(a), LR(a))
    }

    function KR(a) {
        !a.l || a.C.__uspapi || a.C.frames.__uspapiLocator || (a.C.__uspapiManager = "fc", $J(a.C, "__uspapiLocator"), Ca("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && (b = !A(a.j, 3), d({
                version: 1,
                uspString: b ? "1---" : a.l
            }, !0))
        }, a.C), CR(a.C))
    }

    function LR(a) {
        !a.tcString || a.C.__tcfapi || a.C.frames.__tcfapiLocator || (a.C.__tcfapiManager = "fc", $J(a.C, "__tcfapiLocator"), a.C.__tcfapiEventListeners = a.C.__tcfapiEventListeners || [], Ca("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.2 || c <= 1)) d(null, !1);
                else {
                    var f = a.C.__tcfapiEventListeners;
                    c = !a.j.g();
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: !c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.2",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            e = f.push(d);
                            b = !c;
                            --e;
                            a.tcString ? (b = rR(a.tcString, b), b.addtlConsent = a.g != null ? a.g : void 0, b.cmpStatus = "loaded", b.eventStatus = "tcloaded", e != null && (b.listenerId = e)) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.C), zR(a.C))
    }

    function MR(a) {
        if (!a ? .g() || C(a, 1).length === 0 || Gh(a, FR, 2, ph()).length === 0) return null;
        const b = C(a, 1);
        let c;
        try {
            var d = EP(b.split("~")[0]);
            c = zP(b)
        } catch (e) {
            return null
        }
        a = Gh(a, FR, 2, ph()).reduce((e, f) => {
            var g = NR(e);
            g = Qh(g, 1);
            g = Zv(g);
            var h = NR(f);
            h = Qh(h, 1);
            return g > Zv(h) ? e : f
        });
        d = Sh(d, 3).indexOf(Ph(a, 1));
        return d === -1 || d >= c.length ? null : {
            uspString: HR(c[d], Ph(a, 1)),
            Dg: EQ(NR(a))
        }
    }

    function OR(a) {
        a = a.find(b => b && D(b, 1) === 13);
        if (a ? .g()) try {
            return GR(C(a, 2))
        } catch (b) {}
        return null
    }

    function NR(a) {
        return kh(a, FQ, 2) ? x(a, FQ, 2) : DQ(new FQ, 0)
    }
    var JR = class {
        constructor(a, b) {
            this.C = a;
            this.j = b;
            b = yR(this.C.document);
            try {
                var c = b ? wR(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = x(b, uR, 5) || null, b = Gh(b, tR, 7, ph()), b = OR(b ? ? []), c = {
                Ei: c,
                cj: b
            }) : c = {
                Ei: null,
                cj: null
            };
            b = c;
            c = MR(b.cj);
            b = b.Ei;
            if (b ? .B() && C(b, 2).length !== 0) {
                var d = kh(b, FQ, 1) ? x(b, FQ, 1) : DQ(new FQ, 0);
                b = {
                    uspString: C(b, 2),
                    Dg: EQ(d)
                }
            } else b = null;
            this.l = b && c ? c.Dg > b.Dg ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.tcString = (c = xR(a.document)) && c.j() ? C(c, 1) : null;
            this.g = (a = xR(a.document)) && ii(a, 2) ? C(a,
                2) : null
        }
    };

    function PR() {
        const a = Hb();
        return a ? Oa("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), b => Gb(a, b)) || Gb(a, "OMI/") && !Gb(a, "XiaoMi/") ? !0 : Gb(a, "Presto") && Gb(a, "Linux") && !Gb(a, "X11") && !Gb(a, "Android") && !Gb(a, "Mobi") : !1
    };

    function QR(a) {
        const b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return (b <= .03928 ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) * .2126 + (c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) * .7152 + (a <= .03928 ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4)) * .0722
    }
    var RR = (a, b) => {
        a = QR(a);
        b = QR(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };

    function SR(a, b, c, d = null) {
        const e = g => {
            let h;
            try {
                h = JSON.parse(g.data)
            } catch (k) {
                return
            }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
        };
        ql(a, "message", e);
        let f = !1;
        return () => {
            let g = !1;
            f || (f = !0, g = rl(a, "message", e));
            return g
        }
    }

    function TR(a, b, c, d = null) {
        const e = SR(a, b, vb(c, () => e()), d);
        return e
    }

    function UR(a, b, c, d) {
        c.googMsgType = b;
        a.postMessage(JSON.stringify(c), d)
    }

    function VR(a, b, c, d, e) {
        if (!(e <= 0) && (UR(a, b, c, d), a = a.frames))
            for (let f = 0; f < a.length; ++f) e > 1 && VR(a[f], b, c, d, --e)
    };

    function WR(a, b, c, d) {
        return SR(a, "fullscreen", d.lc(952, (e, f) => {
            if (f.source === b) {
                if (!("eventType" in e)) throw Error(`bad message ${JSON.stringify(e)}`);
                delete e.googMsgType;
                c(e)
            }
        }))
    };
    class YR {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };
    async function ZR(a) {
        return a.A.promise
    }
    async function $R(a) {
        return a.j.promise
    }
    async function aS(a) {
        return a.l.promise
    }

    function bS(a, b) {
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = .25;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.D.ln;
        b.version = a.D.version;
        Fn(a.L, "fullscreen_tag", b, !1, .25)
    }
    class cS extends O {
        constructor(a, b, c) {
            var d = cC,
                e = aC,
                f = {
                    ln: 2,
                    version: Kq()
                };
            super();
            this.slotType = a;
            this.pubWin = b;
            this.Cg = c;
            this.hb = d;
            this.L = e;
            this.D = f;
            this.state = 1;
            this.qem = null;
            this.A = new YR;
            this.j = new YR;
            this.l = new YR
        }
        init() {
            const a = WR(this.pubWin, this.Cg, b => {
                if (b.eventType === "adError") this.l.resolve(), this.state = 4;
                else if (b.eventType === "adReady" && this.state === 1) this.qem = b.qem, b.slotType !== this.slotType && (bS(this, {
                        cur_st: this.state,
                        evt: b.eventType,
                        adp_tp: b.slotType
                    }), this.state = 4), this.A.resolve(),
                    this.state = 2;
                else if (b.eventType === "adClosed" && this.state === 2) this.j.resolve(b.result), this.state = 3;
                else if (b.eventType !== "adClosed" || this.state !== 3) b.eventType === "adClosed" && b.closeAfterError && (this.j.resolve(b.result), this.state = 3), bS(this, {
                    cur_st: this.state,
                    evt: b.eventType
                }), this.state = 4
            }, this.hb);
            jt(this, a)
        }
    };
    var dS = Promise;
    class eS {
        constructor(a) {
            this.l = a
        }
        g(a, b, c) {
            this.l.then(d => {
                d.g(a, b, c)
            })
        }
        j(a, b) {
            return this.l.then(c => c.j(a, b))
        }
    };
    class fS {
        constructor(a) {
            this.data = a
        }
    };

    function gS(a, b) {
        hS(a, b);
        return new iS(a)
    }
    class iS {
        constructor(a) {
            this.l = a
        }
        g(a, b, c = []) {
            const d = new MessageChannel;
            hS(d.port1, b);
            this.l.postMessage(a, [d.port2].concat(c))
        }
        j(a, b) {
            return new dS(c => {
                this.g(a, c, b)
            })
        }
    }

    function hS(a, b) {
        b && (a.onmessage = c => {
            b(new fS(c.data, gS(c.ports[0])))
        })
    };
    var jS = class {
        constructor(a) {
            this.g = a
        }
    };
    const kS = a => {
        const b = Object.create(null);
        (typeof a === "string" ? [a] : a).forEach(c => {
            if (c === "null") throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
            b[c] = !0
        });
        return c => b[c] === !0
    };
    var mS = ({
        destination: a,
        O: b,
        origin: c,
        Ib: d = "ZNWN1d",
        onMessage: e,
        zj: f
    }) => lS({
        destination: a,
        Hl: () => b.contentWindow,
        wm: c instanceof jS ? c : typeof c === "function" ? new jS(c) : new jS(kS(c)),
        Ib: d,
        onMessage: e,
        zj: f
    });
    const lS = ({
        destination: a,
        Hl: b,
        wm: c,
        jr: d,
        Ib: e,
        onMessage: f,
        zj: g
    }) => new eS(new dS((h, k) => {
        const l = m => {
            m.source && m.source === b() && c.g(m.origin) && (m.data.n || m.data) === e && (a.removeEventListener("message", l, !1), d && m.data.t !== d ? k(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${m.data.t}.`)) : (h(gS(m.ports[0], f)), g && g(m)))
        };
        a.addEventListener("message", l, !1)
    }));

    function nS(a) {
        return eb(b => {
            if (b instanceof a) return !0;
            const c = b ? .ownerDocument ? .defaultView ? .[a.name];
            return hb(c) && b instanceof c
        })
    }
    nS(Node);
    var oS = nS(Element),
        pS = nS(HTMLElement);
    nS(SVGElement);
    var qS = vk(bo);
    var rS = vk(co);
    var sS = vk(fo);
    var tS = vk(ao);
    var uS = vk(eo);

    function vS(a, b, c, d, e, f = null) {
        if (e) {
            if (T($w)) var g = null;
            else try {
                g = e.getItem("google_ama_config")
            } catch (l) {
                g = null
            }
            try {
                var h = g ? Nv(g) : null
            } catch (l) {
                h = null
            }
        } else h = null;
        a: {
            if (d) try {
                var k = Nv(d);
                break a
            } catch (l) {
                vO(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            k = null
        }
        if (d = k) {
            if (e) {
                k = new av;
                y(d, 3, k);
                h = Yv(d ? .g() ? .j()) || 1;
                h = Date.now() + 864E5 * h;
                Number.isFinite(h) && ci(k, 1, Math.round(h));
                k = ah(d);
                d.g() && (h = new $u, g = d ? .g() ? .g(), h = $h(h, 23, g), g = d ? .g() ? .B(), h = $h(h, 12, g), y(k, 15, h));
                h = Gh(k, zv, 1, ph());
                for (g = 0; g < h.length; g++) ih(h[g], 11);
                ih(k, 22);
                if (T($w)) CO(a, e);
                else try {
                    e.setItem("google_ama_config", jj(k))
                } catch (l) {
                    vO(a, {
                        lserr: 1
                    })
                }
            }
            e = AO(a, Gh(d, kv, 7, ph()));
            k = {};
            T(ax) || (k.Hm = x(d, tv, 8) || new tv);
            e && (k.ma = e);
            e && zO(e, 3) && (k.be = [1]);
            e = k;
            sJ(a, 2) && (Cm(5, [rg(d)]), c = wO(c), k = (k = e.ma) && Yh(k, 4) || "", c.google_package = k, EO(a, b, d, e, new Ru(["google-auto-placed"], c), f));
            return !0
        }
        h && (vO(a, {
            cfg: 1,
            cl: 1
        }), e != null && CO(a, e));
        return !1
    };

    function wS(a) {
        a.j != null || a.B || (a.j = new MutationObserver(b => {
            for (const c of b)
                for (const d of c.addedNodes) sa(d) && d.nodeType == 1 && (b = a, d.matches('A[href]:not([href=""])') && Bt(b.l, d))
        }), a.j.observe(a.C.document.documentElement, {
            childList: !0,
            subtree: !0
        }))
    }
    var xS = class extends O {
        constructor(a) {
            super();
            this.C = a;
            this.l = new Ct;
            this.j = null;
            jt(this, () => {
                this.j ? .disconnect();
                this.j = null
            })
        }
    };

    function yS(a, b) {
        b.addEventListener("click", () => {
            var c = a.g;
            var d = b.getAttribute("href");
            c = d ? d === "#" ? ru(np(4)) : d.startsWith("#") ? ru(np(5)) : zS(d, c) : tu(Error("Empty href"));
            if (vu(c)) {
                d = c.getValue();
                c = a.Z;
                var e = new pp;
                d = y(e, 1, d);
                c.call(a, d)
            } else a.j(c.g)
        })
    }
    var BS = class {
        constructor(a, b, c) {
            var d = AS();
            this.C = a;
            this.g = b;
            this.Z = c;
            this.j = d
        }
        init() {
            const a = new xS(this.C);
            Array.from(a.C.document.querySelectorAll('A[href]:not([href=""])')).forEach(b => {
                yS(this, b)
            });
            wS(a);
            zt(a.l).listen(b => {
                yS(this, b)
            })
        }
    };

    function zS(a, b) {
        return CS(a, b).map(c => CS(b).map(d => {
            if (c.protocol === "http:" || c.protocol === "https:") {
                var e = np(2);
                e = gi(e, 2, `${c.host}${c.pathname}`);
                d = gi(e, 3, `${d.host}${d.pathname}`)
            } else d = c.protocol === "javascript:" ? np(3) : np(1);
            return d
        }))
    }

    function CS(a, b) {
        return yu(uu(() => new URL(a, b)), () => Error("Invalid URL"))
    };

    function DS(a) {
        if (a < 0 || !Number.isInteger(a)) return tu(Error(`Not a non-negative integer: ${a}`));
        const b = [];
        do b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a % 64)), a = Math.floor(a / 64); while (a > 0);
        return ru(b.reverse().join(""))
    };
    class ES {
        constructor() {
            this.hk = 5E3
        }
        Vk() {
            return 5E3
        }
    }

    function FS(a, b) {
        return a.quantizer ? Math.floor(b / 5E3) * 5E3 / a.quantizer.hk : b
    }

    function GS(a, b) {
        b = b.map(c => FS(a, c));
        return HS(b, a.g === void 0 ? void 0 : FS(a, a.g)).map(c => {
            a: {
                var d = IS;
                const e = [];
                for (const f of c) {
                    c = d(f);
                    if (!vu(c)) {
                        d = tu(c.g);
                        break a
                    }
                    e.push(c.getValue())
                }
                d = ru(e)
            }
            return d
        }).map(c => c.join(".")).map(c => JS(c, a.quantizer ? .Vk()))
    }
    var KS = class {
        constructor(a, b) {
            this.quantizer = a;
            this.g = b
        }
    };

    function IS(a) {
        const b = DS(a.value);
        if (!vu(b)) return b;
        const c = b.getValue();
        return a.Of === 1 ? ru(`${c}`) : a.Of === 2 ? ru(`${c}${"~"}`) : Au(DS(a.Of - 2), d => {
            throw d;
        }).map(d => `${c}${"~"}${d}`)
    }

    function HS(a, b) {
        const c = [];
        for (let d = 0; d < a.length; d++) {
            const e = a[d] ? ? b;
            if (e === void 0) return tu(Error("Sparse but no default"));
            c.length === 0 || e !== c[c.length - 1].value ? c.push({
                value: e,
                Of: 1
            }) : c[c.length - 1].Of++
        }
        return ru(c)
    }

    function JS(a, b) {
        return a === "" ? ru("") : LS(b).map(c => `${c}${a}`)
    }

    function LS(a) {
        return a === void 0 || a === 1 ? ru("") : zu(DS(a), "ComFactor: ").map(b => `${"~"}${b}${"."}`)
    };
    var MS = class extends O {
        constructor(a) {
            super();
            this.C = a;
            this.l = new P(!1);
            this.j = () => {
                this.l.g(this.C.document.hasFocus())
            }
        }
        init() {
            this.C.addEventListener("focus", this.j);
            this.C.addEventListener("blur", this.j);
            jt(this, () => void this.C.removeEventListener("focus", this.j));
            jt(this, () => void this.C.removeEventListener("blur", this.j));
            this.l.g(this.C.document.hasFocus())
        }
    };

    function NS(a) {
        a.l.g(a.C.document.visibilityState === "visible")
    }
    var OS = class extends O {
        constructor(a) {
            super();
            this.C = a;
            this.l = new P(!1);
            this.j = () => void NS(this)
        }
        init() {
            this.C.addEventListener("visibilitychange", this.j);
            jt(this, () => void this.C.removeEventListener("visibilitychange", this.j));
            NS(this)
        }
    };

    function PS(a) {
        return a.g !== null ? a.j + a.l() - a.g : a.j
    }
    var RS = class {
        constructor(a) {
            this.C = a;
            this.j = 0;
            this.g = null;
            this.l = QS(this.C)
        }
        start() {
            this.g === null && (this.g = this.l())
        }
    };

    function QS(a) {
        return a.performance && a.performance.now ? () => a.performance.now() : () => Date.now()
    };

    function SS(a) {
        a = new TS(a);
        a.init();
        return a
    }

    function US(a) {
        const b = Nt(a.C, 1E3, () => void a.handleEvent());
        a.C.addEventListener("scroll", () => void b())
    }

    function VS(a) {
        const b = WS(a.C),
            c = () => {
                const d = WS(a.C),
                    e = Math.abs(d.height - b.height);
                if (Math.abs(d.width - b.width) > 20 || e > 20) a.G = !0, a.C.removeEventListener("resize", c)
            };
        a.C.addEventListener("resize", c)
    }

    function XS(a) {
        a.B = !a.g.X;
        ut(a.g, !1, () => {
            a.C.setTimeout(() => {
                a.B = !0
            }, 100)
        })
    }

    function YS(a) {
        tt(a.g, !0, () => void a.l.start());
        tt(a.g, !1, () => {
            var b = a.l;
            b.g !== null && (b.j += b.l() - b.g);
            b.g = null
        });
        a.F.start()
    }

    function ZS(a) {
        var b = a.C.scrollY;
        var c = ts(a.C);
        b = {
            Vf: Math.floor(b / 100),
            Te: Math.floor((b + c) / 100),
            Vj: a.C.performance.now()
        };
        if (b.Vf < 0 || b.Te < 0 || b.Vf > 1E3 || b.Te > 1E3) a.J = !0, a.j = null;
        else {
            if (a.j) {
                c = a.j;
                var d = new uH(c.Vf, c.Te),
                    e = new uH(b.Vf, b.Te);
                var f = Math.max(d.start, e.start);
                d = Math.min(d.end, e.end);
                if (f = f <= d ? new uH(f, d) : null)
                    for (c = b.Vj - c.Vj, d = f.start; d <= f.end; d++) a.D[d] = (a.D[d] ? ? 0) + c
            }
            a.j = a.A.X ? b : null
        }
    }
    var TS = class {
        constructor(a) {
            this.C = a;
            this.D = [];
            this.G = this.B = this.J = !1;
            this.j = null;
            var b = this.C;
            a = new MS(b);
            a.init();
            a = qt(a.l);
            b = new OS(b);
            b.init();
            b = qt(b.l);
            this.A = this.g = pt(a, b);
            this.l = new RS(this.C);
            this.F = new RS(this.C);
            this.K = new KS((new KS(new ES)).quantizer, 0)
        }
        init() {
            US(this);
            VS(this);
            XS(this);
            YS(this);
            this.A.listen(() => void ZS(this));
            q.setInterval(() => void this.handleEvent(), 5E3);
            this.handleEvent()
        }
        handleEvent() {
            this.A.X && ZS(this)
        }
    };

    function WS(a) {
        return new Ek(ss(a), ts(a))
    };

    function $S(a, {
        Ma: b
    }) {
        a = new aT(a, b);
        if (!a.Ma && T(Ex)) {
            b = a.C;
            var c = bT(cT(a));
            (new BS(b, b.document.baseURI, c)).init()
        }
        dT(a)
    }

    function dT(a) {
        if (T(Fx)) {
            var b = SS(a.C);
            Xr(new yJ(a.C), eT(() => {
                var c = cT(a),
                    d = new sp,
                    e = GS(b.K, b.D);
                if (!vu(e)) throw zu(e, "PVDC: ").g;
                var f = new rp;
                f = E(f, 2, 5E3);
                f = E(f, 1, 100);
                e = e.getValue();
                e = gi(f, 3, e);
                f = WS(b.C);
                var g = new qp;
                g = E(g, 1, f.width);
                f = E(g, 2, f.height);
                e = y(e, 4, f);
                f = new qp;
                f = E(f, 1, Ls(b.C).scrollWidth);
                f = E(f, 2, Ls(b.C).scrollHeight);
                e = y(e, 5, f);
                e = ai(e, 6, b.B);
                f = Math.round(PS(b.F) / 1E3);
                e = E(e, 8, f);
                f = Math.round(PS(b.l) / 1E3);
                e = E(e, 9, f);
                b.J && Jh(e, 7, vf, 1, wf);
                b.G && Jh(e, 7, vf, 2, wf);
                d = z(d, 2, tp, e);
                c(d)
            }))
        }
    }

    function cT(a) {
        if (!a.Z) {
            const b = M(HJ);
            a.Z = c => {
                NJ(b, c)
            }
        }
        return a.Z
    }
    var aT = class {
        constructor(a, b) {
            this.C = a;
            this.Ma = b;
            this.Z = null
        }
    };

    function bT(a) {
        return b => {
            var c = new sp;
            b = z(c, 1, tp, b);
            return void a(b)
        }
    }

    function AS() {
        return a => {
            jC(1243, a, void 0, fT("LCC"))
        }
    }

    function eT(a) {
        return () => void fC(1243, a, fT("PVC"))
    }

    function fT(a) {
        return b => {
            b.errSrc = a
        }
    };
    const gT = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };

    function hT(a, b = !1) {
        try {
            return b ? (new Ek(a.innerWidth, a.innerHeight)).round() : Lk(a || window).round()
        } catch (c) {
            return new Ek(-12245933, -12245933)
        }
    }

    function iT(a = q) {
        a = a.devicePixelRatio;
        return typeof a === "number" ? +a.toFixed(3) : null
    }

    function jT(a, b = q) {
        a = a.scrollingElement || (a.compatMode === "CSS1Compat" ? a.documentElement : a.body);
        return new Dk(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function kT(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function lT(a, b) {
        var c = cC,
            d;
        var e;
        d = (e = (e = Em()) && (d = e.initialLayoutRect) && typeof d.top === "number" && typeof d.left === "number" && typeof d.width === "number" && typeof d.height === "number" ? new $k(d.left, d.top, d.width, d.height) : null) ? new Dk(e.left, e.top) : (d = Hm()) && d.rootBounds && sa(d.rootBounds) ? new Dk(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            {
                const h = new Dk(0, 0);
                let k = Nk(Ik(b));
                if (hc(k, "parent")) {
                    do {
                        if (k == a) var f = jl(b);
                        else {
                            const l = hl(b);
                            f =
                                new Dk(l.left, l.top)
                        }
                        d = f;
                        h.x += d.x;
                        h.y += d.y
                    } while (k && k != a && k != k.parent && (b = k.frameElement) && (k = k.parent))
                }
                var g = h
            }
            return g
        } catch (h) {
            return c.pa(888, h), new Dk(-12245933, -12245933)
        }
    }

    function mT(a, b, c, d = !1) {
        a = lT(a, c);
        c = Tm() || hT(b.top);
        if (!a || a.y === -12245933 || c.width === -12245933 || c.height === -12245933 || !c.height) return 0;
        let e = 0;
        try {
            const f = b.top;
            e = jT(f.document, f).y
        } catch (f) {
            return 0
        }
        b = e + c.height;
        return a.y < e ? d ? 0 : (e - a.y) / c.height : a.y > b ? (a.y - b) / c.height : 0
    };

    function nT(a) {
        return a.length ? a.join("~") : void 0
    };
    var oT = {
            yo: "google_ads_preview",
            Vo: "google_mc_lab",
            fp: "google_anchor_debug",
            ep: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            Ep: "google_scr_debug",
            Hp: "google_ia_debug_allow_onclick",
            bq: "googleads",
            ik: "google_pedestal_debug",
            xq: "google_responsive_slot_preview",
            wq: "google_responsive_dummy_ad"
        },
        pT = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var qT = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function rT(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        b = sT(b);
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function sT(a) {
        let b = "";
        Fd(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    }

    function tT() {
        var a = q.location;
        let b = !1;
        Fd(oT, c => {
            rT(a, c) && (b = !0)
        });
        return b
    }

    function uT(a, b) {
        switch (a) {
            case 1:
                return rT(b, "google_ia_debug");
            case 2:
                return rT(b, "google_bottom_anchor_debug");
            case 3:
                return rT(b, "google_anchor_debug") || rT(b, "googleads")
        }
    };

    function vT({
        P: a,
        tm: b,
        km: c,
        Pk: d,
        lr: e,
        mr: f,
        L: g,
        Ll: h
    }) {
        let k = 0;
        try {
            k |= rs(a, f);
            const n = Math.min(a.screen.width || 0, a.screen.height || 0);
            k |= n ? n < 320 ? 8192 : 0 : 2048;
            k |= a.navigator && wT(a.navigator.userAgent) ? 1048576 : 0;
            if (b) {
                f = k;
                const p = a.innerHeight;
                var l = (Qb() && Rb() ? ie(a) : 1) * p >= b;
                var m = f | (l ? 0 : 1024)
            } else m = k | (a.innerHeight >= a.innerWidth ? 0 : 8);
            k = m;
            k |= us(a, c, !0, e)
        } catch {
            k |= 32
        }
        switch (d) {
            case 2:
                xT(a, g, h) && (k |= 16777216);
                break;
            case 1:
                yT(a, g, h) && (k |= 16777216)
        }
        return k
    }

    function wT(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }

    function xT(a, b = null, c = !1) {
        const d = lH({
            bi: 0,
            Rg: a.innerWidth,
            Jh: 3,
            ci: 0,
            Sg: Math.min(Math.round(a.innerWidth / 320 * 50), zT) + 15,
            Kh: 3
        });
        return qH(AT(a, b), d, c)
    }

    function yT(a, b = null, c = !1) {
        const d = a.innerWidth,
            e = a.innerHeight,
            f = Math.min(Math.round(a.innerWidth / 320 * 50), zT) + 15,
            g = lH({
                bi: 0,
                Rg: d,
                Jh: 3,
                ci: e - f,
                Sg: e,
                Kh: 3
            });
        f > 25 && g.push({
            x: d - 25,
            y: e - 25
        });
        return qH(AT(a, b), g, c)
    }

    function AT(a, b = null) {
        return new sH(a, {
            Xi: BT(a, b)
        })
    }

    function BT(a, b = null) {
        if (b) return (c, d, e) => {
            Fn(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }
    const zT = 90 * 1.38;

    function CT(a, b) {
        const c = U(Rw);
        return vT({
            P: a,
            km: 3E3,
            tm: c !== -1 ? c : a.innerWidth > qs ? 650 : 0,
            L: aC,
            Pk: b,
            Ll: T(Pw)
        })
    };

    function DT(a) {
        let b = 0;
        try {
            b |= rs(a)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function ET(a) {
        let b = 0;
        try {
            b |= rs(a), b |= us(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function FT() {
        const a = {};
        vz(Qw) && (a.bust = vz(Qw));
        return a
    };

    function GT() {
        const {
            promise: a,
            resolve: b
        } = new YR;
        return {
            promise: a,
            resolve: b
        }
    };

    function HT(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = GT();
        b[a] = d;
        c();
        return d
    }

    function IT(a, b, c) {
        return HT(a, b, () => {
            Bd(b.document, c)
        }).promise
    };

    function JT(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] ? ? 0
    }

    function KT(a) {
        let b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function LT(a) {
        return a.hidden != null ? a.hidden : a.mozHidden != null ? a.mozHidden : a.webkitHidden != null ? a.webkitHidden : null
    }

    function MT(a, b) {
        if (JT(b) === 3) var c = !1;
        else a(), c = !0;
        if (!c) {
            const d = () => {
                rl(b, "prerenderingchange", d);
                a()
            };
            ql(b, "prerenderingchange", d)
        }
    };
    Array.from({
        length: 11
    }, (a, b) => b / 10);

    function NT(a, b = !1) {
        let c = 0;
        try {
            c |= rs(a);
            var d;
            if (!(d = !a.navigator)) {
                var e = a.navigator;
                d = "brave" in e && "isBrave" in e.brave || !1
            }
            c |= d || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            c |= us(a, b ? Number.MAX_SAFE_INTEGER : 2500, !0)
        } catch (f) {
            c |= 32
        }
        return c
    };
    const OT = "body div footer header html main section".split(" ");

    function PT(a, b = null, c = !1, d = !1, e = !1) {
        let f = rs(a);
        wT(a.navigator ? .userAgent) && (f |= 1048576);
        const g = a.innerWidth;
        g < 1200 && (f |= 65536);
        const h = a.innerHeight;
        h < 650 && (f |= 2097152);
        b && f === 0 && (b = b === 3 ? "left" : "right", (c = QT({
            P: a,
            Ym: 1,
            position: b,
            da: g,
            ha: h,
            kd: new Set,
            minWidth: 120,
            minHeight: 500,
            kh: c,
            Mh: d,
            Lh: e
        })) ? mE(a).sideRailPlasParam.set(b, `${c.width}x${c.height}_${String(b).charAt(0)}`) : f |= 16);
        return f
    }

    function RT(a) {
        a = mE(a).sideRailPlasParam;
        return [...Array.from(a.values())].join("|")
    }

    function ST(a, b) {
        return Vk(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c)) !== null
    }

    function TT(a, b) {
        return Vk(a, c => c.nodeType === Node.ELEMENT_NODE && b.getComputedStyle(c, null).position === "fixed")
    }

    function UT(a) {
        const b = [];
        for (const c of a.document.querySelectorAll("*")) {
            const d = a.getComputedStyle(c, null);
            d.position === "fixed" && d.display !== "none" && d.visibility !== "hidden" && b.push(c)
        }
        return b
    }

    function VT(a, b) {
        const {
            top: c,
            left: d,
            bottom: e,
            right: f
        } = b.getBoundingClientRect();
        return c >= 0 && d >= 0 && e <= a.innerHeight && f <= a.innerWidth
    }

    function WT(a) {
        return Math.round(Math.round(a / 10) * 10)
    }

    function XT(a) {
        return `${a.position}-${WT(a.da)}x${WT(a.ha)}-${WT(a.scrollY+a.Hd)}Y`
    }

    function YT(a) {
        return `f-${XT({position:a.position,Hd:a.Hd,scrollY:0,da:a.da,ha:a.ha})}`
    }

    function ZT(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return a !== Infinity ? a : 0
    }

    function $T(a, b, c) {
        const d = mE(c.P).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.ha),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.da);
                for (var k = c.da * .3; f <= g; f += 10) {
                    if (e > 0 && h < k) {
                        var l = YT({
                            position: "left",
                            Hd: f,
                            da: c.da,
                            ha: c.ha
                        });
                        b.set(l, ZT(b.get(l), h))
                    }
                    if (h < c.da && e > c.da - k) {
                        l = YT({
                            position: "right",
                            Hd: f,
                            da: c.da,
                            ha: c.ha
                        });
                        const m = c.da - e;
                        b.set(l, ZT(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function aU(a, b) {
        const c = b.P,
            d = b.kh,
            e = b.Lh;
        var f = `f-${WT(b.da)}x${WT(b.ha)}`;
        a.has(f) || (a.set(f, 0), f = UT(c), d || e ? (bU(a, b, f.filter(g => VT(c, g))), cU(c, f.filter(g => !VT(c, g)).concat(e ? Array.from(c.document.querySelectorAll("[google-side-rail-overlap=false]")) : []))) : bU(a, b, f))
    }

    function bU(a, b, c) {
        var d = b.kd;
        const e = b.P;
        mE(e).sideRailProcessedFixedElements.clear();
        d = new Set([...Array.from(e.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...d]);
        for (const f of c) ST(f, d) || $T(f, a, b)
    }

    function dU(a) {
        if (a.da < 1200 || a.ha < 650) return null;
        var b = mE(a.P).sideRailAvailableSpace;
        aU(b, {
            P: a.P,
            da: a.da,
            ha: a.ha,
            kd: a.kd,
            kh: a.kh,
            Lh: a.Lh
        });
        const c = [];
        var d = a.ha * .9,
            e = Ps(a.P),
            f = (a.ha - d) / 2,
            g = f,
            h = d / 7;
        for (var k = 0; k < 8; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    t = b,
                    u = {
                        P: a.P,
                        da: a.da,
                        ha: a.ha,
                        kd: a.kd,
                        Mh: a.Mh
                    };
                const da = YT({
                        position: p,
                        Hd: n,
                        da: u.da,
                        ha: u.ha
                    }),
                    J = XT({
                        position: p,
                        Hd: n,
                        scrollY: e,
                        da: u.da,
                        ha: u.ha
                    });
                if (t.has(J)) {
                    n = ZT(t.get(da), t.get(J));
                    break a
                }
                const N = p === "left" ? 20 : u.da - 20;
                let aa = N;p = u.da * .3 /
                5 * (p === "left" ? 1 : -1);
                for (let Ya = 0; Ya < 6; Ya++) {
                    var B = mH(u.P.document, {
                            x: Math.round(aa),
                            y: Math.round(n)
                        }),
                        F = ST(B, u.kd),
                        R = TT(B, u.P);
                    if (!F && R !== null) {
                        $T(R, t, u);
                        t.delete(J);
                        break
                    }
                    F || (F = u, B.getAttribute("google-side-rail-overlap") === "true" ? F = !0 : B.getAttribute("google-side-rail-overlap") === "false" || F.Mh && !OT.includes(B.tagName.toLowerCase()) ? F = !1 : (R = B.offsetHeight >= F.ha * .25, F = B.offsetWidth >= F.da * .9 && R));
                    if (F) t.set(J, Math.round(Math.abs(aa - N) + 20));
                    else if (aa !== N) aa -= p, p /= 2;
                    else {
                        t.set(J, 0);
                        break
                    }
                    aa += p
                }
                n = ZT(t.get(da),
                    t.get(J))
            }
            m.call(l, n);
            g += h
        }
        b = a.Ym;
        e = a.position;
        d = Math.round(d / 8);
        f = Math.round(f);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l = 0; l < c.length; l++) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = m.length === 0 ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; n >= 0; n--) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = m.length === 0 ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: e,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] -
                        h[k] + 1) * d),
                    offsetY: f + h[k] * d
                }, t = n.width >= g && n.height >= a, b === 0 && t) {
                m = n;
                break
            } else b === 1 && t && (!m || n.width * n.height > m.width * m.height) && (m = n);
        return m
    }

    function cU(a, b) {
        const c = mE(a);
        if (b.length && !c.g) {
            var d = new MutationObserver(() => {
                setTimeout(() => {
                    eU(a);
                    for (const e of c.sideRailMutationCallbacks) e()
                }, 500)
            });
            for (const e of b) d.observe(e, {
                attributes: !0
            });
            c.g = d
        }
    }

    function eU(a) {
        ({
            sideRailAvailableSpace: a
        } = mE(a));
        const b = Array.from(a.keys()).filter(c => c.startsWith("f-"));
        for (const c of b) a.delete(c)
    }

    function QT(a) {
        if (a.hb) return a.hb.kc(1228, () => dU(a)) || null;
        try {
            return dU(a)
        } catch {}
        return null
    };
    const fU = {
        [27]: 512,
        [26]: 128
    };
    var gU = (a, b, c, d) => {
            d = $O(d);
            switch (c) {
                case 1:
                case 2:
                    return CT(a, c) === 0;
                case 3:
                case 4:
                    return PT(a, c, !0, T(Dx), !0) === 0;
                case 8:
                    return NT(a, T(Cw)) === 0;
                case 9:
                    return b = !(b.google_adtest === "on" || rT(a.location, "google_scr_debug")), !DL(a, b, d);
                case 30:
                    return tN(a) === 0;
                case 26:
                    return ET(a) === 0;
                case 27:
                    return DT(a) === 0;
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        hU = (a, b, c, d) => {
            d = d ? $O(d) : null;
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return CT(a, c);
                case 3:
                case 4:
                    return PT(a, c, !1, T(Dx));
                case 8:
                    return NT(a,
                        T(Cw));
                case 9:
                    return DL(a, !(b.google_adtest === "on" || rT(a.location, "google_scr_debug")), d);
                case 16:
                    return Iz(b, a) ? 0 : 8388608;
                case 30:
                    return tN(a);
                case 26:
                    return ET(a);
                case 27:
                    return DT(a);
                default:
                    return 32
            }
        },
        iU = a => {
            if (!a.hash) return null;
            let b = null;
            Fd(oT, c => {
                !b && rT(a, c) && (b = pT[c] || null)
            });
            return b
        },
        kU = (a, b) => {
            const c = mE(a).tagSpecificState[1] || null;
            c !== null && c.debugCard == null && Fd(qT, d => {
                !c.debugCardRequested && typeof d === "number" && uT(d, a.location) && (c.debugCardRequested = !0, jU(a, b, e => {
                    c.debugCard = e.createDebugCard(d,
                        a)
                }))
            })
        },
        mU = (a, b, c) => {
            if (!b) return null;
            const d = mE(b);
            let e = 0;
            Fd(ac, f => {
                const g = fU[f];
                g && lU(a, b, f, c) === 0 && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? `${e}` : null
        },
        nU = (a, b, c) => {
            const d = [];
            Fd(ac, e => {
                const f = lU(b, a, e, c);
                f !== 0 && d.push(`${e}:${f}`)
            });
            return d.join(",") || null
        },
        oU = a => {
            const b = [],
                c = {};
            Fd(a, (d, e) => {
                if ((e = os[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (d === !1) d = 2;
                    else return;
                    b.push(`${e}:${d}`)
                }
            });
            return b.join(",")
        },
        pU = a => {
            a = a.overlays;
            if (!a) return "";
            a =
                a.bottom;
            return typeof a === "boolean" ? a ? "1" : "0" : ""
        };

    function qU(a) {
        return T(Py) ? (a = a.overlays) ? a["collapsed-bottom"] === !0 : !1 : !1
    }
    var lU = (a, b, c, d) => {
            if (!b) return 256;
            let e = 0;
            const f = mE(b),
                g = Ms(f, c);
            if (a.google_reactive_ad_format === c || g) e |= 64;
            let h = !1;
            Fd(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) === String(l) && (h = !0)
            });
            return h && iU(b.location) !== c && (e |= 128, c === 2 || c === 1 || c === 3 || c === 4 || c === 8) ? e : e | hU(b, a, c, d)
        },
        rU = (a, b) => {
            if (a) {
                var c = mE(a),
                    d = {};
                Fd(b, (e, f) => {
                    (f = os[f]) && (e === !1 || /^false$/i.test(e)) && (d[f] = !0)
                });
                Fd(ac, e => {
                    d[ps[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        sU = (a, b, c) => {
            b = gC(b, c);
            c = { ...FT()
            };
            const d = U(Yy);
            [0, 1].includes(d) && (c.osttc = `${d}`);
            return IT(1, window, vd(a, new Map(Object.entries(c)))).then(b)
        },
        jU = (a, b, c) => {
            c = gC(212, c);
            IT(3, a, b).then(c)
        },
        tU = (a, b, c) => {
            a.dataset.adsbygoogleStatus = "reserved";
            a.className += " adsbygoogle-noablate";
            c.adsbygoogle || (c.adsbygoogle = [], Bd(c.document, ud `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`));
            c.adsbygoogle.push({
                element: a,
                params: b
            })
        },
        uU = a => {
            a = a.google_reactive_ad_format;
            return Xb(a) ? `${a}` : null
        },
        vU = a => !!uU(a) || a.google_pgb_reactive != null,
        wU = a => {
            a = Number(uU(a));
            return a === 26 || a === 27 || a === 30 || a === 16 || a === 40 || a === 41
        };

    function xU(a) {
        return typeof a.google_reactive_sra_index === "number"
    }

    function yU(a, b, c) {
        const d = b.P || b.pubWin,
            e = b.I,
            f = $O(c);
        c = nU(d, e, c);
        e.google_reactive_plat = c;
        (c = oU(a)) && (e.google_reactive_plaf = c);
        (c = pU(a)) && (e.google_reactive_fba = c);
        (c = RT(d)) && (e.google_plas = c);
        zU(a, e);
        c = iU(b.pubWin.location);
        AU(a, c, e);
        c ? (e.fra = c, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        e.asro = T(jy);
        e.aihb = T(Gx);
        e.aifxl = nT(M(uz).g(Tx.g, Tx.defaultValue));
        U(py) && (e.aiapm = U(py));
        U(ry) && (e.aiapmi = U(ry));
        U(ny) && (e.aiact = U(ny));
        U(yy) && (e.aicct = U(yy));
        U(Ay) && (e.ailct = U(Ay));
        U(Fy) && (e.aimart = U(Fy));
        T(Mx) && (e.aiudt = !0);
        e.aiapmd = U(qy);
        e.aiapmid = U(sy);
        e.aiactd = U(oy);
        e.aicctd = U(zy);
        e.ailctd = U(By);
        e.aimartd = U(Gy);
        e.aiof = nT(M(uz).g(by.g, by.defaultValue));
        e.fsapi = !0;
        c !== 8 && (f && zL(f) ? (c = CL(f, 86400, "__lsv__"), c ? .length && (c = Math.floor((Date.now() - Math.max(...c)) / 6E4), c >= 0 && (e.vmsli = c))) : e.vmsli = -1);
        qU(a) ? e.dap = 2 : (c = CL(f, 600, "__lsa__"), c ? .length && Math.floor((Date.now() - Math.max(...c)) / 6E4) <= U(sw) && (e.dap = 3));
        Tm() || hT(b.pubWin.top);
        c = TR(b.pubWin, "rsrai", gC(429, (g, h) => BU(b, d, e.google_ad_client, a, g, h, f)),
            gC(430, (g, h) => Ss(b.pubWin, "431", aC, h)));
        b.Ba.push(c);
        mE(d).wasReactiveTagRequestSent = !0;
        CU(b, a, f)
    }

    function CU(a, b, c) {
        const d = a.I,
            e = sa(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = TR(a.pubWin, "apcnf", gC(353, (f, g) => {
            var h = a.pubWin,
                k = d.google_ad_client;
            return ee(g.origin) ? vS(h, k, e, f.config, c, null) : !1
        }), gC(353, (f, g) => Ss(a.pubWin, "353", aC, g)));
        a.Ba.push(b)
    }

    function BU(a, b, c, d, e, f, g) {
        if (!ee(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!sJ(b, 1)) return !0;
        f && Cm(6, [f]);
        e = e.amaConfig;
        const h = [],
            k = [],
            l = mE(b);
        let m = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            const p = f[n],
                t = p.adFormat;
            l && p.enabledInAsfe && (l.reactiveTypeEnabledInAsfe[t] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (t === 9 && e) {
                    p.pubVars = Object.assign(p.pubVars || {}, DU(d, p));
                    const u = new EL;
                    if (xL(u, p) && u.A(p)) {
                        m = u;
                        continue
                    }
                }
                h.push(p);
                k.push(t)
            }
        }
        h.length && sU(a.Sa.Gj,
            522, n => {
                EU(h, b, n, d, g)
            });
        e && vS(b, c, d, e, g, m);
        return !0
    }

    function DU(a, b) {
        const c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        const e = {};
        a = a.page_level_pubvars;
        sa(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        c === 30 && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function EU(a, b, c, d, e) {
        const f = [];
        for (let g = 0; g < a.length; g++) {
            const h = a[g],
                k = h.adFormat,
                l = h.adKey,
                m = c.configProcessorForAdFormat(k);
            k && m && l && (h.pubVars = DU(d, h), delete h.google_reactive_sra_index, f.push(k), fC(466, () => m.verifyAndProcessConfig(b, h, e)))
        }
    }

    function zU(a, b) {
        const c = [];
        let d = !1;
        Fd(os, (e, f) => {
            let g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && c[e] !== "+" || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function AU(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if (a.google_adtest === "on" || d ? .google_adtest === "on" || b) c.google_adtest = "on"
        }
    };
    const FU = /^blogger$/,
        GU = /^wordpress(.|\s|$)/i,
        HU = /^joomla!/i,
        IU = /^drupal/i,
        JU = /\/wp-content\//,
        KU = /\/wp-content\/plugins\/advanced-ads/,
        LU = /\/wp-content\/themes\/genesis/,
        MU = /\/wp-content\/plugins\/genesis/;

    function NU(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (KU.test(e)) return 5;
                if (MU.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", LU.test(e) || MU.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if (f.getAttribute("name") == "generator" && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (FU.test(f)) return 1;
                if (GU.test(f)) return 2;
                if (HU.test(f)) return 3;
                if (IU.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], d.getAttribute("rel") == "stylesheet" && d.hasAttribute("href") && (d = d.getAttribute("href") || "", JU.test(d))) return 2;
        return 0
    };
    var OU = class extends Error {
            constructor(a) {
                super(a)
            }
        },
        PU = class {
            constructor(a) {
                this.reason = a
            }
        };
    class QU {
        constructor() {
            this.g = !1
        }
    }

    function RU(a, b) {
        a.g || (a.g = !0, a.B = b, a.j.resolve(b))
    }

    function SU(a, b, c) {
        a.g = !0;
        a.l = b;
        c && c(a.l);
        a.j.reject(b)
    }
    class TU extends QU {
        constructor() {
            super(...arguments);
            this.j = new YR
        }
        get promise() {
            return this.j.promise
        }
        get Kj() {
            return this.g
        }
        get error() {
            return this.l
        }
    }

    function UU(a, b) {
        RU(a, b)
    }

    function VU(a, b) {
        b.then(c => {
            RU(a, c)
        }).catch(c => {
            a.setError(c, void 0)
        })
    }
    var WU = class extends TU {
        setError(a, b) {
            this.g || (this.g = !0, this.B = null, this.l = a, b && b(this.l), this.j.reject(a))
        }
    };
    class XU extends QU {
        constructor(a) {
            super();
            this.j = a
        }
        get error() {
            return this.j.l
        }
        Kj() {
            return this.j.g
        }
    }
    var YU = class extends XU {
            constructor(a) {
                super(a);
                this.j = a
            }
            get value() {
                return this.j.B
            }
        },
        ZU = class extends XU {
            constructor(a) {
                super(a);
                this.j = a
            }
            get value() {
                return this.j.B ? ? null
            }
        };

    function $U(a, b, c) {
        b.then(() => {
            a.notify()
        }).catch(d => {
            SU(a, d, c)
        })
    }
    var aV = class extends TU {
            notify() {
                RU(this, null)
            }
        },
        bV = class extends WU {
            constructor(a, b = !1) {
                super();
                a = a.map(c => c.promise.then(d => {
                    if (b || d != null) return d;
                    throw d;
                }, d => {
                    SU(this, d);
                    return null
                }));
                ja(Promise, "any").call(Promise, a).then(c => {
                    this.g || RU(this, c)
                }, () => {
                    this.g || RU(this, null)
                })
            }
        };

    function cV(a, b) {
        a.j.push({
            Je: !1,
            Hg: b
        })
    }
    var dV = class extends O {
        constructor() {
            super(...arguments);
            this.l = [];
            this.j = [];
            this.A = []
        }
        Je(a) {
            const b = this.j.find(c => c.Hg === a);
            b && (b.Je = !0)
        }
        g() {
            this.l.length = 0;
            this.A.length = 0;
            this.j.length = 0;
            super.g()
        }
    };
    async function eV(a, b) {
        const c = b ? a.filter(d => !d.Je) : a;
        await Promise.all(c.map(({
            Hg: d
        }) => d.promise));
        a.length !== c.length && (a = a.filter(d => d.Je), await Promise.race([Promise.all(a.map(({
            Hg: d
        }) => d.promise)), new Promise(d => void setTimeout(d, b))]))
    }

    function fV(a, b = new WU) {
        a.j.l.push(b);
        return b
    }

    function gV(a, b) {
        cV(a.j, b);
        b = new YU(b);
        a.j.A.push(b);
        return b
    }
    var hV = class extends O {
        constructor(a, b) {
            super();
            this.id = a;
            this.D = b;
            this.timeoutMs = void 0;
            this.K = !1;
            this.j = new dV;
            it(this, this.j)
        }
        async start() {
            if (!this.K) {
                this.K = !0;
                try {
                    if (await eV(this.j.j, this.la ? ? this.timeoutMs), !this.B) {
                        let a = 0;
                        for (const b of this.j.A) {
                            if (b.j.B == null) throw Error(`missing input: ${this.id}/${a}`);
                            ++a
                        }
                        this.G()
                    }
                } catch (a) {
                    this.B || (a instanceof OU ? this.V(a) : a instanceof Error && (this.D.Na({
                        methodName: this.id,
                        eb: a
                    }), this.l(a)))
                }
            }
        }
        V() {}
        l(a) {
            if (this.j.l.length) {
                var b = new OU(a.message);
                for (const c of this.j.l) c.Kj || SU(c, b)
            }
            a instanceof OU || console ? .error(a)
        }
    };

    function iV(a) {
        const b = {};
        for (const [c, d] of Object.entries(a.ba)) b[c] = d.value;
        return b
    }

    function X(a, b) {
        if (a.K) throw Error("Invalid operation: producer has already started");
        cV(a.j, b);
        return a
    }
    var jV = class extends hV {
        constructor(a, b, c, d, e) {
            super(a, c);
            this.f = b;
            this.T = e;
            a = {};
            for (const [f, g] of Object.entries(d))
                if (d = g) cV(this.j, d), a[f] = new ZU(d);
            this.ba = a
        }
        G() {
            const a = this.f(iV(this), ...this.T);
            this.A(a)
        }
        V(a) {
            this.l(a)
        }
        reportError() {}
    };
    class kV extends jV {
        constructor(a, b, c, d, e, f, g) {
            super(a, b, c, d, g);
            this.na = f;
            this.finished = new aV;
            a = Object.keys(e);
            for (const h of a) this[h] = fV(this)
        }
        A(a) {
            for (const [b, c] of Object.entries(a)) {
                a = b;
                const d = c;
                d instanceof Error && this[a].setError(d);
                d instanceof PU || RU(this[a], d)
            }
            this.finished.notify()
        }
        l(a) {
            this.na ? this.A(this.na(a)) : super.l(a)
        }
    }

    function Y(a, b) {
        a.id = b.id;
        a.H = b.H;
        a.na = b.na;
        return a
    }

    function lV(a, b, c, ...d) {
        return new kV(a.id, a, b, c, a.H, a.na, d)
    };

    function mV(a, b) {
        a = b.ssl.map(c => {
            var d = new Gl;
            d = fi(d, 1, c.nn);
            c = Ah(d, 2, ki, Zf(c.jlu));
            return $h(c, 4, !1)
        });
        a = a.length > 0 ? Kl(Hl(), a) : Kl(new Il, []);
        return {
            ae: a,
            Ui: [a]
        }
    }
    var nV = Y(mV, {
        id: 1377,
        H: {
            ae: void 0,
            Ui: void 0
        }
    });
    var oV = {
        Hi: [],
        Di: 0,
        Mi: [],
        hr: !1,
        wn: !1
    };

    function pV(a, b = window, c = () => {}) {
        try {
            return b.localStorage.getItem(a)
        } catch (d) {
            return c(d), null
        }
    }

    function qV(a, b, c = window, d = () => {}) {
        return b.ca() ? pV(a, c, d) : null
    }

    function rV(a, b, c = window, d = () => {}) {
        try {
            return c.localStorage.setItem(a, b), !0
        } catch (e) {
            d(e)
        }
        return !1
    }

    function sV(a, b, c, d = window, e = () => {}) {
        return c.ca() ? rV(a, b, d, e) : !1
    }

    function tV(a, b = window, c = () => {}) {
        try {
            b.localStorage.removeItem(a)
        } catch (d) {
            c(d)
        }
    }

    function uV(a, b, c = window, d = () => {}) {
        b.ca() && tV(a, c, d)
    }

    function vV(a = window, b = () => {}) {
        try {
            return a.localStorage.length
        } catch (c) {
            b(c)
        }
        return null
    }

    function wV(a) {
        var b = window,
            c = () => {};
        return a.ca() ? vV(b, c) : null
    }

    function xV(a, b = window, c = () => {}) {
        try {
            return b.localStorage.key(a)
        } catch (d) {
            c(d)
        }
        return null
    }

    function yV(a, b) {
        var c = window,
            d = () => {};
        return b.ca() ? xV(a, c, d) : null
    }

    function zV(a = window, b = () => {}) {
        try {
            return Object.keys(a.localStorage)
        } catch (c) {
            b(c)
        }
        return null
    }

    function AV(a) {
        var b = window,
            c = () => {};
        return a.ca() ? zV(b, c) : null
    };
    class BV {
        static bj() {
            throw Error("Must be overridden");
        }
    }
    class CV extends BV {
        constructor() {
            super(...arguments);
            this.g = 0
        }
    }(function() {
        var a = CV;
        a.Hc = void 0;
        a.bj = function() {
            return a.Hc ? a.Hc : a.Hc = new a
        }
    })();

    function DV(a, b, c = null, d = {}) {
        const e = CV.bj();
        e.g === 0 && (e.g = Math.random() < .001 ? 2 : 1);
        e.g === 2 && rm({
            c: String(a),
            pc: String(fe(window)),
            em: c,
            lid: b,
            eids: M(bs).g().join(),
            ...d
        }, "esp")
    };

    function EV() {
        var a = window;
        return new Promise(b => {
            const c = () => {
                b(void 0);
                rl(a, "load", c)
            };
            ql(a, "load", c)
        })
    }

    function FV(a) {
        const b = [],
            c = RegExp("^_GESPSK-(.+)$"),
            d = wV(a);
        for (let f = 0; f < (d ? ? 0); f++) {
            var e = yV(f, a);
            e !== null && (e = (c.exec(e) || [])[1]) && b.push(e)
        }
        return b
    };

    function GV(a) {
        return `${"_GESPSK"}-${a}`
    }

    function HV() {
        IV || (IV = new JV);
        return IV
    }

    function KV(a) {
        const b = $v(Mh(a, 3));
        if (!b) return 3;
        if (Yh(a, 2) === void 0) return 4;
        a = Date.now();
        return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
    }
    var JV = class {
            constructor() {
                this.cache = {}
            }
            get(a, b, c) {
                function d(g) {
                    DV(6, a, g ? .message);
                    e = !0
                }
                if (this.cache[a]) return {
                    U: this.cache[a],
                    success: !0
                };
                let e = !1;
                const f = GV(a);
                b = c ? pV(f, window, d) : qV(f, b, window, d);
                if (e) return {
                    U: null,
                    success: !1
                };
                if (!b) return {
                    U: null,
                    success: !0
                };
                try {
                    const g = mm(b);
                    this.cache[a] = g;
                    return {
                        U: g,
                        success: !0
                    }
                } catch (g) {
                    return DV(5, a, g ? .message), {
                        U: null,
                        success: !1
                    }
                }
            }
            set(a, b, c) {
                function d(g) {
                    DV(7, e, g ? .message)
                }
                const e = a.Wa(),
                    f = GV(e);
                lm(a);
                if (c ? !rV(f, jj(a), window, d) : !sV(f, jj(a), b, window, d)) return !1;
                this.cache[e] = a;
                return !0
            }
            remove(a, b, c) {
                function d(e) {
                    DV(8, a, e ? .message)
                }
                c ? tV(GV(a), window, d) : uV(GV(a), b, window, d);
                delete this.cache[a]
            }
        },
        IV = null;

    function LV(a, b, c) {
        return !!a.g ? .get(c) ? .get(b) ? .some(d => A(d, 4))
    }

    function MV(a, b) {
        for (const c of a.g.values())
            if (c.get(b) ? .some(d => A(d, 4))) return !0;
        return !1
    }

    function NV(a, b, c) {
        const d = new Set;
        a = a.g.get(b);
        if (!a) return d;
        for (const [e, f] of a.entries()) a = e, f.some(g => c(g)) && d.add(a);
        return d
    }

    function OV(a, b) {
        return NV(a, b, c => A(c, 4))
    }
    var PV = class {
        constructor(a) {
            const b = new Map;
            for (const c of a) {
                a = C(c, 1);
                const d = b.get(a) ? ? new Map;
                for (const e of Jl(c)) {
                    const f = e.Wa();
                    d.has(f) || d.set(f, []);
                    d.get(f).push(e)
                }
                b.set(a, d)
            }
            this.g = b
        }
    };

    function QV(a, b) {
        return [].some(c => LV(b, a, c))
    };

    function RV(a, b, c) {
        ({
            ae: a
        } = mV({}, a.pageStateTs.ssc)); {
            var d = [a];
            a = new Map;
            DV(56, "", null);
            var e = a;
            d = new PV(d ? ? []);
            var f = Array,
                g = f.from,
                h = [];
            const n = new Set(FV(c));
            for (var k of h)
                for (var l of OV(d, k)) n.add(l);
            k = g.call(f, n);
            for (const p of k) e.get(p) ? .g() || ({
                U: k
            } = HV().get(p, c, QV(p, d)), k && (l = KV(k), l !== 2 && l !== 3 && ($h(k, 9, !1), (l = Yh(k, 2)) && l.length > 1024 && (DV(55, p, null, {
                sl: String(l.length)
            }), l = k.setError(Pl(108)), ih(l, 2)), e.set(p, k), k = Yh(k, 2), DV(19, p, null, {
                hs: k ? "1" : "0",
                sl: String(k ? .length ? ? -1)
            }))));
            c = new nm;
            for ([, m] of a) Kh(c, 2, km, m);
            if (Gh(c, km, 2, ph()).length) {
                DV(50, "", null, {
                    ns: String(Gh(c, km, 2, ph()).length)
                });
                var m = c.g();
                m = oe(m)
            } else m = null
        }
        m && (b.a3p = m)
    };

    function SV(a) {
        const b = {};
        b.dtd = TV((new Date).getTime(), is);
        return Wm(b, a)
    }

    function TV(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : a >= 0 ? a : "-M"
    };
    const UV = fc("script");
    var VV = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, l = null, m = null, n = null) {
            this.J = a;
            this.Ob = b;
            this.nc = c;
            this.g = d;
            this.F = e;
            this.ya = f;
            this.tb = g;
            this.B = h;
            this.A = k;
            this.j = l;
            this.l = m;
            this.D = n
        }
        size() {
            return this.Ob
        }
    };
    var WV = class {
        constructor(a, b) {
            this.g = a;
            this.B = b
        }
        height() {
            return this.B
        }
        j(a) {
            return a > U(Yw) && this.B > 300 ? this.g : Math.min(1200, Math.round(a))
        }
        l() {}
    };
    const XV = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var YV = {
            "image-top": 0,
            "image-middle": 1,
            "image-side": 2,
            "text-only": 3,
            "in-article": 4
        },
        ZV = class extends WV {
            j() {
                return Math.min(1200, this.g)
            }
        };

    function $V(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = Jz(b, c, g, U(Kw), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = ss(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            const k = g.parentElement.childNodes;
                            for (let l = 0; l < k.length; ++l) {
                                const m = k[l];
                                if (m !== g && Mz(b, m)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    Qz(b, c)
                }
            else a = g;
            else a =
                g
        }
        if (a < 250) throw new $B("Fluid responsive ads must be at least 250px wide: " + `availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new $B("Fluid responsive ads must be at least 50px tall: " + `height=${f}`);
            return new VV(11, new WV(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new $B(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new $B(`Invalid height: height=${f}`);
            if (f < 50) throw new $B("Fluid responsive ads must be at least 50px tall: " + `height=${f}`);
            if (f > 1200) throw new $B("Fluid responsive ads must be at most 1200px tall: " + `height=${f}`);
            return new VV(11, new WV(a, f))
        }
        d = XV[f];
        if (!d) throw new $B("Invalid data-ad-layout value: " + f);
        c = Wz(c, b);
        b = ss(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new VV(11, f === "in-article" ? new ZV(a, b) : new WV(a, b))
    };

    function aW(a) {
        var b = window;
        return a.google_adtest === "on" || a.google_adbreak_test === "on" || b.location.host.endsWith("h5games.usercontent.goog") || b.location.host === "gamesnacks.com" ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && c > 0) || [] : []
    };

    function bW() {
        cW || (cW = new dW);
        return cW
    }

    function eW(a, b) {
        b && !a.g && (b = fW(b), a.g = b.id, a.l = b.creationTimeSeconds)
    }
    var dW = class {
            constructor() {
                this.B = new Date(Date.now());
                this.l = this.g = null;
                this.j = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.j[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.B,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = b !== null ? Hu(`${"w5uHecUBa2S"}:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.j[4] = {
                    [15]: () => {
                        var a = Number(this.l || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(a * 1E3), a = a.getFullYear() * 1E4 + (a.getMonth() + 1) * 100 + a.getDate());
                        return a
                    }
                }
            }
        },
        cW;

    function gW(a) {
        return rJ(a) ? .head_tag_slot_vars ? .google_ad_host ? ? a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };

    function hW(a, b, c = "") {
        return b && (iW(a, c, b) ? .g() ? ? !1) ? !0 : jW(a, c, d => Oa(Gh(d, Ll, 2, ph()), e => Zh(e, 1) === 1), !!x(b, kW, 26) ? .g())
    }

    function jW(a, b, c, d) {
        a = Ad(a) || a;
        const e = lW(a, d);
        b && (b = an(String(b)));
        return Wb(e, (f, g) => Object.prototype.hasOwnProperty.call(e, g) && (!b || b === g) && c(f))
    }

    function lW(a, b) {
        a = mW(a, b);
        const c = {};
        Fd(a, (d, e) => {
            try {
                const f = lj(Ol, sg(d));
                c[e] = f
            } catch (f) {}
        });
        return c
    }

    function mW(a, b) {
        a = pP({
            C: a,
            Ma: b
        });
        return vu(a) ? nW(a.getValue()) : {}
    }

    function nW(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : Vb(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && typeof e === "string" && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function iW(a, b, c) {
        if (!b) return null;
        const d = Vh(c, oW, 27, pW) ? .j(),
            e = Vh(c, oW, 27, pW) ? .B() ? .g();
        return qW(a, b ? ? "", d ? ? "", e ? ? "", C(c, 17) || "") ? Vh(c, oW, 27, pW) : null
    }

    function qW(a, b, c, d, e) {
        a = d === b && !!a.location.host && e === a.location.host;
        return c === b || a
    };

    function rW(a = q) {
        return a.ggeac || (a.ggeac = {})
    };

    function sW(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function tW(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function uW(a = navigator) {
        try {
            return !!a.protectedAudience ? .queryFeatureSupport ? .("deprecatedRenderURLReplacements")
        } catch (b) {
            return !1
        }
    }

    function vW(a, b, c = b.document) {
        return !!(a && "sharedStorage" in b && b.sharedStorage && tW("shared-storage", c) && tW("shared-storage-select-url", c))
    };

    function wW(a = Ed()) {
        return b => Hu(`${b} + ${a}`) % 1E3
    };

    function xW(a, b) {
        a.g = $r(14, b, () => {})
    }
    class yW {
        constructor() {
            this.g = () => {}
        }
    }

    function zW(a) {
        M(yW).g(a)
    };

    function AW(a = rW()) {
        as(M(bs), a);
        BW(a);
        xW(M(yW), a);
        M(uz).j()
    }

    function BW(a) {
        const b = M(uz);
        b.l = (c, d) => $r(5, a, () => !1)(c, d, 1);
        b.B = (c, d) => $r(6, a, () => 0)(c, d, 1);
        b.A = (c, d) => $r(7, a, () => "")(c, d, 1);
        b.D = (c, d) => $r(8, a, () => [])(c, d, 1);
        b.g = (c, d) => $r(17, a, () => [])(c, d, 1);
        b.j = () => {
            $r(15, a, () => {})(1)
        }
    };
    const CW = {
        gfpCookie: null,
        parsedGfpCookie: {
            id: null,
            creationTimeSeconds: null
        }
    };

    function fW(a) {
        var b = a.split(":");
        a = b.find(c => c.indexOf("ID=") === 0) || null;
        b = b.find(c => c.indexOf("T=") === 0) ? .substring(2) || null;
        return {
            id: a,
            creationTimeSeconds: b
        }
    }

    function DW(a, b, c) {
        c ? (a = a.C, b = c.ca() ? dP(b, a) : null) : b = null;
        return b
    }

    function EW(a) {
        var b = a.split(":");
        a = b.find(c => c.indexOf("ID") === 0) || null;
        b = b.find(c => c.indexOf("T=") === 0) ? .substring(2) || null;
        return {
            id: a,
            creationTimeSeconds: b
        }
    }

    function FW(a, b) {
        a = DW(a, "__gads", b);
        if (!a) return CW;
        b = EW(a);
        return {
            gfpCookie: a,
            parsedGfpCookie: b
        }
    }

    function GW(a, b, c, d) {
        if (d) {
            var e = Zv(Qh(c, 2)) - Date.now() / 1E3;
            e = {
                me: Math.max(e, 0),
                path: C(c, 3),
                domain: C(c, 4),
                Pf: !1
            };
            c = c.getValue();
            a = a.C;
            d.ca() && eP(b, c, e, a)
        }
    }

    function HW(a, b, c) {
        var d;
        (d = !c) || (d = a.C, d = !(c.ca() && dP(b, d)));
        if (!d)
            for (const f of IW(a.C.location.hostname)) {
                d = b;
                var e = a.C;
                c.ca() && e.origin !== "null" && (new XO(e.document)).remove(d, "/", f)
            }
    }
    var JW = class {
        constructor(a) {
            this.C = a
        }
    };

    function IW(a) {
        if (a === "localhost") return ["localhost"];
        a = a.split(".");
        if (a.length < 2) return [];
        const b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };

    function KW(a, b, c) {
        var d = {
            [0]: wW(fe(b).toString())
        };
        if (c) {
            const e = new JW(b);
            b = bW();
            let f;
            T(Xy) ? (c = FW(e, c), b = bW(), c.gfpCookie && !b.g && (b.g = c.parsedGfpCookie.id, b.l = c.parsedGfpCookie.creationTimeSeconds), zW(b.j), f = c.parsedGfpCookie.id) : (c = DW(e, "__gads", c) || "", eW(b, c), zW(b.j), f = (new RegExp(/(?:^|:)(ID=[^\s:]+)/)).exec(c) ? .[1]);
            d[1] = g => f ? wW(f)(g) : void 0
        }
        d = cs(a, d);
        hs(IJ(M(HJ), a, d))
    }

    function LW(a) {
        KW(13, a);
        KW(11, a)
    }

    function MW(a) {
        const b = M(bs).g();
        a = aW(a);
        return b.concat(a).join(",")
    }

    function NW(a) {
        const b = kn();
        b && (a.debug_experiment_id = b)
    };
    var OW = {
        google_ad_block: "ad_block",
        google_ad_client: "client",
        google_ad_intent_query: "ait_q",
        google_ad_intent_rs_token: "afdt",
        google_ad_output: "output",
        google_ad_callback: "callback",
        google_ad_height: "h",
        google_ad_resize: "twa",
        google_ad_slot: "slotname",
        google_ad_unit_key: "adk",
        google_ad_dom_fingerprint: "adf",
        google_ad_intent_qetid: "aiqeid",
        google_ad_intents_format: "ait_f",
        google_placement_id: "pi",
        google_daaos_ts: "daaos",
        google_erank: "epr",
        google_ad_width: "w",
        abgtt: "abgtt",
        google_captcha_token: "captok",
        google_content_recommendation_columns_num: "cr_col",
        google_content_recommendation_rows_num: "cr_row",
        google_ctr_threshold: "ctr_t",
        google_cust_criteria: "cust_params",
        gfwrnwer: "fwrn",
        gfwrnher: "fwrnh",
        google_image_size: "image_size",
        google_last_modified_time: "lmt",
        google_loeid: "loeid",
        google_max_num_ads: "num_ads",
        google_max_radlink_len: "max_radlink_len",
        google_mtl: "mtl",
        google_native_settings_key: "nsk",
        google_enable_content_recommendations: "ecr",
        google_num_radlinks: "num_radlinks",
        google_num_radlinks_per_unit: "num_radlinks_per_unit",
        google_pucrd: "pucrd",
        google_reactive_plaf: "plaf",
        google_reactive_plat: "plat",
        google_reactive_fba: "fba",
        google_reactive_sra_channels: "plach",
        google_responsive_auto_format: "rafmt",
        armr: "armr",
        google_plas: "plas",
        google_rl_dest_url: "rl_dest_url",
        google_rl_filtering: "rl_filtering",
        google_rl_mode: "rl_mode",
        google_rt: "rt",
        google_video_play_muted: "vpmute",
        google_source_type: "src_type",
        google_restrict_data_processing: "rdp",
        google_tag_for_child_directed_treatment: "tfcd",
        google_tag_for_under_age_of_consent: "tfua",
        google_tag_origin: "to",
        google_ad_semantic_area: "sem",
        google_tfs: "tfs",
        google_package: "pwprc",
        google_tag_partner: "tp",
        fra: "fpla",
        google_ml_rank: "mlr",
        google_apsail: "psa",
        google_ad_channel: "channel",
        google_ad_type: "ad_type",
        google_ad_format: "format",
        google_color_bg: "color_bg",
        google_color_border: "color_border",
        google_color_link: "color_link",
        google_color_text: "color_text",
        google_color_url: "color_url",
        google_page_url: "url",
        google_ad_section: "region",
        google_cpm: "cpm",
        google_encoding: "oe",
        google_safe: "adsafe",
        google_font_face: "f",
        google_font_size: "fs",
        google_hints: "hints",
        google_ad_host: "host",
        google_ad_host_channel: "h_ch",
        google_ad_host_tier_id: "ht_id",
        google_kw_type: "kw_type",
        google_kw: "kw",
        google_contents: "contents",
        google_targeting: "targeting",
        google_adtest: "adtest",
        google_alternate_color: "alt_color",
        google_alternate_ad_url: "alternate_ad_url",
        google_cust_age: "cust_age",
        google_cust_gender: "cust_gender",
        google_cust_l: "cust_l",
        google_cust_lh: "cust_lh",
        google_language: "hl",
        google_city: "gcs",
        google_country: "gl",
        google_region: "gr",
        google_content_recommendation_ad_positions: "ad_pos",
        google_content_recommendation_ui_type: "crui",
        google_content_recommendation_use_square_imgs: "cr_sq_img",
        sso: "sso",
        google_color_line: "color_line",
        google_disable_video_autoplay: "disable_video_autoplay",
        google_full_width_responsive_allowed: "fwr",
        google_full_width_responsive: "fwrattr",
        efwr: "efwr",
        google_pgb_reactive: "pra",
        rc: "rc",
        google_resizing_allowed: "rs",
        google_resizing_height: "rh",
        google_resizing_width: "rw",
        rpe: "rpe",
        google_responsive_formats: "resp_fmts",
        google_safe_for_responsive_override: "sfro",
        google_video_doc_id: "video_doc_id",
        google_video_product_type: "video_product_type",
        google_webgl_support: "wgl",
        aihb: "aihb",
        aiof: "aiof",
        aiudt: "aiudt",
        asro: "asro",
        aifxl: "aifxl",
        vmsli: "itsi",
        dap: "dap",
        aiapm: "aiapm",
        aiapmd: "aiapmd",
        aiapmi: "aiapmi",
        aiapmid: "aiapmid",
        aiact: "aiact",
        aiactd: "aiactd",
        aicct: "aicct",
        aicctd: "aicctd",
        ailct: "ailct",
        ailctd: "ailctd",
        aimart: "aimart",
        aimartd: "aimartd",
        aieuf: "aieuf"
    };

    function PW(a) {
        a.g === -1 && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var QW = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && a < 52 && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function RW() {
        const a = new QW;
        "SVGElement" in q && "createElementNS" in q.document && a.set(0);
        const b = Rd();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        q.crypto && q.crypto.subtle && a.set(3);
        "TextDecoder" in q && "TextEncoder" in q && a.set(4);
        return PW(a)
    };

    function SW(a, b, {
        Rh: c,
        Sh: d
    }) {
        return A(b, 8) || (c || !b.ca()) && d || !bP(a.g) ? !1 : !0
    }

    function TW(a, b, {
        Rh: c,
        Sh: d
    }) {
        if (SW(a, b, {
                Rh: c,
                Sh: d
            })) return dP("__eoi", a.g) ? ? void 0
    }
    var UW = class {
        constructor(a) {
            this.g = a
        }
    };
    var VW = wk(vP);

    function WW(a, {
        rj: b
    }) {
        return Array.from(a.querySelectorAll("div")).slice(0, b).some(c => Object.keys(c).some(d => d.startsWith("__react")))
    };

    function XW(a = document) {
        var b = {
            gr: 0,
            rj: U(Bx)
        };
        const c = [],
            d = [];
        for (const g of Array.from(a.querySelectorAll("meta[name=generator][content]"))) {
            if (!g) continue;
            var e = g.getAttribute("content") ? ? "";
            const [, h, k] = /^([^0-9]+)(?:\s([0-9]+(?:\.[0-9]+){0,2})[.0-9]*)?[^0-9]*$/.exec(e) ? ? [], l = h, m = k, n = new uP;
            m && fi(n, 3, m.substring(0, 20));
            let p, t;
            if (l) {
                for (const [u, B] of (new Map([
                        [1, "WordPress"],
                        [2, "Drupal"],
                        [3, "MediaWiki"],
                        [4, "Blogger"],
                        [5, "SEOmatic"],
                        [7, "Flutter"],
                        [8, "Joomla! - Open Source Content Management"],
                        [9,
                            "React"
                        ]
                    ])).entries()) {
                    var f = u;
                    if (B === l.trim()) {
                        p = f;
                        break
                    }
                }
                for (const [u, B] of (new Map([
                        [1, "All in One SEO (AIOSEO)"],
                        [2, "All in One SEO Pro (AIOSEO)"],
                        [3, "AMP for WP"],
                        [4, "Site Kit by Google"],
                        [5, "Elementor"],
                        [6, "Powered by WPBakery Page Builder - drag and drop page builder for WordPress."]
                    ])).entries())
                    if (f = u, B === l.trim()) {
                        t = f;
                        break
                    }
            }
            t ? (e = hi(n, 1, 1), hi(e, 2, t)) : p ? hi(n, 1, p) : (f = hi(n, 1, 0), ih(f, 3), d.push({
                content: e,
                name: l,
                version: m
            }));
            c.push(n)
        }
        b.rj > 0 && WW(a, b) && (a = c.push, b = new uP, b = hi(b, 1, 9), a.call(c, b));
        return {
            labels: c,
            kr: d
        }
    };
    var YW = class extends O {
        constructor() {
            super();
            this.value = null
        }
        get() {
            return this.value
        }
    };
    const ZW = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        $W = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function aX(a) {
        try {
            const b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return ZW.get(b.type) ? ? null
        } catch {}
        return $W.get(a.performance ? .navigation ? .type) ? ? null
    };
    var bX = class extends H {};
    var cX = class extends H {};

    function dX(a, b, c, d, e) {
        a.g.push(new eX(b, c, d, e))
    }

    function fX(a) {
        for (let c = a.g.length - 1; c >= 0; c--) {
            var b = a.g[c];
            b.j ? (b.element.style.removeProperty(b.g), b.element.style.setProperty(b.g, String(b.l), b.B)) : b.element.style[b.g] = b.l
        }
        a.g.length = 0
    }
    var gX = class {
            constructor() {
                this.g = []
            }
        },
        eX = class {
            constructor(a, b, c, d) {
                this.element = a;
                this.g = b;
                this.g = (this.j = !(d === void 0 || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
                this.l = this.j ? a.style.getPropertyValue(this.g) : a.style[this.g];
                this.B = this.j ? a.style.getPropertyPriority(this.g) : void 0;
                this.j ? (a.style.removeProperty(this.g), a.style.setProperty(this.g, String(c), d)) : a.style[this.g] = String(c)
            }
        };

    function hX(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return typeof c === "string" ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        cl(a, "transition", b.join(","))
    }
    var iX = zb(function() {
        const a = Ok(document, "DIV"),
            b = dd ? "-webkit" : cd ? "-moz" : null;
        let c = "transition:opacity 1s linear;";
        b && (c += b + "-transition:opacity 1s linear;");
        Nc(a, od("div", {
            style: c
        }));
        return fl(a.firstChild, "transition") != ""
    });

    function jX(a, b, c) {
        a.j[b].indexOf(c) < 0 && (a.j[b] += c)
    }

    function kX(a, b) {
        a.g.indexOf(b) >= 0 || (a.g = b + a.g)
    }

    function lX(a, b) {
        a.errors.indexOf(b) < 0 && (a.errors = b + a.errors)
    }

    function mX(a, b, c, d) {
        return a.errors != "" || b ? null : a.g.replace(nX, "") == "" ? c != null && a.j[0] || d != null && a.j[1] ? !1 : !0 : !1
    }

    function oX(a) {
        var b = mX(a, "", null, 0);
        if (b === null) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return a.indexOf("a") >= 0 ? b + "A" : a.indexOf("f") >= 0 ? b + "F" : b + "S"
    }
    var pX = class {
        constructor(a, b) {
            this.j = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        toString() {
            return [this.j[0], this.j[1], this.g, this.errors].join("|")
        }
    };

    function qX(a) {
        let b = a.ba;
        a.F = () => {};
        rX(a, a.D, b);
        let c = a.D.parentElement;
        if (!c) return a.g;
        let d = !0,
            e = null;
        for (; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : Dd(c, b)
            } catch (g) {
                lX(a.g, "c")
            }
            const f = sX(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.V = !0);
            if (d && !f && tX(e)) {
                kX(a.g, "l");
                a.G = c;
                break
            }
            d = d && f;
            if (e && uX(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !xd(b)) {
                        kX(a.g, "c");
                        break
                    }
                } catch (g) {
                    kX(a.g,
                        "c");
                    break
                }
            }
        }
        a.J && a.A && vX(a);
        return a.g
    }

    function wX(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) cl(k, m[n], "0px")
        }

        function c() {
            xX(d, g, h);
            !k || l || h || (b(yX), b(zX))
        }
        const d = a.D;
        d.style.overflow = a.Ie ? "visible" : "hidden";
        a.J && (a.G ? (hX(d, AX()), hX(a.G, AX())) : hX(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        a.T !== null && (d.style.opacity = String(a.T));
        const e = a.width != null && a.l != null && (a.Nf || a.l > a.width) ? a.l : null,
            f = a.height != null && a.j != null && (a.Nf || a.j > a.height) ? a.j : null;
        if (a.K) {
            const m =
                a.K.length;
            for (let n = 0; n < m; n++) xX(a.K[n], e, f)
        }
        const g = a.l,
            h = a.j,
            k = a.G,
            l = a.V;
        a.J ? q.setTimeout(c, 1E3) : c()
    }

    function BX(a) {
        if (a.A && !a.la || a.l == null && a.j == null && a.T == null && a.A) return a.g;
        var b = a.A;
        a.A = !1;
        qX(a);
        a.A = b;
        if (!b || a.check != null && !mX(a.g, a.check, a.l, a.j)) return a.g;
        a.g.g.indexOf("n") >= 0 && (a.width = null, a.height = null);
        if (a.width == null && a.l !== null || a.height == null && a.j !== null) a.J = !1;
        (a.l == 0 || a.j == 0) && a.g.g.indexOf("l") >= 0 && (a.l = 0, a.j = 0);
        b = a.g;
        b.j[0] = "";
        b.j[1] = "";
        b.g = "";
        b.errors = "";
        wX(a);
        return qX(a)
    }

    function uX(a, b) {
        let c = !1;
        b.display == "none" && (kX(a.g, "n"), a.A && (c = !0));
        b.visibility != "hidden" && b.visibility != "collapse" || kX(a.g, "v");
        b.overflow == "hidden" && kX(a.g, "o");
        b.position == "absolute" ? (kX(a.g, "a"), c = !0) : b.position == "fixed" && (kX(a.g, "f"), c = !0);
        return c
    }

    function rX(a, b, c) {
        let d = 0;
        if (!b || !b.parentElement) return !0;
        let e = !1,
            f = 0;
        const g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = CX(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && jX(a.g, 0, "o"), d & 4 && jX(a.g, 1, "o"));
        return !(d & 1)
    }

    function sX(a, b, c, d) {
        let e = null;
        try {
            e = c.style
        } catch (B) {
            lX(a.g, "s")
        }
        var f = c.getAttribute("width"),
            g = Md(f),
            h = c.getAttribute("height"),
            k = Md(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = rX(a, c, b);
        var m = d && d.width;
        const n = d && d.height;
        var p = e && e.width,
            t = e && e.height,
            u = Nd(m) == a.width && Nd(n) == a.height;
        m = u ? m : p;
        t = u ? n : t;
        p = Nd(m);
        u = Nd(t);
        g = a.width !== null && (p !== null && a.width >= p || g !== null && a.width >= g);
        u = a.height !== null && (u !== null && a.height >= u || k !== null && a.height >= k);
        k = !b && tX(d);
        u = b || u || k || !(f ||
            m || d && (!DX(String(d.minWidth)) || !EX(String(d.maxWidth))));
        l = b || g || k || l || !(h || t || d && (!DX(String(d.minHeight)) || !EX(String(d.maxHeight))));
        FX(a, 0, u, c, "width", f, a.width, a.l);
        GX(a, 0, "d", u, e, d, "width", m, a.width, a.l);
        GX(a, 0, "m", u, e, d, "minWidth", e && e.minWidth, a.width, a.l);
        GX(a, 0, "M", u, e, d, "maxWidth", e && e.maxWidth, a.width, a.l);
        a.Vh ? (c = /^html|body$/i.test(c.nodeName), f = Nd(n), h = d ? d.overflowY === "auto" || d.overflowY === "scroll" : !1, h = a.j != null && d && f && Math.round(f) !== a.j && !h && d.minHeight !== "100%", a.A && !c && h && (e.setProperty("height",
            "auto", "important"), d && !DX(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !EX(String(d.maxHeight)) && a.j && Math.round(f) < a.j && e.setProperty("max-height", "none", "important"))) : (FX(a, 1, l, c, "height", h, a.height, a.j), GX(a, 1, "d", l, e, d, "height", t, a.height, a.j), GX(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.j), GX(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.j));
        return b
    }

    function vX(a) {
        function b() {
            if (c > 0) {
                var l = Dd(e, d) || {
                    width: 0,
                    height: 0
                };
                const m = Nd(l.width);
                l = Nd(l.height);
                m !== null && f !== null && h && h(0, f - m);
                l !== null && g !== null && h && h(1, g - l);
                --c
            } else q.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        let c = 31.25;
        const d = a.ba,
            e = a.D,
            f = a.l,
            g = a.j,
            h = a.F;
        let k;
        q.setTimeout(() => {
            k = q.setInterval(b, 16)
        }, 990)
    }

    function CX(a, b, c) {
        if (b.nodeType == 3) return /\S/.test(b.data) ? 1 : 0;
        if (b.nodeType == 1) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = Dd(b, c)
            } catch (e) {}
            if (d) {
                if (d.display == "none" || d.position == "fixed") return 0;
                if (d.position == "absolute") {
                    if (!a.B.boundingClientRect || d.visibility == "hidden" || d.visibility == "collapse") return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.B.boundingClientRect.left ? 2 : 0) | (c.bottom > a.B.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function FX(a, b, c, d, e, f, g, h) {
        if (h != null) {
            if (typeof f == "string") {
                if (f == "100%" || !f) return;
                f = Md(f);
                f == null && (lX(a.g, "n"), jX(a.g, b, "d"))
            }
            if (f != null)
                if (c) {
                    if (a.A)
                        if (a.J) {
                            const k = Math.max(f + h - (g || 0), 0),
                                l = a.F;
                            a.F = (m, n) => {
                                m == b && Oc(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else Oc(d, e, String(h))
                } else jX(a.g, b, "d")
        }
    }

    function GX(a, b, c, d, e, f, g, h, k, l) {
        if (l != null) {
            f = f && f[g];
            typeof f != "string" || (c == "m" ? DX(f) : EX(f)) || (f = Nd(f), f == null ? kX(a.g, "p") : k != null && kX(a.g, f == k ? "E" : "e"));
            if (typeof h == "string") {
                if (c == "m" ? DX(h) : EX(h)) return;
                h = Nd(h);
                h == null && (lX(a.g, "p"), jX(a.g, b, c))
            }
            if (h != null)
                if (d && e) {
                    if (a.A)
                        if (a.J) {
                            const m = Math.max(h + l - (k || 0), 0),
                                n = a.F;
                            a.F = (p, t) => {
                                p == b && (e[g] = `${m-t}px`);
                                n && n(p, t)
                            }
                        } else e[g] = `${l}px`
                } else jX(a.g, b, c)
        }
    }
    var LX = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.D = b;
            this.K = c;
            this.G = this.F = null;
            this.V = !1;
            this.B = new HX(this.D);
            this.ba = (a = this.D.ownerDocument) && (a.defaultView || a.parentWindow);
            this.B = new HX(this.D);
            this.A = g;
            this.la = IX(this.B, d.ei, d.height, d.ve);
            this.width = this.A ? this.B.boundingClientRect ? this.B.boundingClientRect.right - this.B.boundingClientRect.left : null : e;
            this.height = this.A ? this.B.boundingClientRect ? this.B.boundingClientRect.bottom - this.B.boundingClientRect.top : null : f;
            this.l = JX(d.width);
            this.j = JX(d.height);
            this.T = this.A ? JX(d.opacity) : null;
            this.check = d.check;
            this.ve = !!d.ve;
            this.J = d.ei == "animate" && !KX(this.B, this.j, this.ve) && iX();
            this.Ie = !!d.Ie;
            this.g = new pX;
            KX(this.B, this.j, this.ve) && kX(this.g, "r");
            e = this.B;
            e.g && e.j >= e.ha && kX(this.g, "b");
            this.Nf = !!d.Nf;
            this.Vh = !!d.Vh
        }
    };

    function KX(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.j + Math.min(b, JX(a.getHeight())), a = a.g && b >= a.ha) : a = a.g && a.j >= a.ha, d = a);
        return d
    }
    var HX = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && Ad(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            var d = a;
            let e = 0,
                f = this.boundingClientRect;
            for (; d;) try {
                f && (e += f.top);
                const g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.j = e;
            c = c || q;
            this.ha = (c.document.compatMode == "CSS1Compat" ? c.document.documentElement : c.document.body).clientHeight;
            b = b && JT(b);
            this.visible = !!a && !(b == 2 || b == 3) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function IX(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return KX(a, c, d)
        }
    }

    function tX(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }
    var MX = new pX("s", ""),
        nX = RegExp("[lonvafrbpEe]", "g");

    function EX(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function DX(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function xX(a, b, c) {
        b !== null && Md(a.getAttribute("width")) !== null && a.setAttribute("width", String(b));
        c !== null && Md(a.getAttribute("height")) !== null && a.setAttribute("height", String(c));
        b !== null && (a.style.width = `${b}px`);
        c !== null && (a.style.height = `${c}px`)
    }
    var yX = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        zX = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function AX() {
        let a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = yX;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = zX;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function JX(a) {
        return typeof a === "string" ? Md(a) : typeof a === "number" && isFinite(a) ? a : null
    };

    function NX(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const OX = /[+, ]/;

    function PX(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (a.nodeType === 9) a: {
            try {
                const c = Nk(a);
                if (c) {
                    const d = c.frameElement;
                    if (d && xd(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function QX(a, b) {
        var c = MW(a.pubWin);
        a.I.saaei && (c += (c === "" ? "" : ",") + a.I.saaei);
        b.eid = c;
        c = a.I.google_loeid;
        typeof c === "string" && (a.g |= 4096, b.loeid = c)
    }

    function RX(a, b) {
        a = (a = Ad(a.pubWin)) && a.document ? jT(a.document, a) : new Dk(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function SX(a) {
        try {
            const b = q.top.location.hash;
            if (b) {
                const c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function TX(a, b, c) {
        const d = a.I;
        var e = a.pubWin,
            f = a.P,
            g = he(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = Em(e)) && h.data && sa(h.data) && typeof h.data.type === "string" ? (h = h.data.type.toLowerCase(), h = h === "doubleclick" || h === "adsense" ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = aJ(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.yh || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.Fc && (b.etu = a.Fc);
        (c = mU(d, f, c)) && (b.fc = c);
        if (!Zm(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode &&
                (h = Wk(new Hk(c), "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    const ua = h.contentWindow.document;
                    ua.open();
                    var k = Gc("<!DOCTYPE html>");
                    ua.write(Hc(k));
                    ua.close();
                    g += ua.documentMode
                } catch (ua) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        let l, m, n, p, t, u, B, F, R, da;
        try {
            l = e.screenX, m = e.screenY
        } catch (ua) {}
        try {
            n = e.outerWidth, p = e.outerHeight
        } catch (ua) {}
        try {
            t = e.innerWidth, u = e.innerHeight
        } catch (ua) {}
        try {
            B = e.screenLeft, F = e.screenTop
        } catch (ua) {}
        try {
            t =
                e.innerWidth, u = e.innerHeight
        } catch (ua) {}
        try {
            R = e.screen.availWidth, da = e.screen.availTop
        } catch (ua) {}
        b.brdim = [B, F, l, m, R, da, n, p, t, u].join();
        k = 0;
        q.postMessage === void 0 && (k |= 1);
        k > 0 && (b.osd = k);
        b.vis = JT(e.document);
        k = a.ea;
        e = vU(d) ? MX : BX(new LX(e, k, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = oX(e);
        if (!vU(d) && (e = $m(d), e !== null)) {
            k = 0;
            a: {
                try {
                    {
                        var J = d.google_async_iframe_id;
                        const ua = window.document;
                        if (J) var N = ua.getElementById(J);
                        else {
                            var aa = ua.getElementsByTagName("script"),
                                Ya = aa[aa.length - 1];
                            N = Ya && Ya.parentNode || null
                        }
                    }
                    if (J = N) {
                        N = [];
                        aa = 0;
                        for (var Sb = Date.now(); ++aa <= 100 && Date.now() - Sb < 50 && (J = PX(J));) J.nodeType === 1 && N.push(J);
                        var za = N;
                        b: {
                            for (Sb = 0; Sb < za.length; Sb++) {
                                c: {
                                    var Ha = za[Sb];
                                    try {
                                        if (Ha.parentNode && Ha.offsetWidth > 0 && Ha.offsetHeight > 0 && Ha.style && Ha.style.display !== "none" && Ha.style.visibility !== "hidden" && (!Ha.style.opacity || Number(Ha.style.opacity) !== 0)) {
                                            const ua = Ha.getBoundingClientRect();
                                            var Yc = ua.right > 0 && ua.bottom > 0;
                                            break c
                                        }
                                    } catch (ua) {}
                                    Yc = !1
                                }
                                if (!Yc) {
                                    var Ic = !1;
                                    break b
                                }
                            }
                            Ic = !0
                        }
                        if (Ic) {
                            b: {
                                const ua = Date.now();Ic = /^html|body$/i;Yc = /^fixed/i;
                                for (Ha = 0; Ha < za.length && Date.now() - ua < 50; Ha++) {
                                    const pd = za[Ha];
                                    if (!Ic.test(pd.tagName) && Yc.test(pd.style.position || gl(pd, "position"))) {
                                        var Jc = pd;
                                        break b
                                    }
                                }
                                Jc = null
                            }
                            break a
                        }
                    }
                } catch {}
                Jc = null
            }
            Jc && Jc.offsetWidth * Jc.offsetHeight <= e.width * e.height * 4 && (k = 1);
            b.pfx = k
        }
        a: {
            if (Math.random() < .05 && f) try {
                const ua = f.document.getElementsByTagName("head")[0];
                var Id = ua ? NU(ua) : 0;
                break a
            } catch (ua) {}
            Id = 0
        }
        f = Id;
        f !== 0 && (b.cms = f);
        d.google_lrv !== a.lb && (b.alvm = d.google_lrv ||
            "none")
    }

    function UX(a, b) {
        let c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : yd(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function VX(a, b) {
        const c = iJ(b, 8, {});
        b = iJ(b, 9, {});
        const d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function WX(a, b, c) {
        const d = a.I;
        var e = a.I;
        b.dt = is;
        e.google_async_iframe_id && e.google_bpp && (b.bpp = e.google_bpp);
        a: {
            try {
                var f = q.performance;
                if (f && f.timing && f.now) {
                    var g = f.timing.navigationStart + Math.round(f.now()) - f.timing.domLoading;
                    break a
                }
            } catch (m) {}
            g = null
        }(e = (e = g) ? TV(e, q.Date.now() - is, 1E6) : null) && (b.bdt = e);
        b.idt = TV(a.A, is);
        e = a.I;
        b.shv = a.pageStateTs.bv || C(a.ra, 2);
        a.lb && (b.mjsv = a.lb);
        e.google_loader_used === "sd" ? b.ptt = 5 : e.google_loader_used === "aa" && (b.ptt = 9);
        /^\w{1,3}$/.test(e.google_loader_used) &&
            (b.saldr = e.google_loader_used);
        if (e = Em(a.pubWin)) b.is_amp = 1, b.amp_v = Fm(e), (e = Gm(e)) && (b.act = e);
        e = a.pubWin;
        e == e.top && (b.abxe = 1);
        e = new JW(a.pubWin);
        (g = DW(e, "__gads", c)) ? b.cookie = g: c.ca() && bP(e.C) && (b.cookie_enabled = "1");
        (g = DW(e, "__gpi", c)) && !g.includes("&") && (b.gpic = g);
        DW(e, "__gpi_opt_out", c) === "1" && (b.pdopt = "1");
        e = new UW(a.pubWin);
        g = {
            Rh: !1,
            Sh: !a.Ua
        };
        (f = TW(e, c, g)) ? b.eo_id_str = f: SW(e, c, g) && (b.eoidce = "1");
        c = dJ();
        g = iJ(c, 8, {});
        e = d.google_ad_section;
        g[e] && (b.prev_fmts = g[e]);
        g = iJ(c, 9, {});
        g[e] && (b.prev_slotnames =
            g[e].toLowerCase());
        VX(d, c);
        e = iJ(c, 15, 0);
        e > 0 && (b.nras = String(e));
        (g = Em(window)) ? (g ? (e = g.pageViewId, g = g.clientId, typeof g === "string" && (e += g.replace(/\D/g, "").substring(0, 6))) : e = null, e = +e) : (e = he(window), g = e.google_global_correlator, g || (e.google_global_correlator = g = 1 + Math.floor(Math.random() * 8796093022208)), e = g);
        b.correlator = iJ(c, 7, e);
        T(oz) && (b.rume = 1);
        if (d.google_ad_channel) {
            e = iJ(c, 10, {});
            g = "";
            f = d.google_ad_channel.split(OX);
            for (var h = 0; h < f.length; h++) {
                var k = f[h];
                e[k] ? g += k + "+" : e[k] = !0
            }
            b.pv_ch = g
        }
        if (d.google_ad_host_channel) {
            e =
                d.google_ad_host_channel;
            g = iJ(c, 11, []);
            f = e.split("|");
            c = -1;
            e = [];
            for (h = 0; h < f.length; h++) {
                k = f[h].split(OX);
                g[h] || (g[h] = {});
                let m = "";
                for (let n = 0; n < k.length; n++) {
                    const p = k[n];
                    p !== "" && (g[h][p] ? m += "+" + p : g[h][p] = !0)
                }
                m = m.slice(1);
                e[h] = m;
                m !== "" && (c = h)
            }
            g = "";
            if (c > -1) {
                for (f = 0; f < c; f++) g += e[f] + "|";
                g += e[c]
            }
            b.pv_h_ch = g
        }
        b.frm = d.google_iframing;
        b.ife = d.google_iframing_environment;
        a: {
            c = d.google_ad_client;
            try {
                const m = he(window);
                let n = m.google_prev_clients;
                n || (n = m.google_prev_clients = {});
                if (c in n) {
                    var l = 1;
                    break a
                }
                n[c] = !0;
                l = 2;
                break a
            } catch {
                l = 0;
                break a
            }
            l = void 0
        }
        b.pv = l;
        T(Cx) && a.pubWin.location.host.endsWith("h5games.usercontent.goog") && (b.cdm = a.pubWin.location.host);
        UX(a.pubWin, b);
        (a = d.google_ad_layout) && YV[a] >= 0 && (b.rplot = YV[a])
    }

    function XX(a, b) {
        a = a.R;
        pJ() && (b.npa = 1);
        if (a) {
            Oh(a, 3) != null && (b.gdpr = a.g() ? "1" : "0");
            var c = Yh(a, 1);
            c && (b.us_privacy = c);
            (c = Yh(a, 2)) && (b.gdpr_consent = c);
            (c = Yh(a, 4)) && (b.addtl_consent = c);
            (c = Zh(a, 7)) && (b.tcfe = c);
            (c = C(a, 11)) && (b.gpp = c);
            (a = qh(a, 10, Tf, 1, void 0, 1024)) && a.length > 0 && (b.gpp_sid = a.join(","))
        }
    }

    function YX(a, b) {
        const c = a.I;
        XX(a, b);
        Fd(OW, (d, e) => {
            b[d] = c[e]
        });
        vU(c) && (a = uU(c), b.fa = a);
        b.pi || c.google_ad_slot == null || (a = lB(c), vu(a) && (a = Ku(a.getValue()), b.pi = a))
    }

    function ZX(a, b) {
        var c = Tm() || hT(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = hT(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function $X(a, b) {
        var c = a.pubWin;
        c !== null && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = hT(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = Hu(a.join(""))) : a = 0;
        a !== 0 && (b.ifk = a)
    }

    function aY(a, b) {
        (a = lJ()[a.I.google_ad_client]) && (b.psts = a.join())
    }

    function bY(a, b) {
        (a = a.pageStateTs.pem) && a >= 0 && (b.tmod = a)
    }

    function cY(a, b) {
        (a = a.pubWin.google_user_agent_client_hint) && (b.uach = qe(a))
    }

    function dY(a, b) {
        const c = a.Tf.psldt.fldt.pbfl;
        a = a.Tf.psldt.fldt.pvfl;
        c >= 0 && (b.pubf = c);
        a >= 0 && (b.pvtf = a)
    }

    function eY(a, b) {
        const c = Number(a.I.google_traffic_source);
        c && Object.values(Fa).includes(c) && (b.trt = a.I.google_traffic_source)
    }

    function fY(a, b) {
        var c;
        if (c = !T(tz)) c = a.cookieDeprecationLabel ? .label, c = !(T(bz) && c && c.match(vz($y)));
        c && ("runAdAuction" in a.pubWin.navigator && "joinAdInterestGroup" in a.pubWin.navigator && (b.td = 1), c = a.pubWin.navigator, a.pubWin.isSecureContext && "runAdAuction" in c && c.runAdAuction instanceof Function && tW("run-ad-auction", a.pubWin.document) && (c = new QW, c.set(1, uW(a.pubWin.navigator)), b.tdf = PW(c)))
    }

    function gY(a, b) {
        if (navigator.deprecatedRunAdAuctionEnforcesKAnonymity) {
            var c = new cX;
            var d = new bX;
            d = gi(d, 4, "deprecated_kanon");
            c = y(c, 2, d)
        }
        a.cookieDeprecationLabel != null && Qb() && (c ? ? (c = new cX), d = gi(c, 3, a.cookieDeprecationLabel.label), G(d, 4, a.cookieDeprecationLabel.status));
        c && (b.psd = qe(jj(c)))
    }

    function hY(a, b) {
        T(lz) || tW("attribution-reporting", a.pubWin.document) && (b.nt = 1)
    }

    function iY(a, b) {
        if (typeof a.I.google_privacy_treatments === "string") {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.I.google_privacy_treatments.split(",");
            var d = [];
            for (const [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function jY(a, b) {
        if (a.j) {
            a.j.Wl && (b.xatf = 1);
            try {
                a.j.ih ? .disconnect(), a.j.ih = void 0
            } catch {}
        }
    }

    function kY(a, b = document) {
        if (T(Gw)) try {
            const {
                labels: c
            } = XW(b);
            c.length && (a.pgls = c.map(d => {
                d = VW(d);
                return oe(d)
            }).join("~"))
        } catch (c) {
            cC.pa(1278, c)
        }
    }

    function lY(a, b) {
        T(Fw) && (a = a.Cb ? .get(), b.bisch = a ? .charging, b.blev = a ? .level)
    }

    function mY(a, b) {
        const c = {};
        YX(a, c);
        cY(a, c);
        WX(a, c, b);
        c.u_tz = -(new Date).getTimezoneOffset();
        try {
            var d = um.history.length
        } catch (e) {
            d = 0
        }
        c.u_his = d;
        c.u_h = um.screen ? .height;
        c.u_w = um.screen ? .width;
        c.u_ah = um.screen ? .availHeight;
        c.u_aw = um.screen ? .availWidth;
        c.u_cd = um.screen ? .colorDepth;
        c.u_sd = iT(a.pubWin);
        c.dmc = a.pubWin.navigator ? .deviceMemory;
        fC(889, () => {
            if (a.P === null) c.adx = -12245933, c.ady = -12245933;
            else {
                var e = lT(a.P, a.ea);
                c.adx && c.adx !== -12245933 && c.ady && c.ady !== -12245933 || (c.adx = Math.round(e.x), c.ady =
                    Math.round(e.y));
                kT(a.ea) || (c.adx = -12245933, c.ady = -12245933, a.g |= 32768)
            }
        });
        ZX(a, c);
        $X(a, c);
        RX(a, c);
        QX(a, c);
        c.oid = 2;
        aY(a, c);
        T(Hw) && RV(a, c, b);
        c.pvsid = fe(a.pubWin, cC);
        bY(a, c);
        c.uas = NX(a.pubWin);
        (d = aX(a.pubWin)) && (c.nvt = d);
        a.l && (c.scar = a.l);
        jY(a, c);
        TX(a, c, b);
        c.fu = a.g;
        c.bc = RW();
        a.pageStateTs.idi && (NW(c), c.creatives = SX(/\b(?:creatives)=([\d,]+)/), c.adgroups = SX(/\b(?:adgroups)=([\d,]+)/), c.adgroups || c.sso) && (c.adtest = "on", c.disable_budget_throttling = !0, c.use_budget_filtering = !1, c.retrieve_only = !0, c.disable_fcap = !0);
        Am() && (c.atl = !0);
        c.bz = ie(a.pubWin);
        dY(a, c);
        eY(a, c);
        fY(a, c);
        gY(a, c);
        hY(a, c);
        iY(a, c);
        String(a.I.google_special_category_data) === "true" && (c.scd = 1);
        kY(c, a.pubWin.document);
        lY(a, c);
        return c
    }
    const nY = /YtLoPri/;

    function oY(a) {
        const b = dJ(),
            c = a.google_ad_section;
        vU(a) && kJ(b, 15);
        if (Zm(a)) {
            if (kJ(b, 5) > 100) return !1
        } else if (kJ(b, 6) - iJ(b, 15, 0) > 100 && c === "") return !1;
        return !0
    }
    var pY = Y(function(a, b) {
        const c = b.I;
        var d = b.Sa,
            e = b.pubWin;
        a = a.R;
        var f = "";
        if (xU(c)) f = (a.ca() ? d.gk : d.fk).toString() + "#" + (encodeURIComponent("RS-" + c.google_reactive_sra_index + "-") + "&" + Xm({
            adk: c.google_ad_unit_key,
            client: c.google_ad_client,
            fa: c.google_reactive_ad_format
        })), VX(c, dJ()), oY(c);
        else if ((d = c.google_pgb_reactive === 5 && !!c.google_reactive_ads_config) || (d = c.google_reactive_ad_format, d = !(!c.google_reactive_ads_config && vU(c) && d !== 16 && d !== 10 && d !== 11 && d !== 40 && d !== 41 && d !== 42)), d || (d = c.google_reactive_ad_format,
                Xb(d) ? (e = Ad(e)) && gU(e, c, d, a) ? (e = mE(e), Ms(e, d) ? d = !1 : (e.adCount[d] || (e.adCount[d] = 0), e.adCount[d]++, d = !0)) : d = !1 : d = !1), d && oY(c)) {
            d = f = b.I;
            var g = b.pubWin;
            e = {};
            const t = g.document;
            var h = {
                Xj: he(g),
                oh: !1,
                gj: "",
                Tg: 1
            };
            a: {
                var k = d.google_ad_width || g.google_ad_width,
                    l = d.google_ad_height || g.google_ad_height;
                if (g && g.top === g) var m = !1;
                else {
                    m = g.document;
                    var n = m.documentElement;
                    if (k && l) {
                        let u = 1,
                            B = 1;
                        g.innerHeight ? (u = g.innerWidth, B = g.innerHeight) : n && n.clientHeight ? (u = n.clientWidth, B = n.clientHeight) : m.body && (u = m.body.clientWidth,
                            B = m.body.clientHeight);
                        if (B > 2 * l || u > 2 * k) {
                            m = !1;
                            break a
                        }
                    }
                    m = !0
                }
            }
            h.oh = m;
            m = h.oh;
            n = aJ(h.Xj).yh;
            k = g.top == g ? 0 : xd(g.top) ? 1 : 2;
            l = 4;
            m || k !== 1 ? m || k !== 2 ? m && k === 1 ? l = 7 : m && k === 2 && (l = 8) : l = 6 : l = 5;
            n && (l |= 16);
            h.gj = String(l);
            h.Tg = cJ(g);
            n = h;
            h = n.Xj;
            m = n.oh;
            k = !!d.google_page_url;
            e.google_iframing = n.gj;
            n.Tg !== 0 && (e.google_iframing_environment = n.Tg);
            if (!k && t.domain === "ad.yieldmanager.com") {
                for (n = t.URL.substring(t.URL.lastIndexOf("http")); n.indexOf("%") > -1;) try {
                    n = decodeURIComponent(n)
                } catch (u) {
                    break
                }
                d.google_page_url = n;
                k = !!n
            }
            k ?
                (e.google_page_url = d.google_page_url, e.google_page_location = (m ? t.referrer : t.URL) || "EMPTY") : (m && xd(g.top) && t.referrer && g.top.document.referrer === t.referrer ? e.google_page_url = g.top.document.URL : e.google_page_url = m ? t.referrer : t.URL, e.google_page_location = null);
            if (t.URL === e.google_page_url) try {
                var p = Math.round(Date.parse(t.lastModified) / 1E3) || null
            } catch {
                p = null
            } else p = null;
            e.google_last_modified_time = p;
            p = h === h.top ? h.document.referrer : (p = Em()) && p.referrer || "";
            e.google_referrer_url = p;
            bJ(e, f);
            a.ca() ? (p = f.google_page_location ||
                f.google_page_url, "EMPTY" === p && (p = f.google_page_url), p ? (p = p.toString(), p.indexOf("http://") == 0 ? p = p.substring(7, p.length) : p.indexOf("https://") == 0 && (p = p.substring(8, p.length)), e = p.indexOf("/"), e === -1 && (e = p.length), p = p.substring(0, e).split("."), e = !1, p.length >= 3 && (e = p[p.length - 3] in gT), p.length >= 2 && (e = e || p[p.length - 2] in gT), p = e) : p = !1, p = p ? "pagead2.googlesyndication.com" : "googleads.g.doubleclick.net") : p = "pagead2.googlesyndication.com";
            a = mY(b, a);
            e = b.I;
            d = e.google_ad_channel;
            g = "/pagead/ads?";
            e.google_ad_client ===
                "ca-pub-6219811747049371" && nY.test(d) && (g = "/pagead/lopri?");
            b = Wm(a, `https://${p}${g}` + (b.pageStateTs.idi && f.google_debug_params ? f.google_debug_params : ""));
            f = f.google_ad_url = b
        }
        Cm(2, [c, f]);
        return {
            Ja: f,
            oa: !f
        }
    }, {
        id: 1437,
        H: {
            Ja: void 0,
            oa: void 0
        }
    });
    var qY = Y(function(a, b, c, d, e) {
        var f = a.th;
        if (!f) return {
            Ja: "",
            xc: ""
        };
        if (!b.google_async_iframe_id) {
            var g = c;
            g = Um(Em(g)) || g;
            g.google_unique_id = (g.google_unique_id || 0) + 1
        }
        const h = Ym(b);
        g = c === d ? "a!" + h.toString(36) : `${h.toString(36)}.${Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)}`;
        c = mT(d, c, e, !0) > 0;
        d = {
            ifi: h,
            uci: g
        };
        c && (c = dJ(), d.btvi = iJ(c, 21, 1), kJ(c, 21));
        f = Wm(d, f);
        Sd() && !xU(b) && (f = Bn(f, "fsb", 1));
        return a.ta ? {
            Ja: Bn(f, "fca", "1"),
            xc: g
        } : {
            Ja: f,
            xc: g
        }
    }, {
        id: 1438,
        H: {
            Ja: void 0,
            xc: void 0
        }
    });
    var rY = Y(function(a) {
        const b = a.url;
        if (a.oa) return {
            Ja: ""
        };
        a = b;
        a.length > 61440 && (a = a.substring(0, 61432), a = a.replace(/%\w?$/, ""), a = a.replace(/&[^=]*=?$/, ""), a += "&trunc=1");
        if (a !== b) {
            let c = b.lastIndexOf("&", 61432);
            c === -1 && (c = b.lastIndexOf("?", 61432));
            iC("trn", {
                ol: b.length,
                tr: c === -1 ? "" : b.substring(c + 1),
                url: b
            }, .01)
        }
        return {
            Ja: a
        }
    }, {
        id: 1374,
        H: {
            Ja: void 0
        }
    });
    var sY = class extends jV {
        constructor(a, b, c, d, e, f) {
            super(a, b, c, d, f);
            this.na = e;
            this.output = fV(this, new WU);
            this.complete = new aV
        }
        A(a) {
            a.then(b => {
                b instanceof PU || (RU(this.output, b), this.complete.notify())
            }, b => {
                this.na ? RU(this.output, this.na(b)) : this.output.setError(new OU(`output error: ${b.message}`), () => {
                    this.D.Na({
                        methodName: this.id,
                        eb: b
                    })
                });
                this.complete.notify()
            })
        }
        l(a) {
            this.na ? (RU(this.output, this.na(a)), this.complete.notify()) : super.l(a)
        }
    };

    function tY(a, b) {
        a.id = b.id;
        a.na = b.na;
        return a
    }

    function uY(a, b, c, ...d) {
        return new sY(a.id, a, b, c, a.na, d)
    };

    function vY(a, b) {
        it(a, b);
        a.T.push(b);
        return b
    }

    function Z(a, b, c, ...d) {
        return vY(a, lV(b, a.F, c, ...d))
    }

    function wY(a, b, c, ...d) {
        return vY(a, uY(b, a.F, c, ...d))
    }

    function xY(a, b) {
        a.V.push(b);
        it(a, b);
        return b
    }
    async function yY(a) {
        a.D.length && await Promise.all(a.D.map(d => d.ba.promise));
        if (await a.Fa()) {
            for (var b of a.T) b.start();
            for (var c of a.V) yY(c);
            if (a.G && (b = Object.keys(a.G), b.length)) {
                c = await Promise.all(Object.values(a.G).map(e => e.promise));
                let d = 0;
                for (const e of b) a.bb[e] = c[d++]
            }
        }
        a.ba.resolve(a.bb)
    }
    var zY = class extends O {
        constructor(a) {
            super();
            this.F = a;
            this.T = [];
            this.V = [];
            this.bb = {};
            this.D = [];
            this.ba = new YR;
            this.G = {}
        }
        run() {
            yY(this)
        }
        async Fa() {
            return !0
        }
        g() {
            super.g();
            this.T.length = 0;
            this.V.length = 0;
            this.D.length = 0
        }
    };
    var AY = class extends zY {
        constructor(a, b, c, d, e) {
            super(a);
            a = X(Z(this, pY, {
                R: c
            }, b), d);
            b = Z(this, qY, {
                th: a.Ja,
                ta: e
            }, b.I, b.pubWin, b.P, b.ea);
            this.j = {
                xm: Z(this, rY, {
                    oa: a.oa,
                    url: b.Ja
                }).Ja,
                oa: a.oa,
                xc: b.xc
            }
        }
    };
    var BY = Y(function(a, b) {
        return {
            R: b.R
        }
    }, {
        id: 1462,
        H: {
            R: void 0
        }
    });
    var CY = Y(function(a, b, c, d, e) {
        b = a.Ua;
        return a.R.ca() || b ? {
            Ld: !0
        } : (iC("afc_noc_req", {
            client: d.google_ad_client,
            isGdprCountry: e.gcs.igc.toString()
        }, U(Sw)), {
            Ld: !1
        })
    }, {
        id: 1381,
        H: {
            Ld: void 0
        }
    });

    function DY(a, b, c, d) {
        const e = SR(a, "gpi-uoo", (f, g) => {
            if (g.source === c) {
                g = Ml(f.userOptOut ? "1" : "0");
                g = ci(g, 2, 2147483647);
                g = fi(g, 3, "/");
                g = fi(g, 4, a.location.hostname);
                var h = new JW(a);
                GW(h, "__gpi_opt_out", g, b);
                if (f.userOptOut || f.clearAdsData) HW(h, "__gads", b), HW(h, "__gpi", b)
            }
        });
        d.push(e)
    };
    var EY = Y(function(a, b) {
        a = a.R;
        if (a.ca()) {
            var c = new JW(b);
            b = b.location.hostname;
            var d = DW(c, "__gpi_opt_out", a);
            d && (d = Ml(d), d = ci(d, 2, 2147483647), d = fi(d, 3, "/"), b = fi(d, 4, b), GW(c, "__gpi_opt_out", b, a))
        }
        return {}
    }, {
        id: 1382,
        H: {}
    });
    var FY = Y(function(a, b) {
        a = a.R;
        KW(20, b, a);
        KW(17, b, a);
        return {}
    }, {
        id: 1433,
        H: {}
    });
    var GY = Y(function(a, b) {
        T(Nx) && !vU(b) && (b.aieuf = !0);
        return {}
    }, {
        id: 1449,
        H: {}
    });

    function HY() {
        return navigator.cookieDeprecationLabel ? Promise.race([navigator.cookieDeprecationLabel.getValue().then(a => ({
            status: 1,
            label: a
        })).catch(() => ({
            status: 2
        })), ge(U(az), {
            status: 5
        })]) : Promise.resolve({
            status: 3
        })
    }
    var IY = tY(async function(a) {
        a = a.R;
        T(Zy) && a.ca() ? (a = dJ(), a = gJ(a, 39, HY)) : a = null;
        return a
    }, {
        id: 1432
    });
    var JY = Y(function(a, b) {
        a = a.R;
        const c = b.I.google_reactive_ads_config;
        c && (rU(b.P, c), yU(c, b, a), a = c.page_level_pubvars, sa(a) && ec(b.I, a));
        return {}
    }, {
        id: 1434,
        H: {}
    });
    var KY = Y(function(a, b) {
        a = a.R;
        a: {
            var c = [q.top];
            var d = [];
            let f = 0,
                g;
            for (; g = c[f++];) {
                d.push(g);
                try {
                    if (g.frames)
                        for (let h = 0; h < g.frames.length && c.length < 1024; ++h) c.push(g.frames[h])
                } catch {}
            }
            c = d;
            for (d = 0; d < c.length; d++) try {
                var e = c[d].frames.google_esf;
                if (e) {
                    tm = e;
                    break a
                }
            } catch (h) {}
            tm = null
        }
        if (tm) return {};
        e = Cd("IFRAME");
        e.id = "google_esf";
        e.name = "google_esf";
        b = a.ca() ? b.gk : b.fk;
        e.src = rc(b).toString();
        e.style.display = "none";
        e && document.documentElement.appendChild(e);
        return {}
    }, {
        id: 1441,
        H: {}
    });
    ud `https://securepubads.g.doubleclick.net/pagead/js/car.js`;
    ud `https://securepubads.g.doubleclick.net/pagead/js/cocar.js`;
    var LY = ud `https://ep3.adtrafficquality.google/ivt/worklet/caw.js`;

    function MY(a) {
        const b = [];
        for (let c = 0; c < 8; ++c) {
            const d = new sR(f => {
                    b.push({
                        url: f
                    })
                }),
                e = Eq(Dq(Cq(new Fq, a), c));
            d.F(e)
        }
        return b
    }

    function NY(a, b = () => {}) {
        const c = Nk();
        c.sharedStorage && !c.clientAgeRequested && (c.clientAgeRequested = !0, c.sharedStorage.createWorklet(LY.toString(), {
            dataOrigin: "script-origin"
        }).then(d => {
            OY(d, c, a, b)
        }).catch(b))
    }

    function OY(a, b, c, d = () => {}) {
        a.selectURL("ps_caus", MY(c), {
            resolveToConfig: !0,
            savedQuery: "ps_cac"
        }).then(e => {
            if (e) {
                var f = b.document.body;
                const g = document.createElement("fencedframe");
                g.id = "ps_caff";
                g.name = "ps_caff";
                g.mode = "opaque-ads";
                g.config = e;
                cl(g, "display", "none");
                f.appendChild(g)
            }
        }).catch(d)
    };
    var PY = Y(function(a, b, c) {
        if (T(Qy)) {
            a = vW(b.isSecureContext, b, b.document);
            const d = !!b.sharedStorage ? .createWorklet;
            c && a && d && !iJ(dJ(), 34, !1) && (jJ(dJ(), 34, !0), NY(fe(b), e => {
                let f = void 0;
                e.message.includes("sharedStorage.worklet.addModule is disabled") && (f = 1E-4);
                cC.pa(1279, e, f)
            }))
        }
        return {}
    }, {
        id: 1435,
        H: {}
    });
    var QY = tY(async function(a, b) {
        return b.j ? .dl || Promise.resolve()
    }, {
        id: 1436
    });
    var RY = Y(function(a, b) {
        a.cookieDeprecationLabel && (b.cookieDeprecationLabel = a.cookieDeprecationLabel);
        return {}
    }, {
        id: 1439,
        H: {}
    });
    var SY = class extends zY {
        async Fa() {
            const a = await this.l();
            a || this.A();
            return a
        }
    };
    async function TY(a, b, c) {
        a = new UY(b.id, b, a, c, b.na);
        await a.start();
        b = await a.F.promise;
        a.dispose();
        return b
    }
    class UY extends jV {
        constructor(a, b, c, d, e) {
            super(a, b, c, d, []);
            this.na = e;
            this.F = ja(Promise, "withResolvers").call(Promise)
        }
        G() {
            const a = this.f(iV(this), ...this.T);
            this.F.resolve(a)
        }
        A() {}
        l(a) {
            this.na !== void 0 ? this.F.resolve(this.na(a)) : super.l(a)
        }
    }

    function VY(a, b) {
        a.id = b.id;
        a.na = b.na;
        return a
    };
    const WY = VY(function(a) {
        return a.Ka
    }, {
        id: 1464
    });
    var XY = class extends SY {
        constructor(a, b, c, d, e) {
            super(a);
            this.ia = a;
            this.Ka = d;
            a = X(Z(this, KY, {
                R: c
            }, b.Sa), e);
            a = X(wY(this, IY, {
                R: c
            }), a.finished);
            d = Z(this, RY, {
                cookieDeprecationLabel: a.output
            }, b);
            d = X(Z(this, FY, {
                R: c
            }, b.pubWin), d.finished);
            d = X(Z(this, JY, {
                R: c
            }, b), d.finished);
            c = X(Z(this, PY, {
                R: c
            }, b.pubWin, b.Ua), d.finished);
            c = X(wY(this, QY, {}, b), c.finished);
            this.j = X(Z(this, GY, {}, b.I), c.complete).finished;
            this.cookieDeprecationLabel = a.output
        }
        async l() {
            return TY(this.ia, WY, {
                Ka: this.Ka
            })
        }
        A() {
            this.j.notify();
            RU(this.cookieDeprecationLabel,
                null)
        }
    };
    var YY = Y(function(a, b) {
        return {
            ta: T(cz) && !xU(b.I) && !vU(b.I)
        }
    }, {
        id: 1488,
        H: {
            ta: void 0
        }
    });
    var ZY = Y(function(a, b) {
        var c = b.pubWin;
        const d = b.ea;
        var e = b.I;
        const f = b.lb;
        a = U(kz);
        e = !Ns(e.google_reactive_ad_format) && (vU(e) || e.google_reactive_ads_config);
        if (b.j ? .ih || a <= 0 || Ad(c) || !q.IntersectionObserver || e) return {};
        b.j = {};
        const g = new Vr(f),
            h = ln();
        c = new Promise(k => {
            let l = 0;
            const m = b.j,
                n = new q.IntersectionObserver(gC(1236, p => {
                    if (p = p.find(t => t.target === d)) g.zf.Wf.He.g.g.se({
                        we: ln() - h,
                        rn: ++l
                    }), m.Wl = p.isIntersecting && p.intersectionRatio >= .8, k()
                }), {
                    threshold: [.8]
                });
            n.observe(d);
            m.ih = n
        });
        b.j.dl = Promise.race([c,
            ge(a, null)
        ]).then(k => {
            g.zf.Wf.He.g.j.se({
                we: ln() - h,
                status: k === null ? "TIMEOUT" : "OK"
            })
        });
        return {}
    }, {
        id: 1345,
        H: {}
    });
    var $Y = Y(function(a, b, c) {
        const d = a.ga;
        d && d.setAttribute("data-google-container-id", a.xc);
        a = b.iaaso;
        a != null && (b = c.parentElement, (b && Zz.test(b.className) ? b : c).setAttribute("data-auto-ad-size", a));
        d.setAttribute("tabindex", "0");
        d.setAttribute("title", "Advertisement");
        d.setAttribute("aria-label", "Advertisement");
        return {}
    }, {
        id: 1418,
        H: {}
    });
    var aZ = Y(function(a) {
        return {
            ga: a.ta ? a.yl : a.zn
        }
    }, {
        id: 1489,
        H: {
            ga: void 0
        }
    });

    function bZ(a, b) {
        const c = Cd("STYLE", a);
        c.textContent = Sc(ed `* { pointer-events: none; }`);
        a ? .head.appendChild(c);
        setTimeout(() => {
            a ? .head.removeChild(c)
        }, b)
    }

    function cZ(a, b, c) {
        if (!a.body) return null;
        const d = new dZ;
        d.apply(a, b);
        return () => {
            var e = c || 0;
            e > 0 && bZ(b.document, e);
            cl(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.l,
                position: d.B,
                top: d.A
            });
            b.scrollTo(0, d.j)
        }
    }
    class dZ {
        constructor() {
            this.g = this.A = this.B = this.l = null;
            this.j = 0
        }
        apply(a, b) {
            this.l = a.body.style.overflow;
            this.B = a.body.style.position;
            this.A = a.body.style.top;
            this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
            this.j = Ps(b);
            cl(a.body, "top", `${-this.j}px`)
        }
    };

    function eZ(a, b) {
        var c;
        if (!a.l)
            for (a.l = [], c = a.j.parentElement; c;) {
                a.l.push(c);
                if (a.K(c)) break;
                c = c.parentNode && c.parentNode.nodeType === 1 ? c.parentNode : null
            }
        c = a.l.slice();
        let d, e;
        for (d = 0; d < c.length; ++d)(e = c[d]) && b.call(a, e, d, c)
    }
    var fZ = class extends O {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.V = b;
            this.F = c;
            this.l = null;
            jt(this, () => this.l = null)
        }
        K(a) {
            return this.F === a
        }
    };

    function gZ(a, b) {
        const c = a.F;
        c && (b ? (vE(a.G), r(c, {
            display: "block"
        }), a.D.body && !a.A && (a.A = cZ(a.D, a.V, a.ba)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.D.body.setAttribute("aria-hidden", "true")) : (wE(a.G), r(c, {
            display: "none"
        }), a.A && (a.A(), a.A = null), a.D.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
    }

    function hZ(a) {
        gZ(a, !1);
        const b = a.F;
        if (b) {
            var c = iZ(a.T);
            eZ(a, d => {
                r(d, c);
                Ts(d)
            });
            a.j.setAttribute("width", "");
            a.j.setAttribute("height", "");
            cl(a.j, c);
            cl(a.j, jZ);
            cl(b, kZ);
            cl(b, {
                background: "transparent"
            });
            r(b, {
                display: "none",
                position: "fixed"
            });
            Ts(b);
            Ts(a.j);
            (Qb() && Rb() ? ie(a.T) : 1) <= 1 || (cl(b, {
                overflow: "scroll",
                "max-width": "100vw"
            }), Yd(b))
        }
    }
    var lZ = class extends fZ {
            constructor(a, b, c) {
                var d = U(jz);
                super(a, b, c);
                this.T = b;
                this.ba = d;
                this.A = null;
                this.D = b.document;
                this.G = pE(new uE(b), 2147483646)
            }
        },
        kZ = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        jZ = {
            left: "0",
            position: "absolute",
            top: "0"
        };

    function iZ(a) {
        a = Qb() && Rb() ? ie(a) : 1;
        a = 100 * (a < 1 ? 1 : a);
        return {
            width: `${a}vw`,
            height: `${a}vh`
        }
    };
    var mZ = class extends lZ {
        constructor(a, b, c) {
            super(b, a, c);
            hZ(this)
        }
        K(a) {
            return a.classList ? a.classList.contains("adsbygoogle") : Pa(a.classList ? a.classList : (typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || "").match(/\S+/g) || [], "adsbygoogle")
        }
    };
    const nZ = {
        [1]: "closed",
        [2]: "viewed",
        [3]: "dismissed"
    };
    async function oZ(a, b, c, d, e) {
        a = new pZ(a, b, c, d, e);
        await a.init();
        return a
    }

    function qZ(a) {
        return setTimeout(gC(728, () => {
            rZ(() => {
                a.D.reject()
            });
            a.dispose()
        }), U(ez) * 1E3)
    }

    function sZ(a, b) {
        var c = ZR(a.j).then(() => {
            clearTimeout(b);
            a.D.resolve()
        });
        hC(1005, c);
        c = $R(a.j).then(d => {
            tZ(a, nZ[d.status], d.payload)
        });
        hC(1006, c);
        c = aS(a.j).then(() => {
            tZ(a, "error")
        });
        hC(1004, c)
    }

    function uZ(a) {
        if (T(fz)) {
            a.C.location.hash !== "" && iC("pub_hash", {
                o_url: a.C.location.href
            }, .1);
            a.C.location.hash = "goog_fullscreen_ad";
            var b = gC(950, c => {
                c.oldURL.endsWith("#goog_fullscreen_ad") && (a.l === 10 ? (tZ(a, "closed"), a.C.removeEventListener("hashchange", b)) : (a.C.location.hash = "goog_fullscreen_ad", UR(a.j.Cg, "fullscreen", {
                    eventType: "backButton"
                }, "*")))
            });
            a.C.addEventListener("hashchange", b);
            jt(a, () => {
                a.C.removeEventListener("hashchange", b);
                a.C.location.hash === "#goog_fullscreen_ad" && a.C.history.back()
            })
        }
    }

    function rZ(a) {
        try {
            a()
        } catch (b) {}
    }

    function tZ(a, b, c) {
        gZ(a.G, !1);
        a.A && (c && b === "viewed" ? rZ(() => {
            a.A({
                status: b,
                reward: c
            })
        }) : rZ(() => {
            a.A({
                status: b
            })
        }));
        a.l === 11 && iC("fs_ad", {
            tgorigin: a.I.google_tag_origin,
            client: a.I.google_ad_client,
            url: a.I.google_page_url ? ? "",
            slot: a.I.google_ad_slot ? ? "0",
            ratype: a.l,
            clostat: b
        }, 1);
        a.dispose()
    }
    var pZ = class extends O {
        constructor(a, b, c, d, e) {
            super();
            this.C = a;
            this.F = b;
            this.K = c;
            this.l = d;
            this.I = e;
            this.A = null;
            this.G = new mZ(a, c, b);
            a = new cS(this.l === 10 ? 1 : 2, this.C, this.K.contentWindow);
            a.init();
            this.j = a;
            this.D = new YR;
            this.F.dataset["slotcar" + (this.l === 10 ? "Interstitial" : "Rewarded")] = "true"
        }
        async init() {
            const a = qZ(this);
            sZ(this, a);
            jt(this, () => {
                this.j.dispose();
                clearTimeout(a);
                Pk(this.F)
            });
            await this.D.promise
        }
        show(a) {
            this.B || (this.A = a, gZ(this.G, !0), q.IntersectionObserver || UR(this.j.Cg, "fullscreen", {
                eventType: "visible"
            }, "*"), uZ(this))
        }
        disposeAd() {
            this.dispose()
        }
    };
    var vZ = Y(function(a, b, c, d) {
        a = a.ga;
        if (b.google_acr)
            if (b.google_wrap_fullscreen_ad) {
                const e = b.google_acr;
                oZ(c, d.parentElement, a, b.google_reactive_ad_format, b).then(e).catch(() => {
                    e(null)
                })
            } else b.google_acr(a);
        return {}
    }, {
        id: 1354,
        H: {}
    });
    const wZ = (a, b) => {
        try {
            const n = A(b, 6) === void 0 ? !0 : A(b, 6);
            var c = Dl(D(b, 2)),
                d = C(b, 3);
            a: switch (D(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new Fl(c, d, e),
                g = x(b, Bl, 5) ? .g() ? ? "";
            f.he = g;
            f.j = n;
            var h = !!A(b, 7);
            f.Sb = h;
            var k = !!A(b, 8);
            f.Fb = k;
            var l = !!A(b, 9);
            f.g = l;
            f.C = a;
            var m = f.build();
            Al(m)
        } catch {}
    };

    function xZ(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), a.document.readyState === "complete" ? wZ(a, b) : ql(a, "load", () => void wZ(a, b)))
    };
    var yZ = Y(function(a, b, c, d, e) {
        a = a.R;
        var f = M(HJ);
        f.g && (f.state.tar += 1);
        f.Dc = b.google_page_url;
        b = new Cl;
        f = new Bl;
        var g = String(fe(c));
        f = gi(f, 1, g);
        b = y(b, 5, f);
        b = G(b, 4, 1);
        b = G(b, 2, 1);
        d = d.bv || C(e, 2);
        d = gi(b, 3, d);
        a = a.ca();
        a = ai(d, 6, a);
        T(Ew) && ai(a, 7, !0);
        T(hz) && ai(a, 8, !0);
        T(gz) && ai(a, 9, !0);
        xZ(c, a);
        return {}
    }, {
        id: 1347,
        H: {}
    });

    function zZ(a, b, c) {
        const d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => {
            AZ(d)
        });
        return TR(a, "adpnt", (e, f) => {
            if (Os(f, c.contentWindow)) {
                e = Rs(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), a.googletag.queryIds.length > 500 && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                e = !0
            } else e = !1;
            return e
        })
    }

    function AZ(a) {
        setTimeout(() => {
            a.dataset.adStatus !== "filled" && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };
    var BZ = Y(function(a, b, c, d) {
        a = a.ga;
        b && d.push(zZ(b, c, a));
        return {}
    }, {
        id: 1423,
        H: {}
    });

    function CZ(a) {
        if (a.location ? .ancestorOrigins) return a.location.ancestorOrigins.length;
        let b = 0;
        yd(() => {
            b++;
            return !1
        }, a);
        return b
    }

    function DZ(a, b, c, d = "//tpc.googlesyndication.com") {
        var e = c;
        e && (e = "?" + e);
        b = d + ("/safeframe/" + b + "/html/container.html" + e);
        (a = CZ(a)) && (b += `${c?"&":"?"}n=${a}`);
        return `https:${b}`
    };

    function EZ(a) {
        return `//${a}${".safeframe.googlesyndication.com"}`
    }
    var GZ = zb(FZ);

    function FZ() {
        let a = "";
        for (const b of HZ()) b <= 15 && (a += "0"), a += b.toString(16);
        return a
    }

    function HZ() {
        if (typeof window.crypto ? .getRandomValues === "function") {
            var a = new Uint8Array(16);
            window.crypto.getRandomValues(a);
            return a
        }
        a = window;
        if (typeof a.msCrypto ? .getRandomValues === "function") {
            var b = new Uint8Array(16);
            a.msCrypto.getRandomValues(b);
            return b
        }
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(Math.random() * 255);
        return a
    };

    function IZ(a, b, c) {
        try {
            if (!JZ(a, c.origin) || !Os(c, a.j.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e = null;
        typeof d === "string" && (e = a.messageHandlers[d]) && a.hb.kc(168, () => {
            e.call(a, b, c)
        })
    }

    function JZ(a, b) {
        return a.kk.includes(b) || ee(b)
    }
    var KZ = class extends O {
        constructor(a, b) {
            var c = cC,
                d = aC,
                e = T(cz) ? [`https:${EZ(GZ())}`] : [];
            super();
            this.l = a;
            this.j = b;
            this.hb = c;
            this.L = d;
            this.kk = e;
            this.messageHandlers = {};
            this.ba = [];
            this.Fa = this.hb.lc(168, (f, g) => void IZ(this, f, g));
            this.Fe = this.hb.lc(169, (f, g) => Ss(this.l, "ras::xsf", this.L, g));
            this.init({})
        }
        init() {
            this.V(this.messageHandlers);
            this.ba.push(SR(this.l, "sth", this.Fa, this.Fe))
        }
        g() {
            for (const a of this.ba) a();
            this.ba.length = 0;
            super.g()
        }
    };
    var LZ = class extends KZ {};

    function MZ(a, b, c, d = null) {
        return new NZ(a, b, c, d)
    }
    var NZ = class extends LZ {
        constructor(a, b, c, d) {
            super(a, b);
            this.Ma = c;
            this.R = d;
            this.ia = M(HJ);
            this.A = () => {};
            ql(this.j, "load", this.A)
        }
        g() {
            rl(this.j, "load", this.A);
            super.g()
        }
        V(a) {
            a["adsense-labs"] = b => {
                if (b = Rs(b).settings)
                    if (b = lj(Ol, JSON.parse(b)), ii(b, 1)) {
                        var c = b.aa;
                        if (Fh(b, c, c[v] | 0, Nl, 4, 3).length > 0) {
                            var d = c = Gh(b, Nl, 4, ph(Ue)),
                                e = this.ia;
                            const h = new up;
                            for (var f of d) switch (f.getVersion()) {
                                case 1:
                                    $h(h, 1, !0);
                                    break;
                                case 2:
                                    $h(h, 2, !0)
                            }
                            f = new vp;
                            f = z(f, 1, wp, h);
                            OJ(e, f);
                            f = this.l;
                            e = this.R;
                            if (!iJ(dJ(), 37, !1)) {
                                f = new JW(f);
                                for (var g of c) switch (g.getVersion()) {
                                    case 1:
                                        GW(f, "__gads", g, e);
                                        break;
                                    case 2:
                                        GW(f, "__gpi", g, e)
                                }
                                jJ(dJ(), 37, !0)
                            }
                            ih(b, 4)
                        }
                        if (g = x(b, Nl, 5)) c = this.l, iJ(dJ(), 40, !1) || (c = new UW(c), f = Zv(Qh(g, 2)) - Date.now() / 1E3, f = {
                            me: Math.max(f, 0),
                            path: C(g, 3),
                            domain: C(g, 4),
                            Pf: !1
                        }, eP("__eoi", g.getValue(), f, c.g), jJ(dJ(), 40, !0));
                        ih(b, 5);
                        g = this.l;
                        c = C(b, 1) || "";
                        f = this.Ma;
                        if (vu(pP({
                                C: g,
                                Ma: f
                            }))) {
                            f = mW(g, f);
                            b !== null && (f[c] = rg(b));
                            try {
                                g.localStorage.setItem("google_adsense_settings", JSON.stringify(f))
                            } catch (h) {}
                        }
                    }
            }
        }
    };
    var OZ = Y(function(a, b, c) {
        const d = a.ga,
            e = a.za;
        a = a.R;
        b && e(MZ(b, d, c.gcs.igc, a));
        return {}
    }, {
        id: 1424,
        H: {}
    });
    var PZ = Y(function(a, b, c, d) {
        return {
            za: e => {
                e && d.push(() => {
                    e.dispose()
                })
            },
            Ha: b && (!vU(c) || wU(c))
        }
    }, {
        id: 1425,
        H: {
            za: void 0,
            Ha: void 0
        }
    });
    var QZ = Y(function(a, b, c) {
        DY(b, a.R, a.ga.contentWindow, c);
        return {}
    }, {
        id: 1429,
        H: {}
    });

    function RZ(a) {
        const b = a.K.getBoundingClientRect(),
            c = b.top + b.height < 0;
        return !(b.top > a.j.innerHeight) && !c
    }
    var SZ = class extends O {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.D = b;
            this.K = c;
            this.F = 0;
            this.A = RZ(this);
            const d = Bb(this.G, this);
            this.l = gC(433, () => {
                um.requestAnimationFrame ? um.requestAnimationFrame(d) : d()
            });
            ql(this.j, "scroll", this.l, nl)
        }
        G() {
            const a = RZ(this);
            if (a && !this.A) {
                var b = {
                    rr: "vis-bcr"
                };
                const c = this.D.contentWindow;
                c && (VR(c, "ig", b, "*", 2), ++this.F >= 10 && this.dispose())
            }
            this.A = a
        }
        dispose() {
            this.l && rl(this.j, "scroll", this.l, nl)
        }
    };
    var TZ = Y(function(a, b, c) {
        const d = a.ga,
            e = a.Ha;
        a = a.za;
        b && e && a(b.IntersectionObserver ? null : new SZ(b, d, c));
        return {}
    }, {
        id: 1427,
        H: {}
    });

    function UZ(a, b) {
        const c = a.pubWin,
            d = a.I.google_ad_client,
            e = lJ();
        let f = null;
        const g = SR(c, "pvt", (h, k) => {
            typeof h.token === "string" && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), e[d].length > 100 && e[d].shift())
        });
        a.Ba.push(g);
        return () => {
            f && Array.isArray(e[d]) && (Ta(e[d], f), e[d].length || delete e[d], f = null)
        }
    };
    var VZ = Y(function(a, b) {
        return {
            Me: UZ(b, a.ga)
        }
    }, {
        id: 1430,
        H: {
            Me: void 0
        }
    });
    var WZ = class extends H {};

    function XZ(a) {
        return Gh(a, WZ, 15, ph())
    }
    var YZ = class extends H {
            g() {
                return Sh(this, 24)
            }
        },
        ZZ = xk(YZ);
    var $Z = class extends H {},
        a_ = xk($Z);
    var c_ = class extends LZ {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.ea = c;
            this.I = d;
            this.wc = e
        }
        V(a) {
            a["resize-me"] = (b, c) => {
                if (this.wc && this.l ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/)) {
                    var d = this.I.google_ad_client;
                    if (typeof d !== "string") throw new $B(`Invalid property code ${d}`);
                    c = this.wc;
                    b = new $Z;
                    b = gi(b, 2, d);
                    b_(c, b)
                } else {
                    b = Rs(b);
                    var e = b.r_chk;
                    if (e == null || e === "") {
                        d = Md(b.r_nw);
                        var f = Md(b.r_nh),
                            g = Md(b.r_no);
                        g != null || d !== 0 && f !== 0 || (g = 0);
                        var h = b.r_str;
                        h = h ? h : null; {
                            var k = /^true$/.test(b.r_ao),
                                l = /^true$/.test(b.r_ifr),
                                m = /^true$/.test(b.r_cab);
                            const t = window;
                            if (t)
                                if (h === "no_rsz") b.err = "7", d = !0;
                                else {
                                    var n = new HX(this.j);
                                    if (n.g) {
                                        var p = n.getWidth();
                                        p != null && (b.w = p);
                                        p = n.getHeight();
                                        p != null && (b.h = p);
                                        IX(n, h, f, m) ? (n = this.ea, e = BX(new LX(t, n, [this.j], {
                                            width: d,
                                            height: f,
                                            opacity: g,
                                            check: e,
                                            ei: h,
                                            Ie: k,
                                            Nf: l,
                                            ve: m
                                        }, null, null, !0)), b.r_cui && /^true$/.test(b.r_cui.toString()) && r(n, {
                                            height: `${f===null?0:f-48}px`,
                                            top: "24px"
                                        }), d != null && (b.nw = d), f != null && (b.nh = f), b.rsz = e.toString(), b.abl = oX(e), b.frsz = (h === "force").toString(), b.err = "0", d = !0) : (b.err = "1", d = !1)
                                    } else b.err = "3", d = !1
                                }
                            else b.err = "2", d = !1
                        }
                        UR(c.source, "sth", {
                            msg_type: "resize-result",
                            r_str: h,
                            r_status: d
                        }, "*");
                        this.j.dataset.googleQueryId || this.j.setAttribute("data-google-query-id", b.qid)
                    }
                }
            }
        }
    };
    var d_ = Y(function(a, b, c, d) {
        const e = a.ga,
            f = a.Ha,
            g = a.za;
        a = a.wc;
        b && f && (c.no_resize || g(new c_(b, e, d, c, a)));
        return {}
    }, {
        id: 1426,
        H: {}
    });

    function e_(a) {
        return b => !!(b.nc() & a)
    }
    var f_ = class extends WV {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.D = c;
            this.A = d
        }
        nc() {
            return this.D
        }
        l(a, b, c) {
            c.style.height = `${this.height()}px`;
            b.rpe = !0
        }
    };
    const g_ = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        h_ = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        i_ = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function j_(a) {
        var b = 0;
        a.ub && b++;
        a.mb && b++;
        a.nb && b++;
        if (b < 3) return {
            Tb: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.ub.split(",");
        const c = a.nb.split(",");
        a = a.mb.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            Tb: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length > 2) return {
            Tb: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        const d = [],
            e = [];
        for (let g = 0; g <
            b.length; g++) {
            var f = Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                Tb: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                Tb: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
            };
            e.push(f)
        }
        return {
            nb: d,
            mb: e,
            mj: b
        }
    }

    function k_(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function l_(a, b, c, d) {
        b = Math.floor(((a - 8 * b - 8) / b * g_[d] + h_[d]) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            dn: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            dn: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function m_(a, b) {
        const c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor((c * g_.mobile_banner_image_sidebyside + h_.mobile_banner_image_sidebyside) * b + 8 * b + 8)
        }
    };
    const n_ = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var o_ = class extends WV {
        j(a) {
            return Math.min(1200, Math.max(this.g, Math.round(a)))
        }
    };

    function p_(a, b) {
        q_(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal") return new VV(9, new o_(a, Math.floor(a * 2.189)));
        if (T(yw)) {
            var c = Rb();
            var d = U(zw);
            var e = U(xw),
                f = U(ww);
            a < 468 ? c ? (a = m_(a, d), d = {
                Pb: a.width,
                Nb: a.height,
                mb: 1,
                nb: d,
                ub: "mobile_banner_image_sidebyside"
            }) : (a = l_(a, 1, d, "image_sidebyside"), d = {
                Pb: a.width,
                Nb: a.height,
                mb: 1,
                nb: d,
                ub: "image_sidebyside"
            }) : (d = k_(a), e === 1 && (d.height = Math.floor(d.height * .5)), d = {
                Pb: d.width,
                Nb: d.height,
                mb: f,
                nb: e,
                ub: "image_stacked"
            })
        } else d = Rb(), a < 468 ? d ? (d = m_(a,
            12), d = {
            Pb: d.width,
            Nb: d.height,
            mb: 1,
            nb: 12,
            ub: "mobile_banner_image_sidebyside"
        }) : (d = k_(a), d = {
            Pb: d.width,
            Nb: d.height,
            mb: 1,
            nb: 13,
            ub: "image_sidebyside"
        }) : (d = k_(a), d = {
            Pb: d.width,
            Nb: d.height,
            mb: 4,
            nb: 2,
            ub: "image_stacked"
        });
        r_(b, d);
        return new VV(9, new o_(d.Pb, d.Nb))
    }

    function s_(a, b) {
        q_(a, b); {
            const f = j_({
                nb: b.google_content_recommendation_rows_num,
                mb: b.google_content_recommendation_columns_num,
                ub: b.google_content_recommendation_ui_type
            });
            if (f.Tb) a = {
                Pb: 0,
                Nb: 0,
                mb: 0,
                nb: 0,
                ub: "image_stacked",
                Tb: f.Tb
            };
            else {
                var c = f.mj.length === 2 && a >= 468 ? 1 : 0;
                var d = f.mj[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = i_[d];
                let g = f.mb[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.nb[c];
                a = l_(a, e, c, d);
                a = {
                    Pb: a.width,
                    Nb: a.height,
                    mb: e,
                    nb: c,
                    ub: d
                }
            }
        }
        if (a.Tb) throw new $B(a.Tb);
        r_(b, a);
        return new VV(9,
            new o_(a.Pb, a.Nb))
    }

    function q_(a, b) {
        if (a <= 0) throw new $B(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function r_(a, b) {
        a.google_content_recommendation_ui_type = b.ub;
        a.google_content_recommendation_columns_num = b.mb;
        a.google_content_recommendation_rows_num = b.nb
    };
    var t_ = class extends WV {
        j() {
            return this.g
        }
        l(a, b, c) {
            Qz(a, c);
            c.style.height = `${this.height()}px`;
            b.rpe = !0
        }
    };

    function u_(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function v_(a, b) {
        var c = w_.slice(0);
        const d = c.length;
        let e = null;
        for (let f = 0; f < d; ++f) {
            const g = c[f];
            if (a(g)) {
                if (b == null || b(g)) return g;
                e === null && (e = g)
            }
        }
        return e
    };
    var x_ = [new f_(970, 90, 2), new f_(728, 90, 2), new f_(468, 60, 2), new f_(336, 280, 1), new f_(320, 100, 2), new f_(320, 50, 2), new f_(300, 600, 4), new f_(300, 250, 1), new f_(250, 250, 1), new f_(234, 60, 2), new f_(200, 200, 1), new f_(180, 150, 1), new f_(160, 600, 4), new f_(125, 125, 1), new f_(120, 600, 4), new f_(120, 240, 4), new f_(120, 120, 1, !0)],
        w_ = [x_[6], x_[12], x_[3], x_[0], x_[7], x_[14], x_[1], x_[8], x_[10], x_[4], x_[15], x_[2], x_[11], x_[5], x_[13], x_[9], x_[16]];

    function y_(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            Va: a,
            ya: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || z_(b) || e.google_ad_resize ? (b = Kz(a, c, d, e), c = b !== !0 ? {
            Va: a,
            ya: b
        } : {
            Va: ss(c) || a,
            ya: !0
        }) : c = {
            Va: a,
            ya: 2
        };
        const {
            Va: f,
            ya: g
        } = c;
        return g !== !0 ? {
            Va: a,
            ya: g
        } : d.parentElement ? {
            Va: f,
            ya: g
        } : {
            Va: a,
            ya: g
        }
    }

    function A_(a, b, c, d, e) {
        const {
            Va: f,
            ya: g
        } = fC(247, () => y_(a, b, c, d, e));
        var h = g === !0;
        const k = Nd(d.style.width),
            l = Nd(d.style.height),
            {
                Ob: m,
                tb: n,
                nc: p,
                kj: t
            } = B_(f, b, c, d, e, h);
        h = C_(b, p);
        var u;
        const B = (u = Rz(d, c, "marginLeft")) ? `${u}px` : "",
            F = (u = Rz(d, c, "marginRight")) ? `${u}px` : "";
        u = Tz(d, c) || "";
        return new VV(h, m, p, null, t, g, n, B, F, l, k, u)
    }

    function z_(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function B_(a, b, c, d, e, f) {
        b = D_(c, a, b);
        let g;
        var h = !1;
        let k = !1;
        var l = ss(c) < 488;
        if (l) {
            g = Dz(d, c);
            var m = Wz(d, c);
            h = !m && g;
            k = m && g
        }
        m = [Uz(a), e_(b)];
        T(Ww) || m.push(Vz(l, c, d, k));
        e.google_max_responsive_height != null && m.push(Xz(e.google_max_responsive_height));
        l = [u => !u.A];
        if (h || k) h = Yz(c, d), l.push(Xz(h));
        const n = v_(u_(m), u_(l));
        if (!n) throw new $B(`No slot size for availableWidth=${a}`);
        const {
            Ob: p,
            tb: t
        } = fC(248, () => {
            var u;
            a: if (f) {
                if (e.gfwrnh && (u = Nd(e.gfwrnh))) {
                    u = {
                        Ob: new t_(a, u),
                        tb: !0
                    };
                    break a
                }
                if (e.google_resizing_allowed ||
                    e.google_full_width_responsive === "true") u = Infinity;
                else {
                    u = d;
                    let F = Infinity;
                    do {
                        var B = Rz(u, c, "height");
                        B && (F = Math.min(F, B));
                        (B = Rz(u, c, "maxHeight")) && (F = Math.min(F, B))
                    } while (u.parentElement && (u = u.parentElement) && u.tagName !== "HTML");
                    u = F
                }!(T(Nw) && u <= a * 2) && (u = Math.min(a, u), u < a * .5 || u < 100) && (u = a);
                u = {
                    Ob: new t_(a, Math.floor(u)),
                    tb: u < a ? 102 : !0
                }
            } else u = {
                Ob: n,
                tb: 100
            };
            return u
        });
        return e.google_ad_layout === "in-article" ? {
            Ob: E_(a, c, d, p, e),
            tb: !1,
            nc: b,
            kj: g
        } : {
            Ob: p,
            tb: t,
            nc: b,
            kj: g
        }
    }

    function C_(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function D_(a, b, c) {
        if (c === "auto") c = Math.min(1200, ss(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (const d in Cz) c.indexOf(d) !== -1 && (b |= Cz[d])
        }
        return b
    }

    function E_(a, b, c, d, e) {
        const f = e.google_ad_height || Rz(c, b, "height");
        b = $V(a, b, c, f, e).size();
        return b.g * b.height() > a * d.height() ? new f_(b.g, b.height(), 1) : d
    };

    function F_(a, b, c, d, e) {
        var f;
        (f = ss(b)) ? ss(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, Qz(b, c), f = {
            Va: f,
            ya: !0
        }) : f = {
            Va: a,
            ya: 5
        } : f = {
            Va: a,
            ya: 4
        }: f = {
            Va: a,
            ya: 10
        };
        const {
            Va: g,
            ya: h
        } = f;
        if (h !== !0 || a === g) return new VV(12, new WV(a, d), null, null, !0, h, 100);
        const {
            Ob: k,
            tb: l,
            nc: m
        } = B_(g, "auto", b, c, e, !0);
        return new VV(1, k, m, 2, !0, h, l)
    };

    function G_(a) {
        const b = a.google_ad_format;
        if (b === "autorelaxed") {
            a: {
                if (a.google_content_recommendation_ui_type !== "pedestal")
                    for (const c of n_)
                        if (a[c] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (z_(b)) return 1;
        if (b === "link") return 4;
        if (b === "fluid") return a.google_ad_layout === "in-article" ? (H_(a), 1) : 8;
        if (a.google_reactive_ad_format === 27) return H_(a), 1
    }

    function I_(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && Rz(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = J_(a, f, b, c, d)) ? e : A_(f, c.google_ad_format, d, b, c);
        e.size().l(d, c, b);
        e.nc != null && (c.google_responsive_formats = e.nc);
        e.F != null && (c.google_safe_for_responsive_override = e.F);
        e.ya != null && (e.ya === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.ya));
        e.tb != null && e.tb !== !0 && (c.gfwrnher = e.tb);
        d = e.l || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.j || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().j(f);
        const g = e.size().height();
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        f = `${h.j(f)}x${h.height()}`;
        c.google_ad_format = f;
        c.google_responsive_auto_format = e.J;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.ya === !0 && (c.gfwrnh = `${e.size().height()}px`);
        e.B != null && (c.gfwroml = e.B);
        e.A != null && (c.gfwromr = e.A);
        e.j != null &&
            (c.gfwroh = e.j);
        e.l != null && (c.gfwrow = e.l);
        e.D != null && (c.gfwroz = e.D);
        f = Ad(window) || window;
        rT(f.location, "google_responsive_dummy_ad") && (Pa([1, 2, 3, 4, 5, 6, 7, 8], e.J) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${UV}>window.top.postMessage('${f}', '*'); 
          </${UV}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height(), b.style.height = `${a}px`)
    }

    function J_(a, b, c, d, e) {
        const f = d.google_ad_height || Rz(c, e, "height") || 0;
        switch (a) {
            case 5:
                const {
                    Va: g,
                    ya: h
                } = fC(247, () => y_(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && Qz(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return p_(g, d);
            case 9:
                return s_(b, d);
            case 8:
                return $V(b, e, c, f, d);
            case 10:
                return F_(b, e, c, f, d)
        }
    }

    function H_(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function K_(a, b) {
        a.google_resizing_allowed = !0;
        a.ovlp = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };
    var L_ = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function M_(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };

    function N_(a, b) {
        var c = Ad(b);
        if (c) {
            c = ss(c);
            const d = Dd(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function O_(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            default:
                return b
        }
    }

    function P_(a, b) {
        if (a = Em(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else return b.google_ad_intent_query ? 17 : 12
    };

    function Q_(a, b) {
        if (!Iz(b, a)) return () => {};
        a = R_(b, a);
        if (!a) return () => {};
        const c = qJ();
        b = cc(b);
        const d = {
            Nc: a,
            I: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => Ta(c, d)
    }

    function R_(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !Zz.test(a.className);) a = a.parentElement;
        return a
    }

    function S_(a, b) {
        for (let c = 0; c < a.childNodes.length; c++) {
            const d = {},
                e = a.childNodes[c];
            Ez(e.style, d);
            if (d.google_ad_width == b.google_ad_width && d.google_ad_height == b.google_ad_height) return e
        }
        return null
    }

    function T_(a, b) {
        a.style.display = b ? "inline-block" : "none";
        const c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function U_(a, b, c) {
        const d = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.j != d) {
            a.j = d;
            a = qJ();
            for (const e of a)
                if (e.Nc.offsetWidth != e.offsetWidth || e.I.google_full_width_responsive_allowed) e.offsetWidth = e.Nc.offsetWidth, fC(467, () => {
                    var f = e.Nc,
                        g = e.I;
                    const h = S_(f, g);
                    g.google_full_width_responsive_allowed && (f.style.marginLeft = g.gfwroml || "", f.style.marginRight = g.gfwromr || "", f.style.height = g.gfwroh ? `${g.gfwroh}px` : "", f.style.width = g.gfwrow ? `${g.gfwrow}px` : "", f.style.zIndex = g.gfwroz || "", delete g.google_full_width_responsive_allowed);
                    delete g.google_ad_format;
                    delete g.google_ad_width;
                    delete g.google_ad_height;
                    delete g.google_content_recommendation_ui_type;
                    delete g.google_content_recommendation_rows_num;
                    delete g.google_content_recommendation_columns_num;
                    if (f.getAttribute("src")) {
                        var k = f.getAttribute("src") || "",
                            l = Dn(k, "client");
                        l && (g.google_ad_client = O_("google_ad_client", l));
                        (k = Dn(k, "host")) && (g.google_ad_host = O_("google_ad_host", k))
                    }
                    for (var m of f.attributes) /data-/.test(m.name) && (k = Fb(m.name.replace("data-matched-content", "google_content_recommendation").replace("data",
                        "google").replace(/-/g, "_")), g.hasOwnProperty(k) || (l = O_(k, m.value), l !== null && (g[k] = l)));
                    if (b.document && b.document.body && !G_(g) && !g.google_reactive_ad_format && !g.google_ad_intent_query && (l = parseInt(f.style.width, 10), k = N_(f, b), k > 0 && l > k)) {
                        m = parseInt(f.style.height, 10);
                        l = !!L_[l + "x" + m];
                        let n = k;
                        if (l) {
                            const p = M_(k, m);
                            if (p) n = p, g.google_ad_format = p + "x" + m + "_0ads_al";
                            else throw new $B("No slot size for availableWidth=" + k);
                        }
                        g.google_ad_resize = !0;
                        g.google_ad_width = n;
                        l || (g.google_ad_format = null, g.google_override_format = !0);
                        k = n;
                        f.style.width = `${k}px`;
                        K_(g, 4)
                    }
                    if (T(Aw) || ss(b) < 488) {
                        k = Ad(b) || b;
                        m = f.offsetWidth || Rz(f, b, "width") || g.google_ad_width || 0;
                        l = g.google_ad_client;
                        if (k = rT(k.location, "google_responsive_slot_preview") || hW(k, c, l)) b: if (g.google_reactive_ad_format || g.google_ad_resize || G_(g) || Fz(f, g)) k = !1;
                            else {
                                for (k = f; k; k = k.parentElement) {
                                    l = Dd(k, b);
                                    if (!l) {
                                        g.gfwrnwer = 18;
                                        k = !1;
                                        break b
                                    }
                                    if (!Pa(["static", "relative"], l.position)) {
                                        g.gfwrnwer = 17;
                                        k = !1;
                                        break b
                                    }
                                }
                                if (!T(Xw) && (k = U(Lw), m = Jz(b, f, m, k, g), m !== !0)) {
                                    g.gfwrnwer = m;
                                    k = !1;
                                    break b
                                }
                                k =
                                    b === b.top ? !0 : !1
                            }
                        k ? (K_(g, 1), m = !0) : m = !1
                    } else m = !1;
                    if (k = G_(g)) I_(k, f, g, b, m);
                    else {
                        if (Fz(f, g)) {
                            if (m = Dd(f, b)) f.style.width = m.width, f.style.height = m.height, Ez(m, g);
                            g.google_ad_width || (g.google_ad_width = f.offsetWidth);
                            g.google_ad_height || (g.google_ad_height = f.offsetHeight);
                            g.google_loader_features_used = 256;
                            g.google_responsive_auto_format = P_(b, g)
                        } else Ez(f.style, g);
                        b.location && b.location.hash === "#gfwmrp" || g.google_responsive_auto_format === 12 && g.google_full_width_responsive === "true" ? I_(10, f, g, b, !1) : Math.random() <
                            .01 && g.google_responsive_auto_format === 12 && (m = Kz(f.offsetWidth || parseInt(f.style.width, 10) || g.google_ad_width, b, f, g), m !== !0 ? (g.efwr = !1, g.gfwrnwer = m) : g.efwr = !0)
                    }
                    m = S_(f, g);
                    !m && h && f.childNodes.length == 1 ? (T_(h, !1), g.google_reactive_ad_format = 16, g.google_ad_section = "responsive_resize", tU(f, g, b)) : m && h && m != h && (T_(h, !1), T_(m, !0))
                })
        }
    }
    var V_ = class extends O {
        constructor() {
            super(...arguments);
            this.j = null
        }
        init(a, b) {
            const c = dJ();
            if (!iJ(c, 27, !1)) {
                jJ(c, 27, !0);
                this.j = a.innerHeight >= a.innerWidth ? 1 : 2;
                var d = () => {
                    U_(this, a, b)
                };
                ql(a, "resize", d);
                jt(this, () => {
                    rl(a, "resize", d)
                })
            }
        }
    };
    var W_ = Y(function(a, b, c, d, e) {
        b && (d.push(Q_(b, c)), M(V_).init(b, e));
        return {}
    }, {
        id: 1417,
        H: {}
    });

    function X_(a) {
        a.A = a.D;
        a.F.style.transition = "height 500ms";
        a.Ia.style.transition = "height 500ms";
        a.j.style.transition = "height 500ms";
        Y_(a)
    }

    function Z_(a, b) {
        UR(a.j.contentWindow, "sth", {
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b
        }, "*")
    }

    function Y_(a) {
        const b = `rect(0px, ${a.j.width}px, ${a.A}px, 0px)`;
        a.j.style.clip = b;
        a.Ia.style.clip = b;
        a.j.setAttribute("height", a.A.toString());
        a.j.style.height = `${a.A}px`;
        a.Ia.setAttribute("height", a.A.toString());
        a.Ia.style.height = `${a.A}px`;
        a.F.style.height = `${a.A}px`
    }

    function $_(a, b) {
        b = Md(b.r_nh);
        a.D = b == null ? 0 : b;
        if (a.D <= 0) return "1";
        a.K = jl(a.F).y;
        a.G = Ps(a.l);
        if (a.K + a.A < a.G) return "2";
        if (a.K > ws(a.l) - a.l.innerHeight) return "3";
        b = a.G;
        a.j.setAttribute("height", a.D.toString());
        a.j.style.height = `${a.D}px`;
        a.Ia.style.overflow = "hidden";
        a.F.style.position = "relative";
        a.F.style.transition = "height 100ms";
        a.Ia.style.transition = "height 100ms";
        a.j.style.transition = "height 100ms";
        b = Math.min(b + a.l.innerHeight - a.K, a.A);
        cl(a.Ia, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.j.width}px, ${b}px, 0px)`;
        cl(a.j, {
            clip: b
        });
        cl(a.Ia, {
            clip: b
        });
        return "0"
    }
    var a0 = class extends LZ {
        constructor(a, b) {
            super(a.P, b);
            this.bb = this.Ub = !1;
            this.la = this.G = this.D = 0;
            this.Ia = a.ea;
            this.F = this.Ia.parentElement && this.Ia.parentElement.classList.contains("adsbygoogle") ? this.Ia.parentElement : this.Ia;
            this.A = parseInt(this.Ia.style.height, 10);
            this.lk = this.A / 5;
            this.K = jl(this.F).y;
            this.jk = Cb(gC(651, () => {
                this.K = jl(this.F).y;
                var c = this.G;
                this.G = Ps(this.l);
                this.A < this.D ? (c = this.G - c, c > 0 && (this.la += c, this.la >= this.lk ? (X_(this), Z_(this, this.D)) : (this.A = Math.min(this.D, this.A + c), Z_(this,
                    c), Y_(this)))) : rl(this.l, "scroll", this.T)
            }), this);
            this.T = () => {
                var c = this.jk;
                um.requestAnimationFrame ? um.requestAnimationFrame(c) : c()
            }
        }
        V(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = Rs(b);
                this.Ub || (this.Ub = !0, b = $_(this, b), b === "0" && ql(this.l, "scroll", this.T, nl), UR(c.target, "sth", {
                    msg_type: "expand-on-scroll-result",
                    eos_success: b === "0"
                }, "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.bb || (this.bb = !0, X_(this), rl(this.l, "scroll", this.T))
            }
        }
        g() {
            this.T && rl(this.l, "scroll", this.T, nl);
            super.g()
        }
    };
    var b0 = Y(function(a, b) {
        const c = a.ga,
            d = a.Ha;
        a = a.za;
        b.P && d && a(new a0(b, c));
        return {}
    }, {
        id: 1428,
        H: {}
    });

    function c0() {
        var a = new d0;
        var b = new zv;
        b = hi(b, 2, 4);
        b = hi(b, 8, 1);
        var c = new Fu;
        c = fi(c, 7, "#dpId");
        b = y(b, 1, c);
        return Kh(a, 3, zv, b)
    }
    var d0 = class extends H {},
        e0 = xk(d0);

    function f0(a, b) {
        return C(a, 10).replace("TERM", b)
    };
    var g0 = class {
        constructor(a) {
            this.ec = a.ec ? ? [];
            this.Lg = !!a.Lg;
            this.Ng = !!a.Ng;
            this.Mg = !!a.Mg;
            this.Cf = a.Cf ? ? 250;
            this.Bf = a.Bf ? ? 300;
            this.ig = a.ig ? ? 15E3;
            this.hg = a.hg ? ? 15E3;
            this.jg = a.jg ? ? 0;
            this.wf = a.wf ? ? 0;
            this.xf = a.xf ? ? 670;
            this.Sc = !!a.Sc;
            this.Bh = a.Bh ? ? 9;
            this.uf = a.uf ? ? 0;
            this.Jd = !!a.Jd;
            this.Af = a.Af ? ? 0;
            this.Cd = a.Cd ? ? 0;
            this.Fh = new Set(a.Fh ? ? []);
            this.Lf = !!a.Lf;
            this.Mf = !!a.Mf;
            this.Kc = a.Kc ? ? 0;
            this.Ne = !!a.Ne;
            this.mh = a.mh ? ? 0;
            this.Gb = a.Gb ? ? 0;
            this.Th = !!a.Th;
            this.Vg = !!a.Vg;
            this.Ug = !!a.Ug;
            this.Xg = !!a.Xg;
            this.Wg = !!a.Wg;
            this.Yg = !!a.Yg;
            this.di = !!a.di
        }
    };

    function h0(a, b, c, d, e, f, g, h, k, l) {
        const m = k(999, a.top, n => {
            n.data.action === "init" && n.data.adChannel === "ShoppingVariant" && i0(a, b, d, c, e, f, g, h, k, l)
        });
        g(() => {
            a.top.removeEventListener("message", m)
        })
    }

    function i0(a, b, c, d, e, f, g, h, k, l) {
        A(f, 13) || kE(c, d, e);
        if (l) {
            const m = k(1066, a, n => {
                if (n = SO(n)) b.height = `${Math.ceil(n.height+26)}px`
            });
            g(() => void a.removeEventListener("message", m))
        } else {
            const m = b.contentDocument.documentElement,
                n = new ResizeObserver(() => {
                    b.height = `${Math.ceil(m.offsetHeight+26)}px`
                });
            n.observe(m);
            const p = h(1066, a, () => {
                const t = m.offsetHeight;
                t && (b.height = `${t+26}px`)
            }, 1E3);
            g(() => {
                n.disconnect();
                a.clearInterval(p)
            })
        }
    }
    var j0 = class {
        constructor(a) {
            this.Yc = a
        }
        tg(a) {
            const b = a.C.document.createElement("iframe"),
                c = a.W,
                d = T(Ix),
                e = new lE({
                    O: b,
                    qb: C(c, 16),
                    hd: "anno-cse",
                    Hb: this.Yc.replace("ca", "partner"),
                    Ee: "ShoppingVariant",
                    location: a.C.location,
                    language: C(c, 7),
                    xd: f0(c, a.searchTerm),
                    sb: a.M.ec.filter(f => f !== 42),
                    Nd: d,
                    Mc: vz(ey),
                    re: !0,
                    ze: void 0,
                    Md: !0
                });
            e.init();
            h0(a.C, b, a.searchTerm, e, a.rsToken, c, a.yb, a.Qc, a.Wb, d);
            return b
        }
    };

    function k0(a) {
        var b = {},
            c = a.searchTerm;
        const d = a.ql;
        var e = a.Yc,
            f = a.hh;
        const g = a.Se,
            h = a.nk,
            k = a.fm,
            l = a.vn,
            m = a.Um,
            n = a.ym,
            p = a.zm;
        var t = a.Bm,
            u = a.pk;
        const B = a.Im,
            F = a.rsToken,
            R = b && b.Vd;
        a = b && b.Wk;
        b = AD;
        f = (l ? "" : '<link href="https://fonts.googleapis.com/css?family=Google+Sans:500" rel="stylesheet"' + (R ? ' nonce="' + V(cE(R)) + '"' : "") + ">") + "<style" + (R ? ' nonce="' + V(cE(R)) + '"' : "") + ">#gda-search-term {height: 24px; font-size: 18px; font-weight: 500; color: #202124; font-family: 'Google Sans'; padding-bottom: 6px;" + (k ?
            "padding-right: 16px;" : "padding-left: 16px;") + "}#display-slot {display: inline-block; height: " + W(h) + "; width: " + W(g) + 'px;}</style><div id="gda-search-term">' + yD(c) + "</div>" + (p !== -1 ? "<script" + (a ? ' nonce="' + V(cE(a)) + '"' : "") + ">window[" + KD(LD(n)) + "] = " + KD(LD(p)) + ";\x3c/script>" : "") + (f !== "" ? '<meta name="google-adsense-platform-account" content="' + V(f) + '">' : "") + '<ins id="display-slot" class="adsbygoogle" data-ad-client="' + V(e) + '"></ins>' + (m ? "<script" + (a ? ' nonce="' + V(cE(a)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" :
            "") + (l ? "<script" + (a ? ' nonce="' + V(cE(a)) + '"' : "") + ">const el = document.querySelector('ins.adsbygoogle'); el.dir = 'ltr'; el.style.backgroundColor = 'lightblue'; el.style.fontSize = '25px'; el.style.textDecoration = 'none'; el.textContent = \"Loading display ads inside this slot for query = " + String(c).replace(MD, ND) + ' and " + "property code = ' + String(e).replace(MD, ND) + '";\x3c/script>' : "") + "<script" + (a ? ' nonce="' + V(cE(a)) + '"' : "") + ">top.postMessage({'action':'sgda-ready'}, top.location.origin);\x3c/script>";
        l ? e = "" : (c = '<script data-ad-intent-query="' + V(c) + '" data-ad-intent-qetid="' + V(d) + '"' + (B ? ' data-ad-intent-rs-token="' + V(F) + '"' : "") + ' data-page-url="', zD(t, rD) || zD(t, sD) ? t = String(t).replace(RD, SD) : uc(t) ? t = QD(vc(t)) : t instanceof pc ? t = QD(rc(t).toString()) : (t = String(t), t = $D.test(t) ? t.replace(RD, SD) : "about:invalid#zSoyz"), u = c + V(t) + '" data-ad-intents-format="' + V(u) + '" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=', e = encodeURIComponent(String(e)), OD.lastIndex = 0, e = OD.test(e) ?
            e.replace(OD, PD) : e, e = u + e + '" crossorigin="anonymous"' + (a ? ' nonce="' + V(cE(a)) + '"' : "") + ">\x3c/script>");
        return b(f + e)
    };
    var o0 = class {
        constructor(a, b, c, d) {
            this.Yc = a;
            this.hh = b;
            this.g = c;
            this.Dc = d
        }
        tg(a) {
            var b = k0({
                searchTerm: a.searchTerm,
                ql: a.Si || "",
                Yc: this.Yc,
                hh: this.hh ? ? "",
                Se: a.Se,
                nk: vz(a.Ca ? Wx : Ux).replace("<DH>", `${a.Qg}px`),
                fm: a.ja,
                vn: !!A(a.W, 13),
                Um: a.Jj ? ? !1,
                ym: "goog_pvsid",
                zm: this.g,
                Bm: this.Dc,
                pk: a.format,
                Im: T(dy),
                rsToken: a.rsToken
            });
            b = od("body", {
                dir: a.ja ? "rtl" : "ltr",
                lang: C(a.W, 7),
                style: "margin:0;height:100%;padding-top:0;overflow:hidden"
            }, vD(b));
            const c = a.C.document.createElement("iframe");
            r(c, {
                border: "0",
                width: "100%"
            });
            c.height = "24px";
            const d = T(Vx),
                e = new P(!0),
                f = a.Wb(999, a.C, g => {
                    if (g.data.action === "sgda-ready" && (g = c.contentDocument, g ? .body)) {
                        var h = c.contentWindow;
                        if (!d || h) {
                            var k = g.getElementById("display-slot");
                            if (k) {
                                var l = g.createElement("iframe"),
                                    m = d ? h : a.C,
                                    n = new MutationObserver((p, t) => {
                                        if (k.getAttribute("data-ad-status") === "unfilled") Pk(k);
                                        else if (T(cy) && k.getAttribute("data-ad-status") === "filled") e.g(!1), d && (l0(l, c, 0), l.remove()), l.contentDocument ? .body && (l.contentDocument.body.innerText = "");
                                        else if (k.getAttribute("data-ad-status") !==
                                            "filled") return;
                                        d ? e.X && l0(l, c, a.Qg) : l0(l, c);
                                        m0(m, l, c, a.yb, a.Qc, a.Wb, d);
                                        t.disconnect()
                                    });
                                n.observe(k, {
                                    attributes: !0,
                                    attributeFilter: ["data-ad-status"]
                                });
                                a.yb(() => void n.disconnect());
                                n0(m, this.Yc, l, a, d, e);
                                g.body.append(l)
                            }
                        }
                    }
                });
            a.yb(() => {
                a.C.removeEventListener("message", f)
            });
            c.srcdoc = Hc(b);
            return c
        }
    };

    function n0(a, b, c, d, e, f) {
        const g = new lE({
                O: c,
                qb: C(d.W, 16),
                hd: "anno-cse",
                Hb: b.replace("ca", "partner"),
                Ee: "ShoppingVariant",
                location: d.C.location,
                language: C(d.W, 7),
                xd: f0(d.W, d.searchTerm),
                sb: d.M.ec.filter(k => k !== 42),
                Nd: e,
                Mc: vz(ey),
                re: !0,
                ze: void 0,
                Md: !0,
                Sf: !0
            }),
            h = d.Wb(999, a, k => {
                k.data.action === "init" && k.data.adChannel === "ShoppingVariant" && (A(d.W, 13) || kE(g, d.searchTerm, d.rsToken))
            });
        g.init();
        b = () => {
            a.removeEventListener("message", h)
        };
        d.yb(b);
        ut(f, !1, b)
    }

    function m0(a, b, c, d, e, f, g) {
        if (g) {
            const h = f(1066, a, k => {
                (k = SO(k)) && l0(b, c, k.height)
            });
            d(() => void a.removeEventListener("message", h))
        } else {
            f = b.contentDocument.documentElement;
            const h = new ResizeObserver(() => void l0(b, c));
            h.observe(f);
            const k = e(1066, a, () => void l0(b, c), 1E3);
            d(() => {
                h.disconnect();
                a.clearInterval(k)
            })
        }
    }

    function l0(a, b, c = a.contentDocument ? .documentElement ? .offsetHeight) {
        if (T(cy)) {
            if (c === void 0) return
        } else if (!c) return;
        const d = b.contentDocument ? .getElementById("display-slot") ? .offsetHeight ? ? 0;
        a.height = `${Math.ceil(c+26)}px`;
        b.height = `${Math.ceil(c+26+d)}px`
    };

    function p0(a, b, c, d, e, f) {
        return {
            W: q0(a) ? ? Eh(b, YZ, 1),
            Dc: c,
            ef: d,
            params: r0(2, []),
            Rb: s0(2),
            M: new g0({ ...t0(e),
                Sc: !0
            }),
            jd: f
        }
    }

    function t0(a) {
        return {
            ec: a,
            Cf: U(My),
            Bf: U(Ly),
            xf: U(Ey),
            Fh: wz($x)
        }
    }

    function r0(a, b) {
        return {
            wordWindowSize: U(wy),
            sameSearchTermPerWindow: U(Ky),
            annotationsPerWindow: U(Iy),
            maximumAnnotationsPerPage: U(Jy),
            Ni: b,
            gi: U(Oy),
            nj: a === 2 ? 10 : 2
        }
    }

    function u0(a, b) {
        a = sB(LA([...b], a), a);
        if (a.length !== 0) return a.reduce((c, d) => c.Aa.g > d.Aa.g ? c : d)
    }

    function s0(a) {
        switch (a) {
            case 1:
                return 2;
            case 2:
                return 1;
            default:
                return 0
        }
    }

    function q0(a) {
        try {
            a = a ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
            if (!a) return null;
            const b = decodeURIComponent(a[1]);
            return ZZ(b)
        } catch (b) {
            return null
        }
    };

    function v0(a) {
        r(a, {
            border: "0",
            "box-shadow": "none",
            display: "inline",
            "float": "none",
            margin: "0",
            outline: "0",
            padding: "0"
        })
    }

    function w0(a, b) {
        b = a.document.createElement(b);
        fw(a, b);
        r(b, {
            color: "inherit",
            cursor: "inherit",
            direction: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-weight": "inherit",
            "text-align": "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit"
        });
        return b
    }

    function x0(a) {
        a.dataset.googleVignette = "false";
        a.dataset.googleInterstitial = "false"
    };
    async function y0(a, b) {
        await new Promise(c => void a.C.setTimeout(c, 0));
        a.j = a.g.va(b) + a.l
    }
    var z0 = class {
        constructor(a, b) {
            var c = U(xy);
            this.C = a;
            this.g = b;
            this.l = c;
            this.j = b.va(2) + c
        }
    };
    var A0 = class {
            constructor(a) {
                this.performance = a
            }
            va() {
                return this.performance.now()
            }
        },
        B0 = class {
            va() {
                return Date.now()
            }
        };
    const C0 = [255, 255, 255];

    function D0(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), d.length > 4 ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if (a === "transparent" || a === "") return [0, 0, 0, 0];
        throw Error(`Invalid color: ${a}`);
    }

    function E0(a) {
        var b = getComputedStyle(a);
        if (b.backgroundImage !== "none") return null;
        b = D0(b.backgroundColor);
        var c = F0(b);
        if (c) return c;
        a = (a = a.parentElement) ? E0(a) : C0;
        if (!a) return null;
        c = b[3];
        return [Math.round(c * b[0] + (1 - c) * a[0]), Math.round(c * b[1] + (1 - c) * a[1]), Math.round(c * b[2] + (1 - c) * a[2])]
    }

    function F0(a) {
        return a[3] === 1 ? [a[0], a[1], a[2]] : null
    };

    function G0(a, b) {
        const c = b.Ca === b.ja;
        var d = H0(a, b, c);
        if (!d) return null;
        d = d.position.cf();
        a = I0(a, d, b, function(f) {
            f = f.getBoundingClientRect();
            return c ? b.da - f.right : f.left
        });
        if (!a || a - 16 < 200) return null;
        const e = b.da;
        return {
            kb: c ? e - a : 16,
            zb: c ? 16 : e - a,
            sa: d
        }
    }

    function J0(a, b) {
        const c = ss(a),
            d = ts(a);
        return nH(new sH(a), new Yk(d - b.sa - 50, c - b.zb, d - b.sa, b.kb)).size > 0
    }

    function H0(a, b, c) {
        b = Math.floor(b.ha * .3);
        return b < 66 ? null : vH(a, {
            Id: c ? BH({
                sa: 16,
                zb: 16
            }) : zH({
                sa: 16,
                kb: 16
            }),
            Ah: b - 66,
            Vc: 200,
            Gh: 50,
            vf: b,
            Bc: 16
        }, [a.document.body]).rg
    }

    function I0(a, b, c, d) {
        a = c.Ca ? K0(a, b, c) : L0(a, b, c);
        b = c.da;
        let e = c.Ca ? b : b * .35;
        a.forEach(f => {
            e = Math.min(e, d(f))
        });
        return e < 16 ? null : e - 16
    }

    function K0(a, b, c) {
        const d = c.ha;
        return nH(new sH(a), new Yk(d - b - 50, c.da - 16, d - b, 16))
    }

    function L0(a, b, c) {
        const d = c.ha,
            e = c.da;
        c = c.ja;
        return nH(new sH(a), new Yk(d - b - 50, (c ? e * .35 : e) - 16, d - b, (c ? 16 : e * .65) + 16))
    }

    function M0(a, b, c) {
        const d = a.ja;
        return {
            kb: d ? N0(a, b, c) : c,
            zb: d ? c : N0(a, b, c),
            sa: 16
        }
    }

    function N0(a, b, c) {
        const d = a.da;
        return a.Ca ? d - b + 16 : Math.max(d - c - d * .35, d - b + 16)
    }

    function O0(a, b) {
        const c = b.ja,
            d = b.da;
        return [...(b.Ca ? K0(a, 16, b) : L0(a, 16, b))].map(e => new uH(c ? d - e.getBoundingClientRect().right : e.getBoundingClientRect().left, c ? d - e.getBoundingClientRect().left : e.getBoundingClientRect().right)).sort((e, f) => e.start - f.start)
    };

    function P0(a, b, c) {
        a = Q0(a, "100 -1000 840 840", `calc(${b} - 2px)`, b, R0[c]);
        r(a, {
            color: "inherit",
            cursor: "inherit",
            fill: "currentcolor"
        });
        return a
    }

    function S0(a, b) {
        a = T0(a, "20px", "#1A73E8", b);
        a.classList.add("google-anno-sa-intent-icon");
        return a
    }

    function U0(a, b) {
        a = Q0(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        r(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: "15px",
            transform: "none",
            fill: "#1A73E8"
        });
        a.role = "button";
        a.ariaLabel = b;
        a.tabIndex = 0;
        return a
    }
    const R0 = {
        [0]: "M503-104q-24 24-57 24t-57-24L103-390q-23-23-23-56.5t23-56.5l352-353q11-11 26-17.5t32-6.5h286q33 0 56.5 23.5T879-800v286q0 17-6.5 32T855-456L503-104Zm196-536q25 0 42.5-17.5T759-700q0-25-17.5-42.5T699-760q-25 0-42.5 17.5T639-700q0 25 17.5 42.5T699-640ZM446-160l353-354v-286H513L160-446l286 286Zm353-640Z",
        [1]: "m274-274-128-70 42-42 100 14 156-156-312-170 56-56 382 98 157-155q17-17 42.5-17t42.5 17q17 17 17 42.5T812-726L656-570l98 382-56 56-170-312-156 156 14 100-42 42-70-128Z",
        [2]: "M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z",
        [3]: "M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm200-500 54-18 16-54q-32-48-77-82.5T574-786l-54 38v56l160 112Zm-400 0 160-112v-56l-54-38q-54 17-99 51.5T210-652l16 54 54 18Zm-42 308 46-4 30-54-58-174-56-20-40 30q0 65 18 118.5T238-272Zm242 112q26 0 51-4t49-12l28-60-26-44H378l-26 44 28 60q24 8 49 12t51 4Zm-90-200h180l56-160-146-102-144 102 54 160Zm332 88q42-50 60-103.5T800-494l-40-28-56 18-58 174 30 54 46 4Z",
        [4]: "M120-680v-160l160 80-160 80Zm600 0v-160l160 80-160 80Zm-280-40v-160l160 80-160 80Zm0 640q-76-2-141.5-12.5t-114-26.5Q136-135 108-156t-28-44v-360q0-25 31.5-46.5t85.5-38q54-16.5 127-26t156-9.5q83 0 156 9.5t127 26q54 16.5 85.5 38T880-560v360q0 23-28 44t-76.5 37q-48.5 16-114 26.5T520-80v-160h-80v160Zm40-440q97 0 167.5-11.5T760-558q0-5-76-23.5T480-600q-128 0-204 18.5T200-558q42 15 112.5 26.5T480-520ZM360-166v-154h240v154q80-8 131-23.5t69-27.5v-271q-55 22-138 35t-182 13q-99 0-182-13t-138-35v271q18 12 69 27.5T360-166Zm120-161Z",
        [5]: "M200-80q-33 0-56.5-23.5T120-160v-480q0-33 23.5-56.5T200-720h80q0-83 58.5-141.5T480-920q83 0 141.5 58.5T680-720h80q33 0 56.5 23.5T840-640v480q0 33-23.5 56.5T760-80H200Zm0-80h560v-480H200v480Zm280-240q83 0 141.5-58.5T680-600h-80q0 50-35 85t-85 35q-50 0-85-35t-35-85h-80q0 83 58.5 141.5T480-400ZM360-720h240q0-50-35-85t-85-35q-50 0-85 35t-35 85ZM200-160v-480 480Z",
        [6]: "M80-160v-120h80v-440q0-33 23.5-56.5T240-800h600v80H240v440h240v120H80Zm520 0q-17 0-28.5-11.5T560-200v-400q0-17 11.5-28.5T600-640h240q17 0 28.5 11.5T880-600v400q0 17-11.5 28.5T840-160H600Zm40-120h160v-280H640v280Zm0 0h160-160Z",
        [7]: "M400-40v-80H200q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h200v-80h80v880h-80ZM200-240h200v-240L200-240Zm360 120v-360l200 240v-520H560v-80h200q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H560Z",
        [8]: "M300-240q25 0 42.5-17.5T360-300q0-25-17.5-42.5T300-360q-25 0-42.5 17.5T240-300q0 25 17.5 42.5T300-240Zm0-360q25 0 42.5-17.5T360-660q0-25-17.5-42.5T300-720q-25 0-42.5 17.5T240-660q0 25 17.5 42.5T300-600Zm180 180q25 0 42.5-17.5T540-480q0-25-17.5-42.5T480-540q-25 0-42.5 17.5T420-480q0 25 17.5 42.5T480-420Zm180 180q25 0 42.5-17.5T720-300q0-25-17.5-42.5T660-360q-25 0-42.5 17.5T600-300q0 25 17.5 42.5T660-240Zm0-360q25 0 42.5-17.5T720-660q0-25-17.5-42.5T660-720q-25 0-42.5 17.5T600-660q0 25 17.5 42.5T660-600ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z",
        [9]: "M160-80v-440H80v-240h208q-5-9-6.5-19t-1.5-21q0-50 35-85t85-35q23 0 43 8.5t37 23.5q17-16 37-24t43-8q50 0 85 35t35 85q0 11-2 20.5t-6 19.5h208v240h-80v440H160Zm400-760q-17 0-28.5 11.5T520-800q0 17 11.5 28.5T560-760q17 0 28.5-11.5T600-800q0-17-11.5-28.5T560-840Zm-200 40q0 17 11.5 28.5T400-760q17 0 28.5-11.5T440-800q0-17-11.5-28.5T400-840q-17 0-28.5 11.5T360-800ZM160-680v80h280v-80H160Zm280 520v-360H240v360h200Zm80 0h200v-360H520v360Zm280-440v-80H520v80h280Z",
        [10]: "m456-200 174-340H510v-220L330-420h126v220Zm24 120q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"
    };

    function T0(a, b, c, d) {
        a = Q0(a, "0 -960 960 960", b, b, R0[d]);
        r(a, {
            fill: c,
            cursor: "inherit"
        });
        return a
    }

    function Q0(a, b, c, d, e) {
        const f = a.document.createElementNS("http://www.w3.org/2000/svg", "path");
        f.setAttribute("d", e);
        e = a.document.createElementNS("http://www.w3.org/2000/svg", "svg");
        fw(a, e);
        e.setAttribute("viewBox", b);
        e.setAttribute("width", c);
        e.setAttribute("height", d);
        v0(e);
        e.appendChild(f);
        return e
    };

    function V0(a, b, c, d) {
        const e = document.createElement("SPAN");
        fw(a, e);
        e.id = "gda";
        e.appendChild(U0(a, C(b.W, 18)));
        x0(e);
        W0(b, 1064, e, f => {
            d ? .();
            Pk(c);
            f.preventDefault();
            f.stopImmediatePropagation();
            return !1
        });
        return e
    }

    function X0(a, b, c, d, e) {
        const f = document.createElement("SPAN");
        fw(a, f);
        v0(f);
        r(f, {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (b.ja(), "50px"),
            right: b.ja() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: "#1A73E8",
            cursor: "pointer",
            transition: "width 5s"
        });
        b.Ca || r(f, {
            "justify-content": ""
        });
        const g = S0(a, b.g.get(d.gb) || 0),
            h = document.createElement("SPAN");
        r(h, {
            display: "inline-block",
            cursor: "inherit"
        });
        r(h, {
            "margin-left": b.ja() ? "6px" : "4px",
            "margin-right": b.ja() ? "4px" : "6px",
            "margin-top": "12px"
        });
        f.appendChild(h);
        h.appendChild(g);
        c.classList ? .add("google-anno-sa-qtx", "google-anno-skip");
        c.tabIndex = 0;
        c.role = "link";
        c.ariaLive = "polite";
        Y0(c, d.gb, C(b.W, 19));
        r(c, {
            height: "40px",
            "align-items": "center",
            "line-height": "44px",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            "font-family": "Roboto",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: "#1A73E8"
        });
        x0(f);
        W0(b, 999, f, k => {
            k.preventDefault();
            if ((d.ui ? ? 0) + 800 <= b.va(28)) {
                k =
                    d.gb;
                const m = b.A.get(k) || "";
                var l = fq(dq(k), d.je);
                l = ci(l, 3, d.rf);
                l = b.Z.ed(l);
                b.Oa(1401, Z0(e, a, b, l, k, m, 2, b.M.Sc ? b.j.get(k) || "" : null))
            }
            return !1
        });
        f.appendChild(c);
        return f
    }

    function $0(a, b, c, d, e, f) {
        const g = document.createElement("div");
        fw(a, g);
        g.id = "google-anno-sa";
        g.dir = b.ja() ? "rtl" : "ltr";
        g.tabIndex = 0;
        r(g, {
            background: "#FFFFFF",
            "border-style": "solid",
            bottom: `${d.sa}px`,
            "border-radius": "16px",
            height: "50px",
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: `${d.kb}px`,
            right: `${d.zb}px`,
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        });
        r(g, {
            fill: "white"
        });
        d = document.createElement("SPAN");
        fw(a, d);
        r(d, {
            cursor: "inherit"
        });
        g.appendChild(X0(a, b, d, c, f));
        g.appendChild(V0(a, b, g, e));
        return g
    }

    function a1(a, b, c, d, e) {
        var f = c.getElementsByClassName("google-anno-sa-qtx")[0];
        f instanceof HTMLElement && (f.innerText = a.gb);
        if ((d.g.get(e) || 0) !== (d.g.get(a.gb) || 0)) {
            b = S0(b, d.g.get(a.gb) || 0);
            for (const g of c.getElementsByClassName("google-anno-sa-intent-icon")) g.replaceWith(b)
        }
        Y0(f, a.gb, C(d.W, 19));
        c = d.Z;
        d = c.lg;
        f = new Fp;
        f = ih(f, 2, Vf(a.je));
        a = gi(f, 4, a.gb);
        return d.call(c, a)
    }

    function b1(a, b, c, d, e) {
        if (J0(b, d)) return null;
        a.ui = c.va(27);
        d = $0(b, c, a, d, () => {
            a.g = !0;
            var f = c.Z,
                g = f.gg;
            var h = new Dp;
            h = ei(h, 3, a.je);
            h = gi(h, 2, a.gb);
            g.call(f, h)
        }, e);
        e = a1(a, b, d, c, a.gb);
        b.document.body.appendChild(d);
        return e
    }

    function c1(a, b, c, d, e, f, g, h) {
        if (!(a.g || a.gb === e && a.je === d && a.j === f)) {
            if (a.rf !== null) {
                var k = a.rf,
                    l = c.Z,
                    m = l.kg,
                    n = new Ep;
                k = di(n, 1, k);
                m.call(l, k)
            }
            l = a.gb;
            a.gb = e;
            a.je = d;
            a.j = f;
            A(c.W, 17) || (d = b.document.getElementById("google-anno-sa"), a.rf = d ? a1(a, b, d, c, l) : b1(a, b, c, g, h))
        }
    }
    var d1 = class {
        constructor() {
            this.gb = "";
            this.je = null;
            this.j = "";
            this.rf = null;
            this.g = !1;
            this.ui = null
        }
    };

    function Y0(a, b, c) {
        a.ariaLabel = c.replace("TERM", b)
    };

    function e1(a, b, c = null) {
        a.g >= a.l.length && (a.g = 0, a.A++);
        a.config.M.wf && a.A >= a.config.M.wf || (c ? ? a.j.g.X ? a.j.yb(() => void e1(a, b, !1)) : (c = a.l[a.g++], a.B = !1, c1(a.J, a.C, a.config, c.g, c.searchTerm, c.j, a.D, a.j), f1(a.config, 898, a.C, () => {
            e1(a, b)
        }, a.gi)))
    }
    var g1 = class {
        constructor(a, b, c, d) {
            var e = new d1;
            this.C = a;
            this.config = b;
            this.J = e;
            this.D = c;
            this.j = d;
            this.l = [];
            this.B = !0;
            this.A = this.g = 0;
            this.gi = b.params.gi
        }
    };
    class h1 {
        constructor(a, b, c) {
            this.g = a;
            this.searchTerm = b;
            this.j = c
        }
    };

    function i1(a) {
        return a.maximumAnnotationsPerPage > 0 && a.j.l >= a.maximumAnnotationsPerPage
    }
    var k1 = class {
        constructor(a, b, c, d) {
            this.sameSearchTermPerWindow = b;
            this.annotationsPerWindow = c;
            this.maximumAnnotationsPerPage = d;
            this.g = 0;
            this.j = new j1(a)
        }
    };

    function l1(a, b) {
        b -= a.B;
        for (const c of a.g.keys()) {
            const d = a.g.get(c);
            let e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.j -= e;
            e > 0 && a.g.set(c, d.slice(e))
        }
    }

    function m1(a, b, c) {
        let d = [];
        a.g.has(b) && (d = a.g.get(b));
        d.push(c);
        a.j++;
        a.g.set(b, d)
    }
    class j1 {
        constructor(a) {
            this.B = a;
            this.g = new Map;
            this.j = 0
        }
        get l() {
            return this.j
        }
    };

    function n1(a, b, c, d, e, f) {
        const g = w0(a, "div");
        g.classList.add("google-anno-skip", "google-anno-sc");
        d = a.getComputedStyle(d).fontSize || "16px";
        var h = g.appendChild;
        var k = b.g.get(c) || 0;
        k = T0(a, d, f, k);
        r(k, {
            position: "relative",
            top: "3px"
        });
        const l = w0(a, "span");
        r(l, {
            display: "inline-block",
            "padding-left": b.ja() ? "" : "3px",
            "padding-right": b.ja() ? "3px" : ""
        });
        l.appendChild(k);
        h.call(g, l);
        h = g.appendChild;
        k = w0(a, "span");
        k.appendChild(a.document.createTextNode(c));
        r(k, {
            position: "relative",
            left: b.ja() ? "" : "3px",
            right: b.ja() ?
                "3px" : "",
            "padding-left": b.ja() ? "6px" : "",
            "padding-right": b.ja() ? "" : "6px"
        });
        h.call(g, k);
        r(g, {
            display: "inline-block",
            "border-radius": "20px",
            "padding-left": b.ja() ? "7px" : "6px",
            "padding-right": b.ja() ? "6px" : "7px",
            "padding-top": "3px",
            "padding-bottom": "3px",
            "border-width": "1px",
            "border-style": "solid",
            color: f,
            "font-family": "Roboto",
            "font-weight": "500",
            "font-size": d,
            "border-color": "#D7D7D7",
            background: e,
            cursor: "pointer",
            "margin-top": "-3px",
            height: "min-content"
        });
        g.tabIndex = 0;
        g.role = "link";
        g.ariaLabel = c;
        return g
    };
    const o1 = [{
        Xh: "1907259590",
        Df: 480,
        eg: 220
    }, {
        Xh: "2837189651",
        Df: 400,
        eg: 180
    }, {
        Xh: "9211025045",
        Df: 360,
        eg: 160
    }, {
        Xh: "6584860439",
        Df: -Infinity,
        eg: 150
    }];

    function p1(a) {
        o1.find(b => b.Df <= a)
    };
    var q1 = class {
        constructor() {
            this.g = []
        }
    };

    function r1(a) {
        f1(a.config, 1065, a.C, () => {
            if (!a.g) {
                var b = new qq;
                b = di(b, 1, a.j);
                var c = new pq;
                b = z(b, 2, rq, c);
                a.config.Z.Kf(b)
            }
        }, 1E4)
    }
    class s1 {
        constructor(a, b, c) {
            this.C = a;
            this.config = b;
            this.j = c;
            this.g = !1
        }
        cancel(a) {
            this.C.clearTimeout(a)
        }
    }

    function Z0(a, b, c, d, e, f, g, h = null, k = !1) {
        a.j();
        return new Promise(l => {
            const m = ut(a.g, !1, () => void l(t1(a, b, c, d, e, f, g, h, k)));
            a.j = () => {
                m();
                l(null)
            }
        })
    }

    function t1(a, b, c, d, e, f, g, h = null, k) {
        p1(b.document.body.clientWidth);
        e = c.Ca ? u1(a, b, c, e, f, h, g, k) : v1(a, b, c, e, f, h, g, k);
        vt(e.isVisible(), !1, () => {
            var m = a.l;
            for (const n of m.g) n();
            m.g.length = 0;
            a.g.g(!1)
        });
        e.show({
            Oi: !0
        });
        a.g.g(!0);
        const l = new s1(b, c, d);
        r1(l);
        a.yb(() => {
            var m = c.Z,
                n = m.Kf;
            var p = new qq;
            p = di(p, 1, d);
            var t = new oq;
            p = z(p, 3, rq, t);
            n.call(m, p);
            l.g = !0
        });
        return e
    }

    function u1(a, b, c, d, e, f, g, h) {
        e = c.jd.tg({
            C: b,
            searchTerm: d,
            rsToken: e,
            M: c.M,
            Ca: c.Ca,
            ja: c.ja(),
            W: c.W,
            Si: f,
            Se: c.Ca ? b.innerWidth : Math.min(b.document.body.clientWidth, c.M.xf),
            Qg: c.Ca ? .95 * b.innerHeight - 30 : b.innerHeight,
            Wb: c.Wb.bind(c),
            Qc: c.Qc.bind(c),
            yb: k => void a.yb(k),
            format: g,
            Jj: h
        });
        return PG(b, e, {
            Cj: .95,
            Zi: .95,
            zIndex: 2147483647,
            Zd: !0,
            Jg: "adpub-drawer-root",
            Ig: !1,
            Lb: !0,
            Pg: new P(f0(c.W, d))
        })
    }

    function v1(a, b, c, d, e, f, g, h) {
        const k = c.Ca ? b.innerWidth : Math.min(b.document.body.clientWidth, c.M.xf);
        e = c.jd.tg({
            C: b,
            searchTerm: d,
            rsToken: e,
            M: c.M,
            Ca: c.Ca,
            ja: c.ja(),
            W: c.W,
            Si: f,
            Se: k,
            Qg: c.Ca ? .95 * b.innerHeight - 30 : b.innerHeight,
            Wb: c.Wb.bind(c),
            Qc: c.Qc.bind(c),
            yb: l => void a.yb(l),
            format: g,
            Jj: h
        });
        return YF(b, e, {
            bf: `${k}px`,
            Xe: c.ja(),
            Oe: C(c.W, 14),
            zIndex: 2147483647,
            Zd: !0,
            Qi: !0,
            Jg: "adpub-drawer-root",
            Ig: !1,
            Lb: !0,
            Pg: new P(f0(c.W, d))
        })
    }
    var w1 = class {
        constructor() {
            this.g = new P(!1);
            this.l = new q1;
            this.j = () => {}
        }
        yb(a) {
            this.l.g.push(a)
        }
    };
    const x1 = ["BTN", "BUTTON"],
        y1 = ["BTN", "BUTTON", "LINK"],
        A1 = z1("gdpr cookie privacy notice notification dialog prompt sticky".split(" ")),
        B1 = z1("accept ok reject dismiss acknowledge close consent allow deny opt-in opt-out".split(" ")),
        C1 = z1(["header", "nav", "menu"]),
        D1 = /^(?:[A-Z][^\s]*\s?)+$/;

    function z1(a) {
        return new RegExp(`(?:^|[_-\\s])${a.join("|(?:^|[_-\\s])")}`, "i")
    }

    function E1(a, b) {
        switch (a.tagName ? .toUpperCase ? .()) {
            case "IFRAME":
            case "A":
            case "AUDIO":
            case "BUTTON":
            case "CANVAS":
            case "CITE":
            case "CODE":
            case "EMBED":
            case "FOOTER":
            case "FORM":
            case "KBD":
            case "LABEL":
            case "OBJECT":
            case "PRE":
            case "SAMP":
            case "SCRIPT":
            case "SELECT":
            case "STYLE":
            case "SUB":
            case "SUPER":
            case "SVG":
            case "TEXTAREA":
            case "TIME":
            case "VAR":
            case "VIDEO":
            case null:
                return !1
        }
        return (a.className.toUpperCase ? .() ? .includes("CRUMB") || a.id.toUpperCase ? .() ? .includes("CRUMB")) && a.offsetHeight <= 50 ||
            F1(a, b) ? !1 : !(b.Xg && G1(a)) && !(b.Wg && (a.tagName.toUpperCase ? .() === "MENU" || a.className.toUpperCase ? .().includes("MENU") || a.id.toUpperCase ? .().includes("MENU"))) && !(b.Yg && a.tabIndex >= 0) && !a.classList ? .contains("google-anno-skip") && !a.classList ? .contains("adsbygoogle")
    }

    function F1(a, b) {
        if (b.Ug) {
            b = a.role ? .toUpperCase ? .() === "BUTTON";
            const c = a.tagName ? .toUpperCase ? .() === "INPUT" && a.getAttribute("type") ? .toUpperCase ? .() === "BUTTON",
                d = a.childElementCount === 1 && a.firstElementChild ? .tagName ? .toUpperCase ? .() === "A";
            return y1.some(e => a.className.toUpperCase ? .() ? .includes(e) || a.id.toUpperCase ? .() ? .includes(e)) || b || c || a.getAttribute("style") ? .toUpperCase ? .() ? .includes("CURSOR: POINTER") || d
        }
        return x1.some(c => a.className.toUpperCase ? .() ? .includes(c) || a.id.toUpperCase ? .() ? .includes(c))
    }

    function H1(a) {
        const b = document.elementsFromPoint(a.getBoundingClientRect().x + a.getBoundingClientRect().width / 2, a.getBoundingClientRect().y + a.getBoundingClientRect().height / 2);
        for (const c of b)
            if (a.contains(c)) break;
            else if (I1(c)) return !0;
        return !1
    }

    function I1(a) {
        return !(a.closest(".adsbygoogle") || a.closest("#google-anno-sa") || G1(a))
    }

    function G1(a) {
        const b = a.getAttribute("id") ? ? "",
            c = a.className;
        if (b.match(A1) || c.match ? .(A1)) return !0;
        if (a.tagName === "A" || a.tagName === "BUTTON")
            if (b.match(B1) || c.match ? .(B1)) return !0;
        return !!a.parentElement && a.parentElement.tagName !== "BODY" && G1(a.parentElement)
    }

    function J1(a, b) {
        switch (a.tagName ? .toUpperCase ? .()) {
            case "ADDRESS":
            case "ARTICLE":
            case "FOOTER":
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "HEADER":
            case "HGROUP":
            case "HR":
            case "NAV":
            case "SECTION":
            case "TABLE":
            case null:
                return !0;
            case "IMG":
                return pS(a) && a.offsetHeight >= b.mh;
            default:
                return !1
        }
    }

    function K1(a) {
        const b = a.textContent;
        if (!b) return !1;
        switch (a.tagName ? .toUpperCase ? .()) {
            case "H1":
            case "H2":
            case "H3":
            case "H4":
            case "H5":
            case "H6":
            case "HEADER":
            case "HGROUP":
            case "TH":
            case "THEAD":
                return !0;
            case "LI":
            case "OL":
            case "TD":
            case "TR":
            case "UL":
                return !1
        }
        return D1.test(b)
    };

    function L1(a, b, c) {
        b = b.getBoundingClientRect();
        a = Yp(Xp(Wp(new Zp, a), 3), c);
        a = E(a, 6, Math.round(b.x));
        return E(a, 7, Math.round(b.y))
    }

    function M1(a, b) {
        return Yp(Xp(Wp(new Zp, a), 4), b)
    }

    function N1(a) {
        a = D0(a);
        var b = new Up;
        b = E(b, 1, a[0]);
        b = E(b, 2, a[1]);
        b = E(b, 3, a[2]);
        return zh(b, 4, pf(a[3]), 0)
    }

    function O1(a, b, c, d) {
        var e = d.getBoundingClientRect();
        var f = new gq;
        f = E(f, 1, Math.round(e.x));
        f = E(f, 2, Math.round(e.y));
        f = E(f, 3, Math.round(e.height));
        e = E(f, 4, Math.round(e.width));
        e = E(e, 6, a.innerHeight);
        a = E(e, 5, a.innerWidth);
        e = Sp(new Tp, c.tagName);
        c = [...c.classList];
        c = yh(e, 2, c, Yf);
        e = new hq;
        b = ei(e, 1, b);
        b = y(b, 2, a);
        b = y(b, 3, c);
        a: {
            d = document.elementsFromPoint(d.getBoundingClientRect().x + d.getBoundingClientRect().width / 2, d.getBoundingClientRect().y + d.getBoundingClientRect().height / 2);
            for (g of d)
                if (I1(g)) break a;
            var g = null
        }
        if (d = g) g = Sp(new Tp, d.tagName), d = [...d.classList], g = yh(g, 2, d, Yf), y(b, 4, g);
        g = new iq;
        return z(g, 1, jq, b)
    };
    const P1 = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function Q1(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return a === "" || P1.test(a)
        }
    };

    function R1(a, b) {
        const c = new S1(b);
        for (const d of a) C(d, 5) && Th(d, 3).forEach(e => {
            T1(c, e, e)
        });
        U1(c);
        return new V1(c)
    }

    function W1(a, b) {
        b = a.match(b);
        a = new Map;
        for (const c of b)
            if (b = c.l, a.has(b)) {
                const d = a.get(b);
                c.length > d.length && a.set(b, c)
            } else a.set(b, c);
        return [...a.values()]
    }
    var V1 = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };

    function T1(a, b, c) {
        const d = a.j.has(c) ? a.j.get(c) : a.B++;
        a.j.set(c, d);
        a.A.set(d, c);
        c = 0;
        for (let e = 0; e < b.length; e++) {
            const f = b.charCodeAt(e);
            a.g[c].contains(f) || (a.g.push(new X1), a.g[a.size].A = c, a.g[a.size].J = f, a.g[c].l.set(f, a.size), a.size++);
            c = a.g[c].l.get(f)
        }
        a.g[c].B = !0;
        a.g[c].D = d;
        a.g[c].F = a.l.length;
        a.l.push(b.length)
    }

    function U1(a) {
        const b = [];
        for (b.push(0); b.length > 0;) {
            const f = b.shift();
            var c = a,
                d = c.g[f];
            if (f === 0) d.g = 0, d.j = 0;
            else if (d.A === 0) d.g = 0, d.j = d.B ? f : c.g[c.g[f].g].j;
            else {
                d = c.g[c.g[f].A].g;
                for (var e = c.g[f].J;;) {
                    if (c.g[d].contains(e)) {
                        c.g[f].g = c.g[d].l.get(e);
                        break
                    }
                    if (d === 0) {
                        c.g[f].g = 0;
                        break
                    }
                    d = c.g[d].g
                }
                c.g[f].j = c.g[f].B ? f : c.g[c.g[f].g].j
            }
            for (const g of a.g[f].bb) b.push(g)
        }
    }
    class S1 {
        constructor(a) {
            this.D = a;
            this.size = 1;
            this.g = [new X1];
            this.l = [];
            this.j = new Map;
            this.A = new Map;
            this.B = 0
        }
        isEmpty() {
            return this.B === 0
        }
        match(a) {
            let b = 0;
            const c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.l.get(d);
                        break
                    }
                    if (b === 0) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].j;
                    if (h === 0) break;
                    const k = g + 1 - this.l[this.g[h].F],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.D;
                    Q1(d.charAt(k - 1), f) && Q1(d.charAt(e + 1), f) && c.push(new Y1(k, l, this.A.get(this.g[h].D)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class X1 {
        constructor() {
            this.l = new Map;
            this.T = !1;
            this.Fa = this.K = this.G = this.la = this.V = this.ba = -1
        }
        contains(a) {
            return this.l.has(a)
        }
        set A(a) {
            this.ba = a
        }
        get A() {
            return this.ba
        }
        set J(a) {
            this.V = a
        }
        get J() {
            return this.V
        }
        set B(a) {
            this.T = a
        }
        get B() {
            return this.T
        }
        set D(a) {
            this.K = a
        }
        get D() {
            return this.K
        }
        set g(a) {
            this.la = a
        }
        get g() {
            return this.la
        }
        set j(a) {
            this.G = a
        }
        get j() {
            return this.G
        }
        set F(a) {
            this.Fa = a
        }
        get F() {
            return this.Fa
        }
        get bb() {
            return this.l.values()
        }
    }
    var Y1 = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.A = c
        }
        get l() {
            return this.j
        }
        get B() {
            return this.g
        }
        get searchTerm() {
            return this.A
        }
        get length() {
            return this.g - this.j
        }
    };
    async function Z1(a, b, c, d, e, f) {
        const g = R1(XZ(b.W), b.l);
        if (!g.isEmpty()) {
            var h = new Map;
            for (const k of XZ(b.W).filter(l => C(l, 5))) Th(k, 3).forEach(l => {
                h.set(l, C(k, 1))
            });
            await $1(a, a.document.body, b, g, h, new Set, b.M.Gb ? new Map : null, c, d, new k1(0, 0, 0, b.M.Bh), b.M.Af || b.M.Kc ? new a2(b.M.Af, b.M.Kc) : null, e, f)
        }
    }
    async function $1(a, b, c, d, e, f, g, h, k, l, m, n, p) {
        h.g.va(9) >= h.j && await y0(h, 10);
        if (pS(b) && (!E1(b, c.M) || c.M.Vg && (b.tagName ? .toUpperCase ? .() === "HEADER" || b.tagName ? .toUpperCase ? .() === "NAV" || b.id ? .match(C1) || b.className.match ? .(C1)))) c.M.Kc && m && b.classList ? .contains("adsbygoogle") && b.dataset.adStatus === "filled" && b2(m, b.getBoundingClientRect().bottom + a.scrollY);
        else if (c.M.Ne && f.size && oS(b) && J1(b, c.M) && f.clear(), b.nodeType === Node.TEXT_NODE && b.textContent) W1(d, b.textContent).map(t => e.get(t.searchTerm)).filter(t =>
            !!t).forEach(t => {
            f.add(t);
            c.M.Gb && g && b.parentElement && g.set(t, b.parentElement.getBoundingClientRect().bottom)
        });
        else {
            for (const t of b.childNodes) await $1(a, t, c, d, e, f, g, h, k, l, m, n, p);
            f.size && oS(b) && ["block", "table-cell"].includes(a.getComputedStyle(b).display) && !c2(a, c, b) && d2(a, m, b.getBoundingClientRect().bottom) && !K1(b) && e2(a, f, g, c, k, b, l, m, p);
            if (a = c.M.Ne && f.size && oS(b)) a: switch (b.tagName ? .toUpperCase ? .()) {
                case "ARTICLE":
                case "NAV":
                case "SECTION":
                case "TABLE":
                case null:
                    a = !0;
                    break a;
                default:
                    a = !1
            }
            a &&
                (f.clear(), c.M.Gb && g && g.clear())
        }
    }

    function e2(a, b, c, d, e, f, g, h, k) {
        var l = [...b];
        d.M.Th && cb(l);
        for (const [m, n] of l.entries()) {
            l = m;
            const p = n;
            if (i1(g) || d.M.Cd && l === d.M.Cd) return;
            if (d.M.Gb && c && (l = c.get(p), l !== void 0 && l !== null && f2(l, f, d))) {
                b.delete(p);
                continue
            }
            d.M.Cd && (b.delete(p), d.M.Gb && c ? .delete(p));
            const t = L1(d.Z.Pd(), f, p);
            e.entries.push(ah(t));
            m1(g.j, p, g.g);
            if (A(d.W, 17)) continue;
            l = n1(a, d, p, f, "#0B57D0", "#FFFFFF");
            const u = g2(l, d, Nh(t) ? ? "0", a);
            x0(l);
            W0(d, 999, l, B => {
                try {
                    var F = fq(dq(p), Nh(t) ? ? "0");
                    var R = ci(F, 7, u.l);
                    const da = d.Z.ed(R);
                    d.Oa(1401,
                        Z0(k, a, d, da, p, d.B.get(p) || "", 3, d.M.Sc ? d.j.get(p) || "" : null));
                    return !1
                } finally {
                    B.preventDefault(), B.stopImmediatePropagation()
                }
            });
            f.insertBefore(l, null);
            if (d.M.Lf && H1(l)) {
                const B = O1(a, Nh(t) ? ? "0", f, l);
                d.Z.Eg(B);
                l.remove()
            } else h && h2(h, l.getBoundingClientRect().bottom + window.scrollY)
        }
        d.M.Cd || (b.clear(), d.M.Gb && c ? .clear())
    }
    async function i2(a, b, c, d, e) {
        const f = new w1;
        for (const [, g] of [...b].entries()) {
            const h = g,
                k = M1(c.Z.Pd(), h);
            d.entries.push(ah(k));
            b = n1(a, c, h, e, "#FFFFFF", "#1A73E8");
            const l = j2(b, c, Nh(k) ? ? "0");
            x0(b);
            W0(c, 999, b, m => {
                try {
                    var n = fq(dq(h), Nh(k) ? ? "0");
                    var p = ci(n, 8, l.l);
                    const t = c.Z.ed(p);
                    Z0(f, a, c, t, h, c.B.get(h) || "", 4, c.j.get(h) || "", !0);
                    return !1
                } finally {
                    m.preventDefault(), m.stopImmediatePropagation()
                }
            });
            e.appendChild(b);
            if (e.scrollHeight > e.clientHeight) {
                e.removeChild(b);
                break
            }
        }
    }

    function c2(a, b, c) {
        if (!b.M.uf) return !1;
        a = Nd(a.getComputedStyle(c).fontSize);
        return a !== null && a > b.M.uf
    }

    function d2(a, b, c) {
        b ? (a = c + a.scrollY, b = (b.g === void 0 || a - b.g > b.l) && (b.j === void 0 || a - b.j > b.Kc)) : b = !0;
        return b
    }

    function f2(a, b, c) {
        b = b.getBoundingClientRect().bottom;
        return c.M.Gb < b - a || c.M.Gb < a - b
    }
    class k2 {
        constructor() {
            this.j = this.g = null
        }
        get l() {
            return this.g
        }
    }

    function g2(a, b, c, d) {
        const e = new k2;
        l2(b, f => {
            for (const m of f)
                if (m.isIntersecting)
                    if (b.M.Lf && e.l === null && H1(a)) f = O1(d, c, a.parentElement, a), b.Z.Eg(f), a.remove();
                    else {
                        var g = e,
                            h = b.Z;
                        f = c;
                        if (!g.g) {
                            var k = h.wg,
                                l = new Ap;
                            f = ei(l, 1, f);
                            g.g = k.call(h, f)
                        }
                    }
            else e.g && !e.j && (f = b.Z, g = f.vg, h = new zp, h = di(h, 1, e.g), e.j = g.call(f, h))
        }).observe(a);
        return e
    }

    function b2(a, b) {
        a.j = b
    }

    function h2(a, b) {
        a.g = b
    }
    class a2 {
        constructor(a, b) {
            this.l = a;
            this.Kc = b;
            this.j = this.g = void 0
        }
    }
    class m2 {
        constructor() {
            this.j = this.g = null
        }
        get l() {
            return this.g
        }
    }

    function j2(a, b, c) {
        const d = new m2;
        l2(b, e => {
            for (const l of e)
                if (l.isIntersecting) {
                    var f = d,
                        g = b.Z;
                    e = c;
                    if (!f.g) {
                        var h = g.ki,
                            k = new Cp;
                        e = ei(k, 1, e);
                        f.g = h.call(g, e)
                    }
                } else d.g && !d.j && (e = b.Z, f = e.ji, g = new Bp, g = di(g, 1, d.g), d.j = f.call(e, g))
        }).observe(a);
        return d
    };

    function n2(a, b, c, d, e, f, g) {
        if (!a.g) {
            var h = b.document.createElement("span");
            h.appendChild(P0(b, "12px", f));
            h.appendChild(b.document.createTextNode(d));
            HI(b, c || null, {
                informationText: h
            }, e, g ? k => {
                g.Og(k)
            } : g);
            a.g = !0
        }
    }
    var o2 = class {
        constructor() {
            this.g = !1
        }
    };
    const p2 = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function q2(a, b, c, d, e) {
        d.g.va(5) >= d.j && await y0(d, 6);
        const f = new w1;
        c.M.Lg || r2(a, b, c, e, XZ(c.W), f);
        c.M.Mg && !s2(a) || await c.Oa(898, Z1(a, c, d, e, b, f));
        c.M.Ng || await t2(a, c, () => new o2, d, e, f)
    }

    function s2(a) {
        try {
            const b = a.location ? .href ? .match(/goog_fac=1/);
            return b !== null && b !== void 0
        } catch (b) {
            return !1
        }
    }
    async function t2(a, b, c, d, e, f) {
        var g = XZ(b.W);
        var h = new S1(b.l);
        for (const k of g) C(k, 6) !== "" && (g = C(k, 1), T1(h, g, g));
        U1(h);
        h = new V1(h);
        h.isEmpty() || await b.Oa(898, u2(a, b, d, e, h, new k1(b.params.wordWindowSize, b.params.sameSearchTermPerWindow, b.params.annotationsPerWindow, b.params.maximumAnnotationsPerPage), c(), f))
    }
    async function u2(a, b, c, d, e, f, g, h) {
        let k = a.document.body;
        if (A(b.W, 17) || x(b.W, sv, 21))
            for (; k;) {
                c.g.va(7) >= c.j && await y0(c, 8);
                if (k.nodeType === Node.TEXT_NODE && k.textContent !== "" && k.parentElement) {
                    const Yb = k.parentElement;
                    a: {
                        var l = a,
                            m = b,
                            n = Yb,
                            p = k.textContent,
                            t = d,
                            u = e,
                            B = f,
                            F = h;
                        const Qa = [];b: {
                            var R = p;
                            switch (m.l) {
                                case 1:
                                    var da = R;
                                    const nc = Array(da.length);
                                    let $b = 0;
                                    for (let oc = 0; oc < da.length; oc++) P1.test(da[oc]) || $b++, nc[oc] = $b;
                                    var J = nc;
                                    break b;
                                default:
                                    var N = R;
                                    const Zc = Array(N.length);
                                    let rd = 0,
                                        ub = 0;
                                    for (; ub < N.length;) {
                                        for (;
                                            /\s/.test(N[ub]);) Zc[ub] =
                                            rd, ub++;
                                        let oc = !1;
                                        for (; ub < N.length && !/\s/.test(N[ub]);) oc = !0, Zc[ub] = rd, ub++;
                                        oc && (rd++, Zc[ub - 1] = rd)
                                    }
                                    J = Zc
                            }
                        }
                        const Zb = J,
                            Vg = p.includes("\u00bb") ? [] : W1(u, p);
                        let ae = -1;
                        for (const nc of Vg) {
                            const $b = nc.l,
                                Zc = nc.B;
                            if ($b < ae) continue;
                            var aa = B,
                                Ya = nc.searchTerm;
                            l1(aa.j, aa.g + Zb[$b]);
                            var Sb = aa,
                                za = Sb.j,
                                Ha = Ya;
                            if (!((za.g.has(Ha) ? za.g.get(Ha).length : 0) < Sb.sameSearchTermPerWindow && aa.j.l < aa.annotationsPerWindow)) continue;
                            const rd = l.getComputedStyle(n),
                                ub = rd.fontSize.match(/\d+/);
                            if (!(ub && Number(ub[0]) >= 12 && Number(ub[0]) <=
                                    22 && Pa(p2, rd.display))) {
                                B.g += Zb[Zb.length - 1];
                                var Yc = [];
                                break a
                            }
                            const oc = ae + 1;
                            oc < $b && Qa.push(l.document.createTextNode(p.substring(oc, $b)));
                            const Wg = p.substring($b, Zc + 1);
                            var Ic = p,
                                Jc = $b,
                                Id = Zc + 1;
                            const fj = Ic.substring(Math.max(Jc - 30, 0), Jc) + "~~" + Ic.substring(Id, Math.min(Id + 30, Ic.length));
                            var ua = l,
                                pd = m.Z.Pd(),
                                Ne = n,
                                Fg = Wg,
                                Gg = fj,
                                Hg = nc.searchTerm,
                                Ig = Zb[$b];
                            const Xg = Ne.getBoundingClientRect();
                            var Jg = Xp(Wp(new Zp, pd), 2);
                            var Kg = gi(Jg, 2, Fg);
                            var Lg = gi(Kg, 3, Gg);
                            var Mg = Yp(Lg, Hg);
                            var Ng = E(Mg, 5, Ig);
                            var Og = E(Ng, 6, Math.round(Xg.x));
                            var Pg = E(Og, 7, Math.round(Xg.y));
                            const sd = ua.getComputedStyle(Ne);
                            var Ti = new Vp;
                            var Ui = gi(Ti, 1, sd.fontFamily);
                            var Vi = N1(sd.color);
                            var Wi = y(Ui, 7, Vi);
                            var Xi = N1(sd.backgroundColor);
                            var Yi = y(Wi, 8, Xi);
                            const Yg = sd.fontSize.match(/^(\d+(\.\d+)?)px$/);
                            var Cf = E(Yi, 4, Yg ? Math.round(Number(Yg[1])) : 0);
                            const Ef = Math.round(Number(sd.fontWeight));
                            isNaN(Ef) || Ef === 400 || E(Cf, 5, Ef);
                            sd.textDecorationLine !== "none" && gi(Cf, 6, sd.textDecorationLine);
                            var Zi = y(Pg, 8, Cf);
                            const Ff = [];
                            let be = Ne;
                            for (; be && Ff.length < 20;) {
                                var Qg = Ff,
                                    $i = Qg.push,
                                    Df = be;
                                const $g = Sp(new Tp, Df.tagName);
                                Df.className !== "" && yh($g, 2, Df.className.split(" "), Yf);
                                $i.call(Qg, $g);
                                if (be.tagName === "BODY") break;
                                be = be.parentElement
                            }
                            var aj = Ff.reverse();
                            const Zg = Ih(Zi, 9, aj);
                            t.entries.push(ah(Zg));
                            Qa.push(v2(l, m, Nh(Zg) ? ? "0", nc.searchTerm, Wg, n, F));
                            m1(B.j, nc.searchTerm, B.g + Zb[$b]);
                            ae = Zc;
                            if (i1(B)) break
                        }
                        const Oe = ae + 1;Oe !== 0 && Oe < p.length && Qa.push(l.document.createTextNode(p.substring(Oe)));B.g += Zb[Zb.length - 1];Yc = Qa
                    }
                    const qd = Yc;
                    if (qd.length && !A(b.W, 17)) {
                        !b.M.Sc && n2(g,
                            a, b.params.Ni ? u0(a, b.params.Ni) : void 0, C(b.W, 3), kj(x(b.W, sv, 21)), b.params.nj, b.Z);
                        for (const Qa of qd) Yb.insertBefore(Qa, k), w2(Qa);
                        Yb.removeChild(k);
                        if (b.M.Mf)
                            for (const Qa of Yb.children) Qa.classList ? .contains("google-anno") && Qa.firstElementChild && H1(Qa.firstElementChild) && Qa.replaceWith(a.document.createTextNode(Qa.textContent ? .trimStart() ? ? ""));
                        for (k = qd[qd.length - 1]; k.lastChild;) k = k.lastChild;
                        if (i1(f)) break
                    }
                }
                a: {
                    var bj = a,
                        mc = k,
                        cj = f,
                        dj = b.l,
                        ej = b.M;
                    if (mc.firstChild && pS(mc) && !mc.classList ? .contains("google-anno-skip") &&
                        (mc.offsetHeight || bj.getComputedStyle(mc).display === "contents")) {
                        if (E1(mc, ej)) {
                            k = mc.firstChild;
                            break a
                        }
                        if (mc.textContent ? .length) {
                            var Rg = cj;
                            b: {
                                var Sg = mc.textContent;
                                switch (dj) {
                                    case 1:
                                        var Tg = Sg;
                                        let qd = 0;
                                        for (let Zb = Tg.length - 1; Zb >= 0; Zb--) P1.test(Tg[Zb]) || qd++;
                                        var Ug = qd;
                                        break b;
                                    default:
                                        const Qa = Sg.trim();
                                        Ug = Qa === "" ? 0 : Qa.split(/\s+/).length
                                }
                            }
                            l1(Rg.j, Rg.g + Ug)
                        }
                    }
                    let Yb = mc;
                    for (;;) {
                        if (Yb.nextSibling) {
                            k = Yb.nextSibling;
                            break a
                        }
                        if (!Yb.parentNode) {
                            k = null;
                            break a
                        }
                        Yb = Yb.parentNode
                    }
                    k = void 0
                }
            }
    }

    function x2(a, b) {
        b = {
            ja: b.ja(),
            Ca: b.Ca,
            da: ss(a),
            ha: ts(a)
        };
        if (b.ha >= 400) {
            var c;
            if ((c = G0(a, b)) != null) var d = c;
            else a: {
                c = b.da;
                var e = O0(a, b);a = 16;
                for (d of e) {
                    e = d.start;
                    const f = d.end;
                    if (e > a) {
                        if (e - a - 16 >= 200) {
                            d = M0(b, e, a);
                            break a
                        }
                        a = f + 16
                    } else f >= a && (a = f + 16)
                }
                d = c - a - 16 >= 200 ? M0(b, c, a) : null
            }
        } else d = null;
        return d
    }

    function r2(a, b, c, d, e, f) {
        function g() {
            return k ? ? (k = c.Qc(898, a, () => {
                if (!h) {
                    var m = c.va(12);
                    a.clearInterval(k);
                    h = !0;
                    var n = x2(a, c);
                    n && y2(a, b, c, d, m, e, n, f)
                }
            }, c.M.ig))
        }
        if (e.filter(m => C(m, 7).length).length) {
            var h = !1,
                k = void 0,
                l = z2(c, a, () => {
                    if (!(a.scrollY <= c.M.jg || h)) {
                        var m = c.va(12),
                            n = x2(a, c);
                        n ? (h = !0, a.removeEventListener("scroll", l), y2(a, b, c, d, m, e, n, f)) : k = g()
                    }
                });
            f1(c, 898, a, () => {
                if (!h) {
                    var m = c.va(12),
                        n = x2(a, c);
                    n ? (h = !0, y2(a, b, c, d, m, e, n, f)) : k = g()
                }
            }, c.M.hg)
        }
    }

    function y2(a, b, c, d, e, f, g, h) {
        const k = new g1(a, c, g, h);
        f.filter(l => C(l, 7).length).forEach(l => {
            var m = c.Z.Pd();
            var n = C(l, 1);
            m = Yp(Xp(Wp(new Zp, m), 1), n);
            d.entries.push(ah(m));
            m = Nh(m) ? ? "0";
            n = C(l, 1);
            l = C(l, 1);
            k.l.push(new h1(m, n, l));
            k.B && e1(k, b)
        });
        c.Z.zh(A2(d, c.va(13) - e))
    }

    function w2(a) {
        if (oS(a)) {
            if (a.tagName === "A") {
                var b = F0(D0(getComputedStyle(a.parentElement).color)),
                    c = F0(D0(getComputedStyle(a).color));
                var d = E0(a);
                if (d = b && c && d ? RR(c, d) < Math.min(RR(b, d), 2.5) ? b : null : b) {
                    b = d[0];
                    c = d[1];
                    d = d[2];
                    b = Number(b);
                    c = Number(c);
                    d = Number(d);
                    if (b != (b & 255) || c != (c & 255) || d != (d & 255)) throw Error('"(' + b + "," + c + "," + d + '") is not a valid RGB color');
                    c = b << 16 | c << 8 | d;
                    b = b < 16 ? "#" + (16777216 | c).toString(16).slice(1) : "#" + c.toString(16);
                    r(a, {
                        color: b
                    })
                }
            }
            for (b = 0; b < a.childElementCount; b++) w2(a.children[b])
        }
    }
    class B2 {
        constructor() {
            this.j = this.g = null
        }
        get l() {
            return this.g
        }
    }

    function v2(a, b, c, d, e, f, g) {
        const h = b.M.Jd ? w0(a, "span") : a.document.createElement("SPAN");
        h.className = "google-anno-t";
        r(h, {
            "text-decoration": "underline"
        });
        r(h, {
            "text-decoration-style": "dotted"
        });
        r(h, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        r(h, {
            color: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit"
        });
        h.appendChild(a.document.createTextNode(e));
        e = b.M.Jd ? w0(a, "a") : a.document.createElement("A");
        b.M.Jd ? r(e, {
            color: "",
            "text-decoration": "none",
            fill: "currentColor"
        }) : (v0(e), r(e, {
            "text-decoration": "none",
            fill: "currentColor"
        }));
        Dc(e, "#");
        e.className = "google-anno";
        x0(e);
        b.M.Jd ? e.append(C2(a, b, f), a.document.createTextNode("\u00a0"), h) : (e.appendChild(C2(a, b, f)), e.appendChild(a.document.createTextNode("\u00a0")), e.appendChild(h));
        const k = D2(b, c, e, a);
        W0(b, 999, e, l => {
            try {
                var m = fq(dq(d), c);
                var n = ci(m, 2, k.l);
                const p = b.Z.ed(n);
                b.Oa(1401, Z0(g, a, b, p, d, b.D.get(d) || "", 1, b.M.Sc ? b.j.get(d) || "" : null));
                return !1
            } finally {
                l.preventDefault(),
                    l.stopImmediatePropagation()
            }
        });
        return e
    }

    function C2(a, b, c) {
        return P0(a, a.getComputedStyle(c).fontSize, b.params.nj)
    }

    function D2(a, b, c, d) {
        const e = new B2;
        l2(a, f => {
            for (const m of f)
                if (m.isIntersecting)
                    if (a.M.Mf && c.classList ? .contains("google-anno") && e.l === null && c.firstElementChild && H1(c.firstElementChild)) c.replaceWith(d.document.createTextNode(c.textContent ? .trimStart() ? ? ""));
                    else {
                        var g = e,
                            h = a.Z;
                        f = b;
                        if (!g.g) {
                            var k = h.Dh,
                                l = new nq;
                            f = ei(l, 2, f);
                            g.g = k.call(h, f)
                        }
                    }
            else e.g && !e.j && (f = a.Z, g = f.Ch, h = new mq, h = di(h, 1, e.g), e.j = g.call(f, h))
        }).observe(c);
        return e
    };

    function A2(a, b) {
        const c = a.g;
        a.g = a.entries.length;
        var d = new lq,
            e = new $p;
        a = Ih(e, 2, a.entries.slice(c));
        d = y(d, 1, a);
        b !== 0 && di(d, 2, Math.round(b));
        return d
    }
    var E2 = class {
        constructor() {
            this.entries = [];
            this.language = null;
            this.g = 0
        }
    };

    function F2(a) {
        return a ? 1 : 0
    };

    function G2(a, b, c) {
        H2(a);
        var d = new Map;
        for (const e of b) b = I2(e), d.set(b, (d.get(b) ? ? 0) + 1);
        for (const [e, f] of d) d = e, J2(a, f, d, c), K2(a, d)
    }

    function L2(a, b, c, d) {
        a.j.forEach(e => {
            M2(e, { ...a.g,
                outcome: b,
                ge: c,
                bh: d
            })
        })
    }

    function N2(a, b, c, d, e) {
        a.j.forEach(f => {
            f.ng(b, { ...a.g,
                outcome: c,
                ge: d,
                bh: e
            })
        })
    }

    function H2(a) {
        a.B || (a.B = !0, a.j.forEach(b => {
            O2(b, a.g)
        }))
    }

    function J2(a, b, c, d) {
        a.j.forEach(e => {
            e.pg(b, { ...a.g,
                format: c,
                ge: d
            })
        })
    }

    function K2(a, b) {
        a.D.has(b) || (a.D.add(b), a.j.forEach(c => {
            a.M.di || P2(c, { ...a.g,
                format: b
            });
            Q2(c, { ...a.g,
                Rb: a.Rb,
                format: b
            })
        }))
    }

    function R2(a, b) {
        a.j.forEach(c => {
            S2(c, { ...a.g,
                reason: T2(b)
            })
        })
    }
    var a3 = class {
        constructor(a, b, c, d) {
            this.M = a;
            this.J = this.l = 1;
            this.A = this.B = !1;
            this.g = {
                language: a.Fh.has(b) ? b : "other",
                Ta: Qb() ? 2 : Ob() ? 4 : Pb() ? 7 : 10
            };
            a: switch (d) {
                case 1:
                    a = 1;
                    break a;
                case 2:
                    a = 2;
                    break a;
                default:
                    a = 0
            }
            this.Rb = a;
            this.D = new Set;
            this.j = [...c]
        }
        Pd() {
            return this.J++
        }
        og(a) {
            a: switch (Dh(a, bq)) {
                case 4:
                    var b = 1;
                    break a;
                case 5:
                    b = 2;
                    break a;
                default:
                    b = 0
            }
            const c = U2(a);
            var d = Zv(Qh(a, 3)),
                e = c.length > 0;L2(this, b, !1, e);N2(this, d, b, !1, e);a.g() && c.length > 0 && G2(this, c, !1);
            if (mh(a, Rp, 5, bq)) {
                a = Vh(a, Rp, 5, bq);
                for (const f of Gh(a,
                        Mp, 1, ph())) R2(this, f)
            }
            this.l++
        }
        zh(a) {
            const b = a.g() ? 1 : 0,
                c = U2(a);
            var d = Zv(Qh(a, 2)),
                e = c.length > 0;
            L2(this, b, !0, e);
            N2(this, d, b, !0, e);
            a.g() && c.length > 0 && G2(this, c, !0);
            this.l++
        }
        Dh() {
            this.j.forEach(a => {
                V2(a, { ...this.g,
                    format: 2
                })
            });
            return this.l++
        }
        Ch() {
            this.j.forEach(a => {
                W2(a, { ...this.g,
                    format: 2
                })
            });
            return this.l++
        }
        lg() {
            this.j.forEach(a => {
                V2(a, { ...this.g,
                    format: 1
                })
            });
            return this.l++
        }
        kg() {
            this.j.forEach(a => {
                W2(a, { ...this.g,
                    format: 1
                })
            });
            this.l++
        }
        wg() {
            this.j.forEach(a => {
                V2(a, { ...this.g,
                    format: 3
                })
            });
            return this.l++
        }
        vg() {
            this.j.forEach(a => {
                W2(a, { ...this.g,
                    format: 3
                })
            });
            return this.l++
        }
        ki() {
            this.j.forEach(a => {
                V2(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        ji() {
            this.j.forEach(a => {
                W2(a, { ...this.g,
                    format: 4
                })
            });
            return this.l++
        }
        ed(a) {
            let b = 0;
            Lh(a, 2) != null ? b = 2 : Lh(a, 3) != null ? b = 1 : Lh(a, 7) != null && (b = 3);
            this.j.forEach(c => {
                c.click({ ...this.g,
                    format: b
                })
            });
            return this.l++
        }
        Kf(a) {
            let b = 0;
            mh(a, pq, 2, rq) ? b = 1 : mh(a, oq, 3, rq) && (b = 2);
            this.j.forEach(c => {
                X2(c, { ...this.g,
                    type: b
                })
            });
            this.l++
        }
        Og(a) {
            a: switch (D(a, 1)) {
                case 1:
                    a = 1;
                    break a;
                case 2:
                    a = 2;
                    break a;
                default:
                    a =
                        0
            }
            const b = a;this.j.forEach(c => {
                Y2(c, { ...this.g,
                    type: b
                })
            });this.A || (this.A = !0, this.j.forEach(c => {
                Z2(c, this.g)
            }));this.l++
        }
        gg() {
            this.j.forEach(a => {
                $2(a, this.g)
            });
            this.l++
        }
        Eg() {
            this.l++
        }
    };

    function U2(a) {
        a.g() ? (a = a.j(), a = [...Gh(a, Zp, 2, ph())]) : a = [];
        return a
    }

    function T2(a) {
        switch (Dh(a, Np)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 9:
                return 4;
            case 11:
                return 5;
            case 12:
                return 6;
            case 13:
                return 7;
            default:
                return 0
        }
    }

    function I2(a) {
        switch (D(a, 1)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 4:
                return 4;
            default:
                return 0
        }
    };

    function b3(a, b) {
        var c = new sq;
        var d = a.l++;
        c = di(c, 1, d);
        b = di(c, 2, Math.round(a.B.va(b) - a.D));
        b = y(b, 10, a.J);
        b = $h(b, 15, a.F ? !0 : void 0);
        return G(b, 18, a.Rb)
    }
    var c3 = class {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.B = b;
            this.D = c;
            this.J = d;
            this.F = f;
            this.Rb = k;
            this.j = this.l = 1;
            this.A = [...g];
            this.g = h.length ? new a3(e, a, h, k) : null
        }
        Pd() {
            return this.j++
        }
        og(a) {
            this.g ? .og(a);
            var b = this.handle,
                c = b3(this, 11);
            a = z(c, 3, tq, a);
            b.call(this, a)
        }
        zh(a) {
            this.g ? .zh(a);
            var b = this.handle,
                c = b3(this, 11);
            a = z(c, 14, tq, a);
            b.call(this, a)
        }
        Dh(a) {
            this.g ? .Dh(a);
            var b = this.handle,
                c = b3(this, 15);
            a = z(c, 4, tq, a);
            return b.call(this, a)
        }
        Ch(a) {
            this.g ? .Ch(a);
            var b = this.handle,
                c = b3(this, 16);
            a = z(c, 5, tq, a);
            return b.call(this,
                a)
        }
        lg(a) {
            this.g ? .lg(a);
            var b = this.handle,
                c = b3(this, 17);
            a = z(c, 6, tq, a);
            return b.call(this, a)
        }
        kg(a) {
            this.g ? .kg(a);
            var b = this.handle,
                c = b3(this, 18);
            a = z(c, 7, tq, a);
            b.call(this, a)
        }
        wg(a) {
            this.g ? .wg(a);
            var b = this.handle,
                c = b3(this, 19);
            a = z(c, 16, tq, a);
            return b.call(this, a)
        }
        vg(a) {
            this.g ? .vg(a);
            var b = this.handle,
                c = b3(this, 20);
            a = z(c, 17, tq, a);
            return b.call(this, a)
        }
        ki(a) {
            this.g ? .ki(a);
            var b = this.handle,
                c = b3(this, 21);
            a = z(c, 20, tq, a);
            return b.call(this, a)
        }
        ji(a) {
            this.g ? .ji(a);
            var b = this.handle,
                c = b3(this, 22);
            a = z(c, 21, tq,
                a);
            return b.call(this, a)
        }
        ed(a) {
            this.g ? .ed(a);
            var b = this.handle,
                c = b3(this, 14);
            a = z(c, 8, tq, a);
            return b.call(this, a)
        }
        Kf(a) {
            this.g ? .Kf(a);
            var b = this.handle,
                c = b3(this, 23);
            a = z(c, 9, tq, a);
            b.call(this, a)
        }
        Og(a) {
            this.g ? .Og(a);
            var b = this.handle,
                c = b3(this, 24);
            a = z(c, 11, tq, a);
            b.call(this, a)
        }
        gg(a) {
            this.g ? .gg(a);
            var b = this.handle,
                c = b3(this, 26);
            a = z(c, 12, tq, a);
            b.call(this, a)
        }
        Eg(a) {
            var b = this.handle,
                c = b3(this, 29);
            a = z(c, 19, tq, a);
            b.call(this, a)
        }
        handle(a) {
            for (const b of this.A) b(a);
            return Zv(Qh(a, 1))
        }
    };

    function d3(a, b) {
        return a ? (a = DW(new JW(a), "__gads", b)) ? Hu(a + "t2Z7mVic") % 20 : null : null
    };

    function e3(a) {
        return a ? (a = a.match(/^[a-z]{2,3}/i)) ? a[0].toLowerCase() : "" : ""
    };

    function W0(a, b, c, d) {
        c.addEventListener("click", f3(a, b, d))
    }

    function f1(a, b, c, d, e) {
        c.setTimeout(f3(a, b, d), e)
    }

    function l2(a, b) {
        return new IntersectionObserver(f3(a, 1065, b), {
            threshold: .98
        })
    }

    function z2(a, b, c) {
        a = f3(a, 898, c);
        b.addEventListener("scroll", a, {
            passive: !0
        });
        return a
    }

    function f3(a, b, c) {
        return a.hb.lc(b, c, void 0, d => {
            d.es = a.M.ec.join(",")
        })
    }
    var h3 = class {
        constructor(a, b, c, d, e, f, g, h) {
            this.Ca = a;
            this.W = b;
            this.hb = c;
            this.Z = d;
            this.J = e;
            this.params = f;
            this.M = g;
            this.jd = h;
            this.D = new Map;
            this.A = new Map;
            this.B = new Map;
            this.g = new Map;
            this.j = new Map;
            this.l = Pa(g3, C(b, 7)) ? 1 : 0;
            for (const k of XZ(this.W)) ii(k, 6) && this.D.set(C(k, 1), C(k, 6)), ii(k, 7) && this.A.set(C(k, 1), C(k, 7)), ii(k, 5) && this.B.set(C(k, 1), C(k, 5)), wf(w(k, 10)) != null && this.g.set(C(k, 1), D(k, 10)), ii(k, 11) && this.j.set(C(k, 1), C(k, 11))
        }
        Wb(a, b, c) {
            a = f3(this, a, c);
            b.addEventListener("message", a);
            return a
        }
        Qc(a,
            b, c, d) {
            return b.setInterval(f3(this, a, c), d)
        }
        Oa(a, b) {
            this.hb.Oa(a, b, c => {
                c.es = this.M.ec.join(",")
            });
            return b
        }
        va(a) {
            return this.J.va(a)
        }
        ja() {
            return D(this.W, 12) === 2
        }
    };
    const g3 = ["ja", "zh_CN", "zh_TW"];
    const i3 = new Map([
        [1, 1],
        [2, 2]
    ]);
    async function j3(a, b, c, d, e, f, g, h) {
        var k = cC,
            l = d3(a, h) ? ? Math.floor(Ed() * 20),
            m = f.va(0),
            n = !!a && ss(a) < 488;
        h = c.W;
        var p = e3(C(h, 7)),
            t = new kq;
        l = E(t, 2, l);
        l = Jh(l, 3, Bf, c.M.ec, Sf, void 0, void 0, !0);
        d = new c3(p, f, m, l, c.M, A(h, 17), d, e, c.Rb);
        e = new h3(n, h, k, d, f, c.params, c.M, c.jd);
        k = new E2;
        k.language = p;
        g = await k3(a, b, e, g, k);
        b = d.og;
        p = c.Dc;
        a = a ? .location ? .hostname || "";
        c = c.ef;
        f = f.va(11) - m;
        m = new cq;
        e = new Gp;
        p = gi(e, 1, p);
        a = gi(p, 2, a);
        n = ai(a, 3, n);
        n = y(m, 1, n);
        m = new Hp;
        m = gi(m, 2, k.language);
        c = gi(m, 3, c);
        n = y(n, 2, c);
        n = di(n, 3, Math.round(f));
        e = XZ(h);
        h = f = c = m = a = p = 0;
        for (u of e) p += F2(C(u, 6) !== "") + F2(C(u, 7) !== "") + F2(C(u, 5) !== "") + F2(C(u, 12) !== ""), a += F2(C(u, 6) !== "") + F2(C(u, 7) !== "") + F2(C(u, 5) !== "") + F2(C(u, 12) !== ""), m += F2(C(u, 6) !== ""), c += F2(C(u, 7) !== ""), f += F2(C(u, 5) !== ""), h += F2(C(u, 12) !== "");
        var u = new aq;
        u = bi(u, 1, e.length);
        u = bi(u, 2, p);
        u = ih(u, 3, a == null ? a : zf(a));
        u = ih(u, 4, m == null ? m : zf(m));
        u = ih(u, 5, c == null ? c : zf(c));
        u = bi(u, 6, f);
        u = bi(u, 7, h);
        u = y(n, 6, u);
        if (g.length) {
            var B = new Rp;
            B = Ih(B, 1, g);
            z(u, 5, bq, B)
        } else {
            k.g = k.entries.length;
            g = new $p;
            c = k.entries;
            dh(g);
            k = g.aa;
            h = Fh(g, k, k[v] | 0, Zp, 2, 2, void 0, !0);
            f = n = 0;
            if (Array.isArray(c))
                for (B = c.length, m = 0; m < B; m++) a = c[m], h.push(a), (a = Re(a)) && !n++ && (h[v] &= -9), a || f++ || Ke(h, 4096);
            else
                for (B of c) c = B, h.push(c), (c = Re(c)) && !n++ && (h[v] &= -9), c || f++ || Ke(h, 4096);
            f && eh(k);
            z(u, 4, bq, g)
        }
        b.call(d, u)
    }
    async function l3(a, b, c, d, e, f, g, h, k) {
        var l = cC;
        const m = e3(C(c.W, 7));
        var n = f.va(0);
        var p = new kq;
        g = d3(b, g) ? ? Math.floor(Ed() * 20);
        p = E(p, 2, g);
        p = Jh(p, 3, Bf, c.M.ec, Sf, void 0, void 0, !0);
        d = new c3(m, f, n, p, c.M, A(c.W, 17), d, e, c.Rb);
        b = !!b && ss(b) < 488;
        c = new h3(b, c.W, l, d, f, c.params, c.M, c.jd);
        f = new E2;
        f.language = m;
        await c.Oa(898, i2(a, h, c, f, k))
    }
    async function k3(a, b, c, d, e) {
        if (!a) return [Op()];
        var f = a.document.body;
        if (!f || !m3(f)) return [Lp()];
        d.g.va(3) >= d.j && await y0(d, 4);
        f = [];
        (c.M.Cf && ss(a) < c.M.Cf || c.M.Bf && ts(a) < c.M.Bf) && f.push(Lp());
        if (Uh(c.W, 1).length) {
            const g = Uh(c.W, 1).map(h => i3.get(h) ? ? 0);
            f.push(Qp(new Mp, Ip(g)))
        }
        Jd() && f.push(Pp());
        f.length || await q2(a, b, c, d, e);
        return f
    }

    function m3(a) {
        try {
            (new ResizeObserver(() => {})).disconnect()
        } catch {
            return !1
        }
        return a.classList && a.classList.contains !== void 0 && a.attachShadow !== void 0
    };
    async function n3(a, b, c, d, e, f, g) {
        const h = a.performance ? .now ? new A0(a.performance) : new B0,
            k = new z0(a, h);
        if (typeof e !== "string") throw Error(`Invalid config string ${e}`);
        e = e0(e);
        var l = Eh(e, YZ, 1),
            m = c.google_ad_client;
        if (typeof m !== "string") throw new $B(`Invalid property code ${m}`);
        if (!C(e, 5) || m === C(e, 5)) {
            c = o3(c);
            m = D(e, 4) === 2 ? new o0(m, gW(a), fe(a), c) : new j0(m);
            a = M(HJ);
            l = p3(l);
            var n = q0(b) || Eh(e, YZ, 1),
                p = D(e, 4);
            var t = e.aa;
            t = Fh(e, t, t[v] | 0, zv, 3, 1);
            g = {
                W: n,
                Dc: c,
                ef: g,
                params: r0(p, t),
                Rb: s0(D(e, 4)),
                M: new g0({ ...t0(l),
                    Lg: T(Jx),
                    Ng: T(Lx),
                    ig: U(uy),
                    hg: U(ty),
                    jg: U(vy),
                    wf: U(Cy),
                    Mg: T(Kx),
                    Sc: D(e, 4) === 2,
                    Bh: U(Dy),
                    uf: U(Yx),
                    Jd: T(fy),
                    Af: U(Ny),
                    Cd: U(Hy),
                    Lf: T(hy),
                    Mf: T(iy),
                    Kc: U(ay),
                    Ne: T(Hx),
                    mh: U(Xx),
                    Gb: U(Zx),
                    Th: T(gy),
                    Vg: T(Px),
                    Ug: T(Ox),
                    Xg: T(Rx),
                    Wg: T(Qx),
                    Yg: T(Sx),
                    di: T(ky)
                }),
                jd: m
            };
            await q3(b, d, a, g, h, k, f)
        }
    }
    async function r3(a, b, c, d, e, f, g) {
        const h = a.performance ? .now ? new A0(a.performance) : new B0;
        var k = c.google_ad_client;
        if (typeof k !== "string") throw new $B(`Invalid property code ${k}`);
        if (k === C(d, 2)) {
            c = o3(c);
            d = p0(b, d, c, f, p3(Eh(d, YZ, 1)), new o0(k, gW(a), fe(a), c));
            f = d.W;
            k = new Set;
            for (var l of XZ(f).filter(m => C(m, 5))) k.add(C(l, 1));
            l = M(HJ);
            c = w0(a, "div");
            c.className = "goog-rtopics";
            c.append(document.createTextNode(C(f, 2)));
            c.ariaLabel = C(f, 4);
            c.tabIndex = 0;
            r(c, {
                "font-family": "Google Sans Text",
                "font-size": "16px",
                "font-weight": "500",
                "line-height": "24px",
                "letter-spacing": "0%",
                color: "#5F6368",
                "text-align": "center",
                "border-radius": "5px",
                "padding-left": "5px",
                "padding-right": "5px",
                "padding-top": "2px",
                "padding-bottom": "2px",
                background: "#FFFFFF"
            });
            g.appendChild(c);
            await l3(a, b, d, s3(l, h, f), [new t3(l, f)], h, e, k, g)
        }
    }

    function s3(a, b, c) {
        return [d => {
            cC.Oa(1214, KJ(a, d, b.va(25)), e => {
                e.es = p3(c)
            })
        }]
    }

    function p3(a) {
        a = [42, ...M(bs).g(), ...M(uz).g(my.g, my.defaultValue).map(Number), ...(a ? .g() ? ? [])].filter(b => b > 0);
        return [...(new Set(a))].sort((b, c) => b - c)
    }
    async function q3(a, b, c, d, e, f, g) {
        if (a) {
            const h = mE(a);
            if (h.wasReactiveAdConfigReceived[42]) return;
            h.wasReactiveAdConfigReceived[42] = !0
        }
        await j3(a, b, d, s3(c, e, d.W), [new t3(c, d.W)], e, f, g)
    }

    function O2(a, b) {
        u3(a, c => c.tk, {
            ka: 1,
            ...b
        })
    }

    function P2(a, b) {
        u3(a, c => c.Bl, {
            ka: 1,
            ...b
        })
    }

    function Q2(a, b) {
        u3(a, c => c.Cl, {
            ka: 1,
            ...b
        })
    }

    function M2(a, b) {
        u3(a, c => c.uk, {
            ka: 1,
            ...b
        })
    }

    function S2(a, b) {
        u3(a, c => c.vk, {
            ka: 1,
            ...b
        })
    }

    function V2(a, b) {
        u3(a, c => c.xk, {
            ka: 1,
            ...b
        })
    }

    function W2(a, b) {
        u3(a, c => c.wk, {
            ka: 1,
            ...b
        })
    }

    function X2(a, b) {
        u3(a, c => c.Km, {
            ka: 1,
            ...b
        })
    }

    function Y2(a, b) {
        u3(a, c => c.gl, {
            ka: 1,
            ...b
        })
    }

    function Z2(a, b) {
        u3(a, c => c.fl, {
            ka: 1,
            ...b
        })
    }

    function $2(a, b) {
        u3(a, c => c.sk, {
            ka: 1,
            ...b
        })
    }

    function u3(a, b, c) {
        a.ia && a.hb.Oa(1214, LJ(a.ia, b, c), d => {
            d.es = p3(a.g)
        })
    }

    function v3(a, b, c) {
        a.ia && a.hb.Oa(1214, MJ(a.ia, b, c), d => {
            d.es = p3(a.g)
        })
    }
    class t3 {
        constructor(a, b) {
            var c = cC;
            this.ia = a;
            this.hb = c;
            this.g = b
        }
        ng(a, b) {
            v3(this, c => c.ng, {
                we: a,
                ...b
            })
        }
        pg(a, b) {
            u3(this, c => c.pg, {
                ka: a,
                ...b
            })
        }
        click(a) {
            u3(this, b => b.Qk, {
                ka: 1,
                ...a
            })
        }
    }

    function o3(a) {
        a = a.google_page_url;
        return typeof a === "string" ? a : ""
    };

    function b_(a, b) {
        const c = a.j.getBoundingClientRect(),
            d = document.createElement("div");
        r(d, {
            width: `${c.width}px`,
            display: "flex",
            "flex-wrap": "wrap",
            "justify-content": "center",
            "align-items": "center",
            "align-content": "center",
            gap: "10px",
            "font-size": "initial"
        });
        c.bottom < 0 || c.top >= window.innerHeight ? (r(d, {
            height: "auto",
            "max-height": `${a.j.offsetHeight}px`
        }), r(a.j.parentElement, {
            height: "auto"
        }), r(a.j.parentElement.parentElement, {
            height: "auto",
            "background-color": "transparent"
        })) : r(d, {
            height: `${c.height}px`
        });
        a.j.parentElement.replaceChild(d, a.j);
        r3(a.pubWin, a.l, a.I, b, a.R, a.ef, d)
    }

    function w3(a, b) {
        b = Rs(b);
        b.r_affa && b.r_affa !== "" && (b = a_(b.r_affa), XZ(Eh(b, YZ, 1)).filter(c => C(c, 5)).length >= U(ly) && b_(a, b))
    }
    var x3 = class extends LZ {
        constructor(a, b, c, d, e, f, g) {
            super(a, b);
            this.I = c;
            this.pubWin = d;
            this.Ba = e;
            this.R = f;
            this.ef = g
        }
        V(a) {
            a["unfill-fb"] = b => {
                w3(this, b)
            }
        }
    };
    var y3 = Y(function(a, b, c, d, e, f, g) {
        const h = a.ga;
        var k = a.Ha;
        const l = a.za;
        a = a.R;
        if (c && k) {
            if (!(k = T(Nx))) try {
                k = !!c ? .location ? .hash ? .match(/\bgoog_uffb/)
            } catch (m) {
                k = !1
            }
            k ? (f = f.gd || C(g, 8), b = new x3(c, h, d, b, e, a, f)) : b = null;
            b && l(b);
            return {
                wc: b
            }
        }
        return {
            wc: null
        }
    }, {
        id: 1422,
        H: {
            wc: void 0
        }
    });

    function z3(a, b) {
        return new IntersectionObserver(b, a)
    }

    function A3(a, b, c) {
        ql(a, b, c);
        return () => rl(a, b, c)
    }
    let B3 = null;

    function C3() {
        B3 = ln()
    }

    function D3(a, b) {
        return b ? B3 === null ? (ql(a, "mousemove", C3, {
            passive: !0
        }), ql(a, "scroll", C3, {
            passive: !0
        }), C3(), !1) : ln() - B3 >= b * 1E3 : !1
    }

    function E3({
        C: a,
        element: b,
        qn: c,
        hn: d,
        gn: e = 0,
        Db: f,
        tl: g,
        options: h = {},
        lm: k = !0,
        br: l = z3
    }) {
        let m, n = !1,
            p = !1;
        const t = [],
            u = l(h, (B, F) => {
                try {
                    const R = () => {
                        t.length || (d && (t.push(A3(b, "mouseenter", () => {
                            n = !0;
                            R()
                        })), t.push(A3(b, "mouseleave", () => {
                            n = !1;
                            R()
                        }))), t.push(A3(a.document, "visibilitychange", () => R())));
                        const da = D3(a, e),
                            J = LT(a.document);
                        if (p && !n && !da && !J) m = m || a.setTimeout(() => {
                            D3(a, e) ? R() : (f(), F.disconnect())
                        }, c * 1E3);
                        else if (k || n || da || J) a.clearTimeout(m), m = void 0
                    };
                    ({
                        isIntersecting: p
                    } = B[B.length - 1]);
                    R()
                } catch (R) {
                    g &&
                        g(R)
                }
            });
        u.observe(b);
        return () => {
            u.disconnect();
            for (const B of t) B();
            m != null && a.clearTimeout(m)
        }
    };

    function F3(a, b, c, d, e) {
        return new G3(a, b, c, d, e)
    }

    function H3(a, b, c) {
        const d = a.j,
            e = a.F;
        if (e != null && d != null && Os(c, d.contentWindow) && (b = b.config, typeof b === "string")) {
            try {
                var f = JSON.parse(b);
                if (!Array.isArray(f)) return;
                a.A = lj(om, f)
            } catch (g) {
                return
            }
            a.dispose();
            f = Ph(a.A, 1);
            f <= 0 || (a.D = E3({
                C: a.l,
                element: e,
                qn: f - .2,
                hn: !Rb(),
                gn: Ph(a.A, 3),
                Db: () => void I3(a, e),
                tl: g => fs.pa(1223, g, void 0, void 0),
                options: {
                    threshold: Rh(a.A, 2, 1)
                },
                lm: !0
            }))
        }
    }

    function I3(a, b) {
        a.G();
        setTimeout(fs.lc(1224, () => {
            var c = Number(a.I.rc);
            a.I.rc = c ? c + 1 : 1;
            c = b.parentElement || null;
            c && Zz.test(c.className) || (c = Ok(document, "INS"), c.className = "adsbygoogle", b.parentNode && b.parentNode.insertBefore(c, b.nextSibling));
            T(yx) ? (J3(a, c, b), a.I.no_resize = !0, ut(YK(c), "filled", () => {
                Pk(b)
            })) : Pk(b);
            tU(c, a.I, a.l)
        }), 200)
    }

    function J3(a, b, c) {
        a.l.getComputedStyle(b).position === "static" && (b.style.position = "relative");
        c.style.position = "absolute";
        c.style.top = "0";
        c.style.left = "0";
        delete b.dataset.adsbygoogleStatus;
        delete b.dataset.adStatus;
        b.classList.remove("adsbygoogle-noablate")
    }
    var G3 = class extends LZ {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.I = c;
            this.F = d;
            this.G = e;
            this.A = this.D = null;
            (b = (b = b.contentWindow) && b.parent) && a !== b && this.ba.push(SR(b, "sth", this.Fa, this.Fe))
        }
        V(a) {
            a.av_ref = (b, c) => {
                H3(this, b, c)
            }
        }
        g() {
            super.g();
            this.F = null;
            this.D && this.D()
        }
    };
    var K3 = Y(function(a, b, c, d, e) {
        const f = a.ga,
            g = a.Ha,
            h = a.za,
            k = a.Me;
        b && g && b.IntersectionObserver && h(F3(b, f, c, d, gC(1225, () => {
            k();
            for (const l of e) l();
            e.length = 0
        })));
        return {}
    }, {
        id: 1421,
        H: {}
    });
    var L3 = class extends zY {
        constructor(a, b, c, d, e) {
            super(a);
            a = X(Z(this, PZ, {
                ga: d
            }, b.P, b.I, b.Ba), e);
            e = X(Z(this, VZ, {
                ga: d
            }, b), a.finished);
            var f = X(Z(this, QZ, {
                ga: d,
                R: c
            }, b.pubWin, b.Ba), e.finished);
            f = X(Z(this, y3, {
                ga: d,
                Ha: a.Ha,
                za: a.za,
                R: c
            }, b.pubWin, b.P, b.I, b.Ba, b.pageStateTs, b.ra), f.finished);
            f = X(Z(this, d_, {
                ga: d,
                Ha: a.Ha,
                za: a.za,
                wc: f.wc
            }, b.P, b.I, b.ea), f.finished);
            f = X(Z(this, b0, {
                ga: d,
                Ha: a.Ha,
                za: a.za
            }, b), f.finished);
            f = X(Z(this, TZ, {
                ga: d,
                Ha: a.Ha,
                za: a.za
            }, b.P, b.ea), f.finished);
            e = X(Z(this, K3, {
                    ga: d,
                    Ha: a.Ha,
                    za: a.za,
                    Me: e.Me
                },
                b.P, b.I, b.ea, b.Ba), f.finished);
            c = X(Z(this, OZ, {
                ga: d,
                za: a.za,
                R: c
            }, b.P, b.pageStateTs), e.finished);
            c = X(Z(this, W_, {
                ga: d
            }, b.P, b.I, b.Ba, b.ra), c.finished);
            this.j = X(Z(this, BZ, {
                ga: d
            }, b.P, b.ea, b.Ba), c.finished).finished
        }
    };
    var M3 = Y(function(a, b, c) {
        const d = Em(b);
        if (d)
            if (d.container === "AMP-STICKY-AD") {
                const e = f => {
                    f.data === "fill_sticky" && d.renderStart ? .()
                };
                ql(b, "message", gC(616, e));
                c.push(() => {
                    rl(b, "message", e)
                })
            } else d.renderStart ? .();
        return {}
    }, {
        id: 1419,
        H: {}
    });
    var N3 = Y(function(a) {
        const b = a.ga;
        a = a.qe;
        const c = () => {
            b && b.setAttribute("data-load-complete", "true")
        };
        a ? a.then(c) : ql(b, "load", c);
        return {}
    }, {
        id: 1416,
        H: {}
    });
    var O3 = class extends O {
        constructor(a, b) {
            super();
            this.value = a;
            jt(this, b)
        }
    };

    function P3(a, b) {
        const c = Q3(a.getBoundingClientRect()),
            d = new P(c),
            e = R3(a, b, f => {
                d.g(Q3(f.boundingClientRect))
            });
        return new O3(qt(d), () => void e.disconnect())
    }

    function R3(a, b, c) {
        b = new IntersectionObserver(d => {
            d.filter(e => e.target === a).forEach(c)
        }, {
            root: b
        });
        b.observe(a);
        return b
    }

    function Q3(a) {
        return a.height > 0 || a.width > 0
    };
    var S3 = {
        Gp: 0,
        Nq: 1,
        sq: 2,
        0: "INITIAL_RENDER",
        1: "UNRENDER",
        2: "RENDER_BACK"
    };

    function T3(a, b, c) {
        var d = [1, 2];
        const e = P3(b, c),
            f = e.value,
            g = new Ct;
        ut(f, !0, () => void U3(a, f, g, d));
        return new O3(zt(g), () => void e.dispose())
    }

    function U3(a, b, c, d) {
        const e = new RS(a);
        let f = new RS(a);
        e.start();
        f.start();
        let g = 0;
        const h = k => {
            k = {
                type: k,
                yj: ++g,
                om: PS(f),
                nm: PS(e)
            };
            f = new RS(a);
            f.start();
            return k
        };
        d && !d.includes(0) || Bt(c, h(0));
        b.listen(k => {
            k = k ? 2 : 1;
            d && !d.includes(k) || Bt(c, h(k))
        })
    };

    function V3(a, b) {
        var c = M(HJ);
        fC(1282, () => void W3(a, b, c))
    }

    function W3(a, b, c) {
        const d = X3(a);
        if (!d) throw Error("No adsbygoogle INS found");
        const e = T3(a.pubWin, b, d);
        e.value.listen(f => {
            Y3(f, d, c, () => void e.dispose())
        })
    }

    function X3(a) {
        return (a = a.ea.parentElement) && Zz.test(a.className) ? a : null
    }

    function Y3(a, b, c, d) {
        if (a.yj > 5) d();
        else {
            var e = a.type === 1;
            d = a.type === 2;
            if (!e && !d) throw Error(`Unsupported event type: ${S3[a.type]}`);
            var f = ij(sS());
            f = ci(f, 1, a.om);
            f = ci(f, 2, a.nm);
            a = ci(f, 3, a.yj);
            f = b.dataset.vignetteLoaded;
            var g = ij(qS());
            g = fi(g, 1, b.dataset.adStatus);
            g = fi(g, 2, b.dataset.sideRailStatus);
            g = fi(g, 3, b.dataset.anchorStatus);
            f = $h(g, 4, f !== void 0 ? f === "true" : void 0);
            b = getComputedStyle(b);
            g = ij(tS());
            g = fi(g, 1, b.display);
            g = fi(g, 2, b.position);
            g = fi(g, 3, b.width);
            b = fi(g, 4, b.height);
            b = bh(b);
            b = y(f, 5, b);
            b = bh(b);
            a = y(a, 4, b);
            e = e ? uS() : void 0;
            e = z(a, 5, go, e);
            d = d ? rS() : void 0;
            d = z(e, 6, go, d);
            d = kj(ij(bh(d)));
            PJ(c, d)
        }
    };
    var Z3 = Y(function(a, b) {
        a = a.ga;
        T(Dw) && V3(b, a);
        return {}
    }, {
        id: 1420,
        H: {}
    });
    const $3 = VY(function(a) {
        const b = !a.oa && a.Ka;
        return a.ta ? b && a.qd : b
    }, {
        id: 1460
    });
    var a4 = class extends SY {
        constructor(a, b, c, d, e, f, g, h) {
            super(a);
            this.ia = a;
            this.j = h;
            this.K = new aV;
            this.oa = g.oa;
            this.Ka = g.Ka;
            g = f.gf;
            f = f.zl;
            ({
                ga: b
            } = Z(this, aZ, {
                ta: this.j.ta,
                yl: this.j.ff,
                zn: b
            }));
            g = X(X(Z(this, yZ, {
                R: e
            }, d.I, d.pubWin, d.pageStateTs, d.ra), g), f);
            f = Z(this, vZ, {
                ga: b
            }, d.I, d.pubWin, d.ea);
            X(f, g.finished);
            g = Z(this, N3, {
                ga: b,
                qe: this.j.qe
            });
            X(g, f.finished);
            a = xY(this, new L3(a, d, e, b, g.finished));
            c = Z(this, $Y, {
                ga: b,
                xc: c
            }, d.I, d.ea);
            X(c, a.j);
            a = Z(this, M3, {}, d.pubWin, d.Ba);
            X(a, c.finished);
            d = Z(this, Z3, {
                ga: b
            }, d);
            X(d, a.finished);
            this.K = d.finished
        }
        async l() {
            return TY(this.ia, $3, {
                oa: this.oa,
                Ka: this.Ka,
                ta: this.j.ta,
                qd: this.j.qd
            })
        }
        A() {
            this.K.notify()
        }
    };

    function b4(a, b) {
        b.allow = b.allow && b.allow.length > 0 ? b.allow + ("; " + a) : a
    }

    function c4(a) {
        const b = Cd("IFRAME");
        Fd(a, (c, d) => {
            c != null && b.setAttribute(d, c)
        });
        return b
    };
    var d4 = Y(function(a, b) {
        a = a.Vb;
        sW("attribution-reporting", b) && b4("attribution-reporting", a);
        sW("run-ad-auction", b) && b4("run-ad-auction", a);
        return {
            hc: a
        }
    }, {
        id: 1380,
        H: {
            hc: void 0
        }
    });

    function e4(a, b, c, d) {
        if (a = tW("browsing-topics", a.document)) a = !c.google_restrict_data_processing && c.google_tag_for_under_age_of_consent !== 1 && c.google_tag_for_child_directed_treatment !== 1 && !!b.ca() && !pJ() && !A(b, 9) && !A(b, 13) && !A(b, 12) && (typeof c.google_privacy_treatments !== "string" || !c.google_privacy_treatments.split(",").includes("disablePersonalization")) && !A(b, 14) && !A(b, 16);
        if (b = a && !T(iz)) d = d ? .label, b = !(T(bz) && d && d.match(vz($y)));
        return b
    };
    var f4 = Y(function(a, b, c) {
        const d = a.th;
        var e = c.google_async_iframe_id;
        const f = c.google_ad_width,
            g = c.google_ad_height,
            h = xU(c);
        e = {
            id: e,
            name: e
        };
        e4(b, a.R, c, a.cookieDeprecationLabel) && (e.browsingTopics = "true");
        e.style = h ? `width:${f}px !IMPORTANT;height:${g}px !IMPORTANT;` : "left:0;position:absolute;top:0;border:0;" + `width:${f}px;` + `height:${g}px;`;
        e.style += "min-height:auto;max-height:none;min-width:auto;max-width:none;";
        Sd() && (e.sandbox = Qd(["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation",
            "allow-pointer-lock"
        ]).join(" "));
        c.google_video_play_muted === !1 && b4("autoplay", e);
        return {
            Vb: e,
            adUrl: d,
            wd: h
        }
    }, {
        id: 1346,
        H: {
            Vb: void 0,
            adUrl: void 0,
            wd: void 0
        }
    });

    function g4(a, b, c, d, e, f) {
        const g = d.P,
            h = d.pubWin;
        return a.google_reactive_ad_format === 9 && Uk(e, null, "fsi_container") ? (e.appendChild(f), Promise.resolve(f)) : sU(b.Gj, 525, k => {
            e.appendChild(f);
            k.createAdSlot(g, a, f, e.parentElement, jj(c), h);
            return f
        })
    }
    var h4 = tY(async function(a, b) {
        const c = a.Zg,
            d = a.R;
        if (!a.wd) return null;
        const e = b.I;
        var f = b.li;
        const g = b.ea;
        b = b.Sa;
        const h = f.P;
        f = f.pubWin;
        c.src = a.Ja;
        a = c4(c);
        return g4(e, b, d, {
            P: h,
            pubWin: f
        }, g, a)
    }, {
        id: 1396
    });
    var i4 = Y(function(a, b) {
        var c = a.Zg;
        if (a.wd) return {
            Ce: null
        };
        const d = b.ea;
        var e = b.Ba;
        b = b.li.pubWin;
        c.src = SV(a.Ja);
        a = b == b.top;
        c = c4(c);
        a && e.push(Vm(b, c));
        for (d.style.visibility = "visible"; e = d.firstChild;) d.removeChild(e);
        d.appendChild(c);
        return {
            Ce: c
        }
    }, {
        id: 1397,
        H: {
            Ce: void 0
        }
    });
    var j4 = Y(function(a, b, c, d) {
        if (!b.rpe) return {};
        BX(new LX(c, d, void 0, {
            height: b.google_ad_height,
            ei: "force",
            Ie: !0,
            Vh: !0,
            bg: b.google_ad_client
        }, null, null, !0));
        return {}
    }, {
        id: 1398,
        H: {}
    });
    var k4 = Y(function(a) {
        const b = a.Mm;
        return b ? {
            ag: b
        } : {
            ag: a.Ce
        }
    }, {
        id: 1402,
        H: {
            ag: void 0
        }
    });
    var l4 = Y(function(a, b) {
        a = a.Vb;
        T(Ry) && b.credentialless !== void 0 && (T(Sy) || b.crossOriginIsolated) && (a.credentialless = "true");
        return {
            hc: a
        }
    }, {
        id: 1372,
        H: {
            hc: void 0
        }
    });
    var m4 = Y(function(a, b) {
        a = a.Vb;
        const c = b.google_ad_width;
        b = b.google_ad_height;
        c != null && (a.width = String(c));
        b != null && (a.height = String(b));
        a.frameborder = "0";
        a.marginwidth = "0";
        a.marginheight = "0";
        a.vspace = "0";
        a.hspace = "0";
        a.allowtransparency = "true";
        a.scrolling = "no";
        return {
            hc: a
        }
    }, {
        id: 1373,
        H: {
            hc: void 0
        }
    });
    const n4 = VY(function(a) {
        return !a.oa && a.Ka && !a.ta
    }, {
        id: 1461
    });
    var o4 = class extends SY {
        constructor(a, b, c, d, e, f, g, h, k) {
            super(a);
            this.ia = a;
            this.oa = g;
            this.Ka = h;
            this.ta = k;
            const {
                Vb: l,
                adUrl: m,
                wd: n
            } = Z(this, f4, {
                th: b,
                R: d,
                cookieDeprecationLabel: f
            }, c.pubWin, c.I);
            ({
                hc: a
            } = Z(this, m4, {
                Vb: l
            }, c.I));
            ({
                hc: a
            } = Z(this, d4, {
                Vb: a
            }, e.document));
            ({
                hc: e
            } = Z(this, l4, {
                Vb: a
            }, e));
            d = wY(this, h4, {
                Zg: e,
                Ja: m,
                wd: n,
                R: d
            }, {
                I: c.I,
                li: {
                    pubWin: c.pubWin,
                    P: c.P
                },
                ea: c.ea,
                Sa: c.Sa,
                Ba: c.Ba
            });
            e = Z(this, i4, {
                Zg: e,
                Ja: m,
                wd: n
            }, {
                I: c.I,
                li: {
                    pubWin: c.pubWin,
                    P: c.P
                },
                ea: c.ea,
                Sa: c.Sa,
                Ba: c.Ba
            });
            d = Z(this, k4, {
                Mm: d.output,
                Ce: e.Ce
            });
            this.j = d.ag;
            c = Z(this, j4, {}, c.I, c.pubWin, c.ea);
            X(c, d.finished);
            this.gf = c.finished
        }
        async l() {
            return TY(this.ia, n4, {
                ta: this.ta,
                oa: this.oa,
                Ka: this.Ka
            })
        }
        A() {
            this.gf.notify();
            RU(this.j, null)
        }
    };
    var p4 = Y(function(a) {
        if (!a.O) return {};
        var b = a.La.fn;
        if (b) {
            var c = a.O;
            b = fd(b);
            c.srcdoc = Hc(b)
        }
        Qc(a.O, "allowtransparency", "true");
        Qc(a.O, "vspace", "0");
        Qc(a.O, "hspace", "0");
        return {}
    }, {
        id: 1455,
        H: {}
    });
    var q4 = Y(function(a) {
        if (!a.O) return {};
        const b = a.La.Xc,
            c = a.La.Wc;
        a.O.style.top = "0";
        a.O.style.left = "0";
        a.O.style.position = "absolute";
        a.O.style.width = `${b}px`;
        a.O.style.height = `${c}px`;
        a.O.style.minHeight = "auto";
        a.O.style.maxHeight = "none";
        a.O.style.minWidth = "auto";
        a.O.style.maxWidth = "none";
        a.O.style.removeProperty("vertical-align");
        return {}
    }, {
        id: 1456,
        H: {}
    });

    function r4(a, b = {}) {
        const c = {
            frameborder: 0,
            allowTransparency: "true",
            style: "border:0;vertical-align:bottom;",
            src: "about:blank"
        };
        ec(c, b);
        Jk(a, c)
    };

    function s4(a, b, c) {
        a.F[b] = c
    }

    function t4(a, b, c) {
        let d = {};
        d.c = a.Ib;
        d.i = a.A;
        d.s = b;
        d.p = c;
        try {
            a.D.postMessage(JSON.stringify(d), a.l)
        } catch (e) {}
    }
    class u4 extends O {
        constructor(a, b, c) {
            super();
            this.Ib = a;
            this.status = 1;
            this.D = b;
            this.l = c;
            this.vd = !1;
            this.A = Math.random();
            this.F = {};
            this.j = null;
            this.G = Aa(this.K, this);
            this.Bb = void 0
        }
        K(a) {
            if (!(this.l !== "*" && a.origin !== this.l || !this.vd && a.source != this.D)) {
                var b = null;
                try {
                    b = JSON.parse(a.data)
                } catch (c) {}
                if (sa(b) && (a = b.i, b.c === this.Ib && a != this.A)) {
                    if (this.status !== 2) try {
                        this.status = 2, a = {}, a.c = this.Ib, a.i = this.A, this.Bb && (a.e = this.Bb), this.D.postMessage(JSON.stringify(a), this.l), this.j && (this.j(), this.j = null)
                    } catch (c) {}
                    a =
                        b.s;
                    b = b.p;
                    if (typeof a === "string" && (typeof b === "string" || sa(b)) && this.F.hasOwnProperty(a)) this.F[a](b)
                }
            }
        }
        connect(a) {
            a && (this.j = a);
            ql(window, "message", this.G)
        }
        g() {
            this.status = 3;
            rl(window, "message", this.G);
            super.g()
        }
    };
    var v4 = class {
        constructor(a) {
            this.uid = a;
            this.l = null;
            this.D = this.status = 0;
            this.g = null;
            this.Ib = `sfchannel${a}`
        }
        wh() {
            return this.D === 2
        }
    };

    function w4(a) {
        const b = {};
        Ja(a, c => {
            b[c.g()] = c.j()
        });
        return b
    };

    function x4(a) {
        var b = b || window;
        var c = b.screenX || b.screenLeft || 0,
            d = b.screenY || b.screenTop || 0;
        b = new Yk(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
        c = jl(a);
        d = ll(a);
        var e = new $k(c.x, c.y, d.width, d.height);
        c = al(e);
        d = String(gl(a, "zIndex"));
        var f = new Yk(0, Infinity, Infinity, 0);
        for (var g = Gk(a), h = g.g.body, k = g.g.documentElement, l = Mk(g.g); a = il(a);)
            if ((!dd || a.clientHeight != 0 || a != h) && a != h && a != k && gl(a, "overflow") != "visible") {
                var m = jl(a);
                const n = new Dk(a.clientLeft, a.clientTop);
                m.x += n.x;
                m.y += n.y;
                f.top = Math.max(f.top, m.y);
                f.right = Math.min(f.right, m.x + a.clientWidth);
                f.bottom = Math.min(f.bottom, m.y + a.clientHeight);
                f.left = Math.max(f.left, m.x)
            }
        a = l.scrollLeft;
        l = l.scrollTop;
        f.left = Math.max(f.left, a);
        f.top = Math.max(f.top, l);
        g = Lk(g.xa() || window);
        f.right = Math.min(f.right, a + g.width);
        f.bottom = Math.min(f.bottom, l + g.height);
        l = (f = (f = f.top >= 0 && f.left >= 0 && f.bottom > f.top && f.right > f.left ? f : null) ? new $k(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ?
            bl(e, f) : null;
        g = a = 0;
        l && !(new Ek(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
        l = new Yk(0, 0, 0, 0);
        if (h = f)(h = bl(e, f)) ? (k = al(f), m = al(h), e = m.right !== k.left && k.right !== m.left, k = m.bottom !== k.top && k.bottom !== m.top, h = (h.width !== 0 || e) && (h.height !== 0 || k)) : h = !1;
        h && (l = new Yk(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
        return new y4(b, c, d, l, a, g)
    }

    function z4(a) {
        return JSON.stringify({
            windowCoords_t: a.l.top,
            windowCoords_r: a.l.right,
            windowCoords_b: a.l.bottom,
            windowCoords_l: a.l.left,
            frameCoords_t: a.j.top,
            frameCoords_r: a.j.right,
            frameCoords_b: a.j.bottom,
            frameCoords_l: a.j.left,
            styleZIndex: a.B,
            allowedExpansion_t: a.g.top,
            allowedExpansion_r: a.g.right,
            allowedExpansion_b: a.g.bottom,
            allowedExpansion_l: a.g.left,
            xInView: a.A,
            yInView: a.D
        })
    }
    var y4 = class {
        constructor(a, b, c, d, e, f) {
            this.B = c;
            this.A = e;
            this.D = f;
            this.l = Zk(a);
            this.j = Zk(b);
            this.g = Zk(d)
        }
    };
    var A4 = class {
        constructor(a) {
            this.g = a
        }
        getValue(a, b) {
            a = this.g[a];
            if (a == null) return null;
            b = a[b];
            return b === null || b === void 0 ? null : b
        }
    };
    var B4 = class {
        constructor(a, b) {
            this.Ve = a;
            this.We = b;
            this.j = this.g = !1
        }
    };
    var C4 = class {
        constructor(a, b, c, d, e, f, g, h = []) {
            this.uid = a;
            this.ba = b;
            this.F = c;
            this.permissions = d;
            this.metadata = e;
            this.g = f;
            this.vd = g;
            this.hostpageLibraryTokens = h;
            this.Bb = ""
        }
    };

    function D4(a) {
        return typeof a === "number" || typeof a === "string"
    }
    var E4 = class {
            constructor(a, b) {
                this.uid = a;
                this.Bb = b
            }
            g(a) {
                this.Bb && a && (a.sentinel = this.Bb);
                return JSON.stringify(a)
            }
        },
        F4 = class extends E4 {
            constructor(a, b, c = "") {
                super(a, c);
                this.version = b
            }
            g() {
                return super.g({
                    uid: this.uid,
                    version: this.version
                })
            }
        },
        G4 = class extends E4 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.l = b;
                this.j = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    initialWidth: this.l,
                    initialHeight: this.j
                })
            }
        },
        H4 = class extends E4 {
            constructor(a, b, c = "") {
                super(a, c);
                this.description = b
            }
            g() {
                return super.g({
                    uid: this.uid,
                    description: this.description
                })
            }
        },
        I4 = class extends E4 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.j = b;
                this.push = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    expand_t: this.j.top,
                    expand_r: this.j.right,
                    expand_b: this.j.bottom,
                    expand_l: this.j.left,
                    push: this.push
                })
            }
        },
        J4 = class extends E4 {
            constructor(a, b = "") {
                super(a, b)
            }
            g() {
                return super.g({
                    uid: this.uid
                })
            }
        },
        K4 = class extends E4 {
            constructor(a, b, c = "") {
                super(a, c);
                this.l = b
            }
            g() {
                const a = {
                    uid: this.uid,
                    newGeometry: z4(this.l)
                };
                return super.g(a)
            }
        },
        L4 = class extends K4 {
            constructor(a, b, c, d, e) {
                super(a, c, "");
                this.success =
                    b;
                this.j = d;
                this.push = e
            }
            g() {
                const a = {
                    uid: this.uid,
                    success: this.success,
                    newGeometry: z4(this.l),
                    expand_t: this.j.top,
                    expand_r: this.j.right,
                    expand_b: this.j.bottom,
                    expand_l: this.j.left,
                    push: this.push
                };
                this.Bb && (a.sentinel = this.Bb);
                return JSON.stringify(a)
            }
        },
        M4 = class extends E4 {
            constructor(a, b, c, d = "") {
                super(a, d);
                this.width = b;
                this.height = c
            }
            g() {
                return super.g({
                    uid: this.uid,
                    width: this.width,
                    height: this.height
                })
            }
        };
    var N4 = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        O4 = ["allow-top-navigation"],
        P4 = ["allow-same-origin"],
        Q4 = Qd([...N4, ...O4]);
    Qd([...N4, ...P4]);
    Qd([...N4, ...O4, ...P4]);

    function R4(a) {
        let b = null;
        a.Oj && (b = a.Oj);
        return b == null ? null : b.join(" ")
    }

    function S4({
        Za: a,
        size: b,
        gm: c
    }) {
        b === 1 ? (a.style.width = kl("100%"), a.style.height = kl("auto")) : c || (a.style.width = kl(b.width), a.style.height = kl(b.height))
    }

    function T4(a, {
        O: b,
        content: c,
        jh: d,
        size: e,
        Kl: f = "3rd party ad content",
        ld: g,
        qg: h,
        gm: k
    }) {
        const l = k || !b;
        var m = {
            shared: {
                sf_ver: a.Ab,
                ck_on: YO() ? 1 : 0,
                flash_ver: "0"
            }
        };
        c = k || !b ? c ? ? "" : "";
        var n = a.Ab,
            p = c.length;
        m = new C4(a.uid, a.ba, a.F, a.permissions, new A4(m), a.A, a.vd, a.hostpageLibraryTokens);
        var t = m.uid,
            u = m.ba,
            B = z4(m.F);
        var F = m.permissions;
        F = JSON.stringify({
            expandByOverlay: F.Ve,
            expandByPush: F.We,
            readCookie: F.g,
            writeCookie: F.j
        });
        t = {
            uid: t,
            hostPeerName: u,
            initialGeometry: B,
            permissions: F,
            metadata: JSON.stringify(m.metadata.g),
            reportCreativeGeometry: m.g,
            isDifferentSourceWindow: m.vd,
            goog_safeframe_hlt: w4(m.hostpageLibraryTokens)
        };
        m.Bb && (t.Bb = m.Bb);
        m = JSON.stringify(t);
        u = t = 0;
        e !== 1 && (t = e.width, u = e.height);
        d = {
            id: d,
            title: f,
            name: `${n};${p};${c}${m}`,
            scrolling: "no",
            marginWidth: "0",
            marginHeight: "0",
            width: String(t),
            height: String(u),
            "data-is-safeframe": "true"
        };
        l && (d.src = DZ(Nk(Ik(a.Za)), a.Ab, a.Ci, a.hostname));
        a.sandbox !== null && (d.sandbox = a.sandbox);
        g && (d.allow = g);
        h && (d.credentialless = !0);
        d["aria-label"] = "Advertisement";
        d.tabIndex =
            0;
        k ? (a.Za.removeChild(b), r4(b, d), a.O = b) : b ? (a.O = b, Jk(a.O, d)) : (b = Cd("IFRAME"), r4(b, d), a.O = b);
        a.A && (a.O.style.minWidth = "100%");
        a.Za.appendChild(a.O)
    }

    function U4(a) {
        if (a.status === 1 || a.status === 2) switch (a.B) {
            case 0:
                V4(a);
                W4(a);
                a.B = 1;
                break;
            case 1:
                a.B = 2;
                break;
            case 2:
                a.B = 2
        }
    }

    function X4(a) {
        a.g = new u4(a.Ib, a.O.contentWindow, a.Ub);
        s4(a.g, "init_done", b => {
            a.la(b)
        });
        s4(a.g, "register_done", b => {
            a.bb(b)
        });
        s4(a.g, "report_error", b => {
            a.reportError(b)
        });
        s4(a.g, "expand_request", b => {
            a.T(b)
        });
        s4(a.g, "collapse_request", b => {
            a.G(b)
        });
        s4(a.g, "creative_geometry_update", b => {
            a.K(b)
        });
        a.g.connect(() => {
            a.Fa()
        })
    }

    function V4(a) {
        a.l = x4(a.O);
        t4(a.g, "geometry_update", (new K4(a.uid, a.l)).g())
    }

    function W4(a) {
        a.V = window.setTimeout(() => {
            if (a.status === 1 || a.status === 2) switch (a.B) {
                case 0:
                case 1:
                    a.B = 0;
                    break;
                case 2:
                    V4(a), W4(a), a.B = 1
            }
        }, 1E3)
    }
    var Y4 = class extends v4 {
        constructor(a) {
            super(a.uniqueId);
            this.V = -1;
            this.ia = a.ia;
            this.A = a.size === 1;
            this.permissions = new B4(a.permissions.Ve && !this.A, a.permissions.We && !this.A);
            this.Za = a.Za;
            this.hostpageLibraryTokens = a.hostpageLibraryTokens ? ? [];
            const {
                protocol: b,
                host: c
            } = window.location;
            this.ba = b === "file:" ? "*" : `${b}//${c}`;
            this.vd = !!a.vd;
            this.hostname = a.Mj ? EZ(a.Mj) : "//tpc.googlesyndication.com";
            this.Ub = a.O ? "*" : `https:${this.hostname}`;
            this.sandbox = R4(a);
            this.j = new gX;
            S4(a);
            this.l = this.F = x4(a.Za);
            this.Ab =
                a.Ab || "0-0-0";
            this.Ci = a.Ci ? ? "";
            this.O = null;
            T4(this, a);
            this.J = tA(412, () => {
                U4(this)
            }, a.Zb);
            this.B = 0;
            const d = tA(415, () => {
                this.O && (this.O.name = "", a.Aj && a.Aj(), rl(this.O, "load", d))
            }, a.Zb);
            ql(this.O, "load", d);
            this.la = tA(413, this.la, a.Zb);
            this.bb = tA(417, this.bb, a.Zb);
            this.reportError = tA(419, this.reportError, a.Zb);
            this.T = tA(411, this.T, a.Zb);
            this.G = tA(409, this.G, a.Zb);
            this.K = tA(410, this.K, a.Zb);
            this.Fa = tA(416, this.Fa, a.Zb);
            X4(this)
        }
        Fa() {
            ql(window, "resize", this.J);
            ql(window, "scroll", this.J)
        }
        la(a) {
            try {
                if (this.status !==
                    0) throw Error("Container already initialized");
                if (typeof a !== "string") throw Error("Could not parse serialized message");
                const c = JSON.parse(a);
                if (!sa(c) || !D4(c.uid) || typeof c.version !== "string") throw Error("Cannot parse JSON message");
                var b = new F4(c.uid, c.version, c.sentinel || "");
                if (this.uid !== b.uid || this.Ab !== b.version) throw Error("Wrong source container");
                this.status = 1
            } catch (c) {
                this.ia ? .error(`Invalid INITIALIZE_DONE message. Reason: ${c.message}`)
            }
        }
        bb(a) {
            try {
                if (this.status !== 1) throw Error("Container not initialized");
                if (typeof a !== "string") throw Error("Could not parse serialized message");
                const b = JSON.parse(a);
                if (!sa(b) || !D4(b.uid) || typeof b.initialWidth !== "number" || typeof b.initialHeight !== "number") throw Error("Cannot parse JSON message");
                if (this.uid !== (new G4(b.uid, b.initialWidth, b.initialHeight, b.sentinel || "")).uid) throw Error("Wrong source container");
                this.status = 2
            } catch (b) {
                this.ia ? .error(`Invalid REGISTER_DONE message. Reason: ${b.message}`)
            }
        }
        reportError(a) {
            try {
                if (typeof a !== "string") throw Error("Could not parse serialized message");
                const c = JSON.parse(a);
                if (!sa(c) || !D4(c.uid) || typeof c.description !== "string") throw Error("Cannot parse JSON message");
                var b = new H4(c.uid, c.description, c.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                this.ia ? .info(`Ext reported an error. Description: ${b.description}`)
            } catch (c) {
                this.ia ? .error(`Invalid REPORT_ERROR message. Reason: ${c.message}`)
            }
        }
        T(a) {
            try {
                if (this.status !== 2) throw Error("Container is not registered");
                if (this.D !== 0) throw Error("Container is not collapsed");
                if (typeof a !== "string") throw Error("Could not parse serialized message");
                const J = JSON.parse(a);
                if (!sa(J) || !D4(J.uid) || typeof J.expand_t !== "number" || typeof J.expand_r !== "number" || typeof J.expand_b !== "number" || typeof J.expand_l !== "number" || typeof J.push !== "boolean") throw Error("Cannot parse JSON message");
                var b = new I4(J.uid, new Yk(J.expand_t, J.expand_r, J.expand_b, J.expand_l), J.push, J.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                if (!(b.j.top >= 0 && b.j.left >= 0 && b.j.bottom >= 0 &&
                        b.j.right >= 0)) throw Error("Invalid expansion amounts");
                var c;
                if (c = b.push && this.permissions.We || !b.push && this.permissions.Ve) {
                    var d = b.j,
                        e = b.push,
                        f = this.l = x4(this.O);
                    if (d.top <= f.g.top && d.right <= f.g.right && d.bottom <= f.g.bottom && d.left <= f.g.left) {
                        if (!e)
                            for (let N = this.O.parentNode; N && N.style; N = N.parentNode) dX(this.j, N, "overflowX", "visible", "important"), dX(this.j, N, "overflowY", "visible", "important");
                        var g = al(new $k(0, 0, this.l.j.getWidth(), this.l.j.getHeight()));
                        sa(d) ? (g.top -= d.top, g.right += d.right, g.bottom +=
                            d.bottom, g.left -= d.left) : (g.top -= d, g.right += Number(void 0), g.bottom += Number(void 0), g.left -= Number(void 0));
                        dX(this.j, this.Za, "position", "relative");
                        dX(this.j, this.O, "position", "absolute");
                        if (e) {
                            var h = this.j,
                                k = this.Za,
                                l = g.getWidth();
                            dX(h, k, "width", `${l}px`);
                            var m = this.j,
                                n = this.Za,
                                p = g.getHeight();
                            dX(m, n, "height", `${p}px`)
                        } else dX(this.j, this.O, "zIndex", "10000");
                        var t = this.j,
                            u = this.O,
                            B = g.getWidth();
                        dX(t, u, "width", `${B}px`);
                        var F = this.j,
                            R = this.O,
                            da = g.getHeight();
                        dX(F, R, "height", `${da}px`);
                        dX(this.j,
                            this.O, "left", `${g.left}px`);
                        dX(this.j, this.O, "top", `${g.top}px`);
                        this.D = 2;
                        this.l = x4(this.O);
                        c = !0
                    } else c = !1
                }
                a = c;
                t4(this.g, "expand_response", (new L4(this.uid, a, this.l, b.j, b.push)).g());
                if (!a) throw Error("Viewport or document body not large enough to expand into.");
            } catch (J) {
                this.ia ? .error(`Invalid EXPAND_REQUEST message. Reason: ${J.message}`)
            }
        }
        G(a) {
            try {
                if (this.status !== 2) throw Error("Container is not registered");
                if (!this.wh()) throw Error("Container is not expanded");
                if (typeof a !== "string") throw Error("Could not parse serialized message");
                const b = JSON.parse(a);
                if (!sa(b) || !D4(b.uid)) throw Error("Cannot parse JSON message");
                if (this.uid !== (new J4(b.uid, b.sentinel || "")).uid) throw Error("Wrong source container");
                this.collapse();
                t4(this.g, "collapse_response", (new K4(this.uid, this.l)).g())
            } catch (b) {
                this.ia ? .error(`Invalid COLLAPSE_REQUEST message. Reason: ${b.message}`)
            }
        }
        collapse() {
            fX(this.j);
            this.D = 0;
            this.O && (this.l = x4(this.O))
        }
        K(a) {
            try {
                if (typeof a !== "string") throw Error("Could not parse serialized message");
                const c = JSON.parse(a);
                if (!sa(c) ||
                    !D4(c.uid) || typeof c.width !== "number" || typeof c.height !== "number" || c.sentinel && typeof c.sentinel !== "string") throw Error("Cannot parse JSON message");
                var b = new M4(c.uid, c.width, c.height, c.sentinel || "");
                if (this.uid !== b.uid) throw Error("Wrong source container");
                const d = String(b.height);
                this.A ? d !== this.O.height && (this.O.height = d, U4(this)) : this.ia ? .error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            } catch (c) {
                this.ia ? .error(`Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: ${c.message}`)
            }
        }
        destroy() {
            this.status !==
                100 && (this.wh() && (fX(this.j), this.D = 0), window.clearTimeout(this.V), this.V = -1, this.B = 3, this.g && (this.g.dispose(), this.g = null), rl(window, "resize", this.J), rl(window, "scroll", this.J), this.Za && this.O && this.Za === (this.O.parentElement || null) && this.Za.removeChild(this.O), this.Za = this.O = null, this.status = 100)
        }
    };
    var Z4 = Y(function(a) {
        const b = a.La.jh,
            c = a.La.Xc,
            d = a.La.Wc,
            e = a.La.ea,
            f = a.La.qg,
            {
                promise: g,
                resolve: h
            } = ja(Promise, "withResolvers").call(Promise);
        a = (new Y4({
            Za: e,
            jh: b,
            Kl: b,
            size: new Ek(c, d),
            content: a.mk,
            Aj: h,
            uniqueId: b,
            Oj: a.xe ? ? void 0,
            permissions: {
                Ve: !1,
                We: !1
            },
            Mj: GZ(),
            qg: f,
            ld: a.ld ? .join(";"),
            Ab: a.Ab
        })).O;
        return {
            ff: a,
            qd: !!a,
            qe: g
        }
    }, {
        id: 1453,
        H: {
            ff: void 0,
            qd: void 0,
            qe: void 0
        }
    });
    var $4 = Y(function() {
        return Sd() ? {
            xe: Q4
        } : {
            xe: void 0
        }
    }, {
        id: 1475,
        H: {
            xe: void 0
        }
    });
    const a5 = ["run-ad-auction", "attribution-reporting"];
    var b5 = Y(function(a, b) {
        a = a.La.Ck;
        const c = a5.filter(d => sW(d, b));
        a && c.push("autoplay");
        return {
            ld: c
        }
    }, {
        id: 1476,
        H: {
            ld: void 0
        }
    });

    function c5() {
        var a = vz(dz) || "0-0-0";
        const b = a.split("-").map(d => Number(d)),
            c = ["0", "0", "0"].map(d => Number(d));
        for (let d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "0-0-0"
    }
    var d5 = Y(function() {
        return {
            Ab: c5()
        }
    }, {
        id: 1477,
        H: {
            Ab: void 0
        }
    });
    var e5 = class extends zY {
        constructor(a, b, c, d) {
            super(a);
            this.j = new aV;
            ({
                xe: a
            } = Z(this, $4, {}));
            const {
                Ab: e
            } = Z(this, d5, {});
            ({
                ld: b
            } = Z(this, b5, {
                La: d
            }, b));
            const {
                ff: f,
                qd: g,
                qe: h
            } = Z(this, Z4, {
                mk: c,
                xe: a,
                ld: b,
                Ab: e,
                La: d
            });
            c = Z(this, p4, {
                O: f,
                La: d
            });
            d = X(Z(this, q4, {
                O: f,
                La: d
            }), c.finished);
            this.A = this.l = f;
            this.K = g;
            this.la = h;
            this.j = d.finished
        }
    };
    var f5 = Y(function(a, b, c, d) {
        return {
            La: {
                jh: c.google_async_iframe_id,
                Xc: c.google_ad_width,
                Wc: c.google_ad_height,
                ea: b,
                Ck: c.google_video_play_muted === !1,
                fn: c.dash || "",
                qg: T(Ry) && d.credentialless !== void 0 && (T(Sy) || d.crossOriginIsolated)
            }
        }
    }, {
        id: 1482,
        H: {
            La: void 0
        }
    });
    var g5 = tY(async function(a) {
        const b = a.Ol,
            c = a.browsingTopics;
        a = SV(a.adUrl);
        try {
            return {
                response: await fetch(a, {
                    credentials: b ? "include" : "omit",
                    ...(c ? {
                        browsingTopics: c
                    } : {})
                })
            }
        } catch (d) {
            return {
                error: d
            }
        }
    }, {
        id: 1452
    });
    var h5 = Y(function(a, b) {
        return {
            Bi: e4(b.pubWin, a.R, b.I, a.cookieDeprecationLabel)
        }
    }, {
        id: 1481,
        H: {
            Bi: void 0
        }
    });
    var i5 = Y(function(a, b) {
        b = b.Ua;
        a = a.R.ca();
        return {
            output: !b && a
        }
    }, {
        id: 1474,
        H: {
            output: void 0
        }
    });
    var j5 = class extends Error {
        constructor(a) {
            super(a)
        }
    };
    j5.prototype.name = "NetworkError";
    var k5 = tY(async function(a) {
        let b = Promise.resolve(null);
        const c = a.Vi.response;
        a = a.Vi.error;
        c ? c.status >= 300 ? jC(1454, new j5(`Received non-200 response from BOW, status: ${c.status}`)) : b = c.text() : a && jC(1454, a);
        return b
    }, {
        id: 1454
    });
    var l5 = class extends zY {
        constructor(a, b) {
            super(a);
            ({
                output: a
            } = wY(this, k5, {
                Vi: b
            }));
            this.j = a
        }
    };
    const m5 = VY(function(a) {
        return a.ta && !a.oa && a.Ka
    }, {
        id: 1487
    });
    var n5 = class extends SY {
        constructor(a, b, c, d, e, f) {
            super(a);
            this.ia = a;
            this.ta = f.ta;
            this.oa = f.oa;
            this.fh = f.fh;
            f = Z(this, f5, {}, c.ea, c.I, c.pubWin);
            e = Z(this, h5, {
                R: d,
                cookieDeprecationLabel: e
            }, c);
            ({
                output: d
            } = Z(this, i5, {
                R: d
            }, c));
            ({
                output: b
            } = wY(this, g5, {
                Ol: d,
                browsingTopics: e.Bi,
                adUrl: b
            }));
            ({
                j: b
            } = xY(this, new l5(a, b)));
            const {
                l: g,
                A: h,
                la: k,
                K: l,
                j: m
            } = xY(this, new e5(a, c.pubWin.document, b, f.La));
            this.Ub = g;
            this.j = h;
            this.Fe = k;
            this.K = l;
            this.la = m
        }
        async l() {
            return TY(this.ia, m5, {
                ta: this.ta,
                oa: this.oa,
                Ka: this.fh
            })
        }
        A() {
            RU(this.Ub,
                null);
            RU(this.j, null);
            RU(this.K, !1);
            RU(this.Fe, null);
            this.la.notify()
        }
    };
    var o5 = class extends zY {
        constructor(a, b, c, d) {
            super(a);
            const {
                R: e
            } = X(Z(this, BY, {}, b), c);
            c = X(Z(this, ZY, {}, b), c);
            c = X(Z(this, EY, {
                R: e
            }, b.pubWin), c.finished);
            d = X(Z(this, CY, {
                R: e,
                Ua: d
            }, b.pubWin, b.ra, b.I, b.pageStateTs), c.finished);
            var f = xY(this, new XY(a, b, e, d.Ld, d.finished));
            c = X(Z(this, YY, {}, b), f.j).ta;
            var g = xY(this, new AY(a, b, e, f.j, c));
            const h = g.j.xm,
                k = g.j.oa;
            g = g.j.xc;
            const l = xY(this, new n5(a, h, b, e, f.cookieDeprecationLabel, {
                ta: c,
                oa: k,
                fh: d.Ld
            }));
            f = xY(this, new o4(a, h, b, e, b.pubWin, f.cookieDeprecationLabel, k,
                d.Ld, c));
            this.j = xY(this, new a4(a, f.j, g, b, e, {
                gf: f.gf,
                zl: l.la
            }, {
                oa: k,
                Ka: d.Ld
            }, {
                ta: c,
                ff: l.j,
                qd: l.K
            })).K
        }
    };
    var p5 = Y(function(a, b) {
        b.g |= a.Ze;
        return {
            Sj: b
        }
    }, {
        id: 1412,
        H: {
            Sj: void 0
        }
    });
    const q5 = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        r5 = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        s5 = {
            sf: a => a.listener,
            ke: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            Ed: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        t5 = {
            sf: a => a.listener,
            ke: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            Ed: (a, b) => {
                b = b.__gppReturn;
                const c = b.returnValue.data;
                a ? .(c, b.success)
            }
        };

    function u5(a) {
        let b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Ph: b.__gppReturn.callId
        }
    }

    function v5(a, b, c) {
        let d = !(b.includes(2) && c ? .idpcApplies),
            e = !1,
            f = !1,
            g = !1;
        if (a && !a.startsWith("GPP_ERROR_STRING_")) {
            const W5 = EP(a.split("~")[0]),
                X5 = zP(a),
                WE = Sh(W5, 3);
            for (let Im = 0; Im < WE.length; ++Im) {
                const XE = WE[Im];
                if (!b.includes(XE)) continue;
                const wb = X5[Im];
                switch (XE) {
                    case 2:
                        if (c ? .supportTcfeu) {
                            a: {
                                const na = oR(wb);
                                if (!na || !wb) {
                                    var h = null;
                                    break a
                                }
                                const bb = x(na, ZQ, 1),
                                    Jm = x(na, CQ, 2) || new CQ;
                                var k = Ph(bb, 9),
                                    l = Ph(bb, 4),
                                    m = Ph(bb, 5),
                                    n = A(bb, 10),
                                    p = A(bb, 11),
                                    t = C(bb, 16),
                                    u = A(bb, 15),
                                    B = {
                                        consents: pR(Uh(bb, 13), bR),
                                        legitimateInterests: pR(Uh(bb,
                                            14), bR)
                                    },
                                    F = {
                                        consents: pR(Sh(bb, 17)),
                                        legitimateInterests: pR(Sh(bb, 18))
                                    },
                                    R = pR(Uh(bb, 12), cR),
                                    da = Gh(bb, xQ, 19, ph());
                                const Km = {};
                                for (const xs of da) {
                                    const ys = D(xs, 1);
                                    Km[ys] = Km[ys] || {};
                                    for (const Y5 of Sh(xs, 3)) Km[ys][Y5] = D(xs, 2)
                                }
                                h = {
                                    tcString: wb,
                                    tcfPolicyVersion: k,
                                    gdprApplies: !0,
                                    cmpId: l,
                                    cmpVersion: m,
                                    isServiceSpecific: n,
                                    useNonStandardStacks: p,
                                    publisherCC: t,
                                    purposeOneTreatment: u,
                                    purpose: B,
                                    vendor: F,
                                    specialFeatureOptins: R,
                                    publisher: {
                                        restrictions: Km,
                                        consents: pR(Uh(Jm, 1), bR),
                                        legitimateInterests: pR(Uh(Jm, 2), bR),
                                        customPurposes: {
                                            consents: pR(Sh(Jm,
                                                3)),
                                            legitimateInterests: pR(Sh(Jm, 4))
                                        }
                                    }
                                }
                            }
                            const oa = h;
                            if (!oa) throw Error("Cannot decode TCF V2 section string.");d = oK(oa);!rK(oa, ["3", "4"], 0) && (e = !0);!rK(oa, ["2", "7", "9", "10"], 3) && (f = !0)
                        }
                        break;
                    case 7:
                        const YE = rQ(wb, c ? .supportUsnatV2 ? [1, 2] : [1]),
                            Lm = x(YE, kQ, 1),
                            ZE = x(Lm, hQ, 12);
                        D(Lm, 8) !== 1 && D(Lm, 9) !== 1 && D(Lm, 10) !== 1 && ZE ? .j() !== 1 && ZE ? .g() !== 1 || (e = !0);
                        var J = x(YE, kQ, 1);
                        const $E = x(J, hQ, 12) ? .B();
                        $E !== 1 && $E !== 2 || (g = !0);
                        break;
                    case 8:
                        if (wb.length === 0) throw Error("Cannot decode empty USCA section string.");
                        const wj =
                            wb.split(".");
                        if (wj.length > 2) throw Error(`Expected at most 1 sub-section but got ${wj.length-1} when decoding ${wb}.`);
                        var N = void 0,
                            aa = void 0,
                            Ya = void 0,
                            Sb = void 0,
                            za = void 0,
                            Ha = void 0,
                            Yc = void 0,
                            Ic = void 0,
                            Jc = void 0,
                            Id = void 0,
                            ua = void 0,
                            pd = void 0,
                            Ne = void 0,
                            Fg = void 0,
                            Gg = void 0,
                            Hg = void 0,
                            Ig = void 0,
                            Jg = void 0,
                            Kg = void 0,
                            Lg = void 0,
                            Mg = void 0,
                            Ng = void 0,
                            Og = void 0,
                            Pg = wj[0];
                        if (Pg.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Mm = DP(Pg, NP);
                        const zs = BP(Mm.slice(0, 6));
                        Mm = Mm.slice(6);
                        if (zs !==
                            1) throw Error(`Unable to decode unsupported USCA Section specification version ${zs} - only version 1 is supported.`);
                        let As = 0;
                        const Ra = [];
                        for (let oa = 0; oa < MP.length; oa++) {
                            const na = MP[oa];
                            Ra.push(BP(Mm.slice(As, As + na)));
                            As += na
                        }
                        var Ti = new IP;
                        Og = E(Ti, 1, zs);
                        var Ui = Ra.shift();
                        Ng = G(Og, 2, Ui);
                        var Vi = Ra.shift();
                        Mg = G(Ng, 3, Vi);
                        var Wi = Ra.shift();
                        Lg = G(Mg, 4, Wi);
                        var Xi = Ra.shift();
                        Kg = G(Lg, 5, Xi);
                        var Yi = Ra.shift();
                        Jg = G(Kg, 6, Yi);
                        var Cf = new HP,
                            Zi = Ra.shift();
                        Ig = G(Cf, 1, Zi);
                        var Qg = Ra.shift();
                        Hg = G(Ig, 2, Qg);
                        var $i = Ra.shift();
                        Gg = G(Hg, 3, $i);
                        var Df = Ra.shift();
                        Fg = G(Gg, 4, Df);
                        var aj = Ra.shift();
                        Ne = G(Fg, 5, aj);
                        var bj = Ra.shift();
                        pd = G(Ne, 6, bj);
                        var mc = Ra.shift();
                        ua = G(pd, 7, mc);
                        var cj = Ra.shift();
                        Id = G(ua, 8, cj);
                        var dj = Ra.shift();
                        Jc = G(Id, 9, dj);
                        Ic = y(Jg, 7, Jc);
                        var ej = new GP,
                            Rg = Ra.shift();
                        Yc = G(ej, 1, Rg);
                        var Sg = Ra.shift();
                        Ha = G(Yc, 2, Sg);
                        za = y(Ic, 8, Ha);
                        var Tg = Ra.shift();
                        Sb = G(za, 9, Tg);
                        var Ug = Ra.shift();
                        Ya = G(Sb, 10, Ug);
                        var Yb = Ra.shift();
                        aa = G(Ya, 11, Yb);
                        var qd = Ra.shift();
                        const aF = N = G(aa, 12, qd);
                        if (wj.length === 1) var Qa = KP(aF);
                        else {
                            var Zb = KP(aF),
                                Vg = void 0,
                                ae = void 0,
                                Oe = void 0,
                                nc = wj[1];
                            if (nc.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            const oa = DP(nc, 3),
                                na = BP(oa.slice(0, 2));
                            if (na < 0 || na > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${na}.`);
                            Oe = na + 1;
                            const bb = BP(oa.charAt(2));
                            var $b = new JP;
                            ae = G($b, 2, Oe);
                            Vg = ai(ae, 1, !!bb);
                            Qa = y(Zb, 2, Vg)
                        }
                        const bF = Qa,
                            cF = x(bF, IP, 1);
                        D(cF, 5) !== 1 && D(cF, 6) !== 1 || (e = !0);
                        var Zc = x(bF, IP, 1);
                        const Nm = x(Zc, GP, 8);
                        Nm ? .g() !== 1 && Nm ? .g() !== 2 && Nm ? .j() !== 1 && Nm ? .j() !== 2 || (g = !0);
                        break;
                    case 9:
                        if (wb.length ===
                            0) throw Error("Cannot decode empty USVA section string.");
                        let Om = DP(wb, wQ);
                        const Bs = BP(Om.slice(0, 6));
                        Om = Om.slice(6);
                        if (Bs !== 1) throw Error(`Unable to decode unsupported USVA Section specification version ${Bs} - only version 1 is supported.`);
                        let Cs = 0;
                        const kb = [];
                        for (let oa = 0; oa < vQ.length; oa++) {
                            const na = vQ[oa];
                            kb.push(BP(Om.slice(Cs, Cs + na)));
                            Cs += na
                        }
                        var rd = Bs,
                            ub = new uQ,
                            oc = E(ub, 1, rd),
                            Wg = kb.shift(),
                            fj = G(oc, 2, Wg),
                            Xg = kb.shift(),
                            sd = G(fj, 3, Xg),
                            Yg = kb.shift(),
                            Ef = G(sd, 4, Yg),
                            Ff = kb.shift(),
                            be = G(Ef, 5, Ff),
                            Zg = kb.shift();
                        var $g = G(be, 6, Zg);
                        var Tq = new tQ,
                            Uq = kb.shift(),
                            Vq = G(Tq, 1, Uq),
                            Wq = kb.shift(),
                            Xq = G(Vq, 2, Wq),
                            Yq = kb.shift(),
                            Zq = G(Xq, 3, Yq),
                            $q = kb.shift(),
                            ar = G(Zq, 4, $q),
                            br = kb.shift(),
                            cr = G(ar, 5, br),
                            dr = kb.shift(),
                            er = G(cr, 6, dr),
                            fr = kb.shift(),
                            gr = G(er, 7, fr),
                            hr = kb.shift();
                        var ir = G(gr, 8, hr);
                        var jr = y($g, 7, ir),
                            kr = kb.shift(),
                            lr = G(jr, 8, kr),
                            mr = kb.shift(),
                            nr = G(lr, 9, mr),
                            or = kb.shift(),
                            pr = G(nr, 10, or),
                            qr = kb.shift();
                        const Ds = G(pr, 11, qr);
                        D(Ds, 5) !== 1 && D(Ds, 6) !== 1 || (e = !0);
                        const dF = D(Ds, 8);
                        dF !== 1 && dF !== 2 || (g = !0);
                        break;
                    case 10:
                        if (wb.length === 0) throw Error("Cannot decode empty USCO section string.");
                        const xj = wb.split(".");
                        if (xj.length > 2) throw Error(`Expected at most 2 segments but got ${xj.length} when decoding ${wb}.`);
                        var rr = void 0,
                            Rl = void 0,
                            Sl = void 0,
                            Tl = void 0,
                            Ul = void 0,
                            Vl = void 0,
                            Wl = void 0,
                            Xl = void 0,
                            Yl = void 0,
                            Zl = void 0,
                            $l = void 0,
                            am = void 0,
                            bm = void 0,
                            cm = void 0,
                            dm = void 0,
                            em = void 0,
                            fm = void 0,
                            gm = void 0,
                            hm = xj[0];
                        if (hm.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Pm = DP(hm, UP);
                        const Es = BP(Pm.slice(0, 6));
                        Pm = Pm.slice(6);
                        if (Es !== 1) throw Error(`Unable to decode unsupported USCO Section specification version ${Es} - only version 1 is supported.`);
                        let Fs = 0;
                        const xb = [];
                        for (let oa = 0; oa < TP.length; oa++) {
                            const na = TP[oa];
                            xb.push(BP(Pm.slice(Fs, Fs + na)));
                            Fs += na
                        }
                        var sr = new PP;
                        gm = E(sr, 1, Es);
                        var tr = xb.shift();
                        fm = G(gm, 2, tr);
                        var Si = xb.shift();
                        em = G(fm, 3, Si);
                        var Ql = xb.shift();
                        dm = G(em, 4, Ql);
                        var Z5 = xb.shift();
                        cm = G(dm, 5, Z5);
                        var $5 = xb.shift();
                        bm = G(cm, 6, $5);
                        var a6 = new OP,
                            b6 = xb.shift();
                        am = G(a6, 1, b6);
                        var c6 = xb.shift();
                        $l = G(am, 2, c6);
                        var d6 = xb.shift();
                        Zl = G($l, 3, d6);
                        var e6 = xb.shift();
                        Yl = G(Zl, 4, e6);
                        var f6 = xb.shift();
                        Xl = G(Yl, 5, f6);
                        var g6 = xb.shift();
                        Wl = G(Xl, 6, g6);
                        var h6 =
                            xb.shift();
                        Vl = G(Wl, 7, h6);
                        Ul = y(bm, 7, Vl);
                        var i6 = xb.shift();
                        Tl = G(Ul, 8, i6);
                        var j6 = xb.shift();
                        Sl = G(Tl, 9, j6);
                        var k6 = xb.shift();
                        Rl = G(Sl, 10, k6);
                        var l6 = xb.shift();
                        const eF = rr = G(Rl, 11, l6);
                        if (xj.length === 1) var fF = RP(eF);
                        else {
                            var m6 = RP(eF),
                                gF = void 0,
                                hF = void 0,
                                iF = void 0,
                                jF = xj[1];
                            if (jF.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            const oa = DP(jF, 3),
                                na = BP(oa.slice(0, 2));
                            if (na < 0 || na > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${na}.`);
                            iF = na + 1;
                            const bb = BP(oa.charAt(2));
                            var n6 = new QP;
                            hF = G(n6, 2, iF);
                            gF = ai(hF, 1, !!bb);
                            fF = y(m6, 2, gF)
                        }
                        const kF = fF,
                            lF = x(kF, PP, 1);
                        D(lF, 5) !== 1 && D(lF, 6) !== 1 || (e = !0);
                        var o6 = x(kF, PP, 1);
                        const mF = D(o6, 8);
                        mF !== 1 && mF !== 2 || (g = !0);
                        break;
                    case 12:
                        if (wb.length === 0) throw Error("Cannot decode empty usct section string.");
                        const yj = wb.split(".");
                        if (yj.length > 2) throw Error(`Expected at most 2 segments but got ${yj.length} when decoding ${wb}.`);
                        var p6 = void 0,
                            nF = void 0,
                            oF = void 0,
                            pF = void 0,
                            qF = void 0,
                            rF = void 0,
                            sF = void 0,
                            tF = void 0,
                            uF = void 0,
                            vF = void 0,
                            wF = void 0,
                            xF =
                            void 0,
                            yF = void 0,
                            zF = void 0,
                            AF = void 0,
                            BF = void 0,
                            CF = void 0,
                            DF = void 0,
                            EF = void 0,
                            FF = void 0,
                            GF = void 0,
                            HF = void 0,
                            IF = yj[0];
                        if (IF.length === 0) throw Error("Cannot decode empty core segment string.");
                        let Qm = DP(IF, bQ);
                        const Gs = BP(Qm.slice(0, 6));
                        Qm = Qm.slice(6);
                        if (Gs !== 1) throw Error(`Unable to decode unsupported USCT Section specification version ${Gs} - only version 1 is supported.`);
                        let Hs = 0;
                        const Va = [];
                        for (let oa = 0; oa < aQ.length; oa++) {
                            const na = aQ[oa];
                            Va.push(BP(Qm.slice(Hs, Hs + na)));
                            Hs += na
                        }
                        var q6 = new XP;
                        HF = E(q6,
                            1, Gs);
                        var r6 = Va.shift();
                        GF = G(HF, 2, r6);
                        var s6 = Va.shift();
                        FF = G(GF, 3, s6);
                        var t6 = Va.shift();
                        EF = G(FF, 4, t6);
                        var u6 = Va.shift();
                        DF = G(EF, 5, u6);
                        var v6 = Va.shift();
                        CF = G(DF, 6, v6);
                        var w6 = new WP,
                            x6 = Va.shift();
                        BF = G(w6, 1, x6);
                        var y6 = Va.shift();
                        AF = G(BF, 2, y6);
                        var z6 = Va.shift();
                        zF = G(AF, 3, z6);
                        var A6 = Va.shift();
                        yF = G(zF, 4, A6);
                        var B6 = Va.shift();
                        xF = G(yF, 5, B6);
                        var C6 = Va.shift();
                        wF = G(xF, 6, C6);
                        var D6 = Va.shift();
                        vF = G(wF, 7, D6);
                        var E6 = Va.shift();
                        uF = G(vF, 8, E6);
                        tF = y(CF, 7, uF);
                        var F6 = new VP,
                            G6 = Va.shift();
                        sF = G(F6, 1, G6);
                        var H6 = Va.shift();
                        rF = G(sF, 2, H6);
                        var I6 = Va.shift();
                        qF = G(rF, 3, I6);
                        pF = y(tF, 8, qF);
                        var J6 = Va.shift();
                        oF = G(pF, 9, J6);
                        var K6 = Va.shift();
                        nF = G(oF, 10, K6);
                        var L6 = Va.shift();
                        const JF = p6 = G(nF, 11, L6);
                        if (yj.length === 1) var KF = ZP(JF);
                        else {
                            var M6 = ZP(JF),
                                LF = void 0,
                                MF = void 0,
                                NF = void 0,
                                OF = yj[1];
                            if (OF.length === 0) throw Error("Cannot decode empty GPC segment string.");
                            const oa = DP(OF, 3),
                                na = BP(oa.slice(0, 2));
                            if (na < 0 || na > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${na}.`);
                            NF = na + 1;
                            const bb = BP(oa.charAt(2));
                            var N6 =
                                new YP;
                            MF = G(N6, 2, NF);
                            LF = ai(MF, 1, !!bb);
                            KF = y(M6, 2, LF)
                        }
                        const PF = KF,
                            Is = x(PF, XP, 1),
                            QF = x(Is, VP, 8);
                        D(Is, 5) !== 1 && D(Is, 6) !== 1 && QF ? .j() !== 1 && QF ? .B() !== 1 || (e = !0);
                        var O6 = x(PF, XP, 1);
                        const RF = x(O6, VP, 8);
                        RF ? .g() !== 1 && RF ? .g() !== 2 || (g = !0);
                        break;
                    case 13:
                        if (wb.length === 0) throw Error("Cannot decode empty USFL section string.");
                        let Rm = DP(wb, gQ);
                        const Js = BP(Rm.slice(0, 6));
                        Rm = Rm.slice(6);
                        if (Js !== 1) throw Error(`Unable to decode unsupported USFL Section specification version ${Js} - only version 1 is supported.`);
                        let Ks =
                            0;
                        const Sa = [];
                        for (let oa = 0; oa < fQ.length; oa++) {
                            const na = fQ[oa];
                            Sa.push(BP(Rm.slice(Ks, Ks + na)));
                            Ks += na
                        }
                        var P6 = Js,
                            Q6 = new eQ,
                            R6 = E(Q6, 1, P6),
                            S6 = Sa.shift(),
                            T6 = G(R6, 2, S6),
                            U6 = Sa.shift(),
                            V6 = G(T6, 3, U6),
                            W6 = Sa.shift(),
                            X6 = G(V6, 4, W6),
                            Y6 = Sa.shift(),
                            Z6 = G(X6, 5, Y6),
                            $6 = Sa.shift();
                        var a7 = G(Z6, 6, $6);
                        var b7 = new dQ,
                            c7 = Sa.shift(),
                            d7 = G(b7, 1, c7),
                            e7 = Sa.shift(),
                            f7 = G(d7, 2, e7),
                            g7 = Sa.shift(),
                            h7 = G(f7, 3, g7),
                            i7 = Sa.shift(),
                            j7 = G(h7, 4, i7),
                            k7 = Sa.shift(),
                            l7 = G(j7, 5, k7),
                            m7 = Sa.shift(),
                            n7 = G(l7, 6, m7),
                            o7 = Sa.shift(),
                            p7 = G(n7, 7, o7),
                            q7 = Sa.shift();
                        var r7 = G(p7, 8, q7);
                        var s7 = y(a7, 7, r7);
                        var t7 = new cQ,
                            u7 = Sa.shift(),
                            v7 = G(t7, 1, u7),
                            w7 = Sa.shift(),
                            x7 = G(v7, 2, w7),
                            y7 = Sa.shift();
                        var z7 = G(x7, 3, y7);
                        var A7 = y(s7, 8, z7),
                            B7 = Sa.shift(),
                            C7 = G(A7, 9, B7),
                            D7 = Sa.shift(),
                            E7 = G(C7, 10, D7),
                            F7 = Sa.shift(),
                            G7 = G(E7, 11, F7),
                            H7 = Sa.shift();
                        const Sm = G(G7, 12, H7),
                            SF = x(Sm, cQ, 8);
                        D(Sm, 5) !== 1 && D(Sm, 6) !== 1 && SF ? .j() !== 1 && SF ? .B() !== 1 || (e = !0);
                        const TF = x(Sm, cQ, 8) ? .g();
                        TF !== 1 && TF !== 2 || (g = !0)
                }
            }
        }
        return {
            jn: d,
            xj: e,
            on: f,
            Fi: g
        }
    }
    var z5 = class extends O {
        constructor(a) {
            ({
                timeoutMs: b
            } = {});
            var b;
            super();
            this.caller = new eK(a, "__gppLocator", c => typeof c.__gpp === "function", u5);
            this.caller.F.set("addEventListener", q5);
            this.caller.D.set("addEventListener", s5);
            this.caller.F.set("removeEventListener", r5);
            this.caller.D.set("removeEventListener", t5);
            this.timeoutMs = b ? ? 500
        }
        g() {
            this.caller.dispose();
            super.g()
        }
        j() {
            return !!bK(this.caller)
        }
        addEventListener(a) {
            const b = Ab(() => {
                    a(w5, !0)
                }),
                c = this.timeoutMs === -1 ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            dK(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (d.pingData ? .gppVersion === void 0 || d.pingData.gppVersion === "1" || d.pingData.gppVersion === "1.0") {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) ? f = d : (this.removeEventListener(d.listenerId), f = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 2,
                                gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                applicableSections: [-1]
                            }
                        });
                        a(f, e)
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(x5, !0);
                            return
                        }
                        a(y5, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            dK(this.caller, "removeEventListener", {
                listener: () => {},
                listenerId: a
            })
        }
    };
    const y5 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        w5 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        x5 = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function A5(a) {
        return !a || a.length === 1 && a[0] === -1
    };

    function B5(a) {
        a = new z5(a);
        if (!a.j()) return Promise.resolve(null);
        const b = dJ(),
            c = iJ(b, 35);
        if (c) return Promise.resolve(c);
        const d = new Promise(e => {
            e = {
                resolve: e
            };
            const f = iJ(b, 36, []);
            f.push(e);
            jJ(b, 36, f)
        });
        c || c === null || (jJ(b, 35, null), a.addEventListener(e => {
            if (e.pingData.signalStatus === "ready" || A5(e.pingData.applicableSections)) {
                e = e.pingData;
                jJ(b, 35, e);
                for (const f of iJ(b, 36, [])) f.resolve(e);
                jJ(b, 36, [])
            }
        }));
        return d
    };

    function C5(a) {
        a = new xK(a, {
            timeoutMs: -1,
            Hk: !0
        });
        if (!tK(a)) return Promise.resolve(null);
        const b = dJ(),
            c = oJ(b);
        if (c) return Promise.resolve(c);
        const d = new Promise(e => {
            e = {
                resolve: e
            };
            const f = iJ(b, 25, []);
            f.push(e);
            jJ(b, 25, f)
        });
        c || c === null || (jJ(b, 24, null), a.addEventListener(e => {
            if (nK(e)) {
                jJ(b, 24, e);
                for (const f of iJ(b, 25, [])) f.resolve(e);
                jJ(b, 25, [])
            } else jJ(b, 24, null)
        }));
        return d
    };
    const D5 = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.Db({
                    Ud: c ? ? void 0,
                    Ti: d ? void 0 : 2
                })
            })
        },
        E5 = {
            sf: a => a.Db,
            ke: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            Ed: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    Ud: b.returnValue ? ? void 0,
                    Ti: b.success ? void 0 : 2
                })
            }
        };

    function F5(a) {
        let b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Ph: b.__uspapiReturn.callId
        }
    }

    function G5(a, b) {
        let c = {};
        if (bK(a.caller)) {
            var d = Ab(() => {
                b(c)
            });
            dK(a.caller, "getDataWithCallback", {
                Db: e => {
                    e.Ti || (c = e.Ud);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var H5 = class extends O {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new eK(a, "__uspapiLocator", b => typeof b.__uspapi === "function", F5);
            this.caller.F.set("getDataWithCallback", D5);
            this.caller.D.set("getDataWithCallback", E5)
        }
        g() {
            this.caller.dispose();
            super.g()
        }
    };

    function I5(a) {
        const b = new H5(a);
        return new Promise(c => {
            G5(b, d => {
                d && typeof d.uspString === "string" ? c(d.uspString) : c(null)
            })
        })
    }

    function J5(a, {
        mn: b,
        yn: c,
        Il: d
    }) {
        var e = new jP;
        var f = T(Ty) ? Oh(d, 5) != null ? d.ca() : Oh(b, 5) != null ? b.ca() : a.ca() : Oh(b, 5) != null ? b.ca() : a.ca();
        e = fP(e, f);
        f = T(Ty) ? Oh(d, 8) != null ? A(d, 8) : Oh(b, 8) != null ? A(b, 8) : void 0 : Oh(b, 8);
        e = gP(e, f);
        a = Oh(a, 14);
        a = $h(e, 14, a);
        f = Oh(b, 3);
        a = $h(a, 3, f);
        f = $f(w(b, 2));
        a = fi(a, 2, f);
        f = $f(w(b, 4));
        a = fi(a, 4, f);
        f = wf(w(b, 7));
        a = hi(a, 7, f);
        b = Oh(b, 9);
        b = $h(a, 9, b);
        a = $f(w(c, 1));
        b = fi(b, 1, a);
        c = Oh(c, 13);
        c = $h(b, 13, c);
        b = $f(w(d, 11));
        c = fi(c, 11, b);
        b = qh(d, 10, Sf, ph(), void 0, 0);
        hP(yh(c, 10, b, Bf), Oh(d, 12));
        return e
    }
    async function K5(a, {
        Ma: b,
        Zl: c
    }) {
        const [d, e, f] = await Promise.all([C5(a.pubWin), I5(a.pubWin), B5(a.pubWin)]);
        b = !!b && (T(Uy) || !PR());
        var g = fP(new jP, !b);
        c = $h(g, 14, c && navigator.globalPrivacyControl);
        g = new jP;
        if (d) {
            var h = fP(g, oK(d, {
                idpcApplies: b
            }));
            h = fi(h, 2, d.tcString);
            h = fi(h, 4, d.addtlConsent || "");
            h = hi(h, 7, d.internalErrorState);
            var k = !rK(d, ["3", "4"], 0);
            h = $h(h, 9, k);
            gP(h, !rK(d, ["2", "7", "9", "10"], 3));
            d.gdprApplies != null && $h(g, 3, d.gdprApplies)
        }
        h = new jP;
        if (e) {
            k = fi(h, 1, e);
            var l = e.toUpperCase();
            if (l.length == 4 &&
                (l.indexOf("-") == -1 || l.substring(1) === "---") && l[0] >= "1" && l[0] <= "9" && xP.hasOwnProperty(l[1]) && xP.hasOwnProperty(l[2]) && xP.hasOwnProperty(l[3])) {
                var m = new wP;
                m = E(m, 1, parseInt(l[0], 10));
                m = G(m, 2, xP[l[1]]);
                m = G(m, 3, xP[l[2]]);
                l = G(m, 4, xP[l[3]])
            } else l = null;
            l = l ? .Gl() === 2;
            $h(k, 13, l)
        }
        k = new jP;
        if (f)
            if (f.internalErrorState) fi(k, 11, f.gppString);
            else if (A5(f.applicableSections)) hP(yh(k, 10, f.applicableSections, Bf), !1), T(Ty) && fP(k, !0);
        else if (l = yh(k, 10, f.applicableSections, Bf), fi(l, 11, f.gppString), T(Ty)) try {
            const n =
                v5(f.gppString, f.applicableSections, {
                    idpcApplies: b,
                    supportTcfeu: !0,
                    supportUsnatV2: T(Vy)
                });
            gP(iP(hP(fP(k, n.jn), n.xj), n.Fi), n.on)
        } catch (n) {
            jC(1182, n), gP(iP(hP(fP(k, !b), !1), !1), !1)
        } else try {
            const n = v5(f.gppString, f.applicableSections, {
                idpcApplies: b,
                supportUsnatV2: T(Vy)
            });
            iP(hP(k, n.xj), n.Fi)
        } catch (n) {
            jC(1182, n), iP(hP(k, !1), !1)
        }
        a.R = J5(c, {
            mn: g,
            yn: h,
            Il: k
        })
    };
    var kW = class extends H {
        g() {
            return A(this, 1)
        }
    };
    var L5 = vk(kW);
    async function M5(a) {
        const b = ln(),
            c = a.ra,
            d = a.pageStateTs;
        GJ(g => {
            D(g, 1) === 0 && (g = ai(g, 2, !!d.gcs.igc), g = ai(g, 6, !!d.iur), G(g, 1, 1))
        });
        IR(a.pubWin, N5(d.gcs));
        O5(a.I.google_ad_client);
        GJ(g => {
            D(g, 1) === 1 && G(g, 1, 2)
        });
        const e = new lK(a.pubWin);
        await P5(e, d.gd || C(c, 8));
        GJ(g => {
            D(g, 1) === 2 && (g = ai(g, 3, !0), G(g, 1, 3))
        });
        await K5(a, {
            Ma: d.gcs.igc,
            Zl: d.gcs.iga
        });
        const f = ln();
        GJ(g => {
            if (D(g, 1) === 3) {
                g = ai(g, 3, f - b > 500);
                var h = !!a.R ? .g();
                g = ai(g, 4, h);
                h = !!a.R ? .ca();
                g = ai(g, 5, h);
                h = !!a.R ? .j();
                g = ai(g, 7, h);
                h = !!a.R ? .B();
                g = ai(g, 8, h);
                G(g,
                    1, 4)
            }
        })
    }

    function N5(a) {
        var b = ij(L5());
        b = $h(b, 1, a.igc);
        b = $h(b, 2, a.iga);
        a = $h(b, 3, a.iuswfcoor);
        return bh(a)
    }

    function O5(a) {
        var b = Td(q.top, "googlefcPresent");
        q.googlefc && !b && iC("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    }

    function P5(a, b) {
        return iK(a, b === ".google.cn") ? jK(a) : Promise.resolve(null)
    };
    var Q5 = tY(async function(a) {
        return M5(a.Ae)
    }, {
        id: 1404
    });

    function R5(a) {
        const b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function S5(a) {
        if (a === a.top || xd(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && R5(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        const c = new YR;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            d.data.msgType === "__goog_top_url_resp" && c.resolve({
                Fc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };

    function T5(a) {
        const b = ln();
        return Promise.race([S5(a), ge(200)]).then(c => {
            iC("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: ln() - b,
                tms: 200
            });
            return c ? .Fc
        })
    }
    var U5 = tY(async function(a, b) {
        return T5(b)
    }, {
        id: 1411
    });
    var V5 = Y(function(a, b, c, d) {
        a = 0;
        he(b) !== b && (a |= 4);
        JT(b.document) === 3 && (a |= 32);
        var e;
        if (e = c) e = ss(c), e = !(Ls(c).scrollWidth <= e);
        e && (a |= 1024);
        b.Prototype ? .Version && (a |= 16384);
        d && (a |= d);
        return {
            Ze: a
        }
    }, {
        id: 1379,
        H: {
            Ze: void 0
        }
    });
    var I7 = Y(function(a) {
        const b = a.Ae;
        b.Fc = a.Fc || "";
        return {
            en: b
        }
    }, {
        id: 1406,
        H: {
            en: void 0
        }
    });

    function J7(a, b, c, d) {
        const e = new YR;
        let f = "";
        const g = k => {
            try {
                const l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                f === l.paw_id && (rl(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
            } catch (l) {}
        };
        var h = typeof a.gmaSdk ? .getQueryInfo === "function" ? a.gmaSdk : void 0;
        if (h) return ql(a, "message", g), f = c(h), e.promise;
        c = typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage === "function" || typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage === "function" ? a.webkit.messageHandlers :
            void 0;
        return c ? (f = String(Math.floor(Ed() * 2147483647)), ql(a, "message", g), b(c, f), e.promise) : null
    }

    function K7(a) {
        return J7(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    }(function(a) {
        return eb(b => {
            if (!ib(b)) return !1;
            for (const [c, d] of Object.entries(a)) {
                const e = c,
                    f = d;
                if (!(e in b)) {
                    if (f.dm === !0) continue;
                    return !1
                }
                if (!f(b[e])) return !1
            }
            return !0
        })
    })({
        vc: gb,
        pn: gb,
        eid: jb(),
        vnm: jb(),
        js: gb
    }, "RawGmaSdkStaticSignalObject");

    function L7(a) {
        const b = U(Ow);
        if (b <= 0) return null;
        const c = ln(),
            d = K7(a.pubWin);
        if (!d) return null;
        a.l = "0";
        return Promise.race([d, ge(b, "0")]).then(e => {
            iC("adsense_paw", {
                time: ln() - c
            });
            e ? .length > 1E4 ? jC(809, Error(`ML:${e.length}`)) : a.l = e
        }).catch(e => {
            jC(809, e)
        })
    }
    var M7 = tY(async function(a) {
        return L7(a.Ae)
    }, {
        id: 1405
    });
    var N7 = class extends zY {
        constructor(a, b, c, d) {
            super(a);
            var e = b.I.google_loader_features_used;
            e = Z(this, V5, {}, b.pubWin, b.P, e ? e : null);
            d && X(e, d);
            ({
                Sj: e
            } = Z(this, p5, {
                Ze: e.Ze
            }, b));
            const f = wY(this, Q5, {
                    Ae: e
                }),
                g = wY(this, U5, {}, b.pubWin);
            X(g, f.complete);
            d = wY(this, M7, {
                Ae: e
            });
            X(d, f.complete);
            e = Z(this, I7, {
                Ae: e,
                Fc: g.output
            });
            X(e, d.complete);
            this.j = xY(this, new o5(a, b, e.finished, c)).j
        }
    };
    var O7 = Y(function(a, b) {
        KW(13, b);
        KW(11, b);
        return {}
    }, {
        id: 1486,
        H: {}
    });
    var P7 = Y(function(a, b, c) {
        T(zx) && (b.googFloatingToolbarManagerAsyncPositionUpdate = !0, c && c !== b && (c.googFloatingToolbarManagerAsyncPositionUpdate = !0));
        return {}
    }, {
        id: 1483,
        H: {}
    });
    var Q7 = Y(function() {
        return Em() || Nb() ? {
            Da: !0,
            zg: new PU
        } : {
            Da: new PU,
            zg: !0
        }
    }, {
        id: 1502,
        H: {
            Da: void 0,
            zg: void 0
        }
    });

    function R7() {
        var a = U(Uw);
        const b = U(Vw);
        return b === 3 && a === 6 ? (a = {
            hidden: 0,
            visible: 3
        }, q.IntersectionObserver || (a.visible = -1), Rb() && (a.visible *= 2), a) : {
            hidden: 0,
            visible: q.IntersectionObserver ? Rb() ? a : b : -1
        }
    };
    var S7 = Y(function(a, b) {
        var c = b.ea,
            d = b.I;
        a = b.pubWin;
        b = b.P;
        const e = R7().visible;
        if (!c || e < 0 || !Ns(d.google_reactive_ad_format) && (vU(d) || d.google_reactive_ads_config) || !kT(c) || mT(b, a, c) <= e) return {
            Da: !0,
            De: new PU
        };
        b = dJ();
        c = iJ(b, 8, {});
        b = iJ(b, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        a = !!a.google_apltlad;
        return c[d] || b[d] || a ? {
            Da: new PU,
            De: !0
        } : {
            Da: !0,
            De: new PU
        }
    }, {
        id: 1499,
        H: {
            Da: void 0,
            De: void 0
        }
    });
    var T7 = Y(function(a, b, c) {
        a = R7();
        return a.hidden < 0 && a.visible < 0 || !c ? {
            Da: !0,
            Bg: new PU
        } : {
            Da: new PU,
            Bg: !0
        }
    }, {
        id: 1491,
        H: {
            Da: void 0,
            Bg: void 0
        }
    });
    var U7 = Y(function(a) {
        return a.result
    }, {
        id: 1498,
        H: {
            Kb: void 0,
            Ag: void 0
        }
    });
    var V7 = Y(function(a) {
        return a.result
    }, {
        id: 1496,
        H: {
            Kb: void 0,
            Da: void 0
        }
    });
    var W7 = tY(async function(a, b, c) {
        c.notify();
        return new Promise(d => {
            b.ea.addEventListener("adsbygoogle-close-to-visible-event", () => {
                d(!0)
            })
        })
    }, {
        id: 1501
    });
    var X7 = tY(async function(a, b, c) {
        c.notify();
        return new Promise(d => {
            const e = b.ea;
            var f = R7().visible;
            f = new q.IntersectionObserver((g, h) => {
                Ja(g, k => {
                    k.intersectionRatio <= 0 || (h.unobserve(k.target), d(!0))
                })
            }, {
                rootMargin: `${f*100}%`
            });
            b.B = f;
            f.observe(e)
        })
    }, {
        id: 1500
    });
    var Y7 = tY(async function(a, b, c) {
        const d = b.pubWin.document,
            e = JT(d) === 3;
        return new Promise(f => {
            e ? (c.notify(), MT(gC(332, () => {
                f({
                    Kb: !0,
                    Ag: new PU
                })
            }), d)) : f({
                Kb: new PU,
                Ag: !0
            })
        })
    }, {
        id: 1494
    });
    var Z7 = tY(async function(a, b, c) {
        const d = b.I,
            e = b.pubWin;
        if (!d.google_pause_ad_requests) return !0;
        c.notify();
        const f = q.setTimeout(() => {
            iC("abg:cmppar", {
                client: d.google_ad_client,
                url: d.google_page_url
            })
        }, 1E4);
        return new Promise(g => {
            const h = gC(450, () => {
                d.google_pause_ad_requests = !1;
                q.clearTimeout(f);
                e.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", h);
                g(!0)
            });
            e.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", h)
        })
    }, {
        id: 1492
    });
    var $7 = tY(async function(a, b, c, d) {
        return new Promise(e => {
            const f = b.pubWin,
                g = b.P,
                h = b.ea,
                k = f.document;
            if (LT(k))
                if (mT(g, f, h) <= R7().hidden) e({
                    Kb: new PU,
                    Da: !0
                });
                else {
                    var l = gC(332, () => {
                        !LT(k) && l && (rl(k, d, l), e({
                            Kb: !0,
                            Da: new PU
                        }), l = null)
                    });
                    ql(k, d, l) ? c.notify() : e({
                        Kb: new PU,
                        Da: !0
                    })
                }
            else e({
                Kb: !0,
                Da: new PU
            })
        })
    }, {
        id: 1493
    });
    var a8 = class extends zY {
        constructor(a, b, c) {
            super(a);
            this.j = new aV;
            a = X(Z(this, Q7, {}), c);
            c = X(wY(this, Z7, {}, b, this.j), a.zg);
            c = X(wY(this, Y7, {}, b, this.j), c.output);
            var d = Z(this, U7, {
                    result: c.output
                }),
                e = KT(b.pubWin.document);
            c = X(Z(this, T7, {}, b, e), d.Ag);
            e = X(wY(this, $7, {}, b, this.j, e), c.Bg);
            e = Z(this, V7, {
                result: e.output
            });
            d = new bV([d.Kb, e.Kb]);
            d = X(Z(this, S7, {}, b), d);
            const f = X(wY(this, X7, {}, b, this.j), d.De);
            b = X(wY(this, W7, {}, b, this.j), d.De);
            b = new bV([f.output, b.output]);
            this.Qh = new bV([a.Da, c.Da, d.Da, e.Da, b])
        }
    };
    var c8 = Y(function(a, b, c, d, e) {
        if (mJ()) {
            a: {
                if (!mh(d, b8, 28, pW)) try {
                    var f = c.fc ? Bv(c.fc) : null;
                    break a
                } catch (g) {
                    f = null;
                    break a
                }
                f = Vh(d, b8, 28, pW) ? .j() ? ? null
            }
            a = f;c = !!x(d, kW, 26) ? .g();tP(rP(b, e.google_ad_client, a, c, A(d, 20))).run()
        }
        return {}
    }, {
        id: 1485,
        H: {}
    });
    var d8 = Y(function(a, b) {
        a = mh(b.ra, b8, 28, pW) ? Vh(b.ra, b8, 28, pW) ? .g() ? ? !0 : b.pageStateTs.epla;
        b.Ua = a;
        return {
            Ua: a
        }
    }, {
        id: 1484,
        H: {
            Ua: void 0
        }
    });
    var e8 = Y(function(a, b, c) {
        a = c.google_tag_partner;
        a = (a ? [a] : []).concat(rJ(b).tag_partners || []).join("+");
        c.google_tag_partner = a;
        a = c.google_ad_channel;
        b = (a ? [a] : []).concat(rJ(b).ad_channels || []).join("+");
        c.google_ad_channel = b;
        return {}
    }, {
        id: 1444,
        H: {}
    });
    var f8 = Y(function(a, b, c) {
        b && kU(b, vd(c.Zk, new Map(Object.entries(FT()))));
        return {}
    }, {
        id: 1447,
        H: {}
    });
    var g8 = Y(function(a, b) {
        a = b.I;
        a.google_ad_output == null && (a.google_ad_output = "html");
        a.google_ad_client != null && (a.google_ad_client = an(String(a.google_ad_client)));
        a.google_ad_slot != null && (a.google_ad_slot = String(a.google_ad_slot));
        a.google_webgl_support = !!um.WebGLRenderingContext;
        a.google_ad_section = a.google_ad_section || a.google_ad_region || "";
        a.google_country = a.google_country || a.google_gl || "";
        const c = (new Date).getTime();
        var d = "google_color_bg google_color_text google_color_link google_color_url google_color_border google_color_line".split(" ");
        for (const f of d)
            if (Array.isArray(a[f])) {
                d = b;
                var e = a[f];
                d.g |= 2;
                a[f] = e[c % e.length]
            }
        return {}
    }, {
        id: 1446,
        H: {}
    });
    var h8 = Y(function(a, b, c, d, e, f, g) {
        fC(326, () => {
            if (Ym(d) === 1) {
                var h = T(sz);
                if ((h || T(rz)) && b === c) {
                    var k = new wm;
                    const n = new xm;
                    var l = k.setCorrelator(fe(b));
                    var m = MW(b);
                    l = gi(l, 5, m);
                    G(l, 2, 1);
                    k = y(n, 1, k);
                    l = new vm;
                    l = ai(l, 10, !0);
                    m = T(mz);
                    l = ai(l, 8, m);
                    m = T(nz);
                    l = ai(l, 12, m);
                    m = T(qz);
                    l = ai(l, 7, m);
                    m = T(pz);
                    l = ai(l, 13, m);
                    y(k, 2, l);
                    b.google_rum_config = rg(n);
                    Bd(b.document, g.idi && h ? f.Nm : f.Om)
                } else sn(dC)
            }
        });
        return {}
    }, {
        id: 1443,
        H: {}
    });
    var i8 = Y(function(a, b, c) {
        if (!b || rJ(b).ads_density_stats_processed || Em(b)) return {};
        rJ(b).ads_density_stats_processed = !0;
        if (T(Ax) || Ed() < .01) {
            const d = () => {
                if (b) {
                    var e = AN(vN(b), c.google_ad_client, b.location.hostname, MW(c).split(","));
                    iC("ama_stats", e, 1)
                }
            };
            sl(b, () => {
                q.setTimeout(d, 1E3)
            })
        }
        return {}
    }, {
        id: 1445,
        H: {}
    });
    var j8 = Y(function(a, b) {
        vU(b) && (tT() && (b.google_adtest = b.google_adtest || "on"), b.google_pgb_reactive = b.google_pgb_reactive || 3);
        return {}
    }, {
        id: 1448,
        H: {}
    });
    var k8 = Y(function(a, b) {
        a = b.google_start_time;
        typeof a === "number" && (is = a, b.google_start_time = null);
        return {}
    }, {
        id: 1463,
        H: {}
    });
    var l8 = class extends zY {
        constructor(a, b, c) {
            super(a);
            this.j = new aV;
            const d = c.Ua;
            c = c.Qh;
            const e = Z(this, h8, {}, b.pubWin, b.P, b.I, b.ra, b.Sa, b.pageStateTs);
            c && X(e, c);
            c = X(Z(this, e8, {}, b.pubWin, b.I), e.finished);
            c = X(Z(this, i8, {}, b.P, b.I), c.finished);
            c = X(Z(this, k8, {}, b.I), c.finished);
            c = X(Z(this, g8, {}, b), c.finished);
            c = X(Z(this, f8, {}, b.P, b.Sa), c.finished);
            c = X(Z(this, j8, {}, b.I), c.finished);
            this.j = xY(this, new N7(a, b, d, c.finished)).j
        }
    };
    var m8 = class extends zY {
        constructor(a, b) {
            super(a);
            this.j = new aV;
            this.l = new WU;
            if (/_sdo/.test(b.I.google_ad_format)) this.j.notify();
            else {
                var c = Z(this, O7, {}, b.pubWin);
                c = X(Z(this, d8, {}, b), c.finished);
                var d = X(Z(this, c8, {}, b.pubWin, b.pageStateTs, b.ra, b.I), c.finished);
                d = X(Z(this, P7, {}, b.pubWin, b.P), d.finished);
                this.j = d.finished;
                T(Jw) && (d = xY(this, new a8(a, b, d.finished)), a = xY(this, new l8(a, b, {
                    Ua: c.Ua,
                    Qh: d.Qh
                })), this.l = new bV([d.j, a.j], !0))
            }
        }
    };
    var n8 = Y(function(a, b, c, d) {
        const e = a.lb,
            f = a.ra,
            g = a.pageStateTs,
            h = a.Cb,
            k = b(e, f, g.fy, g.bv, g.bvcb || "");
        d.google_sa_impl = l => c({
            ra: f,
            Sa: k,
            lb: e,
            slot: l,
            pageStateTs: g,
            Cb: h
        });
        d.google_process_slots ? .();
        return {}
    }, {
        id: 1338,
        H: {}
    });

    function o8(a) {
        cC.l(b => {
            b.shv = String(a);
            b.mjsv = Kq();
            b.eid = MW(q)
        })
    };
    var p8 = Y(function(a, b) {
        o8(a.pageStateTs.bv);
        AW(rW(b));
        return {}
    }, {
        id: 1337,
        H: {}
    });
    var q8 = Y(function(a, b) {
        let c = null;
        c = c ? ? new Zr(b);
        try {
            we(d => {
                UB(c, 1192, d)
            })
        } catch (d) {}
        return {}
    }, {
        id: 1335,
        H: {}
    });
    var r8 = class extends H {
        g() {
            return C(this, 1)
        }
    };
    var oW = class extends H {
        j() {
            return C(this, 1)
        }
        B() {
            return x(this, r8, 2)
        }
        g() {
            return A(this, 3)
        }
    };
    var b8 = class extends H {
        g() {
            return A(this, 1)
        }
        j() {
            return x(this, Av, 2)
        }
    };
    var s8 = class extends H {},
        pW = [27, 28];
    var t8 = typeof sttc === "undefined" ? void 0 : sttc;
    var u8 = Y(function(a, b, c, d) {
        a = c.adsbygoogle && "pageStateTs" in c.adsbygoogle && c.adsbygoogle.pageStateTs ? c.adsbygoogle.pageStateTs : {
            fy: 0,
            bv: "",
            iur: !1,
            idi: !1,
            pem: void 0,
            gd: "",
            bvcb: "",
            gcs: {
                igc: !1,
                iga: !1,
                iuswfcoor: !1
            },
            ssc: {
                ssl: []
            },
            epla: !0
        };
        a: {
            c = cC;
            try {
                if (!gb(b)) throw Error(String(b));
                if (b.length > 0) {
                    var e = new s8(JSON.parse(b));
                    break a
                }
            } catch (f) {
                c.pa(838, f instanceof Error ? f : Error(String(f)))
            }
            e = new s8
        }
        b = e;
        Cm(16, [3, rg(b)]);
        return {
            pageStateTs: a,
            ra: b,
            lb: d
        }
    }, {
        id: 1336,
        H: {
            pageStateTs: void 0,
            ra: void 0,
            lb: void 0
        }
    });
    var v8 = Y(function(a, b) {
        a = (b.Prototype || {}).Version;
        a != null && iC("prtpjs", {
            version: a
        });
        return {}
    }, {
        id: 1339,
        H: {}
    });
    var w8 = class extends YW {
        constructor(a) {
            super();
            this.promise = a;
            a.then(b => {
                this.value = b
            })
        }
        j() {
            return Promise.race([this.promise, ge(U(tw), null)]).then(a => {
                this.value = a
            })
        }
    };
    var x8 = Y(function() {
        return T(Fw) ? {
            Cb: new w8(navigator.getBattery ? .() ? ? Promise.resolve(null))
        } : {
            Cb: new w8(Promise.resolve(null))
        }
    }, {
        id: 1413,
        H: {
            Cb: void 0
        }
    });
    var y8 = class {
        constructor() {
            this.g = cC
        }
        Na(a) {
            const b = a.eb;
            this.g.pa(a.methodName ? ? 0, b instanceof Error ? b : Error(String(b)))
        }
    };
    var z8 = ud `https://pagead2.googlesyndication.com/pagead/s/eeframe.html`;
    var A8 = Y(function(a) {
        let b = !1,
            c = !1;
        for (const d of Jl(a.ae)) ji(d, 5) && (c = !0, A(d, 4) && (b = !0));
        if (!b && !a.R.ca() || !c) return {
            O: void 0
        };
        a = document.createElement("iframe");
        a.name = "goog_ee_frame";
        a.style.display = "none";
        a.src = rc(z8).toString();
        document.documentElement.appendChild(a);
        return {
            O: a
        }
    }, {
        id: 1389,
        H: {
            O: void 0
        }
    });
    var B8 = Y(function(a) {
        return (a = a.Zm) ? {
            ue: Jl(a).map(b => {
                var c = ji(b, 2) ? C(b, nh(b, ki, 2)) : C(b, nh(b, ki, 5)),
                    d = b.Wa();
                c = c && (c.startsWith(location.protocol) || c.startsWith("data:") && c.length <= 80) ? qc(c === null ? "null" : c === void 0 ? "undefined" : c) : void 0;
                return {
                    Uk: d,
                    url: c,
                    Yl: A(b, 4),
                    Xl: ji(b, 5)
                }
            })
        } : {
            ue: []
        }
    }, {
        id: 1040,
        H: {
            ue: void 0
        }
    });
    var D8 = Y(C8, {
        id: 1041,
        H: {}
    });

    function C8(a, b) {
        if (!a.U) return {};
        HV().set(a.U, a.R, b) && a.U.g() && DV(27, a.U.Wa());
        return {}
    };
    var E8 = Y(function(a) {
        return KV(a.U) !== 0 ? {
            U: a.U
        } : {
            U: new PU
        }
    }, {
        id: 1036,
        H: {
            U: void 0
        }
    });

    function F8() {
        return q.googletag ? ? (q.googletag = {
            cmd: []
        })
    };
    var G8 = tY(async function(a, b, c) {
        if (c) {
            var d = a.U.Wa();
            a.R.g() && (b = vd(b, {
                gdpr: "1"
            }));
            var e = C(a.R, 2);
            e && (b = vd(b, {
                gdpr_consent: e
            }));
            b = b.toString();
            DV(59, d, null, {
                url: b
            });
            e = (new URL(z8.toString())).origin;
            c = mS({
                destination: window,
                O: c,
                origin: e,
                Ib: "echo-endpoint-channel"
            });
            var {
                data: f
            } = await c.j({
                id: d,
                url: b
            });
            switch (f.kind) {
                case 0:
                    F8().secureSignalProviders ? .push({
                        id: d,
                        collectorFunction: () => Promise.resolve(f.data)
                    });
                    break;
                case 1:
                    return DV(60, d, f.error), a.U.setError(Pl(114));
                default:
                    Ec(f, void 0)
            }
        }
    }, {
        id: 1391
    });
    var H8 = tY(async function(a, b) {
        const c = a.U.Wa(),
            d = b.toString();
        DV(30, c, null, {
            url: d
        });
        const e = document.createElement("script");
        e.setAttribute("esp-signal", "true");
        Lc(e, b);
        const {
            promise: f,
            resolve: g
        } = ja(Promise, "withResolvers").call(Promise), h = () => {
            DV(31, c, null, {
                url: d
            });
            g(a.U.setError(Pl(109)));
            rl(e, "error", h)
        };
        document.head.appendChild(e);
        ql(e, "error", h);
        return f
    }, {
        id: 1035
    });
    var I8 = Y(function(a, b, c, d) {
        ({
            U: a
        } = HV().get(b, d, c));
        if (a) return {
            Pa: a,
            Ea: new PU("CACHED_ENTRY")
        };
        a = lm(jm(b));
        return {
            Pa: a,
            Ea: a.setError(Pl(100))
        }
    }, {
        id: 1027,
        H: {
            Pa: void 0,
            Ea: void 0
        }
    });
    var K8 = Y(J8, {
        id: 1028,
        H: {
            Qa: void 0
        }
    });

    function J8(a) {
        const b = a.U.Wa();
        Lh(a.U, 3) != null || DV(35, b);
        return {
            Qa: a.U
        }
    };
    var L8 = class extends zY {
        constructor(a, b, c, d, e, f, g) {
            super(g);
            const h = Z(this, I8, {}, a, c, f, g);
            vY(this, h);
            a = new WU;
            RU(a, f);
            Z(this, D8, {
                U: h.Ea,
                R: a
            }, c);
            f = Z(this, E8, {
                U: h.Pa
            });
            f = Z(this, K8, {
                U: f.U
            });
            d ? {
                output: b
            } = wY(this, G8, {
                U: f.Qa,
                R: a
            }, b, e) : {
                output: b
            } = wY(this, H8, {
                U: f.Qa
            }, b, g);
            Z(this, D8, {
                U: b,
                R: a
            }, c)
        }
    };
    var M8 = new Set,
        N8 = Y(function(a, b, c, d) {
            var e = a.ue;
            c = a.Jb;
            a = a.rl;
            if (!e ? .length) return {};
            const f = c.ca();
            for (const {
                    Uk: g,
                    url: h,
                    Yl: k,
                    Xl: l
                } of e) h && (f || k) && !M8.has(h.toString()) && (M8.add(h.toString()), e = new L8(g, h, k, l, a, c, b), it(d, e), e.run());
            return {}
        }, {
            id: 813,
            H: {}
        });
    var O8 = class extends zY {
        constructor(a, b, c) {
            super(a);
            this.l = b;
            this.j = c;
            ({
                O: b
            } = Z(this, A8, {
                R: this.j,
                ae: this.l
            }));
            ({
                ue: c
            } = Z(this, B8, {
                Zm: this.l
            }));
            Z(this, N8, {
                ue: c,
                Jb: this.j,
                rl: b
            }, a, {}, this)
        }
    };
    var P8 = Y(function(a) {
        const b = a.R;
        if (a = a.Oc)
            for (var c of a)
                for (const d of Jl(c)) A(d, 4) && HV().remove(d.Wa(), b, !0);
        if (b.ca()) {
            if (b) {
                c = AV(b) ? ? [];
                for (const d of c) d.startsWith("_GESPSK") && uV(d, b)
            }
            IV = new JV
        }
        return {}
    }, {
        id: 1094,
        H: {}
    });
    var Q8 = Y(function(a) {
        const b = a.U;
        a = c => {
            DV(c, b.Wa(), null, {
                tic: String(Math.round((Date.now() - $v(Mh(b, 3))) / 6E4))
            })
        };
        switch (KV(b)) {
            case 0:
                return a(24), {
                    Yb: new PU("FRESH_ENTRY"),
                    Cc: new PU("FRESH_ENTRY")
                };
            case 1:
                return a(25), {
                    Yb: new PU("STALE_ENTRY"),
                    Cc: b
                };
            case 2:
                return a(26), {
                    Yb: b,
                    Cc: new PU("EXPIRED_ENTRY")
                };
            case 3:
                return DV(9, b.Wa()), {
                    Yb: b,
                    Cc: new PU("ERROR_ENTRY")
                };
            case 4:
                return a(23), {
                    Yb: b,
                    Cc: new PU("NEW_ENTRY")
                };
            default:
                return {
                    Yb: new PU("DEFAULT_ENTRY"),
                    Cc: new PU("DEFAULT_ENTRY")
                }
        }
    }, {
        id: 1048,
        H: {
            Yb: void 0,
            Cc: void 0
        }
    });
    var S8 = Y(R8, {
        id: 1046,
        H: {
            Qa: void 0
        }
    });

    function R8(a) {
        return {
            Qa: a.Pa
        }
    };
    var T8 = Y(function(a) {
        const b = a.zi;
        a = a.U;
        return b.Ea ? {
            fi: a.setError(b.Ea),
            Pa: new PU,
            signal: new PU
        } : {
            Pa: b.Pa,
            fi: new PU,
            signal: b.signal
        }
    }, {
        id: 1479,
        H: {
            Pa: void 0,
            fi: void 0,
            signal: void 0
        }
    });

    function U8(a) {
        return typeof a === "string" ? a : a instanceof Error ? a.message : null
    }
    var V8 = tY(async function(a, b) {
        const c = ln(),
            d = $f(w(a.U, 1));
        DV(18, d);
        try {
            return b().then(e => {
                DV(29, d, null, {
                    delta: String(ln() - c)
                });
                return {
                    Pa: fi(a.U, 2, e),
                    Ea: null,
                    signal: e
                }
            }).catch(e => {
                DV(28, d, U8(e));
                return {
                    Pa: null,
                    Ea: Pl(106),
                    signal: null
                }
            })
        } catch (e) {
            return DV(1, d, U8(e)), {
                Pa: null,
                Ea: Pl(107),
                signal: null
            }
        }
    }, {
        id: 1478
    });
    var X8 = Y(W8, {
        id: 1050,
        H: {
            Qa: void 0
        }
    });

    function W8(a, b) {
        const c = a.U.Wa();
        if (a.signal == null) return DV(41, c), a.U.setError(Pl(111)), {
            Qa: a.U
        };
        if (typeof a.signal !== "string") return DV(21, c), {
            Qa: a.U.setError(Pl(113))
        };
        if (a.signal.length > b) return DV(12, c, null, {
            sl: String(a.signal.length)
        }), b = a.U.setError(Pl(108)), ih(b, 2), {
            Qa: a.U
        };
        a.signal.length || DV(20, c);
        ih(a.U, 10);
        return {
            Qa: a.U
        }
    };
    var Y8 = class {
        constructor(a, b) {
            this.output = new aV;
            $U(this.output, a, c => void b.Na({
                methodName: 1046,
                eb: c
            }))
        }
    };
    var Z8 = class extends Y8 {};
    var $8 = class extends zY {
        constructor(a, b, c, d, e) {
            super(e);
            this.j = new WU;
            var f = Z(this, I8, {}, a, b, d, e);
            const g = new WU;
            RU(g, d);
            Z(this, D8, {
                U: f.Ea,
                R: g
            }, b);
            d = Z(this, K8, {
                U: f.Pa
            });
            f = Z(this, Q8, {
                U: d.Qa
            }, e);
            d = wY(this, V8, {
                U: f.Yb
            }, c);
            const {
                signal: h,
                Pa: k,
                fi: l
            } = Z(this, T8, {
                zi: d.output,
                U: f.Yb
            });
            Z(this, D8, {
                U: l,
                R: g
            }, b);
            d = Z(this, X8, {
                U: k,
                signal: h
            }, 1024);
            Z(this, D8, {
                U: d.Qa,
                R: g
            }, b);
            e = new Z8(EV(), e);
            e = X(Z(this, S8, {
                Pa: f.Cc
            }), e.output);
            c = wY(this, V8, {
                U: e.Qa
            }, c);
            ({
                Pa: c
            } = Z(this, T8, {
                zi: c.output,
                U: e.Qa
            }));
            Z(this, D8, {
                U: c,
                R: g
            }, b);
            b =
                d.Qa.promise.then(m => ({
                    id: a,
                    collectorGeneratedData: m ? .j() ? ? null
                })).catch(() => ({
                    id: a,
                    collectorGeneratedData: null
                }));
            VU(this.j, b)
        }
    };
    var a9 = tY(async function(a, b, c) {
        var d = new PV(a.bn ? ? []);
        const e = a.xb.id,
            f = a.xb.collectorFunction,
            g = a.xb.networkCode ? ? e;
        d = !!e && !!MV(d, e);
        if (!a.R.ca() && !d) return new PU("Storage consent not granted.");
        DV(42, g, null, {
            ea: String(Number(b))
        });
        a = new $8(g, d, f, a.R, c);
        a.run();
        return a.j.promise
    }, {
        id: 1059
    });
    var b9 = class extends hV {
        constructor(a, b, c, d) {
            super(1059, d);
            this.ba = b;
            this.T = fV(this);
            this.A = gV(this, a);
            this.F = gV(this, c)
        }
        G() {
            var a = new PV([]);
            const b = this.A.value.id;
            var c = this.A.value.collectorFunction;
            const d = this.A.value.networkCode ? ? b;
            a = !!b && !!MV(a, b);
            if (this.F.value.ca() || a) DV(42, d, null, {
                ea: String(Number(this.ba))
            }), c = new $8(d, a, c, this.F.value, this.D), c.run(), VU(this.T, c.j.promise)
        }
    };
    var c9 = Y(function(a, b, c, d = oV) {
        if (!b) return DV(39, "UNKNOWN_COLLECTOR_ID"), {
            Ea: jm("UNKNOWN_COLLECTOR_ID").setError(Pl(110)),
            xb: new PU
        };
        if (typeof b !== "object") return DV(46, "UNKNOWN_COLLECTOR_ID"), {
            Ea: jm("UNKNOWN_COLLECTOR_ID").setError(Pl(112)),
            xb: new PU
        };
        a = b.id;
        c = b.networkCode;
        a && c && (delete b.id, DV(47, `${a};${c}`));
        a = c ? ? a;
        return typeof a !== "string" ? (DV(37, "INVALID_COLLECTOR_ID", null, {
                ii: JSON.stringify(a)
            }), {
                Ea: jm("INVALID_COLLECTOR_ID").setError(Pl(102)),
                xb: new PU
            }) : typeof b.collectorFunction !== "function" ?
            (DV(14, a), {
                Ea: jm(a).setError(Pl(105)),
                xb: new PU
            }) : d.Mi.includes(a) ? (DV(22, a), {
                Ea: jm(a).setError(Pl(104)),
                xb: new PU
            }) : {
                Ea: null,
                xb: b
            }
    }, {
        id: 1057,
        H: {
            Ea: void 0,
            xb: void 0
        }
    });

    function d9(a, b) {
        a.g.g.push(b)
    }
    var f9 = class {
        constructor(a, b, c, d = document, e, f, g = oV) {
            this.l = b;
            this.B = c;
            this.D = d;
            this.K = e;
            this.J = f;
            this.j = g;
            this.G = [];
            this.F = [];
            this.g = new e9;
            this.A = 0;
            for (const h of a) this.push(h)
        }
        push(a) {
            this.B || this.K();
            const b = new zY(this.g);
            a = Z(b, c9, {}, a, this.g, this.j);
            const c = a.xb;
            Z(b, D8, {
                U: a.Ea,
                R: this.l
            }, void 0);
            a = this.j.wn ? wY(b, a9, {
                xb: c,
                R: this.l,
                bn: void 0
            }, this.B, this.g, this.j).output.promise : vY(b, new b9(c, this.B, this.l, this.g)).T.promise;
            b.run();
            this.G.push(a);
            for (const d of this.F) a.then(d)
        }
        addOnSignalResolveCallback(a) {
            this.F.push(a);
            for (const b of this.G) b.then(a)
        }
        clearAllCache() {
            const a =
                this.D.currentScript instanceof HTMLScriptElement ? this.D.currentScript.src : "";
            if (this.A === 1) DV(49, "", null, {
                url: a
            });
            else if (this.j.Hi.includes(String(Hu(a ? ? "")))) DV(48, "", null, {
                url: a
            });
            else {
                this.J && this.J();
                var b = new zY(this.g),
                    c = Z(b, P8, {
                        R: this.l,
                        Oc: void 0
                    }, this.g);
                b.run();
                this.A = 1;
                setTimeout(() => {
                    this.A = 0
                }, this.j.Di * 1E3);
                DV(43, "", null, {
                    url: a
                });
                return c.finished.promise
            }
        }
    };
    class e9 {
        constructor() {
            this.g = []
        }
        Na(a) {
            this.g.forEach(b => void b.Na(a))
        }
    }
    var g9 = class {
        constructor(a) {
            this.push = b => {
                a.push(b)
            };
            this.addOnSignalResolveCallback = b => {
                a.addOnSignalResolveCallback(b)
            };
            this.addErrorHandler = b => {
                d9(a, {
                    Na: ({
                        methodName: c,
                        eb: d
                    }) => void b(c, d)
                })
            };
            this.clearAllCache = () => {
                a.clearAllCache()
            }
        }
    };

    function h9(a, b, c, d, e, f = oV) {
        if (!i9(a, "encryptedSignalProviders", c) || !i9(a, "secureSignalProviders", c)) {
            DV(38, "");
            var g = {
                Na: ({
                    methodName: h,
                    eb: k
                }) => void c(h, k)
            };
            j9(a, "encryptedSignalProviders", b, f, g, d, e);
            j9(a, "secureSignalProviders", b, f, g, () => {}, e)
        }
    }

    function i9(a, b, c) {
        if (a[b] === void 0 || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    }

    function j9(a, b, c, d, e, f, g) {
        c = new f9(a[b] ? ? [], c, b === "secureSignalProviders", document, f, g, d);
        a[b] = new g9(c);
        d9(c, e)
    }

    function k9(a, b, c, d, e) {
        var f = {
            Hi: wz(vw),
            Di: U(uw),
            Mi: wz(Bw)
        };
        const g = new WU;
        RU(g, b);
        h9(a, g, c, d, e, f)
    };
    var m9 = Y(l9, {
        id: 1049,
        H: {}
    });

    function l9(a) {
        const b = new Set;
        var c = new Set(FV(a.Jb));
        for (var d of a.Oc ? ? [])
            for (const e of Jl(d)) A(e, 4) && (c.add(e.Wa()), b.add(e.Wa()));
        for (const e of Array.from(c))
            if ({
                    U: c
                } = HV().get(e, a.Jb, b.has(e)), c && (d = KV(c), d === 2 || d === 3)) HV().remove($f(w(c, 1)) ? ? "", a.Jb, b.has(e)), DV(40, e);
        return {}
    };
    const o9 = VY(function(a) {
        return a.Jb.ca() || n9(a.Oc)
    }, {
        id: 1415
    });
    var p9 = class extends SY {
        constructor(a, b, c) {
            super(c);
            this.Jb = a;
            this.Oc = b;
            c = new Z8(EV(), c);
            X(Z(this, m9, {
                Jb: a,
                Oc: b
            }), c.output)
        }
        async l() {
            return TY(this.F, o9, {
                Jb: this.Jb,
                Oc: this.Oc
            })
        }
        A() {}
    };

    function n9(a) {
        return a.some(b => Jl(b).some(c => A(c, 4)))
    };

    function q9(a, b, c) {
        return d => {
            if (vu(d) && qW(a, b, c.mcc ? ? "", c.pwpc ? ? "", c.hwrj ? ? "")) {
                var e = new y8;
                k9(F8(), d.getValue(), (k, l) => void e.Na({
                    methodName: k,
                    eb: l
                }), () => void q.console.warn("Using deprecated googletag.encryptedSignalProviders. Please usegoogletag.secureSignalProviders instead."), () => void q.console.warn("Calling this method may reduce the likelihood of signals being included in ad requests for the current and potentially later page views. Due to this, it should only be called when meaningful state changes occur, such as events that indicate a new user log in, log out, sign up, etc."));
                var f = new WU;
                UU(f, d.getValue());
                d = new zY(e);
                var {
                    ae: g,
                    Ui: h
                } = Z(d, nV, {}, c.ssc);
                xY(d, new O8(e, g, f));
                xY(d, new p9(f, h, e));
                d.run()
            }
        }
    };
    var r9 = Y(function(a, b) {
        if (!T(Hw)) return {};
        nP({
            Db: q9(window, tJ(window), a.pageStateTs),
            C: b,
            Ma: a.pageStateTs.gcs.igc
        });
        return {}
    }, {
        id: 1378,
        H: {}
    });

    function s9(a, b, c) {
        var d = cC,
            e = t9;
        const f = new zY({
                Na: m => {
                    const n = m.eb;
                    d.pa(m.methodName ? ? 0, n instanceof Error ? n : Error(String(n)))
                }
            }),
            g = Z(f, q8, {}, b),
            {
                pageStateTs: h,
                ra: k,
                lb: l
            } = X(Z(f, u8, {}, a, q, b), g.finished);
        a = Z(f, p8, {
            pageStateTs: h
        }, q);
        X(Z(f, r9, {
            pageStateTs: h
        }, q), a.finished);
        ({
            Cb: b
        } = X(Z(f, x8, {}), a.finished));
        c = X(Z(f, n8, {
            lb: l,
            ra: k,
            pageStateTs: h,
            Cb: b
        }, c, e, q), a.finished);
        X(Z(f, v8, {}, q), c.finished);
        f.run()
    };
    var u9 = tY(async function(a, b) {
        !T(Fw) || U(tw) <= 0 || await b.Cb ? .j()
    }, {
        id: 1390
    });

    function v9(a) {
        var b = cC;
        const c = new zY({
            Na: d => {
                const e = d.eb;
                b.pa(d.methodName ? ? 0, e instanceof Error ? e : Error(String(e)))
            }
        });
        a = wY(c, u9, {}, a);
        c.run();
        return a.output.promise
    };
    var w9 = class {
        constructor(a, b) {
            this.P = a;
            this.Nc = b;
            this.g = null;
            this.l = 0
        }
        run() {
            this.g = q.setInterval(Aa(this.j, this), 500);
            this.j()
        }
        j() {
            ++this.l >= 10 && q.clearInterval(this.g);
            var a = Oz(this.P, this.Nc);
            Pz(this.P, this.Nc, a);
            a = Hz(this.Nc, this.P);
            a != null && a.x === 0 || q.clearInterval(this.g)
        }
    };
    var x9 = class {
        constructor(a) {
            this.g = 0;
            this.R = this.B = null;
            this.A = 0;
            this.Ba = [];
            this.Fc = this.l = "";
            this.Ua = !1;
            this.P = a.P;
            this.pubWin = a.pubWin;
            this.I = a.I;
            this.ra = a.ra;
            this.Sa = a.Sa;
            this.lb = a.lb;
            this.ea = a.ea;
            this.pageStateTs = a.pageStateTs;
            this.Tf = a.Tf
        }
    };

    function y9(a) {
        a = a.innerInsElement;
        if (!a) throw Error("no_wrapper_element_in_loader_provided_slot");
        return a
    }
    async function t9({
        ra: a,
        Sa: b,
        lb: c,
        slot: d,
        pageStateTs: e,
        Cb: f
    }) {
        const g = d.vars,
            h = Ad(d.pubWin),
            k = y9(d),
            l = new x9({
                P: h,
                pubWin: d.pubWin,
                I: g,
                ra: a,
                Sa: b,
                lb: c,
                ea: k,
                pageStateTs: e,
                Tf: d.sldt
            });
        l.A = Date.now();
        l.Cb = f;
        Cm(1, [l.I]);
        await v9(l);
        try {
            await z9(l)
        } catch (p) {
            if (!jC(159, p)) throw p;
        }
        fC(639, () => {
            var p;
            var t = l.I;
            (p = l.P) && t.google_responsive_auto_format === 1 && t.google_full_width_responsive_allowed === !0 ? (t = (t = p.document.getElementById(t.google_async_iframe_id)) ? Uk(t, "INS", "adsbygoogle") : null) ? ((new w9(p, t)).run(),
                p = !0) : p = !1 : p = !1;
            return p
        });
        const m = e.gd || C(a, 8);
        if (h ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/)) {
            a = d.pubWin;
            b = l.Ba;
            c = c0();
            try {
                var n = !!h ? .location ? .hash ? .match(/\bgoog_aidd/)
            } catch (p) {
                n = !1
            }
            hC(1008, A9(a, h, g, b, jj(hi(c, 4, n ? 2 : 1)), l.R, m), p => {
                p.es = p3(null)
            })
        } else TR(l.pubWin, "affa", p => {
            hC(1008, A9(d.pubWin, h, g, l.Ba, p.config, l.R, m), t => {
                t.es = p3(null)
            });
            return !0
        });
        B9(l);
        return l
    }
    async function A9(a, b, c, d, e, f, g) {
        await n3(a, b, c, d, e, f, g)
    }

    function C9(a, b) {
        if (b) try {
            return a.pageStateTs.fc ? Bv(a.pageStateTs.fc) : null
        } catch (c) {
            return null
        }
        return Vh(a.ra, b8, 28, pW) ? .j() ? ? null
    }

    function z9(a) {
        if (/_sdo/.test(a.I.google_ad_format)) return Promise.resolve();
        if (T(rw)) {
            const c = cC;
            var b = new m8({
                Na: d => {
                    const e = d.eb;
                    c.pa(d.methodName ? ? 0, e instanceof Error ? e : Error(String(e)))
                }
            }, a);
            b.run();
            return T(Jw) ? b.l.promise : b.j.promise.then(() => D9(a))
        }
        LW(a.pubWin);
        b = !mh(a.ra, b8, 28, pW);
        a.Ua = b ? a.pageStateTs.epla : Vh(a.ra, b8, 28, pW) ? .g() ? ? !0;
        mJ() && tP(rP(a.pubWin, a.I.google_ad_client, C9(a, b), !!a.pageStateTs.gcs.igc, a.pageStateTs.iur)).run();
        T(zx) && (a.pubWin.googFloatingToolbarManagerAsyncPositionUpdate = !0, a.P && a.P !== a.pubWin && (a.P.googFloatingToolbarManagerAsyncPositionUpdate = !0));
        return D9(a)
    }

    function D9(a) {
        const b = !Em() && !Nb();
        return !b || b && !E9(a) ? F9(a) : Promise.resolve()
    }

    function E9(a) {
        return G9(a) || H9(a)
    }

    function G9(a) {
        const b = a.I;
        if (!b.google_pause_ad_requests) return !1;
        const c = q.setTimeout(() => {
                iC("abg:cmppar", {
                    client: a.I.google_ad_client,
                    url: a.I.google_page_url
                })
            }, 1E4),
            d = gC(450, () => {
                b.google_pause_ad_requests = !1;
                q.clearTimeout(c);
                a.pubWin.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
                if (!E9(a)) {
                    const e = F9(a);
                    hC(1222, e)
                }
            });
        a.pubWin.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
        return !0
    }

    function H9(a) {
        const b = a.pubWin.document,
            c = a.ea;
        if (JT(b) === 3) return MT(gC(332, () => {
            if (!I9(a, J9().visible, c)) {
                const g = F9(a);
                hC(1222, g)
            }
        }), b), !0;
        const d = J9();
        if (d.hidden < 0 && d.visible < 0) return !1;
        const e = KT(b);
        if (!e) return !1;
        if (!LT(b)) return I9(a, d.visible, c);
        if (mT(a.P, a.pubWin, c) <= d.hidden) return !1;
        let f = gC(332, () => {
            if (!LT(b) && f) {
                rl(b, e, f);
                if (!I9(a, d.visible, c)) {
                    const g = F9(a);
                    hC(1222, g)
                }
                f = null
            }
        });
        return ql(b, e, f)
    }

    function J9() {
        var a = U(Uw);
        const b = U(Vw);
        return b === 3 && a === 6 ? (a = {
            hidden: 0,
            visible: 3
        }, q.IntersectionObserver || (a.visible = -1), Rb() && (a.visible *= 2), a) : {
            hidden: 0,
            visible: q.IntersectionObserver ? Rb() ? a : b : -1
        }
    }

    function I9(a, b, c) {
        if (!c || b < 0) return !1;
        var d = a.I;
        if (!Ns(d.google_reactive_ad_format) && (vU(d) || d.google_reactive_ads_config) || !kT(c) || mT(a.P, a.pubWin, c) <= b) return !1;
        var e = dJ(),
            f = iJ(e, 8, {});
        e = iJ(e, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        const g = !!a.pubWin.google_apltlad;
        if (!f[d] && !e[d] && !g) return !1;
        f = new Promise(h => {
            const k = new q.IntersectionObserver((l, m) => {
                Ja(l, n => {
                    n.intersectionRatio <= 0 || (m.unobserve(n.target), h(void 0))
                })
            }, {
                rootMargin: `${b*100}%`
            });
            a.B = k;
            k.observe(c)
        });
        e = new Promise(h => {
            c.addEventListener("adsbygoogle-close-to-visible-event", () => {
                h(void 0)
            })
        });
        ja(Promise, "any").call(Promise, [f, e]).then(() => {
            fC(294, () => {
                const h = F9(a);
                hC(1222, h)
            })
        });
        return !0
    }

    function F9(a) {
        const b = cC,
            c = new WU;
        RU(c, a.Ua);
        a = new l8({
            Na: d => {
                const e = d.eb;
                b.pa(d.methodName ? ? 0, e instanceof Error ? e : Error(String(e)))
            }
        }, a, {
            Ua: c
        });
        return K9(a)
    }
    async function K9(a) {
        a.run();
        await a.j.promise
    }

    function B9(a) {
        nJ() && q.setTimeout(gC(1244, () => void $S(a.P || a.pubWin, {
            Ma: !!a.pageStateTs.gcs.igc
        })), 1E3)
    };
    (function(a, b, c) {
        fC(843, () => {
            q.google_sa_impl || s9(a, b, c)
        })
    })(t8, Kq(), function(a, b, c, d, e) {
        c = c > 2012 ? `_fy${c}` : "";
        e || (e = C(b, 3));
        d || (d = C(b, 2));
        return {
            Om: ud `https://pagead2.googlesyndication.com/pagead/js/${d}/${e}/rum${c}.js`,
            Nm: ud `https://pagead2.googlesyndication.com/pagead/js/${d}/${e}/rum_debug${c}.js`,
            Gj: ud `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/reactive_library${c}.js`,
            Zk: ud `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/debug_card_library${c}.js`,
            ir: ud `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${c}.js`,
            gk: ud `https://googleads.g.doubleclick.net/pagead/html/${d}/${e}/zrt_lookup${c}.html`,
            fk: ud `https://pagead2.googlesyndication.com/pagead/html/${d}/${e}/zrt_lookup${c}.html`
        }
    });
}).call(this, "");