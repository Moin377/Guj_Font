(function(sttc) {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis,
        ca = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        da = {},
        ea = {};

    function fa(a, b, c) {
        if (!c || a != null) {
            c = ea[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ha(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in da ? f = da : f = ba;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ca && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? aa(da, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ea[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ea[d] = ca ? ba.Symbol(d) : "$jscp$" + a + "$" + d), aa(f, ea[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    ha("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var q = this || self;

    function ia(a) {
        var b = ka("CLOSURE_FLAGS");
        a = b && b[a];
        return a != null ? a : !1
    }

    function ka(a) {
        a = a.split(".");
        for (var b = q, c = 0; c < a.length; c++)
            if (b = b[a[c]], b == null) return null;
        return b
    }

    function la(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function ma(a) {
        return Object.prototype.hasOwnProperty.call(a, na) && a[na] || (a[na] = ++oa)
    }
    var na = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        oa = 0;

    function pa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function qa(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ra(a, b, c) {
        ra = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? pa : qa;
        return ra.apply(null, arguments)
    }

    function sa(a, b, c) {
        a = a.split(".");
        c = c || q;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    };

    function ta(a) {
        q.setTimeout(() => {
            throw a;
        }, 0)
    };

    function ua(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function va(a, b) {
        let c = 0;
        a = ua(String(a)).split(".");
        b = ua(String(b)).split(".");
        const d = Math.max(a.length, b.length);
        for (let g = 0; c == 0 && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (e[0].length == 0 && f[0].length == 0) break;
                c = wa(e[1].length == 0 ? 0 : parseInt(e[1], 10), f[1].length == 0 ? 0 : parseInt(f[1], 10)) || wa(e[2].length == 0, f[2].length == 0) || wa(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (c == 0)
        }
        return c
    }

    function wa(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var xa = ia(610401301),
        ya = ia(748402147);

    function za() {
        var a = q.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Aa;
    const Ba = q.navigator;
    Aa = Ba ? Ba.userAgentData || null : null;

    function Ca(a) {
        if (!xa || !Aa) return !1;
        for (let b = 0; b < Aa.brands.length; b++) {
            const {
                brand: c
            } = Aa.brands[b];
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function r(a) {
        return za().indexOf(a) != -1
    };

    function Da() {
        return xa ? !!Aa && Aa.brands.length > 0 : !1
    }

    function Ea() {
        return Da() ? !1 : r("Trident") || r("MSIE")
    }

    function Fa() {
        return Da() ? Ca("Chromium") : (r("Chrome") || r("CriOS")) && !(Da() ? 0 : r("Edge")) || r("Silk")
    }

    function Ga(a) {
        const b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function Ha() {
        var a = za();
        if (Ea()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), c[1] == "7.0")
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        let d;
        for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = Ga(b);
        return (Da() ? 0 : r("Opera")) ? a(["Version",
            "Opera"
        ]) : (Da() ? 0 : r("Edge")) ? a(["Edge"]) : (Da() ? Ca("Microsoft Edge") : r("Edg/")) ? a(["Edg"]) : r("Silk") ? a(["Silk"]) : Fa() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function Ia(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ja(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Ka(a, b) {
        const c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function La(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Ma(a, b) {
        a: {
            var c = a.length;
            const d = typeof a === "string" ? a.split("") : a;
            for (--c; c >= 0; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function Na(a, b) {
        return Ia(a, b) >= 0
    }

    function Oa(a) {
        const b = a.length;
        if (b > 0) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Pa(a) {
        Pa[" "](a);
        return a
    }
    Pa[" "] = function() {};
    var Qa = null;

    function Ra(a) {
        const b = [];
        Ua(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Ua(a, b) {
        function c(e) {
            for (; d < a.length;) {
                const f = a.charAt(d++),
                    g = Qa[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Va();
        let d = 0;
        for (;;) {
            const e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Va() {
        if (!Qa) {
            Qa = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                const d = a.concat(b[c].split(""));
                for (let e = 0; e < d.length; e++) {
                    const f = d[e];
                    Qa[f] === void 0 && (Qa[f] = e)
                }
            }
        }
    };

    function Wa(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Xa = void 0,
        Ya;

    function Za(a) {
        if (Ya) throw Error("");
        Ya = b => {
            q.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function $a(a) {
        if (Ya) try {
            Ya(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function ab(a) {
        a = Error(a);
        Wa(a, "warning");
        $a(a);
        return a
    };

    function bb(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var db = bb(),
        eb = bb(),
        fb = bb(),
        gb = bb("m_m", !0);
    const u = bb("jas", !0);
    var hb;
    const ib = [];
    ib[u] = 7;
    hb = Object.freeze(ib);

    function jb(a, b) {
        a[u] |= b
    }

    function kb(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function lb(a) {
        jb(a, 32);
        return a
    };
    var mb = {};

    function nb(a, b) {
        return b === void 0 ? a.i !== ob && !!(2 & (a.C[u] | 0)) : !!(2 & b) && a.i !== ob
    }
    const ob = {};
    var pb = Object.freeze({}),
        qb = Object.freeze({});

    function rb(a) {
        a.uc = !0;
        return a
    };
    var sb = rb(a => typeof a === "number"),
        tb = rb(a => typeof a === "string"),
        ub = rb(a => Array.isArray(a));

    function vb() {
        return rb(a => ub(a) ? a.every(b => sb(b)) : !1)
    };

    function wb(a) {
        if (tb(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (sb(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var zb = rb(a => a >= xb && a <= yb);
    const xb = BigInt(Number.MIN_SAFE_INTEGER),
        yb = BigInt(Number.MAX_SAFE_INTEGER);
    let Ab = 0,
        Bb = 0;

    function Cb(a) {
        const b = a >>> 0;
        Ab = b;
        Bb = (a - b) / 4294967296 >>> 0
    }

    function Db(a) {
        if (a < 0) {
            Cb(-a);
            a = Ab;
            var b = Bb;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            const [c, d] = [a, b];
            Ab = c >>> 0;
            Bb = d >>> 0
        } else Cb(a)
    }

    function Eb(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Fb() {
        var a = Ab,
            b = Bb,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Eb(a, b);
        return c
    };

    function Gb(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Hb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Ib = Number.isSafeInteger,
        Jb = Number.isFinite,
        Kb = Math.trunc;

    function Lb(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Mb(a) {
        if (a != null && typeof a !== "boolean") {
            var b = typeof a;
            throw Error(`Expected boolean but got ${b!="object"?b:a?Array.isArray(a)?"array":b:"null"}: ${a}`);
        }
        return a
    }

    function Nb(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    const Ob = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Pb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Jb(a);
            case "string":
                return Ob.test(a);
            default:
                return !1
        }
    }

    function Qb(a) {
        if (!Jb(a)) throw ab("enum");
        return a | 0
    }

    function Rb(a) {
        return a == null ? a : Jb(a) ? a | 0 : void 0
    }

    function Sb(a) {
        if (typeof a !== "number") throw ab("int32");
        if (!Jb(a)) throw ab("int32");
        return a | 0
    }

    function Tb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Jb(a) ? a | 0 : void 0
    }

    function Ub(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Jb(a) ? a >>> 0 : void 0
    }

    function Vb(a) {
        if (!Pb(a)) throw ab("int64");
        switch (typeof a) {
            case "string":
                return Wb(a);
            case "bigint":
                return wb(Hb(64, a));
            default:
                return Xb(a)
        }
    }

    function Yb(a) {
        const b = a.length;
        return a[0] === "-" ? b < 20 ? !0 : b === 20 && Number(a.substring(0, 7)) > -922337 : b < 19 ? !0 : b === 19 && Number(a.substring(0, 6)) < 922337
    }

    function Xb(a) {
        a = Kb(a);
        if (!Ib(a)) {
            Db(a);
            var b = Ab,
                c = Bb;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            const d = c * 4294967296 + (b >>> 0);
            b = Number.isSafeInteger(d) ? d : Eb(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function Zb(a) {
        a = Kb(a);
        if (Ib(a)) a = String(a);
        else {
            {
                const b = String(a);
                Yb(b) ? a = b : (Db(a), a = Fb())
            }
        }
        return a
    }

    function Wb(a) {
        var b = Kb(Number(a));
        if (Ib(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Yb(a) || (a.length < 16 ? Db(Number(a)) : (a = BigInt(a), Ab = Number(a & BigInt(4294967295)) >>> 0, Bb = Number(a >> BigInt(32) & BigInt(4294967295))), a = Fb());
        return a
    }

    function $b(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function ac(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function v(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function bc(a, b, c, d) {
        if (a != null && a[gb] === mb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? ((a = b[db]) || (a = new b, jb(a.C, 34), a = b[db] = a), b = a) : b = new b : b = void 0, b;
        c = a[u] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[u] = d);
        return new b(a)
    };

    function cc(a) {
        return a
    };

    function dc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        const f = [];
        var g = a.length;
        let h, k = 4294967295,
            n = !1;
        const l = !!(b & 64),
            m = l ? b & 128 ? 0 : -1 : void 0;
        b & 1 || (h = g && a[g - 1], h != null && typeof h === "object" && h.constructor === Object ? (g--, k = g) : h = void 0, !l || b & 128 || e || (n = !0, k = (ec ? ? cc)(k - m, m, a, h, void 0) + m));
        b = void 0;
        for (e = 0; e < g; e++) {
            let p = a[e];
            if (p != null && (p = c(p, d)) != null)
                if (l && e >= k) {
                    const w = e - m;
                    (b ? ? (b = {}))[w] = p
                } else f[e] = p
        }
        if (h)
            for (let p in h) {
                if (!Object.prototype.hasOwnProperty.call(h, p)) continue;
                a = h[p];
                if (a == null || (a = c(a, d)) ==
                    null) continue;
                g = +p;
                let w;
                l && !Number.isNaN(g) && (w = g + m) < k ? f[w] = a : (b ? ? (b = {}))[p] = a
            }
        b && (n ? f.push(b) : f[k] = b);
        return f
    }

    function fc(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return zb(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    const b = a[u] | 0;
                    return a.length === 0 && b & 1 ? void 0 : dc(a, b, fc)
                }
                if (a != null && a[gb] === mb) return x(a);
                return
        }
        return a
    }
    var hc = typeof structuredClone != "undefined" ? structuredClone : a => dc(a, 0, fc);
    let ec;

    function x(a) {
        a = a.C;
        return dc(a, a[u] | 0, fc)
    };

    function ic(a) {
        if (a == null) {
            var b = 32;
            a = []
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            b = a[u] | 0;
            if (ya && 1 & b) throw Error("rfarr");
            2048 & b && !(2 & b) && jc();
            if (b & 256) throw Error("farr");
            if (b & 64) return b & 2048 || (a[u] = b | 2048), a;
            var c = a;
            b |= 64;
            var d = c.length;
            if (d) {
                var e = d - 1;
                d = c[e];
                if (d != null && typeof d === "object" && d.constructor === Object) {
                    const f = b & 128 ? 0 : -1;
                    e -= f;
                    if (e >= 1024) throw Error("pvtlmt");
                    for (const g in d) {
                        if (!Object.prototype.hasOwnProperty.call(d, g)) continue;
                        const h = +g;
                        if (h < e) c[h + f] = d[g], delete d[g];
                        else break
                    }
                    b =
                        b & -8380417 | (e & 1023) << 13
                }
            }
        }
        a[u] = b | 2112;
        return a
    }

    function jc() {
        if (ya) throw Error("carr");
        if (fb != null) {
            var a = Xa ? ? (Xa = {});
            var b = a[fb] || 0;
            b >= 5 || (a[fb] = b + 1, a = Error(), Wa(a, "incident"), Ya ? $a(a) : ta(a))
        }
    };

    function kc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[u] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = lc(a, c, !1, b && !(c & 16)) : (jb(a, 34), c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[gb] === mb) return b = a.C, c = b[u] | 0, nb(a, c) ? a : mc(a, b, c) ? nc(a, b) : lc(b, c)
    }

    function nc(a, b, c) {
        a = new a.constructor(b);
        c && (a.i = ob);
        a.A = ob;
        return a
    }

    function lc(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = dc(a, b, kc, d);
        d = 32;
        c && (d |= 2);
        b = b & 8380609 | d;
        a[u] = b;
        return a
    }

    function oc(a) {
        const b = a.C,
            c = b[u] | 0;
        return nb(a, c) ? mc(a, b, c) ? nc(a, b, !0) : new a.constructor(lc(b, c, !1)) : a
    }

    function pc(a) {
        if (a.i !== ob) return !1;
        var b = a.C;
        b = lc(b, b[u] | 0);
        jb(b, 2048);
        a.C = b;
        a.i = void 0;
        a.A = void 0;
        return !0
    }

    function qc(a) {
        if (!pc(a) && nb(a, a.C[u] | 0)) throw Error();
    }

    function rc(a, b) {
        b === void 0 && (b = a[u] | 0);
        b & 32 && !(b & 4096) && (a[u] = b | 4096)
    }

    function mc(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[u] = c | 2, a.i = ob, !0) : !1
    };
    const sc = wb(0),
        tc = {};

    function y(a, b, c, d, e) {
        b = uc(a.C, b, c, e);
        if (b !== null || d && a.A !== ob) return b
    }

    function uc(a, b, c, d) {
        if (b === -1) return null;
        const e = b + (c ? 0 : -1),
            f = a.length - 1;
        let g, h;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f)
                if (g = a[f], g != null && typeof g === "object" && g.constructor === Object) c = g[b], h = !0;
                else if (e === f) c = g;
            else return;
            else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function A(a, b, c) {
        qc(a);
        const d = a.C;
        B(d, d[u] | 0, b, c);
        return a
    }

    function B(a, b, c, d) {
        const e = c + -1;
        var f = a.length - 1;
        if (f >= 0 && e >= f) {
            const g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        d !== void 0 && (f = (b ? ? (b = a[u] | 0)) >> 13 & 1023 || 536870912, c >= f ? d != null && (a[f + -1] = {
            [c]: d
        }) : a[e] = d);
        return b
    }

    function vc(a, b, c) {
        a = a.C;
        return wc(a, a[u] | 0, b, c) !== void 0
    }

    function C(a) {
        return a === pb ? 2 : 4
    }

    function xc(a, b, c, d, e) {
        let f = a.C,
            g = f[u] | 0;
        d = nb(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && pc(a) && (f = a.C, g = f[u] | 0);
        a = yc(f, b);
        let h = a === hb ? 7 : a[u] | 0,
            k = zc(h, g);
        var n = 4 & k ? !1 : !0;
        if (n) {
            4 & k && (a = [...a], h = 0, k = Ac(k, g), g = B(f, g, b, a));
            let l = 0,
                m = 0;
            for (; l < a.length; l++) {
                const p = c(a[l]);
                p != null && (a[m++] = p)
            }
            m < l && (a.length = m);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (a[u] = k, 2 & k && Object.freeze(a));
        return a = Bc(a, k, f, g, b, d, n, e)
    }

    function Bc(a, b, c, d, e, f, g, h) {
        let k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Cc(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && (a[u] = b), Object.freeze(a)) : (f === 2 && Cc(b) && (a = [...a], k = 0, b = Ac(b, d), d = B(c, d, e, a)), Cc(b) || (h || (b |= 16), b !== k && (a[u] = b)));
        2 & b || !(4096 & b || 16 & b) || rc(c, d);
        return a
    }

    function yc(a, b) {
        a = uc(a, b);
        return Array.isArray(a) ? a : hb
    }

    function zc(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Cc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Dc(a, b, c, d) {
        qc(a);
        const e = a.C;
        let f = e[u] | 0;
        if (c == null) return B(e, f, b), a;
        let g = c === hb ? 7 : c[u] | 0,
            h = g;
        var k = Cc(g);
        let n = k || Object.isFrozen(c);
        k || (g = 0);
        n || (c = [...c], h = 0, g = Ac(g, f), n = !1);
        g |= 5;
        k = kb(g) ? ? 0;
        for (let l = 0; l < c.length; l++) {
            const m = c[l],
                p = d(m, k);
            Object.is(m, p) || (n && (c = [...c], h = 0, g = Ac(g, f), n = !1), c[l] = p)
        }
        g !== h && (n && (c = [...c], g = Ac(g, f)), c[u] = g);
        B(e, f, b, c);
        return a
    }

    function Ec(a, b, c, d) {
        qc(a);
        const e = a.C;
        B(e, e[u] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Fc(a, b, c, d) {
        qc(a);
        const e = a.C;
        var f = e[u] | 0;
        if (d == null) {
            var g = Gc(e);
            if (Hc(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Gc(e);
            const h = Hc(g, e, f, c);
            h !== b && (h && (f = B(e, f, h)), g.set(c, b))
        }
        B(e, f, b, d);
        return a
    }

    function Ic(a, b, c) {
        return Jc(a, b) === c ? c : -1
    }

    function Jc(a, b) {
        a = a.C;
        return Hc(Gc(a), a, void 0, b)
    }

    function Gc(a) {
        return a[eb] ? ? (a[eb] = new Map)
    }

    function Hc(a, b, c, d) {
        let e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            const g = d[f];
            uc(b, g) != null && (e !== 0 && (c = B(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Kc(a, b, c) {
        qc(a);
        a = a.C;
        let d = a[u] | 0;
        const e = uc(a, c),
            f = void 0 === qb;
        b = bc(e, b, !f, d);
        if (!f || b) return b = oc(b), e !== b && (d = B(a, d, c, b), rc(a, d)), b
    }

    function wc(a, b, c, d) {
        let e = !1;
        d = uc(a, d, void 0, f => {
            const g = bc(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !nb(d) && rc(a, b), d
    }

    function Lc(a) {
        var b = Mc;
        a = a.C;
        (a = wc(a, a[u] | 0, b, 4)) || (a = b[db]) || (a = new b, jb(a.C, 34), a = b[db] = a);
        return a
    }

    function D(a, b, c) {
        let d = a.C,
            e = d[u] | 0;
        b = wc(d, e, b, c);
        if (b == null) return b;
        e = d[u] | 0;
        if (!nb(a, e)) {
            const f = oc(b);
            f !== b && (pc(a) && (d = a.C, e = d[u] | 0), b = f, e = B(d, e, c, b), rc(d, e))
        }
        return b
    }

    function E(a, b, c, d) {
        var e = a.C,
            f = e;
        e = e[u] | 0;
        var g = nb(a, e);
        const h = g ? 1 : d;
        d = h === 3;
        var k = !g;
        (h === 2 || k) && pc(a) && (f = a.C, e = f[u] | 0);
        a = yc(f, c);
        var n = a === hb ? 7 : a[u] | 0,
            l = zc(n, e);
        if (g = !(4 & l)) {
            var m = a,
                p = e;
            const w = !!(2 & l);
            w && (p |= 2);
            let t = !w,
                z = !0,
                F = 0,
                ja = 0;
            for (; F < m.length; F++) {
                const Sa = bc(m[F], b, !1, p);
                if (Sa instanceof b) {
                    if (!w) {
                        const Ta = nb(Sa);
                        t && (t = !Ta);
                        z && (z = Ta)
                    }
                    m[ja++] = Sa
                }
            }
            ja < F && (m.length = ja);
            l |= 4;
            l = z ? l & -4097 : l | 4096;
            l = t ? l | 8 : l & -9
        }
        l !== n && (a[u] = l, 2 & l && Object.freeze(a));
        if (k && !(8 & l || !a.length && (h === 1 || (h !== 4 ? 0 : 2 & l ||
                !(16 & l) && 32 & e)))) {
            Cc(l) && (a = [...a], l = Ac(l, e), e = B(f, e, c, a));
            b = a;
            k = l;
            for (n = 0; n < b.length; n++) m = b[n], l = oc(m), m !== l && (b[n] = l);
            k |= 8;
            l = k = b.length ? k | 4096 : k & -4097;
            a[u] = l
        }
        return a = Bc(a, l, f, e, c, h, g, d)
    }

    function Nc(a) {
        a == null && (a = void 0);
        return a
    }

    function Oc(a, b, c) {
        c = Nc(c);
        A(a, b, c);
        c && !nb(c) && rc(a.C);
        return a
    }

    function Pc(a, b, c, d) {
        d = Nc(d);
        Fc(a, b, c, d);
        d && !nb(d) && rc(a.C);
        return a
    }

    function Qc(a, b, c) {
        qc(a);
        const d = a.C;
        let e = d[u] | 0;
        if (c == null) return B(d, e, b), a;
        let f = c === hb ? 7 : c[u] | 0,
            g = f;
        const h = Cc(f),
            k = h || Object.isFrozen(c);
        let n = !0,
            l = !0;
        for (let p = 0; p < c.length; p++) {
            var m = c[p];
            h || (m = nb(m), n && (n = !m), l && (l = m))
        }
        h || (f = n ? 13 : 5, f = l ? f & -4097 : f | 4096);
        k && f === g || (c = [...c], g = 0, f = Ac(f, e));
        f !== g && (c[u] = f);
        e = B(d, e, b, c);
        2 & f || !(4096 & f || 16 & f) || rc(d, e);
        return a
    }

    function Ac(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function Rc(a, b) {
        qc(a);
        a = xc(a, 4, v, 2, !0);
        const c = kb(a === hb ? 7 : a[u] | 0) ? ? 0;
        if (Array.isArray(b)) {
            var d = b.length;
            for (let e = 0; e < d; e++) a.push($b(b[e], c))
        } else
            for (d of b) a.push($b(d, c))
    }

    function Sc(a, b) {
        a = y(a, b);
        b = typeof a;
        a != null && (b === "bigint" ? a = wb(Hb(64, a)) : Pb(a) ? b === "string" ? (b = Kb(Number(a)), Ib(b) ? a = wb(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = wb(Hb(64, BigInt(a))))) : a = Ib(a) ? wb(Xb(a)) : wb(Zb(a)) : a = void 0);
        return a
    }

    function Tc(a, b, c) {
        return Tb(y(a, b, void 0, c))
    }

    function G(a, b) {
        return Nb(y(a, b)) ? ? !1
    }

    function H(a, b) {
        return Tc(a, b) ? ? 0
    }

    function Uc(a, b) {
        return y(a, b, void 0, void 0, Lb) ? ? 0
    }

    function I(a, b) {
        return v(y(a, b)) ? ? ""
    }

    function J(a, b) {
        return Rb(y(a, b)) ? ? 0
    }

    function Vc(a, b, c) {
        return J(a, Ic(a, c, b))
    }

    function Wc(a, b, c, d) {
        return D(a, b, Ic(a, d, c))
    }

    function Xc(a, b) {
        return v(y(a, b, void 0, tc))
    }

    function Yc(a, b) {
        return Rb(y(a, b, void 0, tc))
    }

    function Zc(a, b, c) {
        return A(a, b, c == null ? c : Sb(c))
    }

    function $c(a, b, c) {
        return Ec(a, b, c == null ? c : Sb(c), 0)
    }

    function ad(a, b, c) {
        return Ec(a, b, c == null ? c : Vb(c), "0")
    }

    function bd(a, b) {
        var c = performance.now();
        if (c != null && typeof c !== "number") throw Error(`Value of float/double field must be a number, found ${typeof c}: ${c}`);
        Ec(a, b, c, 0)
    }

    function cd(a, b, c) {
        return Ec(a, b, ac(c), "")
    }

    function ed(a, b, c) {
        return A(a, b, c == null ? c : Qb(c))
    }

    function fd(a, b, c) {
        return Ec(a, b, c == null ? c : Qb(c), 0)
    }

    function gd(a, b, c, d) {
        return Fc(a, b, c, d == null ? d : Qb(d))
    };

    function hd(a) {
        const b = a.C,
            c = b[u] | 0;
        return nb(a, c) ? a : mc(a, b, c) ? nc(a, b) : new a.constructor(lc(b, c, !0))
    }
    var K = class {
        constructor(a) {
            this.C = ic(a)
        }
        toJSON() {
            return x(this)
        }
        B() {
            return JSON.stringify(x(this))
        }
    };
    K.prototype[gb] = mb;

    function id(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(lb(b))
    };

    function jd(a) {
        return () => {
            var b;
            (b = a[db]) || (b = new a, jb(b.C, 34), b = a[db] = b);
            return b
        }
    }

    function kd(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(lb(b))
            }
            return b
        }
    };
    var ld = class extends K {};
    var md = class extends K {};
    let nd, od = 64;

    function pd() {
        try {
            return nd ? ? (nd = new Uint32Array(64)), od >= 64 && (crypto.getRandomValues(nd), od = 0), nd[od++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };

    function qd(a, b) {
        if (!sb(a.goog_pvsid)) try {
            const c = pd() + (pd() & 2 ** 21 - 1) * 2 ** 32;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (c) {
            b.ma({
                methodName: 784,
                ua: c
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.ma({
            methodName: 784,
            ua: Error(`Invalid correlator, ${a}`)
        });
        return a || -1
    };

    function rd(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function sd(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function td(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    };

    function ud() {
        return xa && Aa ? Aa.mobile : !vd() && (r("iPod") || r("iPhone") || r("Android") || r("IEMobile"))
    }

    function vd() {
        return xa && Aa ? !Aa.mobile && (r("iPad") || r("Android") || r("Silk")) : r("iPad") || r("Android") && !r("Mobile") || r("Silk")
    };

    function wd(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function xd(a, b) {
        for (const c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function yd(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function zd(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let Ad = globalThis.trustedTypes,
        Bd;

    function Cd() {
        let a = null;
        if (!Ad) return a;
        try {
            const b = c => c;
            a = Ad.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    };
    var Dd = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Ed(a) {
        var b;
        Bd === void 0 && (Bd = Cd());
        a = (b = Bd) ? b.createScriptURL(a) : a;
        return new Dd(a)
    }

    function Fd(a) {
        if (a instanceof Dd) return a.g;
        throw Error("");
    };
    var Gd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Hd(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };
    const Id = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Jd(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };

    function Kd(a, ...b) {
        if (b.length === 0) return Ed(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Ed(c)
    }

    function Ld(a, b) {
        a = Fd(a).toString();
        const c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return Md(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function Md(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        let f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return Ed(a + b + c)
    };

    function Nd(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Pa(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function Od(a) {
        return Nd(a.top) ? a.top : null
    }

    function Pd(a, b) {
        const c = Qd("SCRIPT", a);
        c.src = Fd(b);
        (b = Hd(c.ownerDocument)) && c.setAttribute("nonce", b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Rd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Sd() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Td(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }
    var Ud = /^([0-9.]+)px$/,
        Vd = /^(-?[0-9.]{1,30})$/;

    function Wd(a) {
        if (!Vd.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function Xd(a) {
        return (a = Ud.exec(a)) ? +a[1] : null
    }
    var Yd = sd(() => ud() ? 2 : vd() ? 1 : 0),
        Zd = a => {
            Td({
                display: "none"
            }, (b, c) => {
                a.style.setProperty(c, b, "important")
            })
        };

    function $d() {
        var a = L(ae).A(be.g, be.defaultValue),
            b = M.document;
        if (a.length && b.head)
            for (const c of a) c && b.head && (a = Qd("META"), b.head.appendChild(a), a.httpEquiv = "origin-trial", a.content = c)
    }
    var ce = a => qd(a, {
        ma: () => {}
    });

    function Qd(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };
    let de = [];

    function ee() {
        const a = de;
        de = [];
        for (const b of a) try {
            b()
        } catch {}
    };

    function fe(a, b) {
        this.width = a;
        this.height = b
    }
    fe.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    fe.prototype.isEmpty = function() {
        return !(this.width * this.height)
    };
    fe.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    fe.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    fe.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    fe.prototype.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function ge(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function he(a) {
        this.g = a || q.document || document
    }
    he.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };

    function ie(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    }

    function je(a, b, c) {
        return typeof a.removeEventListener === "function" ? (a.removeEventListener(b, c, !1), !0) : !1
    }

    function ke(a) {
        var b = le;
        b.readyState === "complete" || b.readyState === "interactive" ? (de.push(a), de.length === 1 && (window.Promise ? Promise.resolve().then(ee) : (a = window.setImmediate, typeof a === "function" ? a(ee) : setTimeout(ee, 0)))) : b.addEventListener("DOMContentLoaded", a)
    };

    function me(a, b, c = null, d = !1, e = !1) {
        ne(a, b, c, d, e)
    }

    function ne(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Qd("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    const k = Ia(h, f);
                    k >= 0 && Array.prototype.splice.call(h, k, 1)
                }
                je(f, "load", g);
                je(f, "error", g)
            };
            ie(f, "load", g);
            ie(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function oe(a, b) {
        let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
        Td(a, (d, e) => {
            if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`
        });
        pe(c)
    }

    function pe(a) {
        var b = window;
        b.fetch ? b.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : me(b, a, void 0, !1, !1)
    };
    var le = document,
        M = window;
    let qe = null;
    var re = (a, b = []) => {
        let c = !1;
        q.google_logging_queue || (c = !0, q.google_logging_queue = []);
        q.google_logging_queue.push([a, b]);
        if (a = c) {
            if (qe == null) {
                qe = !1;
                try {
                    const d = Od(q);
                    d && d.location.hash.indexOf("google_logging") !== -1 && (qe = !0)
                } catch (d) {}
            }
            a = qe
        }
        a && Pd(q.document, Kd `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function se(a = q) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function te(a = se()) {
        return a ? Nd(a.master) ? a.master : null : null
    };
    var ue = a => {
            a = te(se(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        ve = a => {
            a = a.google_unique_id;
            return typeof a === "number" ? a : 0
        },
        we = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };

    function xe(a) {
        return !!(a.error && a.meta && a.id)
    }
    var ye = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function ze(a) {
        return new ye(a, {
            message: Ae(a)
        })
    }

    function Ae(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    const Be = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Ce = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        De = class {
            constructor(a, b, c) {
                this.url = a;
                this.l = b;
                this.g = !!c;
                this.depth = null
            }
        };
    let Fe = null;

    function Ge() {
        var a = window;
        if (Fe === null) {
            Fe = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    const c = b.match(/\bdeid=([\d,]+)/);
                    Fe = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return Fe
    };

    function He() {
        const a = q.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Ie() {
        const a = q.performance;
        return a && a.now ? a.now() : null
    };
    var Je = class {
        constructor(a, b) {
            var c = Ie() || He();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const Ke = q.performance,
        Le = !!(Ke && Ke.mark && Ke.measure && Ke.clearMarks),
        Me = sd(() => {
            var a;
            if (a = Le) a = Ge(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function Ne(a) {
        a && Ke && Me() && (Ke.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Ke.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Oe(a) {
        a.g = !1;
        if (a.i !== a.j.google_js_reporting_queue) {
            if (Me()) {
                var b = a.i;
                const c = b.length;
                b = typeof b === "string" ? b.split("") : b;
                for (let d = 0; d < c; d++) d in b && Ne.call(void 0, b[d])
            }
            a.i.length = 0
        }
    }
    var Pe = class {
        constructor(a) {
            this.i = [];
            this.j = a || q;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = Me() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Je(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Ke && Me() && Ke.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (Ie() || He()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Ke && Me() && Ke.mark(b);
                !this.g || this.i.length >
                    2048 || this.i.push(a)
            }
        }
    };

    function Qe(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function Re(a, b, c, d, e) {
        const f = [];
        Td(a, (g, h) => {
            (g = Se(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function Se(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(Se(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Re(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Te(a) {
        let b = 1;
        for (const c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function Ue(a, b, c) {
        b = "https://" + b + c;
        let d = Te(a) - c.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        c = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    c = c == null ? g : c;
                    break
                }
                let n = Re(h[k], a.j, ",$");
                if (n) {
                    n = e + n;
                    if (d >= n.length) {
                        d -= n.length;
                        b += n;
                        e = a.j;
                        break
                    }
                    c = c == null ? g : c
                }
            }
        }
        a = "";
        c != null && (a = `${e}${"trn"}=${c}`);
        return b + a
    }
    var Ve = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.u = 0;
            this.g = []
        }
    };
    var We = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Xe = /#|$/;

    function Ye(a, b) {
        const c = a.search(Xe);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };
    var af = class {
        constructor(a = null) {
            this.F = Ze;
            this.j = a;
            this.i = null;
            this.B = !1;
            this.D = this.J
        }
        H(a) {
            this.D = a
        }
        A(a) {
            this.i = a
        }
        T(a) {
            this.B = a
        }
        g(a, b, c) {
            let d, e;
            try {
                this.j && this.j.g ? (e = this.j.start(a.toString(), 3), d = b(), this.j.end(e)) : d = b()
            } catch (f) {
                b = !0;
                try {
                    Ne(e), b = this.D(a, ze(f), void 0, c)
                } catch (g) {
                    this.J(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        J(a, b, c, d, e) {
            e = e || "jserror";
            let f = void 0;
            try {
                const cb = new Ve;
                var g = cb;
                g.g.push(1);
                g.i[1] = Qe("context",
                    a);
                xe(b) || (b = ze(b));
                g = b;
                if (g.msg) {
                    b = cb;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.i[2] = Qe("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.i) try {
                    this.i(h)
                } catch (V) {}
                if (d) try {
                    d(h)
                } catch (V) {}
                d = cb;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                var n;
                if (!(n = p)) {
                    d = q;
                    k = [];
                    h = null;
                    do {
                        var l = d;
                        if (Nd(l)) {
                            var m = l.location.href;
                            h = l.document && l.document.referrer || null
                        } else m = h, h = null;
                        k.push(new De(m || "", l));
                        try {
                            d = l.parent
                        } catch (V) {
                            d = null
                        }
                    } while (d && l !== d);
                    for (let V = 0, Og = k.length - 1; V <= Og; ++V) k[V].depth = Og - V;
                    l = q;
                    if (l.location && l.location.ancestorOrigins &&
                        l.location.ancestorOrigins.length === k.length - 1)
                        for (m = 1; m < k.length; ++m) {
                            const V = k[m];
                            V.url || (V.url = l.location.ancestorOrigins[m - 1] || "", V.g = !0)
                        }
                    n = k
                }
                var p = n;
                let dd = new De(q.location.href, q, !1);
                n = null;
                const Ee = p.length - 1;
                for (l = Ee; l >= 0; --l) {
                    var w = p[l];
                    !n && Be.test(w.url) && (n = w);
                    if (w.url && !w.g) {
                        dd = w;
                        break
                    }
                }
                w = null;
                const Lk = p.length && p[Ee].url;
                dd.depth !== 0 && Lk && (w = p[Ee]);
                f = new Ce(dd, w);
                if (f.i) {
                    p = cb;
                    var t = f.i.url || "";
                    p.g.push(4);
                    p.i[4] = Qe("top", t)
                }
                var z = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    const V = f.g.url.match(We);
                    var F = V[1],
                        ja = V[3],
                        Sa = V[4];
                    t = "";
                    F && (t += F + ":");
                    ja && (t += "//", t += ja, Sa && (t += ":" + Sa));
                    var Ta = t
                } else Ta = "";
                F = cb;
                z = [z, {
                    url: Ta
                }];
                F.g.push(5);
                F.i[5] = z;
                $e(this.F, e, cb, this.B, c)
            } catch (cb) {
                try {
                    $e(this.F, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Ae(cb),
                        url: f ? .g.url ? ? ""
                    }, this.B, c)
                } catch (dd) {}
            }
            return !0
        }
        pa(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.J(a, c instanceof Error ? c : Error(c), void 0, this.i || void 0)
            })
        }
    };
    var bf = class extends K {},
        cf = [2, 3, 4];
    var df = class extends K {},
        ef = [3, 4, 5],
        ff = [6, 7];
    var gf = class extends K {},
        hf = [4, 5];

    function jf(a, b) {
        var c = E(a, df, 2, C());
        if (!c.length) return kf(a, b);
        a = J(a, 1);
        if (a === 1) return c = jf(c[0], b), c.success ? {
            success: !0,
            value: !c.value
        } : c;
        c = Ka(c, d => jf(d, b));
        switch (a) {
            case 2:
                return c.find(d => d.success && !d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !0
                };
            case 3:
                return c.find(d => d.success && d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    O: 3
                }
        }
    }

    function kf(a, b) {
        var c = Jc(a, ef);
        a: {
            switch (c) {
                case 3:
                    var d = Vc(a, 3, ef);
                    break a;
                case 4:
                    d = Vc(a, 4, ef);
                    break a;
                case 5:
                    d = Vc(a, 5, ef);
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            O: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            property: d,
            fa: c,
            O: 1
        };
        let e;
        try {
            var f = xc(a, 8, v, C());
            e = b(...f)
        } catch (g) {
            return {
                success: !1,
                property: d,
                fa: c,
                O: 2
            }
        }
        f = J(a, 1);
        if (f === 4) return {
            success: !0,
            value: !!e
        };
        if (f === 5) return {
            success: !0,
            value: e != null
        };
        if (f === 12) a = I(a, Ic(a, ff, 7));
        else a: {
            switch (c) {
                case 4:
                    a = Uc(a, Ic(a, ff, 6));
                    break a;
                case 5:
                    a = I(a,
                        Ic(a, ff, 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            property: d,
            fa: c,
            O: 3
        };
        if (f === 6) return {
            success: !0,
            value: e === a
        };
        if (f === 9) return {
            success: !0,
            value: e != null && va(String(e), a) === 0
        };
        if (e == null) return {
            success: !1,
            property: d,
            fa: c,
            O: 4
        };
        switch (f) {
            case 7:
                c = e < a;
                break;
            case 8:
                c = e > a;
                break;
            case 12:
                c = tb(a) && tb(e) && (new RegExp(a)).test(e);
                break;
            case 10:
                c = e != null && va(String(e), a) === -1;
                break;
            case 11:
                c = e != null && va(String(e), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    O: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function lf(a, b) {
        return a ? b ? jf(a, b) : {
            success: !1,
            O: 1
        } : {
            success: !0,
            value: !0
        }
    };

    function mf(a) {
        return xc(a, 4, v, C())
    }
    var Mc = class extends K {};
    var nf = class extends K {
        getValue() {
            return D(this, Mc, 2)
        }
    };
    var of = class extends K {}, pf = kd( of ), qf = [1, 2, 3, 6, 7, 8];
    var rf = class extends K {};

    function sf(a, b) {
        try {
            const c = d => [{
                [d.Aa]: d.za
            }];
            return JSON.stringify([a.filter(d => d.na).map(c), x(b), a.filter(d => !d.na).map(c)])
        } catch (c) {
            return tf(c, b), ""
        }
    }

    function tf(a, b) {
        try {
            oe({
                m: Ae(a instanceof Error ? a : Error(String(a))),
                b: J(b, 1) || null,
                v: I(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }
    var uf = class {
        constructor(a, b) {
            var c = new rf;
            a = fd(c, 1, a);
            b = cd(a, 2, b);
            this.j = hd(b)
        }
    };
    var vf = class extends K {
        getWidth() {
            return H(this, 3)
        }
        getHeight() {
            return H(this, 4)
        }
    };
    var wf = class extends K {};

    function xf(a, b) {
        return A(a, 1, b == null ? b : Vb(b))
    }

    function yf(a, b) {
        return A(a, 2, b == null ? b : Vb(b))
    }
    var zf = class extends K {
        getWidth() {
            return Sc(this, 1) ? ? sc
        }
        getHeight() {
            return Sc(this, 2) ? ? sc
        }
    };
    var Af = class extends K {};
    var Bf = class extends K {};
    var Cf = class extends K {
        getValue() {
            return J(this, 1)
        }
    };
    var Df = class extends K {
        getContentUrl() {
            return I(this, 4)
        }
    };
    var Ef = class extends K {};

    function Ff(a) {
        return Kc(a, Ef, 3)
    }
    var Gf = class extends K {};
    var Hf = class extends K {
        getContentUrl() {
            return I(this, 1)
        }
    };
    var If = class extends K {};

    function Jf(a) {
        var b = new Kf;
        return fd(b, 1, a)
    }
    var Kf = class extends K {};
    var Lf = class extends K {},
        Mf = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19];
    var Nf = class extends K {};

    function Of(a, b) {
        return fd(a, 1, b)
    }

    function Pf(a, b) {
        return fd(a, 2, b)
    }
    var Qf = class extends K {};
    var Rf = class extends K {},
        Sf = [1, 2];

    function Tf(a, b) {
        return Oc(a, 1, b)
    }

    function Uf(a, b) {
        return Qc(a, 2, b)
    }

    function Vf(a, b) {
        return Dc(a, 4, b, Sb)
    }

    function Wf(a, b) {
        return Qc(a, 5, b)
    }

    function Xf(a, b) {
        return fd(a, 6, b)
    }
    var Yf = class extends K {};
    var Zf = class extends K {},
        $f = [1, 2, 3, 4, 6];
    var ag = class extends K {};

    function bg(a) {
        var b = new cg;
        return Pc(b, 4, dg, a)
    }
    var cg = class extends K {
            getTagSessionCorrelator() {
                return Sc(this, 2) ? ? sc
            }
        },
        dg = [4, 5, 7, 8, 9];
    var eg = class extends K {};

    function fg() {
        var a = gg();
        a = oc(a);
        return cd(a, 1, hg())
    }
    var ig = class extends K {};
    var jg = class extends K {};
    var kg = class extends K {
        getTagSessionCorrelator() {
            return Sc(this, 1) ? ? sc
        }
    };
    var lg = class extends K {},
        mg = [1, 7],
        ng = [4, 6, 8];
    class og extends uf {
        constructor() {
            super(...arguments)
        }
    }

    function pg(a, ...b) {
        qg(a, ...b.map(c => ({
            na: !0,
            Aa: 3,
            za: x(c)
        })))
    }

    function rg(a, ...b) {
        qg(a, ...b.map(c => ({
            na: !0,
            Aa: 4,
            za: x(c)
        })))
    }

    function sg(a, ...b) {
        qg(a, ...b.map(c => ({
            na: !0,
            Aa: 7,
            za: x(c)
        })))
    }
    var tg = class extends og {};

    function ug(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function qg(a, ...b) {
        try {
            a.D && sf(a.g.concat(b), a.j).length >= 65536 && vg(a), a.u && !a.A && (a.A = !0, wg(a.u, () => {
                vg(a)
            })), a.g.push(...b), a.g.length >= a.B && vg(a), a.g.length && a.i === null && (a.i = setTimeout(() => {
                vg(a)
            }, a.H))
        } catch (c) {
            tf(c, a.j)
        }
    }

    function vg(a) {
        a.i !== null && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = sf(a.g, a.j);
            a.F("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var xg = class extends tg {
            constructor(a, b, c, d, e, f) {
                super(a, b);
                this.F = ug;
                this.H = c;
                this.B = d;
                this.D = e;
                this.u = f;
                this.g = [];
                this.i = null;
                this.A = !1
            }
        },
        yg = class extends xg {
            constructor(a, b, c = 1E3, d = 100, e = !1, f) {
                super(a, b, c, d, e && !0, f)
            }
        };

    function zg(a, b) {
        var c = Date.now();
        c = Number.isFinite(c) ? Math.round(c) : 0;
        b = ad(b, 1, c);
        c = ce(window);
        b = ad(b, 2, c);
        return ad(b, 6, a.A)
    }

    function Ag(a, b, c, d, e, f) {
        if (a.j) {
            var g = Pf(Of(new Qf, b), c);
            b = Xf(Uf(Tf(Wf(Vf(new Yf, d), e), g), a.g.slice()), f);
            b = bg(b);
            rg(a.i, zg(a, b));
            if (f === 1 || f === 3 || f === 4 && !a.g.some(h => J(h, 1) === J(g, 1) && J(h, 2) === c)) a.g.push(g), a.g.length > 100 && a.g.shift()
        }
    }

    function Bg(a, b, c, d) {
        if (a.j) {
            var e = new Nf;
            b = Zc(e, 1, b);
            c = Zc(b, 2, c);
            d = ed(c, 3, d);
            c = new cg;
            d = Pc(c, 8, dg, d);
            rg(a.i, zg(a, d))
        }
    }

    function Cg(a, b, c, d, e) {
        if (a.j) {
            var f = new gf;
            b = Oc(f, 1, b);
            c = ed(b, 2, c);
            d = Zc(c, 3, d);
            if (e.fa === void 0) gd(d, 4, hf, e.O);
            else switch (e.fa) {
                case 3:
                    c = new bf;
                    c = gd(c, 2, cf, e.property);
                    e = ed(c, 1, e.O);
                    Pc(d, 5, hf, e);
                    break;
                case 4:
                    c = new bf;
                    c = gd(c, 3, cf, e.property);
                    e = ed(c, 1, e.O);
                    Pc(d, 5, hf, e);
                    break;
                case 5:
                    c = new bf, c = gd(c, 4, cf, e.property), e = ed(c, 1, e.O), Pc(d, 5, hf, e)
            }
            e = new cg;
            e = Pc(e, 9, dg, d);
            rg(a.i, zg(a, e))
        }
    }
    var Dg = class {
        constructor(a, b, c, d = new yg(6, "unknown", b)) {
            this.A = a;
            this.u = c;
            this.i = d;
            this.g = [];
            this.j = a > 0 && Sd() < 1 / a
        }
    };
    var L = a => {
        var b = "ya";
        if (a.ya && a.hasOwnProperty(b)) return a.ya;
        b = new a;
        return a.ya = b
    };
    var Eg = class {
        constructor() {
            this.N = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var Fg = /^true$/.test("false");

    function Gg(a, b) {
        switch (b) {
            case 1:
                return Vc(a, 1, qf);
            case 2:
                return Vc(a, 2, qf);
            case 3:
                return Vc(a, 3, qf);
            case 6:
                return Vc(a, 6, qf);
            case 8:
                return Vc(a, 8, qf);
            default:
                return null
        }
    }

    function Hg(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return G(a, 1);
            case 7:
                return I(a, 3);
            case 2:
                return Uc(a, 2);
            case 3:
                return I(a, 3);
            case 6:
                return mf(a);
            case 8:
                return mf(a);
            default:
                return null
        }
    }
    const Ig = sd(() => {
        if (!Fg) return {};
        try {
            var a = window;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch {}
        return {}
    });

    function Jg(a, b, c, d = 0) {
        L(Kg).j[d] = L(Kg).j[d] ? .add(b) ? ? (new Set).add(b);
        const e = Ig();
        if (e[b] != null) return e[b];
        b = Lg(d)[b];
        if (!b) return c;
        b = pf(JSON.stringify(b));
        b = Mg(b);
        a = Hg(b, a);
        return a != null ? a : c
    }

    function Mg(a) {
        const b = L(Eg).N;
        if (b && Jc(a, qf) !== 8) {
            const c = Ma(E(a, nf, 5, C()), d => {
                d = lf(D(d, df, 1), b);
                return d.success && d.value
            });
            if (c) return c.getValue() ? ? null
        }
        return D(a, Mc, 4) ? ? null
    }
    class Kg {
        constructor() {
            this.i = {};
            this.u = [];
            this.j = {};
            this.g = new Map
        }
    }

    function Ng(a, b = !1, c) {
        return !!Jg(1, a, b, c)
    }

    function Pg(a, b = 0, c) {
        a = Number(Jg(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Qg(a, b = "", c) {
        a = Jg(3, a, b, c);
        return typeof a === "string" ? a : b
    }

    function Rg(a, b = [], c) {
        a = Jg(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Sg(a, b = [], c) {
        a = Jg(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Lg(a) {
        return L(Kg).i[a] || (L(Kg).i[a] = {})
    }

    function Tg(a, b) {
        const c = Lg(b);
        Td(a, (d, e) => {
            if (c[e]) {
                var f = d = pf(JSON.stringify(d)),
                    g = Ic(d, qf, 8);
                Rb(y(f, g)) != null && (g = pf(JSON.stringify(c[e])), f = Kc(d, Mc, 4), g = mf(Lc(g)), Rc(f, g));
                c[e] = x(d)
            } else c[e] = d
        })
    }

    function Ug(a, b, c, d, e = !1) {
        var f = [],
            g = [];
        for (const m of b) {
            b = Lg(m);
            for (const p of a) {
                var h = Jc(p, qf);
                const w = Gg(p, h);
                if (w) {
                    a: {
                        var k = w;
                        var n = h,
                            l = L(Kg).g.get(m) ? .get(w) ? .slice(0) ? ? [];
                        const t = new Zf;
                        switch (n) {
                            case 1:
                                gd(t, 1, $f, k);
                                break;
                            case 2:
                                gd(t, 2, $f, k);
                                break;
                            case 3:
                                gd(t, 3, $f, k);
                                break;
                            case 6:
                                gd(t, 4, $f, k);
                                break;
                            case 8:
                                gd(t, 6, $f, k);
                                break;
                            default:
                                k = void 0;
                                break a
                        }
                        Dc(t, 5, l, Sb);k = t
                    }
                    k && L(Kg).j[m] ? .has(w) && f.push(k);h === 8 && b[w] ? (k = pf(JSON.stringify(b[w])), h = Kc(p, Mc, 4), k = mf(Lc(k)), Rc(h, k)) : k && L(Kg).g.get(m) ? .has(w) &&
                    g.push(k);e || (h = w, k = m, n = d, l = L(Kg), l.g.has(k) || l.g.set(k, new Map), l.g.get(k).has(h) || l.g.get(k).set(h, []), n && l.g.get(k).get(h).push(n));b[w] = x(p)
                }
            }
        }
        if (f.length || g.length) a = d ? ? void 0, c.j && c.u && (d = new ag, f = Qc(d, 2, f), g = Qc(f, 3, g), a && $c(g, 1, a), f = new cg, g = Pc(f, 7, dg, g), rg(c.i, zg(c, g)))
    }

    function Vg(a, b) {
        b = Lg(b);
        for (const c of a) {
            a = pf(JSON.stringify(c));
            const d = Jc(a, qf);
            (a = Gg(a, d)) && (b[a] || (b[a] = c))
        }
    }

    function Wg() {
        return Object.keys(L(Kg).i).map(a => Number(a))
    }

    function Xg(a) {
        L(Kg).u.includes(a) || Tg(Lg(4), a)
    };

    function N(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Yg(a, b, c) {
        return b[a] || c
    }

    function Zg(a) {
        N(5, Ng, a);
        N(6, Pg, a);
        N(7, Qg, a);
        N(8, Rg, a);
        N(17, Sg, a);
        N(13, Vg, a);
        N(15, Xg, a)
    }

    function $g(a) {
        N(4, b => {
            L(Eg).N = b
        }, a);
        N(9, (b, c) => {
            var d = L(Eg);
            d.N[3][b] == null && (d.N[3][b] = c)
        }, a);
        N(10, (b, c) => {
            var d = L(Eg);
            d.N[4][b] == null && (d.N[4][b] = c)
        }, a);
        N(11, (b, c) => {
            var d = L(Eg);
            d.N[5][b] == null && (d.N[5][b] = c)
        }, a);
        N(14, b => {
            var c = L(Eg);
            for (const d of [3, 4, 5]) Object.assign(c.N[d], b[d])
        }, a)
    }

    function ah(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function bh(a, b, c) {
        a.j = Yg(1, b, () => {});
        a.u = (d, e) => Yg(2, b, () => [])(d, c, e);
        a.g = () => Yg(3, b, () => [])(c);
        a.i = d => {
            Yg(16, b, () => {})(d, c)
        }
    }
    class ch {
        j() {}
        i() {}
        u() {
            return []
        }
        g() {
            return []
        }
    };

    function $e(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ve ? f = c : (f = new Ve, Td(c, (h, k) => {
                var n = f;
                const l = n.u++;
                h = Qe(k, h);
                n.g.push(l);
                n.i[l] = h
            }));
            const g = Ue(f, a.domain, a.path + b + "&");
            g && me(q, g)
        } catch (f) {}
    }

    function dh(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    var eh = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.g = Math.random()
        }
    };
    let Ze, fh;
    const gh = new Pe(window);
    (function(a) {
        Ze = a ? ? new eh;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        dh(Ze, window.google_srt);
        fh = new af(gh);
        fh.A(() => {});
        fh.T(!0);
        window.document.readyState === "complete" ? window.google_measure_js_timing || Oe(gh) : gh.g && ie(window, "load", () => {
            window.google_measure_js_timing || Oe(gh)
        })
    })();
    let hh = (new Date).getTime();
    var ih = {
        Xb: 0,
        Wb: 1,
        Tb: 2,
        Ob: 3,
        Ub: 4,
        Pb: 5,
        Vb: 6,
        Rb: 7,
        Sb: 8,
        Nb: 9,
        Qb: 10,
        Yb: 11
    };
    var jh = {
        ac: 0,
        bc: 1,
        Zb: 2
    };

    function kh(a) {
        if (a.g != 0) throw Error("Already resolved/rejected.");
    }
    var nh = class {
        constructor() {
            this.i = new lh(this);
            this.g = 0
        }
        resolve(a) {
            kh(this);
            this.g = 1;
            this.u = a;
            mh(this.i)
        }
        reject(a) {
            kh(this);
            this.g = 2;
            this.j = a;
            mh(this.i)
        }
    };

    function mh(a) {
        switch (a.g.g) {
            case 0:
                break;
            case 1:
                a.i && a.i(a.g.u);
                break;
            case 2:
                a.j && a.j(a.g.j);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var lh = class {
        constructor(a) {
            this.g = a
        }
        then(a, b) {
            if (this.i) throw Error("Then functions already set.");
            this.i = a;
            this.j = b;
            mh(this)
        }
    };
    var oh = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new oh(Ja(this.g, a))
        }
        apply(a) {
            return new oh(a(this.g.slice(0)))
        }
        sort(a) {
            return new oh(this.g.slice(0).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = this.g.slice(0);
            b.push(a);
            return new oh(b)
        }
    };

    function ph(a, b) {
        const c = [],
            d = a.length;
        for (let e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    var rh = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            const c = qh(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = qh(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function qh(a) {
        return a instanceof Object ? String(ma(a)) : a + ""
    };

    function sh(a) {
        return new th({
            value: a
        }, null)
    }

    function uh(a) {
        return new th(null, a)
    }

    function vh(a) {
        try {
            return sh(a())
        } catch (b) {
            return uh(b)
        }
    }

    function wh(a) {
        return a.g != null ? a.getValue() : null
    }

    function xh(a, b) {
        a.g != null && b(a.getValue());
        return a
    }

    function yh(a, b) {
        a.g != null || b(a.i);
        return a
    }
    var th = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return this.g != null ? (a = a(this.getValue()), a instanceof th ? a : sh(a)) : this
        }
    };
    var zh = class {
        constructor(a) {
            this.g = new rh;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return this.g.g[qh(a)] !== void 0
        }
    };
    var Ah = class {
        constructor() {
            this.g = new rh
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new zh, this.g.set(a, c));
            c.add(b)
        }
    };
    var Bh = class extends K {
        getId() {
            return Xc(this, 3)
        }
    };
    var Ch = class {
        constructor({
            lb: a,
            ec: b,
            tc: c,
            Gb: d
        }) {
            this.g = b;
            this.u = new oh(a || []);
            this.j = d;
            this.i = c
        }
    };

    function Dh(a) {
        const b = a.length;
        if (b === 0) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };
    const Fh = a => {
            const b = [],
                c = a.u;
            c && c.g.length && b.push({
                ba: "a",
                ea: Eh(c)
            });
            a.g != null && b.push({
                ba: "as",
                ea: a.g
            });
            a.i != null && b.push({
                ba: "i",
                ea: String(a.i)
            });
            a.j != null && b.push({
                ba: "rp",
                ea: String(a.j)
            });
            b.sort(function(d, e) {
                return d.ba.localeCompare(e.ba)
            });
            b.unshift({
                ba: "t",
                ea: "aa"
            });
            return b
        },
        Eh = a => {
            a = a.g.slice(0).map(Gh);
            a = JSON.stringify(a);
            return Dh(a)
        },
        Gh = a => {
            const b = {};
            v(y(a, 7)) != null && (b.q = Xc(a, 7));
            Tc(a, 2) != null && (b.o = Tc(a, 2, tc));
            Tc(a, 5) != null && (b.p = Tc(a, 5, tc));
            return b
        };

    function Hh(a) {
        return Yc(a, 2)
    }
    var Ih = class extends K {
        setLocation(a) {
            return ed(this, 1, a)
        }
    };

    function Jh(a) {
        const b = [].slice.call(arguments).filter(rd(e => e === null));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Ra || []);
            d = Object.assign(d, e.Ya)
        });
        return new Kh(c, d)
    }

    function Lh(a) {
        switch (a) {
            case 1:
                return new Kh(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Kh(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Kh(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Kh(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Mh(a) {
        if (a == null) var b = null;
        else {
            b = Kh;
            var c = Fh(a);
            a = [];
            for (let d of c) c = String(d.ea), a.push(d.ba + "." + (c.length <= 20 ? c : c.slice(0, 19) + "_"));
            b = new b(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    var Kh = class {
        constructor(a, b) {
            this.Ra = a;
            this.Ya = b
        }
    };
    var Nh = new Kh(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var Oh = kd(class extends K {});

    function Ph(a) {
        return D(a, Bh, 1)
    }

    function Qh(a) {
        return Yc(a, 2)
    }
    var Rh = class extends K {};
    var Sh = class extends K {};
    var Th = class extends K {};

    function Uh(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };

    function Vh(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    let d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        Uh(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };
    var O = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        P = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Wh = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var Xh = new P(1359),
        Yh = new P(1358),
        Zh = new O(1360),
        $h = new P(1357),
        ai = new O(1345),
        bi = new P(1130, 100),
        ci = new P(1340, .2),
        di = new P(1338, .3),
        ei = new P(1339, .3),
        fi = new O(1337),
        gi = new class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        }(14),
        hi = new O(782575400),
        ii = new O(1342),
        ji = new O(1344),
        ki = new P(1343, 300),
        li = new O(316),
        mi = new O(313),
        ni = new O(369),
        oi = new O(1318, !0),
        pi = new O(626390500),
        qi = new O(768003785, !0),
        ri = new Wh(635821288, ["29_18", "30_19"]),
        si = new Wh(683929765),
        ti = new O(506914611),
        ui = new P(717888910,
            .5423),
        vi = new P(9604, .5423),
        wi = new P(643258048, .1542),
        xi = new P(9601, .1542),
        yi = new P(643258049, .16),
        zi = new P(9602, .16),
        Ai = new P(717888911, .7),
        Bi = new P(9605, .5799),
        Ci = new P(717888912, .5849),
        Di = new P(9606, .65),
        Ei = new P(748662193, 4),
        Fi = new P(9603, 4),
        Gi = new O(760801919, !0),
        Hi = new O(711741274),
        Ii = new O(45712203),
        Ji = new P(684147711, -1),
        Ki = new P(684147712, -1),
        Li = new O(662101537),
        Mi = new P(1079, 5),
        Ni = new O(10013),
        Oi = new O(772097522),
        be = new class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        }(1934, ["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
            "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A9wSqI5i0iwGdf6L1CERNdmsTPgVu44ewj8QxTBYgsv1LCPUVF7YmWOvTappqB1139jAymxUW/RO8zmMqo4zlAAAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9",
            "A+d7vJfYtay4OUbdtRPZA3y7bKQLsxaMEPmxgfhBGqKXNrdkCQeJlUwqa6EBbSfjwFtJWTrWIioXeMW+y8bWAgQAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
        ]),
        Pi = new O(84);
    var ae = class {
        constructor() {
            const a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.u = (b, c) => a[b] != null ? a[b] : c;
            this.i = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.B = () => {}
        }
    };

    function Q(a) {
        return L(ae).j(a.g, a.defaultValue)
    }

    function R(a) {
        return L(ae).u(a.g, a.defaultValue)
    };

    function Qi(a, b) {
        const c = e => {
                e = Ri(e);
                return e == null ? !1 : 0 < e
            },
            d = e => {
                e = Ri(e);
                return e == null ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: Si(a.previousSibling, c),
                    ia: e => Si(e.previousSibling, c),
                    oa: 0
                };
            case 2:
                return {
                    init: Si(a.lastChild, c),
                    ia: e => Si(e.previousSibling, c),
                    oa: 0
                };
            case 3:
                return {
                    init: Si(a.nextSibling, d),
                    ia: e => Si(e.nextSibling, d),
                    oa: 3
                };
            case 1:
                return {
                    init: Si(a.firstChild, d),
                    ia: e => Si(e.nextSibling, d),
                    oa: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Ri(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Si(a, b) {
        return a && b(a) ? a : null
    };
    var Ti = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };
    var Ui = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function Vi(a) {
        a = a.document;
        let b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function S(a) {
        return Vi(a).clientWidth ? ? void 0
    };

    function Wi(a, b) {
        do {
            const c = Rd(a, b);
            if (c && c.position == "fixed") return !1
        } while (a = a.parentElement);
        return !0
    };

    function Xi(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            const f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = Xd(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function Yi(a, b) {
        return !((Vd.test(b.google_ad_width) || Ud.test(a.style.width)) && (Vd.test(b.google_ad_height) || Ud.test(a.style.height)))
    }

    function Zi(a, b) {
        return (a = $i(a, b)) ? a.y : 0
    }

    function $i(a, b) {
        try {
            const c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function aj(a, b, c, d, e) {
        if (a !== a.top) return Od(a) ? 3 : 16;
        if (!(S(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        const f = S(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = S(a); c; c = c.parentElement)
                    if ((d = Rd(c, a)) && (e = Xd(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function bj(a, b, c, d) {
        const e = aj(b, c, a, R(ei), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || Wi(c, b) ? (b = S(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function cj(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function dj(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = Rd(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function ej(a, b, c) {
        a = $i(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function fj(a, b) {
        var c;
        c = (c = b.parentElement) ? (c = Rd(c, a)) ? c.direction : "" : "";
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            cj(b, c, "0px");
            d.width = `${S(a)}px`;
            if (ej(a, b, c) !== 0) {
                cj(b, c, "0px");
                var e = ej(a, b, c);
                cj(b, c, `${-1*e}px`);
                a = ej(a, b, c);
                a !== 0 && a !== e && cj(b, c, `${e/(a-e)*e}px`)
            }
            d.zIndex = "30"
        }
    };

    function gj(a, b, c) {
        let d;
        return a.style && !!a.style[c] && Xd(a.style[c]) || (d = Rd(a, b)) && !!d[c] && Xd(d[c]) || null
    }

    function hj(a, b) {
        const c = ve(a) === 0;
        return b && c ? Math.max(250, 2 * Vi(a).clientHeight / 3) : 250
    }

    function ij(a, b) {
        let c;
        return a.style && a.style.zIndex || (c = Rd(a, b)) && c.zIndex || null
    }

    function jj(a) {
        return b => b.g <= a
    }

    function kj(a, b, c, d) {
        const e = a && lj(c, b),
            f = hj(b, d);
        return g => !(e && g.height() >= f)
    }

    function mj(a) {
        return b => b.height() <= a
    }

    function lj(a, b) {
        return Zi(a, b) < Vi(b).clientHeight - 100
    }

    function nj(a, b) {
        var c = gj(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = gj(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && Xd(b.style.height)) && (c = Math.min(c, d)), (d = gj(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };
    var oj = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_ad_start_delay_hint: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0,
        google_overlays: !0,
        google_privacy_treatments: !0,
        google_special_category_data: !0,
        google_ad_intent_query: !0,
        google_ad_intent_qetid: !0,
        google_ad_intent_rs_token: !0,
        google_ad_intents_format: !0
    };
    const pj = RegExp("(^| )adsbygoogle($| )");

    function qj(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = Jd(d.property);
            a[e] = d.value
        }
    };
    var rj = class extends K {
        g() {
            return Nb(y(this, 23, void 0, tc))
        }
    };
    var sj = class extends K {
        g() {
            return Sc(this, 1)
        }
    };
    var tj = class extends K {};
    var uj = class extends K {};
    var vj = class extends K {};
    var wj = class extends K {};
    var xj = class extends K {
            getName() {
                return Xc(this, 4)
            }
        },
        yj = [1, 2, 3];
    var zj = class extends K {};
    var Aj = class extends K {};
    var Bj = class extends K {};
    var Dj = class extends K {
            g() {
                return Wc(this, Bj, 2, Cj)
            }
        },
        Cj = [1, 2];
    var Ej = class extends K {
        g() {
            return D(this, Dj, 3)
        }
    };
    var Fj = class extends K {},
        Gj = kd(Fj);

    function Hj(a) {
        const b = [];
        ph(a.getElementsByTagName("p"), function(c) {
            Ij(c) >= 100 && b.push(c)
        });
        return b
    }

    function Ij(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        let b = 0;
        ph(a.childNodes, function(c) {
            b += Ij(c)
        });
        return b
    }

    function Jj(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Kj(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function Lj(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.u)
        } catch (d) {}
        if (!c.length) return [];
        b = Oa(c);
        b = Kj(a, b);
        typeof a.i === "number" && (c = a.i, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.j === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                const e = Hj(b[d]);
                let f = a.j;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var Mj = class {
        constructor(a, b, c, d) {
            this.u = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.u,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };
    var Nj = class {
        constructor() {
            this.i = Kd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        J(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            xe(b) || (b = new ye(b, {
                context: a,
                id: d
            }));
            q.google_js_errors = q.google_js_errors || [];
            q.google_js_errors.push(b);
            q.error_rep_loaded || (Pd(q.document, this.i), q.error_rep_loaded = !0);
            return !1
        }
        g(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.J(a, c, .01, "jserror")) throw c;
            }
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        pa(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.J(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function Oj(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function Pj(a, b, c, d, e = !1) {
        const f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            const k = Ie();
            let n, l = 3;
            try {
                n = b.apply(this, h)
            } catch (m) {
                l = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && k && Oj({
                    label: a.toString(),
                    value: k,
                    duration: (Ie() || 0) - k,
                    type: l,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return n
        }
    }

    function Qj(a, b) {
        return Pj(a, b, (c, d) => {
            (new Nj).J(c, d)
        }, void 0, !1)
    };

    function Rj(a, b, c) {
        return Pj(a, b, void 0, c, !0).apply()
    }

    function Sj(a) {
        if (!a) return null;
        var b = Xc(a, 7);
        if (Xc(a, 1) || a.getId() || xc(a, 4, v, C()).length > 0) {
            var c = a.getId(),
                d = Xc(a, 1),
                e = xc(a, 4, v, C());
            b = Tc(a, 2, tc);
            var f = Tc(a, 5, tc);
            a = Tj(Yc(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + Jj(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Jj(e[c]);
            b = (e = g) ? new Mj(e, b, f, a) : null
        } else b = b ? new Mj(b, Tc(a, 2, tc), Tc(a, 5, tc), Tj(Yc(a, 6))) : null;
        return b
    }
    const Uj = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Tj(a) {
        return a == null ? a : Uj[a]
    }
    const Vj = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function Wj(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function Xj(a) {
        a = Wj(a);
        return a.optimization = a.optimization || {}
    };
    var Yj = a => {
        switch (Yc(a, 8)) {
            case 1:
            case 2:
                if (a == null) var b = null;
                else b = D(a, Bh, 1), b == null ? b = null : (a = Yc(a, 2), b = a == null ? null : new Ch({
                    lb: [b],
                    Gb: a
                }));
                return b != null ? sh(b) : uh(Error("Missing dimension when creating placement id"));
            case 3:
                return uh(Error("Missing dimension when creating placement id"));
            default:
                return b = "Invalid type: " + Yc(a, 8), uh(Error(b))
        }
    };
    var Zj = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function ak(a, b) {
        const c = new Ah,
            d = new zh;
        b.forEach(e => {
            if (Wc(e, vj, 1, yj)) {
                e = Wc(e, vj, 1, yj);
                if (D(e, Rh, 1) && Ph(D(e, Rh, 1)) && D(e, Rh, 2) && Ph(D(e, Rh, 2))) {
                    const g = bk(a, Ph(D(e, Rh, 1))),
                        h = bk(a, Ph(D(e, Rh, 2)));
                    if (g && h)
                        for (var f of Zj({
                                anchor: g,
                                position: Qh(D(e, Rh, 1))
                            }, {
                                anchor: h,
                                position: Qh(D(e, Rh, 2))
                            })) c.set(ma(f.anchor), f.position)
                }
                D(e, Rh, 3) && Ph(D(e, Rh, 3)) && (f = bk(a, Ph(D(e, Rh, 3)))) && c.set(ma(f), Qh(D(e, Rh, 3)))
            } else Wc(e, wj, 2, yj) ? ck(a, Wc(e, wj, 2, yj), c) : Wc(e, uj, 3, yj) && dk(a, Wc(e, uj, 3, yj), d)
        });
        return new ek(c, d)
    }
    var ek = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    const ck = (a, b, c) => {
            D(b, Rh, 2) ? (b = D(b, Rh, 2), (a = bk(a, Ph(b))) && c.set(ma(a), Qh(b))) : D(b, Bh, 1) && (a = fk(a, D(b, Bh, 1))) && a.forEach(d => {
                d = ma(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        dk = (a, b, c) => {
            D(b, Bh, 1) && (a = fk(a, D(b, Bh, 1))) && a.forEach(d => {
                c.add(ma(d))
            })
        },
        bk = (a, b) => (a = fk(a, b)) && a.length > 0 ? a[0] : null,
        fk = (a, b) => (b = Sj(b)) ? Lj(b, a) : null;

    function hg() {
        return "m202507280101"
    };
    var gk = jd(eg);
    var gg = jd(ig);

    function hk(a, b) {
        return b(a) ? a : void 0
    }

    function ik(a, b, c, d, e) {
        c = c instanceof ye ? c.error : c;
        var f = new lg;
        const g = new kg;
        try {
            var h = ce(window);
            ad(g, 1, h)
        } catch (p) {}
        try {
            var k = L(ch).g();
            Dc(g, 2, k, Sb)
        } catch (p) {}
        try {
            cd(g, 3, window.document.URL)
        } catch (p) {}
        h = Oc(f, 2, g);
        k = new jg;
        b = fd(k, 1, b);
        try {
            var n = tb(c ? .name) ? c.name : "Unknown error";
            cd(b, 2, n)
        } catch (p) {}
        try {
            var l = tb(c ? .message) ? c.message : `Caught ${c}`;
            cd(b, 3, l)
        } catch (p) {}
        try {
            var m = tb(c ? .stack) ? c.stack : Error().stack;
            m && Dc(b, 4, m.split(/\n\s*/), $b)
        } catch (p) {}
        n = Pc(h, 1, mg, b);
        if (e) {
            l = 0;
            switch (e.errSrc) {
                case "LCC":
                    l =
                        1;
                    break;
                case "PVC":
                    l = 2
            }
            m = fg();
            b = hk(e.shv, tb);
            m = cd(m, 2, b);
            l = fd(m, 6, l);
            m = gk();
            m = oc(m);
            b = hk(e.es, vb());
            m = Dc(m, 1, b, Sb);
            m = hd(m);
            l = Oc(l, 4, m);
            m = hk(e.client, tb);
            l = A(l, 3, ac(m));
            m = hk(e.slotname, tb);
            l = cd(l, 7, m);
            e = hk(e.tag_origin, tb);
            e = cd(l, 8, e);
            e = hd(e)
        } else e = hd(fg());
        e = Pc(n, 6, ng, e);
        d = ad(e, 5, d ? ? 1);
        pg(a, d)
    };
    var kk = class {
        constructor() {
            this.g = jk
        }
    };

    function jk() {
        return {
            Db: pd() + (pd() & 2 ** 21 - 1) * 2 ** 32,
            rb: Number.MAX_SAFE_INTEGER
        }
    };
    var nk = class {
        constructor(a = !1) {
            var b = lk;
            this.D = mk;
            this.B = a;
            this.F = b;
            this.i = null;
            this.j = this.J
        }
        H(a) {
            this.j = a
        }
        A(a) {
            this.i = a
        }
        T() {}
        g(a, b, c) {
            let d;
            try {
                d = b()
            } catch (e) {
                b = this.B;
                try {
                    b = this.j(a, ze(e), void 0, c)
                } catch (f) {
                    this.J(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        u(a, b) {
            return (...c) => this.g(a, () => b.apply(void 0, c))
        }
        pa(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.J(a, c instanceof Error ? c : Error(c), void 0, void 0)
            })
        }
        J(a, b, c, d) {
            try {
                const g = c === void 0 ? 1 / this.F : c === 0 ? 0 : 1 / c;
                var e = (new kk).g();
                if (g > 0 && e.Db * g <= e.rb) {
                    var f = this.D;
                    c = {};
                    if (this.i) try {
                        this.i(c)
                    } catch (h) {}
                    if (d) try {
                        d(c)
                    } catch (h) {}
                    ik(f, a, b, g, c)
                }
            } catch (g) {}
            return this.B
        }
    };
    var T = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, T) : this.stack = Error().stack || ""
        }
    };
    let mk, ok, pk, qk, lk;
    const rk = new Pe(q);

    function sk(a) {
        a != null && (q.google_measure_js_timing = a);
        q.google_measure_js_timing || Oe(rk)
    }(function(a, b, c = !0) {
        ({
            Fb: lk,
            ub: pk
        } = tk());
        ok = a || new eh;
        dh(ok, pk);
        mk = b || new yg(2, hg(), 1E3);
        qk = new nk(c);
        q.document.readyState === "complete" ? sk() : rk.g && ie(q, "load", () => {
            sk()
        })
    })();

    function uk(a, b, c) {
        return qk.g(a, b, c)
    }

    function vk(a, b) {
        return qk.u(a, b)
    }

    function wk(a, b) {
        qk.pa(a, b)
    }

    function xk(a, b, c = .01) {
        const d = L(ch).g();
        !b.eid && d.length && (b.eid = d.toString());
        $e(ok, a, b, !0, c)
    }

    function yk(a, b, c = lk, d, e) {
        return qk.J(a, b, c, d, e)
    }

    function zk(a, b, c = lk, d, e) {
        return (xe(b) ? b.msg || Ae(b.error) : Ae(b)).indexOf("TagError") === 0 ? ((xe(b) ? b.error : b).pbr = !0, !1) : yk(a, b, c, d, e)
    }

    function tk() {
        let a, b;
        typeof q.google_srt === "number" ? (b = q.google_srt, a = q.google_srt === 0 ? 1 : .01) : (b = Math.random(), a = .01);
        return {
            Fb: a,
            ub: b
        }
    };
    var Ak = class {
        constructor() {
            var a = Math.random;
            this.g = Math.floor(a() * 2 ** 52);
            this.i = 0
        }
    };

    function Bk(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (Ck(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function Dk(a) {
        a = Ek(a);
        return a.has("all") || a.has("after")
    }

    function Fk(a) {
        a = Ek(a);
        return a.has("all") || a.has("before")
    }

    function Ek(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function Ck(a) {
        const b = Ek(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var Gk = class {
        constructor() {
            this.g = new Set;
            this.i = new Ak
        }
    };

    function Hk(a, b) {
        if (!a) return !1;
        a = Rd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function Ik(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function Jk(a) {
        return !!a.nextSibling || !!a.parentNode && Jk(a.parentNode)
    };

    function Kk(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };

    function Mk(a) {
        return {
            dc: Nk(a),
            fc: U(a, "body ins.adsbygoogle"),
            ib: Ok(a),
            jb: U(a, ".google-auto-placed"),
            kb: Pk(a),
            sb: Qk(a),
            lc: Rk(a),
            vc: Sk(a),
            Cb: Tk(a),
            kc: U(a, "div.googlepublisherpluginad"),
            Lb: U(a, "html > ins.adsbygoogle")
        }
    }

    function Rk(a) {
        return Uk(a) || U(a, "div[id^=div-gpt-ad]")
    }

    function Uk(a) {
        const b = Kk(a);
        return b ? Ja(Ka(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
    }

    function U(a, b) {
        return Oa(a.document.querySelectorAll(b))
    }

    function Pk(a) {
        return U(a, "ins.adsbygoogle[data-anchor-status]")
    }

    function Ok(a) {
        return U(a, "iframe[id^=aswift_],iframe[id^=google_ads_frame]")
    }

    function Sk(a) {
        return U(a, "ins.adsbygoogle[data-ad-format=autorelaxed]")
    }

    function Qk(a) {
        return Rk(a).concat(U(a, "iframe[id^=google_ads_iframe]"))
    }

    function Tk(a) {
        return U(a, "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")
    }

    function Nk(a) {
        return U(a, "ins.adsbygoogle-ablated-ad-slot")
    }

    function Vk(a) {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function Wk(a, b) {
        if (a.u) return !0;
        a.u = !0;
        const c = E(a.j, Th, 1, C());
        a.i = 0;
        const d = Xk(a.F);
        var e = a.g;
        var f;
        try {
            var g = (f = e.localStorage.getItem("google_ama_settings")) ? Oh(f) : null
        } catch (w) {
            g = null
        }
        f = g !== null && G(g, 2);
        g = Wj(e);
        f && (g.eatf = !0, re(7, [!0, 0, !1]));
        b: {
            var h = {
                    xb: !1,
                    yb: !1
                },
                k = U(e, ".google-auto-placed"),
                n = Pk(e),
                l = Sk(e),
                m = Qk(e);
            const w = Tk(e),
                t = Nk(e),
                z = U(e, "div.googlepublisherpluginad"),
                F = U(e, "html > ins.adsbygoogle");
            let ja = [].concat(...Ok(e), ...U(e, "body ins.adsbygoogle"));f = [];
            for (const [Sa, Ta] of [
                    [h.nc,
                        k
                    ],
                    [h.xb, n],
                    [h.rc, l],
                    [h.oc, m],
                    [h.sc, w],
                    [h.mc, t],
                    [h.qc, z],
                    [h.yb, F]
                ]) Sa === !1 ? f = f.concat(Ta) : ja = ja.concat(Ta);h = Vk(ja);f = Vk(f);h = h.slice(0);
            for (p of f)
                for (f = 0; f < h.length; f++)(p.contains(h[f]) || h[f].contains(p)) && h.splice(f, 1);
            var p = h;e = Vi(e).clientHeight;
            for (f = 0; f < p.length; f++)
                if (!(p[f].getBoundingClientRect().top > e)) {
                    e = !0;
                    break b
                }
            e = !1
        }
        e = e ? g.eatfAbg = !0 : !1;
        if (e) return !0;
        e = new zh([2]);
        for (g = 0; g < c.length; g++) {
            p = a;
            h = c[g];
            f = g;
            k = b;
            (n = !D(h, Ih, 4)) || (n = e, l = n.contains, m = D(h, Ih, 4), m = Yc(m, 1), n = !l.call(n, m));
            if (n ||
                Yc(h, 8) !== 1 || !Yk(h, d)) p = null;
            else {
                p.i++;
                if (k = Zk(p, h, k, d)) n = Wj(p.g), n.numAutoAdsPlaced || (n.numAutoAdsPlaced = 0), (l = !D(h, Bh, 1)) || (h = D(h, Bh, 1), l = Tc(h, 5) == null), l || (n.numPostPlacementsPlaced ? n.numPostPlacementsPlaced++ : n.numPostPlacementsPlaced = 1), n.placed == null && (n.placed = []), n.numAutoAdsPlaced++, n.placed.push({
                    index: f,
                    element: k.ga
                }), re(7, [!1, p.i, !0]);
                p = k
            }
            if (p) return !0
        }
        re(7, [!1, a.i, !1]);
        return !1
    }

    function Zk(a, b, c, d) {
        if (!Yk(b, d) || Rb(y(b, 8)) != 1) return null;
        d = D(b, Bh, 1);
        if (!d) return null;
        d = Sj(d);
        if (!d) return null;
        d = Lj(d, a.g.document);
        if (d.length == 0) return null;
        d = d[0];
        var e = Yc(b, 2);
        e = Vj[e];
        e = e === void 0 ? null : e;
        var f;
        if (!(f = e == null)) {
            a: {
                f = a.g;
                switch (e) {
                    case 0:
                        f = Hk(Ik(d), f);
                        break a;
                    case 3:
                        f = Hk(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = Hk(g ? g.nodeType == 1 ? g : Ik(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && e == 2 && !Jk(d))) c = e == 1 || e == 2 ? d : d.parentNode,
            c = !(c && !Uh(c) && c.offsetWidth <= 0);f = !c
        }
        if (!(c = f)) {
            c = a.B;
            f = Yc(b,
                2);
            g = c.i;
            var h = ma(d);
            g = g.g.get(h);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.g.contains(ma(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.g.contains(ma(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.D;
            g = Yc(b, 2);
            a: switch (g) {
                case 1:
                    f = Dk(d.previousElementSibling) || Fk(d);
                    break a;
                case 4:
                    f = Dk(d) || Fk(d.nextElementSibling);
                    break a;
                case 2:
                    f = Fk(d.firstElementChild);
                    break a;
                case 3:
                    f = Dk(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " +
                        g);
            }
            g = Bk(c, d, g);
            c = c.i;
            xk("ama_exclusion_zone", {
                typ: f ? g ? "siuex" : "siex" : g ? "suex" : "noex",
                cor: c.g,
                num: c.i++,
                dvc: Yd()
            }, .1);
            c = f || g
        }
        if (c) return null;
        f = D(b, Sh, 3);
        c = {};
        f && (c.fb = Xc(f, 1), c.Pa = Xc(f, 2), c.pb = !!Nb(y(f, 3, void 0, tc)));
        f = D(b, Ih, 4) && Hh(D(b, Ih, 4)) ? Hh(D(b, Ih, 4)) : null;
        f = Lh(f);
        g = Tc(b, 12) != null ? Tc(b, 12, tc) : null;
        g = g == null ? null : new Kh(null, {
            google_ml_rank: g
        });
        b = $k(a, b);
        b = Jh(a.A, f, g, b);
        f = a.g;
        a = a.H;
        h = f.document;
        var k = c.pb || !1;
        g = ge((new he(h)).g, "DIV");
        const n = g.style;
        n.width = "100%";
        n.height = "auto";
        n.clear = k ?
            "both" : "none";
        k = g.style;
        k.textAlign = "center";
        c.Eb && qj(k, c.Eb);
        h = ge((new he(h)).g, "INS");
        k = h.style;
        k.display = "block";
        k.margin = "auto";
        k.backgroundColor = "transparent";
        c.fb && (k.marginTop = c.fb);
        c.Pa && (k.marginBottom = c.Pa);
        c.hb && qj(k, c.hb);
        g.appendChild(h);
        c = {
            wa: g,
            ga: h
        };
        c.ga.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.Ra) c.wa.className = h.join(" ");
        h = c.ga;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var l = c.wa;
                if (Q(mi)) {
                    {
                        const z =
                            Qi(d, e);
                        if (z.init) {
                            var m = z.init;
                            for (d = m; d = z.ia(d);) m = d;
                            var p = {
                                anchor: m,
                                position: z.oa
                            }
                        } else p = {
                            anchor: d,
                            position: e
                        }
                    }
                    l["google-ama-order-assurance"] = 0;
                    Vh(l, p.anchor, p.position)
                } else Vh(l, d, e);
                b: {
                    var w = c.ga;w.dataset.adsbygoogleStatus = "reserved";w.className += " adsbygoogle-noablate";l = {
                        element: w
                    };
                    var t = b && b.Ya;
                    if (w.hasAttribute("data-pub-vars")) {
                        try {
                            t = JSON.parse(w.getAttribute("data-pub-vars"))
                        } catch (z) {
                            break b
                        }
                        w.removeAttribute("data-pub-vars")
                    }
                    t && (l.params = t);
                    (f.adsbygoogle = f.adsbygoogle || []).push(l)
                }
            } catch (z) {
                (w =
                    c.wa) && w.parentNode && (t = w.parentNode, t.removeChild(w), Uh(t) && (t.style.display = t.getAttribute("data-init-display") || "none"));
                w = !1;
                break a
            }
            w = !0
        }
        return w ? c : null
    }

    function $k(a, b) {
        return wh(yh(Yj(b).map(Mh), c => {
            Wj(a.g).exception = c
        }))
    }
    var al = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.H = b;
            this.j = c;
            this.A = e || null;
            (this.F = d) ? (a = a.document, d = E(d, xj, 5, C()), d = ak(a, d)) : d = ak(a.document, []);
            this.B = d;
            this.D = new Gk;
            this.i = 0;
            this.u = !1
        }
    };

    function Xk(a) {
        const b = {};
        a && xc(a, 6, Rb, C()).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function Yk(a, b) {
        return a && vc(a, Ih, 4) && b[Hh(D(a, Ih, 4))] ? !1 : !0
    };
    var bl = kd(class extends K {});

    function cl(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? vh(() => bl(c)) : sh(null)
    };

    function dl() {
        if (el) return el;
        var a = te() || window;
        const b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? el = b : a.google_persistent_state_async = el = new fl
    }

    function gl(a) {
        return hl[a] || `google_ps_${a}`
    }

    function il(a, b, c) {
        b = gl(b);
        a = a.S;
        const d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function jl(a, b, c) {
        return il(a, b, () => c)
    }
    var fl = class {
            constructor() {
                this.S = {}
            }
        },
        el = null;
    const hl = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function kl(a) {
        this.g = a || {
            cookie: ""
        }
    }
    kl.prototype.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        typeof c === "object" && (h = c.wc, g = c.xc || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Ab);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        d === void 0 && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (d < 0 ? "" : d == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + d * 1E3)).toUTCString()) + (g ? ";secure" : "") + (h != null ? ";samesite=" + h : "")
    };
    kl.prototype.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = ua(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    kl.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    kl.prototype.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = ua(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; c >= 0; c--) a = b[c], this.get(a), this.set(a, "", {
            Ab: 0,
            path: void 0,
            domain: void 0
        })
    };

    function ll(a, b = window) {
        if (G(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    };

    function ml(a) {
        var b = new nl;
        return A(b, 5, Mb(a))
    }
    var nl = class extends K {};

    function ol() {
        this.A = this.A;
        this.i = this.i
    }
    ol.prototype.A = !1;
    ol.prototype.dispose = function() {
        this.A || (this.A = !0, this.D())
    };
    ol.prototype[fa(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function pl(a, b) {
        a.A ? b() : (a.i || (a.i = []), a.i.push(b))
    }
    ol.prototype.D = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function ql(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function rl(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = ql(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (oe({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function sl(a) {
        if (a.g) return a.g;
        a: {
            let d = a.j;
            for (let e = 0; e < 50; ++e) {
                try {
                    var b = !(!d.frames || !d.frames.__tcfapiLocator)
                } catch {
                    b = !1
                }
                if (b) {
                    b = d;
                    break a
                }
                b: {
                    try {
                        const f = d.parent;
                        if (f && f != d) {
                            var c = f;
                            break b
                        }
                    } catch {}
                    c = null
                }
                if (!(d = c)) break
            }
            b = null
        }
        a.g = b;
        return a.g
    }

    function tl(a, b, c, d) {
        c || (c = () => {});
        var e = a.j;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : sl(a) ? (ul(a), e = ++a.T, a.B[e] = c, a.g && a.g.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function ul(a) {
        if (!a.u) {
            var b = c => {
                try {
                    var d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.B[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.u = b;
            ie(a.j, "message", b)
        }
    }
    var vl = class extends ol {
        constructor(a) {
            var b = {};
            super();
            this.g = null;
            this.B = {};
            this.T = 0;
            this.u = null;
            this.j = a;
            this.H = b.eb ? ? 500;
            this.F = b.hc ? ? !1
        }
        D() {
            this.B = {};
            this.u && (je(this.j, "message", this.u), delete this.u);
            delete this.B;
            delete this.j;
            delete this.g;
            super.D()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.F
            };
            const c = td(() => a(b));
            let d = 0;
            this.H !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.H));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState =
                    ql(b), b.internalBlockOnErrors = this.F, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                tl(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && tl(this, "removeEventListener", null, a.listenerId)
        }
    };
    var Al = ({
            l: a,
            aa: b,
            eb: c,
            ob: d,
            ja: e = !1,
            ka: f = !1
        }) => {
            b = wl({
                l: a,
                aa: b,
                ja: e,
                ka: f
            });
            b.g != null || b.i.message != "tcunav" ? d(b) : xl(a, c).then(g => g.map(yl)).then(g => g.map(h => zl(a, h))).then(d)
        },
        wl = ({
            l: a,
            aa: b,
            ja: c = !1,
            ka: d = !1
        }) => {
            if (!Bl({
                    l: a,
                    aa: b,
                    ja: c,
                    ka: d
                })) return zl(a, ml(!0));
            b = dl();
            return (b = jl(b, 24)) ? zl(a, yl(b)) : uh(Error("tcunav"))
        };

    function Bl({
        l: a,
        aa: b,
        ja: c,
        ka: d
    }) {
        if (d = !d) d = new vl(a), d = typeof d.j.__tcfapi === "function" || sl(d) != null;
        if (!d) {
            if (c = !c) {
                if (b) {
                    a = cl(a);
                    if (a.g != null)
                        if ((a = a.getValue()) && Rb(y(a, 1)) != null) b: switch (a = J(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else yk(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function xl(a, b) {
        return Promise.race([Cl(), Dl(a, b)])
    }

    function Cl() {
        return (new Promise(a => {
            var b = dl();
            a = {
                resolve: a
            };
            const c = jl(b, 25, []);
            c.push(a);
            b.S[gl(25)] = c
        })).then(El)
    }

    function Dl(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, uh(Error("tcto")))
        })
    }

    function El(a) {
        return a ? sh(a) : uh(Error("tcnull"))
    }

    function yl(a) {
        var b = {};
        if (rl(a))
            if (a.gdprApplies === !1) a = !0;
            else if (a.tcString === "tcunavailable") a = !b.Ta;
        else if ((b.Ta || a.gdprApplies !== void 0 || b.jc) && (b.Ta || typeof a.tcString === "string" && a.tcString.length)) {
            b: {
                if (a.publisher && a.publisher.restrictions && (b = a.publisher.restrictions["1"], b !== void 0)) {
                    b = b["755"];
                    break b
                }
                b = void 0
            }
            b === 0 ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && a.publisherCC === "CH" ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
        }
        else a = !0;
        else a = !1;
        return ml(a)
    }

    function zl(a, b) {
        return (a = ll(b, a)) ? sh(a) : uh(Error("unav"))
    };
    var Fl = class extends K {};
    var Gl = class extends K {};
    var Hl = class {
        constructor(a) {
            this.exception = a
        }
    };

    function Il(a, b) {
        try {
            var c = a.i,
                d = c.resolve,
                e = a.g;
            Wj(e.g);
            E(e.j, Th, 1, C());
            d.call(c, new Hl(b))
        } catch (f) {
            a.i.reject(f)
        }
    }
    var Jl = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
        start() {
            this.u()
        }
        u() {
            try {
                switch (this.j.document.readyState) {
                    case "complete":
                    case "interactive":
                        Wk(this.g, !0);
                        Il(this);
                        break;
                    default:
                        Wk(this.g, !1) ? Il(this) : this.j.setTimeout(ra(this.u, this), 100)
                }
            } catch (a) {
                Il(this, a)
            }
        }
    };
    var Kl = class extends K {
        getVersion() {
            return H(this, 2)
        }
    };

    function Ll(a) {
        return Ra(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function Ml(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function Nl(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Ol(a) {
        var b = Ll(a),
            c = Ml(b.slice(0, 6));
        a = Ml(b.slice(6, 12));
        var d = new Kl;
        c = $c(d, 1, c);
        a = $c(c, 2, a);
        b = b.slice(12);
        c = Ml(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = Ml(e[0]) === 0;
            e = e.slice(1);
            var g = Pl(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = Nl(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = Pl(e, b);
                g = Nl(f);
                for (let n = 0; n <= g; n++) d.push(h + n);
                e = e.slice(f.length)
            }
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Dc(a, 3, d, Sb)
    }

    function Pl(a, b) {
        const c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var Ql = "a".charCodeAt(),
        Rl = yd(ih),
        Sl = yd(jh);

    function Tl() {
        var a = new Ul;
        return ad(a, 1, 0)
    }

    function Vl(a) {
        var b = Number; {
            var c = y(a, 1);
            const d = typeof c;
            c = c == null ? c : d === "bigint" ? String(Hb(64, c)) : Pb(c) ? d === "string" ? Wb(c) : Zb(c) : void 0
        }
        b = b(c ? ? "0");
        a = H(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var Ul = class extends K {};

    function W(a, b) {
        if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function Wl(a) {
        let b = W(a, 12);
        const c = [];
        for (; b--;) {
            var d = !!W(a, 1) === !0,
                e = W(a, 16);
            if (d)
                for (d = W(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function Xl(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (W(a, 1)) {
                const f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function Yl(a) {
        const b = W(a, 16);
        return !!W(a, 1) === !0 ? (a = Wl(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : Xl(a, b)
    }
    var Zl = class {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var am = (a, b) => {
        try {
            var c = Ra(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new Zl(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = b;
            d.skip(78);
            c.cmpId = W(d, 12);
            c.cmpVersion = W(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = W(d, 6);
            c.isServiceSpecific = !!W(d, 1);
            c.useNonStandardStacks = !!W(d, 1);
            c.specialFeatureOptins = $l(Xl(d, 12, Sl), Sl);
            c.purpose = {
                consents: $l(Xl(d, 24, Rl), Rl),
                legitimateInterests: $l(Xl(d, 24, Rl), Rl)
            };
            c.purposeOneTreatment = !!W(d, 1);
            c.publisherCC = String.fromCharCode(Ql + W(d, 6)) + String.fromCharCode(Ql +
                W(d, 6));
            c.vendor = {
                consents: $l(Yl(d), null),
                legitimateInterests: $l(Yl(d), null)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const $l = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var bm = class extends K {
        g() {
            return v(y(this, 2)) != null
        }
    };
    var cm = class extends K {
        g() {
            return v(y(this, 2)) != null
        }
    };
    var dm = class extends K {};
    var em = kd(class extends K {});

    function fm(a) {
        a = gm(a);
        try {
            var b = a ? em(a) : null
        } catch (c) {
            b = null
        }
        return b ? D(b, dm, 4) || null : null
    }

    function gm(a) {
        a = (new kl(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    yd(ih).map(a => Number(a));
    yd(jh).map(a => Number(a));

    function hm(a) {
        a.__tcfapiPostMessageReady || im(new jm(a))
    }

    function im(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.l.__tcfapi)(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.l.addEventListener("message", a.g);
        a.l.__tcfapiPostMessageReady = !0
    }
    var jm = class {
        constructor(a) {
            this.l = a
        }
    };

    function km(a) {
        a.__uspapiPostMessageReady || lm(new mm(a))
    }

    function lm(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.l.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.l.addEventListener("message", a.g);
        a.l.__uspapiPostMessageReady = !0
    }
    var mm = class {
        constructor(a) {
            this.l = a;
            this.g = null
        }
    };
    var nm = class extends K {};
    var om = kd(class extends K {
        g() {
            return v(y(this, 1)) != null
        }
    });

    function pm(a, b) {
        function c(m) {
            if (m.length < 10) return null;
            var p = h(m.slice(0, 4));
            p = k(p);
            m = h(m.slice(6, 10));
            m = n(m);
            return "1" + p + m + "N"
        }

        function d(m) {
            if (m.length < 10) return null;
            var p = h(m.slice(0, 6));
            p = k(p);
            m = h(m.slice(6, 10));
            m = n(m);
            return "1" + p + m + "N"
        }

        function e(m) {
            if (m.length < 12) return null;
            var p = h(m.slice(0, 6));
            p = k(p);
            m = h(m.slice(8, 12));
            m = n(m);
            return "1" + p + m + "N"
        }

        function f(m) {
            if (m.length < 18) return null;
            var p = h(m.slice(0, 8));
            p = k(p);
            m = h(m.slice(12, 18));
            m = n(m);
            return "1" + p + m + "N"
        }

        function g(m) {
            if (m.length < 10) return null;
            var p = h(m.slice(0, 6));
            p = k(p);
            m = h(m.slice(6, 10));
            m = n(m);
            return "1" + p + m + "N"
        }

        function h(m) {
            const p = [];
            let w = 0;
            for (let t = 0; t < m.length / 2; t++) p.push(Ml(m.slice(w, w + 2))), w += 2;
            return p
        }

        function k(m) {
            return m.every(p => p === 1) ? "Y" : "N"
        }

        function n(m) {
            return m.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = Ll(a[0]);
        const l = Ml(a.slice(0, 6));
        a = a.slice(6);
        if (l !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function qm(a, b) {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Qd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function rm(a) {
        if (a != null) return sm(a)
    }

    function sm(a) {
        return zb(a) ? Number(a) : String(a)
    };

    function tm(a) {
        var b = Q(Ii);
        M !== M.top || !b && (M.__uspapi || M.frames.__uspapiLocator) || (a = new um(a), vm(a), wm(a))
    }

    function vm(a) {
        !a.j || a.l.__uspapi || a.l.frames.__uspapiLocator || (a.l.__uspapiManager = "fc", qm(a.l, "__uspapiLocator"), sa("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && (b = !a.i.j(), d({
                version: 1,
                uspString: b ? "1---" : a.j
            }, !0))
        }, a.l), km(a.l))
    }

    function wm(a) {
        !a.tcString || a.l.__tcfapi || a.l.frames.__tcfapiLocator || (a.l.__tcfapiManager = "fc", qm(a.l, "__tcfapiLocator"), a.l.__tcfapiEventListeners = a.l.__tcfapiEventListeners || [], sa("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.2 || c <= 1)) d(null, !1);
                else {
                    var f = a.l.__tcfapiEventListeners;
                    c = !a.i.g();
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: !c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.2",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            e = f.push(d);
                            b = !c;
                            --e;
                            a.tcString ? (b = am(a.tcString, b), b.addtlConsent = a.g != null ? a.g : void 0, b.cmpStatus = "loaded", b.eventStatus = "tcloaded", e != null && (b.listenerId = e)) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.l), hm(a.l))
    }

    function xm(a) {
        if (!a ? .g() || I(a, 1).length === 0 || E(a, nm, 2, C()).length === 0) return null;
        const b = I(a, 1);
        let c;
        try {
            var d = Ol(b.split("~")[0]);
            c = b.includes("~") ? b.split("~").slice(1) : []
        } catch (e) {
            return null
        }
        a = E(a, nm, 2, C()).reduce((e, f) => {
            var g = ym(e);
            g = Sc(g, 1) ? ? sc;
            g = sm(g);
            var h = ym(f);
            h = Sc(h, 1) ? ? sc;
            return g > sm(h) ? e : f
        });
        d = xc(d, 3, Tb, C()).indexOf(H(a, 1));
        return d === -1 || d >= c.length ? null : {
            uspString: pm(c[d], H(a, 1)),
            va: Vl(ym(a))
        }
    }

    function zm(a) {
        a = a.find(b => b && J(b, 1) === 13);
        if (a ? .g()) try {
            return om(I(a, 2))
        } catch (b) {}
        return null
    }

    function ym(a) {
        return vc(a, Ul, 2) ? D(a, Ul, 2) : Tl()
    }
    var um = class {
        constructor(a) {
            var b = M;
            this.l = b;
            this.i = a;
            a = gm(this.l.document);
            try {
                var c = a ? em(a) : null
            } catch (e) {
                c = null
            }(a = c) ? (c = D(a, cm, 5) || null, a = E(a, bm, 7, C()), a = zm(a ? ? []), c = {
                Qa: c,
                Sa: a
            }) : c = {
                Qa: null,
                Sa: null
            };
            a = c;
            c = xm(a.Sa);
            a = a.Qa;
            if (a ? .g() && I(a, 2).length !== 0) {
                var d = vc(a, Ul, 1) ? D(a, Ul, 1) : Tl();
                a = {
                    uspString: I(a, 2),
                    va: Vl(d)
                }
            } else a = null;
            this.j = a && c ? c.va > a.va ? c.uspString : a.uspString : a ? a.uspString : c ? c.uspString : null;
            this.tcString = (c = fm(b.document)) && v(y(c, 1)) != null ? I(c, 1) : null;
            this.g = (b = fm(b.document)) && v(y(b,
                2)) != null ? I(b, 2) : null
        }
    };
    const Am = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function Bm(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        xk("ama", b, .01)
    }

    function Cm(a) {
        const b = {};
        Td(Am, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function Dm(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function Em(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function Fm(a) {
        a = xc(a, 2, Rb, C());
        if (!a) return !1;
        for (let b = 0; b < a.length; b++)
            if (a[b] == 1) return !0;
        return !1
    }

    function Gm(a, b) {
        a = Em(Dm(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = Dh(a),
            d = Hm(a);
        return b.find(e => {
            if (vc(e, tj, 7)) {
                var f = D(e, tj, 7);
                f = Ub(y(f, 1, void 0, tc))
            } else f = Ub(y(e, 1, void 0, tc));
            vc(e, tj, 7) ? (e = D(e, tj, 7), e = Yc(e, 2)) : e = 2;
            if (typeof f !== "number") return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function Hm(a) {
        const b = {};
        for (;;) {
            b[Dh(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function X(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function Im(a) {
        a = X(a);
        const b = a.space_collapsing || "none";
        return a.remove_ads_by_default ? {
            Oa: !0,
            Jb: b,
            ta: a.ablation_viewport_offset
        } : null
    }

    function Jm(a) {
        a = X(a);
        a.had_ads_ablation = !0;
        a.remove_ads_by_default = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = 1
    }

    function Km(a) {
        X(M).allow_second_reactive_tag = a
    }

    function Lm() {
        const a = X(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function Mm(a) {
        return X(a) ? .head_tag_slot_vars ? .google_ad_host ? ? Nm(a)
    }

    function Nm(a) {
        return a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    const Om = [2, 7, 1];

    function Pm(a, b, c, d = "") {
        return b === 1 && c && (Qm(a, d, c) ? .F() ? ? !1) ? !0 : Rm(a, d, e => La(E(e, ld, 2, C()), f => Yc(f, 1) === b), !!D(c, Sm, 26) ? .g())
    }

    function Tm(a, b) {
        const c = Od(M) || M;
        return Um(c, a) ? !0 : Rm(M, "", d => La(xc(d, 3, Rb, C()), e => e === a), b)
    }

    function Um(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Na(a.split(","), b.toString())
    }

    function Rm(a, b, c, d) {
        a = Od(a) || a;
        const e = Vm(a, d);
        b && (b = we(String(b)));
        return xd(e, (f, g) => Object.prototype.hasOwnProperty.call(e, g) && (!b || b === g) && c(f))
    }

    function Vm(a, b) {
        a = Wm(a, b);
        const c = {};
        Td(a, (d, e) => {
            try {
                const f = id(md, hc(d));
                c[e] = f
            } catch (f) {}
        });
        return c
    }

    function Wm(a, b) {
        a = wl({
            l: a,
            aa: b
        });
        return a.g != null ? Xm(a.getValue()) : {}
    }

    function Xm(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : wd(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && typeof e === "string" && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function Ym(a, b) {
        const c = [];
        a = Mm(q) ? Om : (a = Qm(q, a, b) ? .T()) ? [...xc(a, 3, Rb, C())] : Om;
        a.includes(1) || c.push(1);
        a.includes(2) || c.push(2);
        a.includes(7) || c.push(7);
        return c
    }

    function Qm(a, b, c) {
        if (!b) return null;
        var d = Zm(c) ? .u(),
            e = Zm(c) ? .g() ? .g();
        b = b ? ? "";
        d = d ? ? "";
        e = e ? ? "";
        var f = I(c, 17) || "";
        a = e === b && !!a.location.host && f === a.location.host;
        return d === b || a ? Zm(c) : null
    };

    function $m(a, b, c, d) {
        an(new bn(a, b, c, d))
    }

    function an(a) {
        const b = !!D(a.g, Sm, 26) ? .g();
        yh(xh(wl({
            l: a.l,
            aa: b
        }), c => {
            cn(a, c, !0)
        }), () => {
            dn(a)
        })
    }

    function cn(a, b, c) {
        yh(xh(en(b), d => {
            fn("ok");
            a.i(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.l;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                Bm(d, {
                    lserr: 1
                })
            }
            c ? dn(a) : a.i(null, null)
        })
    }

    function dn(a) {
        yh(xh(gn(a), b => {
            a.i(b, {
                fromPABGSettings: !0
            })
        }), () => {
            hn(a)
        })
    }

    function en(a) {
        if (Q(li)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? Gj(b) : null
        } catch (d) {
            c = null
        }
        return (a = (a = c) ? (rm(D(a, sj, 3) ? .g()) ? ? 0) > Date.now() ? a : null : null) ? sh(a) : uh(Error("invlocst"))
    }

    function gn(a) {
        if (Mm(a.l) && !G(a.g, 22)) return uh(Error("invtag"));
        if (a = (a = Qm(a.l, a.j, a.g) ? .H()) && E(a, Th, 1, C()).length > 0 ? a : null) {
            var b = new Fj;
            var c = E(a, Th, 1, C());
            b = Qc(b, 1, c);
            a = E(a, zj, 2, C());
            a = Qc(b, 7, a);
            a = sh(a)
        } else a = uh(Error("invtag"));
        return a
    }

    function hn(a) {
        const b = !!D(a.g, Sm, 26) ? .g();
        Al({
            l: a.l,
            aa: b,
            eb: 50,
            ob: c => {
                jn(a, c)
            }
        })
    }

    function jn(a, b) {
        yh(xh(b, c => {
            cn(a, c, !1)
        }), c => {
            fn(c.message);
            a.i(null, null)
        })
    }

    function fn(a) {
        xk("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class bn {
        constructor(a, b, c, d) {
            this.l = a;
            this.g = b;
            this.j = c;
            this.i = d
        }
    };

    function kn(a, b, c, d) {
        var e = ln;
        try {
            const f = Gm(a, E(c, zj, 7, C()));
            if (f && Fm(f)) {
                if (v(y(f, 4))) {
                    const h = new Kh(null, {
                        google_package: v(y(f, 4))
                    });
                    d = Jh(d, h)
                }
                const g = e(a, b, c, f, d);
                Rj(1E3, () => {
                    const h = new nh;
                    (new Jl(a, g, h)).start();
                    return h.i
                }, a).then(() => {
                    Bm(a, {
                        atf: 1
                    })
                }, h => {
                    (a.google_ama_state = a.google_ama_state || {}).exception = h;
                    Bm(a, {
                        atf: 0
                    })
                })
            }
        } catch (f) {
            Bm(a, {
                atf: -1
            })
        }
    }

    function ln(a, b, c, d, e) {
        return new al(a, b, c, d, e)
    };

    function mn(a) {
        return a.length ? a.join("~") : void 0
    };

    function nn(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        b = on(b);
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function on(a) {
        let b = "";
        Td(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    };

    function pn() {
        const a = {};
        L(ae).i(gi.g, gi.defaultValue) && (a.bust = L(ae).i(gi.g, gi.defaultValue));
        return a
    };
    class qn {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function rn() {
        const {
            promise: a,
            resolve: b
        } = new qn;
        return {
            promise: a,
            resolve: b
        }
    };

    function sn(a = () => {}) {
        q.google_llp || (q.google_llp = {});
        const b = q.google_llp;
        let c = b[7];
        if (c) return c;
        c = rn();
        b[7] = c;
        a();
        return c
    }

    function tn(a) {
        return sn(() => {
            Pd(q.document, a)
        }).promise
    };
    Array.from({
        length: 11
    }, (a, b) => b / 10);

    function un(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = [])) : a.google_reactive_ads_global_state = new vn;
        return a.google_reactive_ads_global_state
    }
    var vn = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new wn;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.clickTriggeredInterstitialMayBeDisplayed = !1
            }
        },
        wn = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };

    function xn(a) {
        if (q.google_apltlad || a.google_ad_intent_query) return null;
        var b = a.google_loader_used !== "sd" && Q(oi) && (q.top == q ? 0 : Nd(q.top) ? 1 : 2) === 1;
        if (q !== q.top && !b || !a.google_ad_client) return null;
        q.google_apltlad = !0;
        b = {
            enable_page_level_ads: {
                pltais: !0
            },
            google_ad_client: a.google_ad_client
        };
        const c = b.enable_page_level_ads;
        Td(a, (d, e) => {
            oj[e] && e !== "google_ad_client" && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        c.asro = Q(ti);
        c.aihb = Q(pi);
        c.aifxl = mn(L(ae).g(ri.g, ri.defaultValue));
        R(wi) && (c.aiapm = R(wi));
        R(yi) && (c.aiapmi =
            R(yi));
        R(ui) && (c.aiact = R(ui));
        R(Ai) && (c.aicct = R(Ai));
        R(Ci) && (c.ailct = R(Ci));
        R(Ei) && (c.aimart = R(Ei));
        Q(qi) && (c.aiudt = !0);
        c.aiapmd = R(xi);
        c.aiapmid = R(zi);
        c.aiactd = R(vi);
        c.aicctd = R(Bi);
        c.ailctd = R(Di);
        c.aimartd = R(Fi);
        c.aiof = mn(L(ae).g(si.g, si.defaultValue));
        if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function yn(a, b) {
        X(M).ama_ran_on_page || Rj(1001, () => {
            zn(new An(a, b))
        }, q)
    }

    function zn(a) {
        $m(a.l, a.i, a.g.google_ad_client || "", (b, c) => {
            var d = a.l,
                e = a.g;
            X(M).ama_ran_on_page || b && Bn(d, e, b, c)
        })
    }
    class An {
        constructor(a, b) {
            this.l = q;
            this.g = a;
            this.i = b
        }
    }

    function Bn(a, b, c, d) {
        d && (Wj(a).configSourceInAbg = d);
        vc(c, Ej, 24) && (d = Xj(a), d.availableAbg = !0, d.ablationFromStorage = !!D(c, Ej, 24) ? .g() ? .g());
        if (la(b.enable_page_level_ads) && b.enable_page_level_ads.google_pgb_reactive === 7) {
            if (!Gm(a, E(c, zj, 7, C()))) {
                xk("amaait", {
                    value: "true"
                });
                return
            }
            xk("amaait", {
                value: "false"
            })
        }
        X(M).ama_ran_on_page = !0;
        D(c, rj, 15) ? .g() && (X(a).enable_overlap_observer = !0);
        D(c, Ej, 24) ? .g() ? .g() && (Xj(a).ablatingThisPageview = !0, Jm(a));
        re(3, [x(c)]);
        const e = b.google_ad_client || "";
        b = Cm(la(b.enable_page_level_ads) ?
            b.enable_page_level_ads : {});
        const f = Jh(Nh, new Kh(null, b));
        uk(782, () => {
            kn(a, e, c, f)
        })
    };

    function Cn(a, b, c) {
        return a ? .[c] ? ? b ? .attributes.getNamedItem(`data-${String(c).slice(7).replace(/_/g,"-")}`) ? .value
    }

    function Dn(a, b) {
        return {
            fldt: {
                pbfl: Cn(a, b, "google_ad_public_floor"),
                pvfl: Cn(a, b, "google_ad_private_floor")
            }
        }
    };

    function En(a, b) {
        a = a.document;
        for (var c = void 0, d = 0; !c || a.getElementById(c + "_host");) c = "aswift_" + d++;
        a = c;
        c = Number(b.google_ad_width || 0);
        b = Number(b.google_ad_height || 0);
        d = document.createElement("div");
        d.id = a + "_host";
        const e = d.style;
        e.border = "none";
        e.height = `${b}px`;
        e.width = `${c}px`;
        e.margin = "0px";
        e.padding = "0px";
        e.position = "relative";
        e.visibility = "visible";
        e.backgroundColor = "transparent";
        e.display = "inline-block";
        return {
            wb: a,
            Mb: d
        }
    };

    function Fn(a) {
        return a.google_ad_client ? String(a.google_ad_client) : X(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };
    var Gn = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function Hn(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };
    var In = class extends K {
        getVersion() {
            return I(this, 2)
        }
    };

    function Jn(a, b) {
        return A(a, 2, ac(b))
    }

    function Kn(a, b) {
        return A(a, 3, ac(b))
    }

    function Ln(a, b) {
        return A(a, 4, ac(b))
    }

    function Mn(a, b) {
        return A(a, 5, ac(b))
    }

    function Nn(a, b) {
        return A(a, 9, ac(b))
    }

    function On(a, b) {
        return Qc(a, 10, b)
    }

    function Pn(a, b) {
        return A(a, 11, Mb(b))
    }

    function Qn(a, b) {
        return A(a, 1, ac(b))
    }

    function Rn(a, b) {
        return A(a, 7, Mb(b))
    }
    var Sn = class extends K {};
    const Tn = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Un() {
        var a = M;
        if (typeof a.navigator ? .userAgentData ? .getHighEntropyValues !== "function") return null;
        const b = a.google_tag_data ? ? (a.google_tag_data = {});
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Tn).then(c => {
            b.uach ? ? (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Vn(a) {
        return Pn(On(Mn(Jn(Qn(Ln(Rn(Nn(Kn(new Sn, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new In;
            c = A(c, 1, ac(b.brand));
            return A(c, 2, ac(b.version))
        }) || []), a.wow64 || !1)
    }

    function Wn() {
        return Un() ? .then(a => Vn(a)) ? ? null
    };

    function Xn(a, b) {
        b.google_ad_host || (a = Nm(a)) && (b.google_ad_host = a)
    }

    function Yn(a, b, c = "") {
        M.google_sa_queue || (M.google_sa_queue = [], M.google_process_slots = vk(215, () => {
            Zn(M.google_sa_queue)
        }), a = $n(c, a, b), Pd(M.document, a))
    }

    function Zn(a) {
        const b = a.shift();
        typeof b === "function" && uk(216, b);
        a.length && q.setTimeout(vk(215, () => {
            Zn(a)
        }), 0)
    }

    function ao(a, b) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? b() : a.google_sa_queue.push(b)
    }

    function $n(a, b, c) {
        var d = M;
        b = G(c, 4) ? Q(Oi) ? Qm(d, a || Fn(d), c) ? b.ab : b.Za : b.Za : b.ab;
        a: {
            if (G(c, 4)) {
                if (a = a || Fn(d)) {
                    b: {
                        try {
                            for (; d;) {
                                if (d.location ? .hostname) {
                                    var e = d.location.hostname;
                                    break b
                                }
                                d = d.parent
                            }
                        } catch (f) {}
                        e = ""
                    }
                    e = {
                        client: we(a),
                        plah: e
                    };
                    break a
                }
                throw Error("PublisherCodeNotFoundForAma");
            }
            e = {}
        }
        e = { ...e,
            ...pn()
        };
        d = R(Ji);
        !G(c, 4) && [0, 1].includes(d) && (e.osttc = `${d}`);
        return Ld(b, new Map(Object.entries(e)))
    }

    function bo(a, b, c, d) {
        const {
            wb: e,
            Mb: f
        } = En(a, b);
        c.appendChild(f);
        co(a, c, b);
        c = b.google_start_time ? ? hh;
        const g = (new Date).getTime();
        b.google_lrv = hg();
        b.google_async_iframe_id = e;
        b.google_start_time = c;
        b.google_bpp = g > c ? g - c : 1;
        a.google_sv_map = a.google_sv_map || {};
        a.google_sv_map[e] = b;
        ao(a, () => {
            var h = f,
                k = {
                    psldt: d
                };
            if (!h || !h.isConnected)
                if (h = a.document.getElementById(String(b.google_async_iframe_id) + "_host"), h == null) throw Error("no_div");
            (k = a.google_sa_impl({
                pubWin: a,
                vars: b,
                innerInsElement: h,
                sldt: k
            })) && wk(911,
                k)
        })
    }

    function co(a, b, c) {
        var d = c.google_ad_output,
            e = c.google_ad_format,
            f = c.google_ad_width || 0,
            g = c.google_ad_height || 0;
        e || d !== "html" && d != null || (e = `${f}x${g}`);
        Q(Ni) && (c.google_reactive_ad_format === 10 ? e = "interstitial" : c.google_reactive_ad_format === 11 && (e = "rewarded"));
        d = !c.google_ad_slot || c.google_override_format || !Gn[c.google_ad_width + "x" + c.google_ad_height] && c.google_loader_used === "aa";
        e = e && d ? e.toLowerCase() : "";
        c.google_ad_format = e;
        if (typeof c.google_reactive_sra_index !== "number" || !c.google_ad_unit_key) {
            e = [c.google_ad_slot,
                c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width, c.google_orig_ad_height || c.google_ad_height
            ];
            d = [];
            f = 0;
            for (g = b; g && f < 25; g = g.parentNode, ++f) g.nodeType === 9 ? d.push("") : d.push(g.id);
            (d = d.join()) && e.push(d);
            c.google_ad_unit_key = Dh(e.join(":")).toString();
            e = [];
            for (d = 0; b && d < 25; ++d) {
                f = (f = b.nodeType !== 9 && b.id) ? "/" + f : "";
                a: {
                    if (b && b.nodeName && b.parentElement) {
                        g = b.nodeName.toString().toLowerCase();
                        const h = b.parentElement.childNodes;
                        let k = 0;
                        for (let n = 0; n < h.length; ++n) {
                            const l =
                                h[n];
                            if (l.nodeName && l.nodeName.toString().toLowerCase() === g) {
                                if (b === l) {
                                    g = "." + k;
                                    break a
                                }++k
                            }
                        }
                    }
                    g = ""
                }
                e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
                b = b.parentElement
            }
            b = e.join();
            e = [];
            if (a) try {
                let h = a.parent;
                for (d = 0; h && h !== a && d < 25; ++d) {
                    const k = h.frames;
                    for (f = 0; f < k.length; ++f)
                        if (a === k[f]) {
                            e.push(f);
                            break
                        }
                    a = h;
                    h = a.parent
                }
            } catch (h) {}
            c.google_ad_dom_fingerprint = Dh(`${b}:${e.join()}`).toString()
        }
    }

    function eo() {
        var a = Od(q);
        a && (a = un(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function fo() {
        const a = Wn();
        a != null && a.then(b => {
            M.google_user_agent_client_hint = b.B()
        });
        $d()
    };
    var go = class {
        constructor(a, b) {
            this.g = a;
            this.u = b
        }
        height() {
            return this.u
        }
        i(a) {
            return a > R(ki) && this.u > 300 ? this.g : Math.min(1200, Math.round(a))
        }
        j() {}
    };

    function ho(a) {
        return b => !!(b.Z() & a)
    }
    var Y = class extends go {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.B = c;
            this.A = d
        }
        Z() {
            return this.B
        }
        j(a, b, c) {
            c.style.height = `${this.height()}px`;
            b.rpe = !0
        }
    };
    const io = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        jo = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        ko = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function lo(a) {
        var b = 0;
        a.R && b++;
        a.K && b++;
        a.L && b++;
        if (b < 3) return {
            Y: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.R.split(",");
        const c = a.L.split(",");
        a = a.K.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            Y: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length > 2) return {
            Y: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        const d = [],
            e = [];
        for (let g = 0; g <
            b.length; g++) {
            var f = Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                Y: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                Y: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
            };
            e.push(f)
        }
        return {
            L: d,
            K: e,
            Va: b
        }
    }

    function mo(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function no(a, b, c, d) {
        b = Math.floor(((a - 8 * b - 8) / b * io[d] + jo[d]) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            Hb: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            Hb: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function oo(a, b) {
        const c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor((c * io.mobile_banner_image_sidebyside + jo.mobile_banner_image_sidebyside) * b + 8 * b + 8)
        }
    };
    const po = Pa("script");
    var qo = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, n = null, l = null, m = null) {
            this.D = a;
            this.W = b;
            this.Z = c;
            this.g = d;
            this.F = e;
            this.G = f;
            this.P = g;
            this.u = h;
            this.A = k;
            this.i = n;
            this.j = l;
            this.B = m
        }
        size() {
            return this.W
        }
    };
    const ro = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var so = class extends go {
        i(a) {
            return Math.min(1200, Math.max(this.g, Math.round(a)))
        }
    };

    function to(a, b) {
        uo(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal") return new qo(9, new so(a, Math.floor(a * 2.189)));
        if (Q(Zh)) {
            var c = ud();
            var d = R($h);
            var e = R(Yh),
                f = R(Xh);
            a < 468 ? c ? (a = oo(a, d), d = {
                X: a.width,
                V: a.height,
                K: 1,
                L: d,
                R: "mobile_banner_image_sidebyside"
            }) : (a = no(a, 1, d, "image_sidebyside"), d = {
                X: a.width,
                V: a.height,
                K: 1,
                L: d,
                R: "image_sidebyside"
            }) : (d = mo(a), e === 1 && (d.height = Math.floor(d.height * .5)), d = {
                X: d.width,
                V: d.height,
                K: f,
                L: e,
                R: "image_stacked"
            })
        } else d = ud(), a < 468 ? d ? (d = oo(a, 12), d = {
            X: d.width,
            V: d.height,
            K: 1,
            L: 12,
            R: "mobile_banner_image_sidebyside"
        }) : (d = mo(a), d = {
            X: d.width,
            V: d.height,
            K: 1,
            L: 13,
            R: "image_sidebyside"
        }) : (d = mo(a), d = {
            X: d.width,
            V: d.height,
            K: 4,
            L: 2,
            R: "image_stacked"
        });
        vo(b, d);
        return new qo(9, new so(d.X, d.V))
    }

    function wo(a, b) {
        uo(a, b); {
            const f = lo({
                L: b.google_content_recommendation_rows_num,
                K: b.google_content_recommendation_columns_num,
                R: b.google_content_recommendation_ui_type
            });
            if (f.Y) a = {
                X: 0,
                V: 0,
                K: 0,
                L: 0,
                R: "image_stacked",
                Y: f.Y
            };
            else {
                var c = f.Va.length === 2 && a >= 468 ? 1 : 0;
                var d = f.Va[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = ko[d];
                let g = f.K[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.L[c];
                a = no(a, e, c, d);
                a = {
                    X: a.width,
                    V: a.height,
                    K: e,
                    L: c,
                    R: d
                }
            }
        }
        if (a.Y) throw new T(a.Y);
        vo(b, a);
        return new qo(9, new so(a.X, a.V))
    }

    function uo(a, b) {
        if (a <= 0) throw new T(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function vo(a, b) {
        a.google_content_recommendation_ui_type = b.R;
        a.google_content_recommendation_columns_num = b.K;
        a.google_content_recommendation_rows_num = b.L
    };
    var xo = class extends go {
        i() {
            return this.g
        }
        j(a, b, c) {
            fj(a, c);
            c.style.height = `${this.height()}px`;
            b.rpe = !0
        }
    };
    const yo = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var zo = class extends go {
        i() {
            return Math.min(1200, this.g)
        }
    };

    function Ao(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = aj(b, c, g, R(ci), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = S(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            const k = g.parentElement.childNodes;
                            for (let n = 0; n < k.length; ++n) {
                                const l = k[n];
                                if (l !== g && dj(b, l)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    fj(b, c)
                }
            else a = g;
            else a =
                g
        }
        if (a < 250) throw new T("Fluid responsive ads must be at least 250px wide: " + `availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new T("Fluid responsive ads must be at least 50px tall: " + `height=${f}`);
            return new qo(11, new go(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new T(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new T(`Invalid height: height=${f}`);
            if (f < 50) throw new T("Fluid responsive ads must be at least 50px tall: " + `height=${f}`);
            if (f > 1200) throw new T("Fluid responsive ads must be at most 1200px tall: " + `height=${f}`);
            return new qo(11, new go(a, f))
        }
        d = yo[f];
        if (!d) throw new T("Invalid data-ad-layout value: " + f);
        c = lj(c, b);
        b = S(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new qo(11,
            f === "in-article" ? new zo(a, b) : new go(a, b))
    };

    function Bo(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function Co(a, b) {
        var c = Do.slice(0);
        const d = c.length;
        let e = null;
        for (let f = 0; f < d; ++f) {
            const g = c[f];
            if (a(g)) {
                if (b == null || b(g)) return g;
                e === null && (e = g)
            }
        }
        return e
    };
    var Z = [new Y(970, 90, 2), new Y(728, 90, 2), new Y(468, 60, 2), new Y(336, 280, 1), new Y(320, 100, 2), new Y(320, 50, 2), new Y(300, 600, 4), new Y(300, 250, 1), new Y(250, 250, 1), new Y(234, 60, 2), new Y(200, 200, 1), new Y(180, 150, 1), new Y(160, 600, 4), new Y(125, 125, 1), new Y(120, 600, 4), new Y(120, 240, 4), new Y(120, 120, 1, !0)],
        Do = [Z[6], Z[12], Z[3], Z[0], Z[7], Z[14], Z[1], Z[8], Z[10], Z[4], Z[15], Z[2], Z[11], Z[5], Z[13], Z[9], Z[16]];

    function Eo(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            I: a,
            G: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || Fo(b) || e.google_ad_resize ? (b = bj(a, c, d, e), c = b !== !0 ? {
            I: a,
            G: b
        } : {
            I: S(c) || a,
            G: !0
        }) : c = {
            I: a,
            G: 2
        };
        const {
            I: f,
            G: g
        } = c;
        return g !== !0 ? {
            I: a,
            G: g
        } : d.parentElement ? {
            I: f,
            G: g
        } : {
            I: a,
            G: g
        }
    }

    function Go(a, b, c, d, e) {
        const {
            I: f,
            G: g
        } = uk(247, () => Eo(a, b, c, d, e));
        var h = g === !0;
        const k = Xd(d.style.width),
            n = Xd(d.style.height),
            {
                W: l,
                P: m,
                Z: p,
                Ua: w
            } = Ho(f, b, c, d, e, h);
        h = Io(b, p);
        var t;
        const z = (t = gj(d, c, "marginLeft")) ? `${t}px` : "",
            F = (t = gj(d, c, "marginRight")) ? `${t}px` : "";
        t = ij(d, c) || "";
        return new qo(h, l, p, null, w, g, m, z, F, n, k, t)
    }

    function Fo(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function Ho(a, b, c, d, e, f) {
        b = Jo(c, a, b);
        let g;
        var h = !1;
        let k = !1;
        var n = S(c) < 488;
        if (n) {
            g = Wi(d, c);
            var l = lj(d, c);
            h = !l && g;
            k = l && g
        }
        l = [jj(a), ho(b)];
        Q(ii) || l.push(kj(n, c, d, k));
        e.google_max_responsive_height != null && l.push(mj(e.google_max_responsive_height));
        n = [t => !t.A];
        if (h || k) h = nj(c, d), n.push(mj(h));
        const m = Co(Bo(l), Bo(n));
        if (!m) throw new T(`No slot size for availableWidth=${a}`);
        const {
            W: p,
            P: w
        } = uk(248, () => {
            var t;
            a: if (f) {
                if (e.gfwrnh && (t = Xd(e.gfwrnh))) {
                    t = {
                        W: new xo(a, t),
                        P: !0
                    };
                    break a
                }
                if (e.google_resizing_allowed ||
                    e.google_full_width_responsive === "true") t = Infinity;
                else {
                    t = d;
                    let F = Infinity;
                    do {
                        var z = gj(t, c, "height");
                        z && (F = Math.min(F, z));
                        (z = gj(t, c, "maxHeight")) && (F = Math.min(F, z))
                    } while (t.parentElement && (t = t.parentElement) && t.tagName !== "HTML");
                    t = F
                }!(Q(fi) && t <= a * 2) && (t = Math.min(a, t), t < a * .5 || t < 100) && (t = a);
                t = {
                    W: new xo(a, Math.floor(t)),
                    P: t < a ? 102 : !0
                }
            } else t = {
                W: m,
                P: 100
            };
            return t
        });
        return e.google_ad_layout === "in-article" ? {
            W: Ko(a, c, d, p, e),
            P: !1,
            Z: b,
            Ua: g
        } : {
            W: p,
            P: w,
            Z: b,
            Ua: g
        }
    }

    function Io(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function Jo(a, b, c) {
        if (c === "auto") c = Math.min(1200, S(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (const d in Ti) c.indexOf(d) !== -1 && (b |= Ti[d])
        }
        return b
    }

    function Ko(a, b, c, d, e) {
        const f = e.google_ad_height || gj(c, b, "height");
        b = Ao(a, b, c, f, e).size();
        return b.g * b.height() > a * d.height() ? new Y(b.g, b.height(), 1) : d
    };

    function Lo(a, b, c, d, e) {
        var f;
        (f = S(b)) ? S(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, fj(b, c), f = {
            I: f,
            G: !0
        }) : f = {
            I: a,
            G: 5
        } : f = {
            I: a,
            G: 4
        }: f = {
            I: a,
            G: 10
        };
        const {
            I: g,
            G: h
        } = f;
        if (h !== !0 || a === g) return new qo(12, new go(a, d), null, null, !0, h, 100);
        const {
            W: k,
            P: n,
            Z: l
        } = Ho(g, "auto", b, c, e, !0);
        return new qo(1, k, l, 2, !0, h, n)
    };

    function Mo(a) {
        const b = a.google_ad_format;
        if (b === "autorelaxed") {
            a: {
                if (a.google_content_recommendation_ui_type !== "pedestal")
                    for (const c of ro)
                        if (a[c] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (Fo(b)) return 1;
        if (b === "link") return 4;
        if (b === "fluid") return a.google_ad_layout === "in-article" ? (No(a), 1) : 8;
        if (a.google_reactive_ad_format === 27) return No(a), 1
    }

    function Oo(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && gj(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = Po(a, f, b, c, d)) ? e : Go(f, c.google_ad_format, d, b, c);
        e.size().j(d, c, b);
        e.Z != null && (c.google_responsive_formats = e.Z);
        e.F != null && (c.google_safe_for_responsive_override = e.F);
        e.G != null && (e.G === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.G));
        e.P != null && e.P !== !0 && (c.gfwrnher = e.P);
        d = e.j || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.i || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().i(f);
        const g = e.size().height();
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        f = `${h.i(f)}x${h.height()}`;
        c.google_ad_format = f;
        c.google_responsive_auto_format = e.D;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.G === !0 && (c.gfwrnh = `${e.size().height()}px`);
        e.u != null && (c.gfwroml = e.u);
        e.A != null && (c.gfwromr = e.A);
        e.i != null &&
            (c.gfwroh = e.i);
        e.j != null && (c.gfwrow = e.j);
        e.B != null && (c.gfwroz = e.B);
        f = Od(window) || window;
        nn(f.location, "google_responsive_dummy_ad") && (Na([1, 2, 3, 4, 5, 6, 7, 8], e.D) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${po}>window.top.postMessage('${f}', '*'); 
          </${po}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height(), b.style.height = `${a}px`)
    }

    function Po(a, b, c, d, e) {
        const f = d.google_ad_height || gj(c, e, "height") || 0;
        switch (a) {
            case 5:
                const {
                    I: g,
                    G: h
                } = uk(247, () => Eo(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && fj(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return to(g, d);
            case 9:
                return wo(b, d);
            case 8:
                return Ao(b, e, c, f, d);
            case 10:
                return Lo(b, e, c, f, d)
        }
    }

    function No(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function Qo(a, b) {
        a.google_resizing_allowed = !0;
        a.ovlp = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };

    function Ro(a, b) {
        var c = Od(b);
        if (c) {
            c = S(c);
            const d = Rd(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function So(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            default:
                return b
        }
    }

    function To(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "";
            const d = Ye(c, "client");
            d && (b.google_ad_client = So("google_ad_client", d));
            (c = Ye(c, "host")) && (b.google_ad_host = So("google_ad_host", c))
        }
        for (const d of a.attributes) /data-/.test(d.name) && (a = ua(d.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_")), b.hasOwnProperty(a) || (c = So(a, d.value), c !== null && (b[a] = c)))
    }

    function Uo(a, b) {
        if (a = se(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else return b.google_ad_intent_query ? 17 : 12
    }

    function Vo(a, b, c, d) {
        To(a, b);
        if (c.document && c.document.body && !Mo(b) && !b.google_reactive_ad_format && !b.google_ad_intent_query) {
            var e = parseInt(a.style.width, 10),
                f = Ro(a, c);
            if (f > 0 && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!Gn[e + "x" + g];
                let h = f;
                if (e) {
                    const k = Hn(f, g);
                    if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
                    else throw new T("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                Qo(b, 4)
            }
        }
        if (Q(ai) ||
            S(c) < 488) {
            f = Od(c) || c;
            g = a.offsetWidth || gj(a, c, "width") || b.google_ad_width || 0;
            e = b.google_ad_client;
            if (d = nn(f.location, "google_responsive_slot_preview") || Pm(f, 1, d, e)) b: if (b.google_reactive_ad_format || b.google_ad_resize || Mo(b) || Yi(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = Rd(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Na(["static", "relative"], f.position)) {
                            b.gfwrnwer = 17;
                            d = !1;
                            break b
                        }
                    }
                    if (!Q(ji) && (d = R(di), d = aj(c, a, g, d, b), d !== !0)) {
                        b.gfwrnwer = d;
                        d = !1;
                        break b
                    }
                    d = c === c.top ? !0 : !1
                }
            d ? (Qo(b, 1), d = !0) : d = !1
        } else d = !1;
        if (g = Mo(b)) Oo(g, a, b, c, d);
        else {
            if (Yi(a, b)) {
                if (d = Rd(a, c)) a.style.width = d.width, a.style.height = d.height, Xi(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = Uo(c, b)
            } else Xi(a.style, b);
            c.location && c.location.hash === "#gfwmrp" || b.google_responsive_auto_format === 12 && b.google_full_width_responsive === "true" ? Oo(10, a, b, c, !1) : Math.random() < .01 && b.google_responsive_auto_format ===
                12 && (a = bj(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), a !== !0 ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };

    function Wo(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && Nd(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function Xo(a, b, c) {
        for (const f of b) a: {
            b = a;
            var d = f,
                e = c;
            for (let g = 0; g < b.g.length; g++) {
                if (b.g[g].element.contains(d)) {
                    b.g[g].labels.add(e);
                    break a
                }
                if (d.contains(b.g[g].element)) {
                    b.g[g].element = d;
                    b.g[g].labels.add(e);
                    break a
                }
            }
            b.g.push({
                element: d,
                labels: new Set([e])
            })
        }
    }
    class Yo {
        constructor() {
            this.g = []
        }
        getSlots() {
            return this.g
        }
    }

    function Zo(a) {
        const b = Mk(a),
            c = new Yo;
        Xo(c, b.ib, 1);
        Xo(c, b.jb, 2);
        Xo(c, b.sb, 3);
        Xo(c, b.Lb, 4);
        Xo(c, b.kb, 5);
        Xo(c, b.Cb, 6);
        return c.getSlots().map(d => {
            var e = new wf;
            var f = [...d.labels];
            e = Dc(e, 1, f, Qb);
            d = d.element.getBoundingClientRect();
            f = new vf;
            f = Zc(f, 1, d.left + a.scrollX);
            f = Zc(f, 2, d.top + a.scrollY);
            f = Zc(f, 3, d.width);
            d = Zc(f, 4, d.height);
            d = hd(d);
            e = Oc(e, 2, d);
            return hd(e)
        }).sort((d, e) => {
            d = D(d, vf, 2);
            d = H(d, 2);
            e = D(e, vf, 2);
            e = H(e, 2);
            return d - e
        })
    };

    function wg(a, b, c = 0) {
        a.g.size > 0 || $o(a);
        c = Math.min(Math.max(0, c), 9);
        const d = a.g.get(c);
        d ? d.push(b) : a.g.set(c, [b])
    }

    function ap(a, b, c, d) {
        ie(b, c, d);
        pl(a, () => je(b, c, d))
    }

    function bp(a, b) {
        a.state !== 1 && (a.state = 1, a.g.size > 0 && cp(a, b))
    }

    function $o(a) {
        a.l.document.visibilityState ? ap(a, a.l.document, "visibilitychange", b => {
            a.l.document.visibilityState === "hidden" && bp(a, b);
            a.l.document.visibilityState === "visible" && (a.state = 0)
        }) : "onpagehide" in a.l ? (ap(a, a.l, "pagehide", b => {
            bp(a, b)
        }), ap(a, a.l, "pageshow", () => {
            a.state = 0
        })) : ap(a, a.l, "beforeunload", b => {
            bp(a, b)
        })
    }

    function cp(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var dp = class extends ol {
        constructor(a) {
            super();
            this.l = a;
            this.state = 0;
            this.g = new Map
        }
    };
    async function ep(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} ${200}`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function fp(a) {
        const b = a.state.pc;
        return b !== null && b !== 0 ? b : a.state.pc = ce(a.l)
    }

    function gp(a) {
        const b = a.state.wpc;
        return b !== null && b !== "" ? b : a.state.wpc = Fn(a.l)
    }

    function hp(a, b) {
        var c = new Lf;
        var d = fp(a);
        c = ad(c, 1, d);
        d = gp(a);
        c = cd(c, 2, d);
        c = ad(c, 3, a.state.sd);
        return ad(c, 7, Math.round(b || a.l.performance.now()))
    }
    async function ip(a) {
        await ep(a.l, () => !(!fp(a) || !gp(a)))
    }

    function jp(a) {
        var b = L(kp);
        if (b.i) {
            var c = b.u;
            a(c);
            b.state.psi = x(c)
        }
    }

    function lp(a) {
        wg(a.j, () => {
            var b = hp(a);
            b = Pc(b, 12, Mf, a.A);
            a.i && !a.state.le.includes(3) && (a.state.le.push(3), sg(a.g, b))
        }, 9)
    }

    function mp(a) {
        const b = new Hf;
        wg(a.j, () => {
            Oc(b, 2, a.u);
            ad(b, 3, a.state.tar);
            var c = a.l;
            var d = new Af;
            var e = Zo(c);
            d = Qc(d, 1, e);
            e = hd(yf(xf(new zf, S(c)), Vi(c).clientHeight));
            d = Oc(d, 2, e);
            c = hd(yf(xf(new zf, Vi(c).scrollWidth), Vi(c).scrollHeight));
            c = Oc(d, 3, c);
            c = hd(c);
            Oc(b, 4, c);
            c = a.g;
            d = hp(a);
            d = Pc(d, 8, Mf, b);
            sg(c, d)
        }, 9)
    }
    async function np(a) {
        var b = L(kp);
        if (b.i && !b.state.le.includes(1)) {
            b.state.le.push(1);
            var c = b.l.performance.now();
            await ip(b);
            var d = new Df;
            a = Ec(d, 5, Mb(a), !1);
            d = yf(xf(new zf, Vi(b.l).scrollWidth), Vi(b.l).scrollHeight);
            a = Oc(a, 2, d);
            d = yf(xf(new zf, S(b.l)), Vi(b.l).clientHeight);
            a = Oc(a, 1, d);
            for (var e = d = b.l; d && d != d.parent;) d = d.parent, Nd(d) && (e = d);
            a = cd(a, 4, e.location.href);
            d = Wo(b.l);
            d !== 0 && (e = new Cf, d = ed(e, 1, d), Oc(a, 3, d));
            d = b.g;
            c = hp(b, c);
            c = Pc(c, 4, Mf, a);
            sg(d, c);
            lp(b);
            mp(b)
        }
    }
    async function op(a, b, c) {
        if (a.i && c.length && !a.state.lgdp.includes(Number(b))) {
            a.state.lgdp.push(Number(b));
            var d = a.l.performance.now();
            await ip(a);
            var e = a.g;
            a = hp(a, d);
            d = new Bf;
            b = fd(d, 1, b);
            c = Dc(b, 2, c, Sb);
            c = Pc(a, 9, Mf, c);
            sg(e, c)
        }
    }
    async function pp(a, b) {
        await ip(a);
        var c = a.g;
        a = hp(a);
        a = ad(a, 3, 1);
        b = Pc(a, 10, Mf, b);
        sg(c, b)
    }
    var kp = class {
        constructor(a, b) {
            this.l = te() || window;
            this.j = b ? ? new dp(this.l);
            this.g = a ? ? new yg(2, hg(), 100, 100, !0, this.j);
            this.state = il(dl(), 33, () => {
                const c = R(bi);
                return {
                    sd: c,
                    ssp: c > 0 && Sd() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get i() {
            return this.state.ssp
        }
        get u() {
            return uk(1178, () => id(Gf, hc(this.state.psi || []))) || new Gf
        }
        get A() {
            return uk(1227, () => id(If, hc(this.state.cc || []))) || new If
        }
    };

    function qp() {
        var a = window;
        return q.google_adtest === "on" || q.google_adbreak_test === "on" || a.location.host.endsWith("h5games.usercontent.goog") || a.location.host === "gamesnacks.com" ? a.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(b => Math.floor(Number(b))).filter(b => !isNaN(b) && b > 0) || [] : []
    };

    function rp(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function sp(a) {
        var b = M.document;
        if (b.currentScript) return rp(b.currentScript, a);
        for (const c of b.scripts)
            if (rp(c, a) === 0) return 0;
        return 1
    };

    function tp(a, b) {
        const c = !!D(b, Sm, 26) ? .g();
        return {
            [3]: {
                [55]: () => a === 0,
                [23]: d => Pm(M, Number(d), b),
                [24]: d => Tm(Number(d), c),
                [61]: () => c,
                [63]: () => c || I(b, 8) === ".google.ch"
            },
            [4]: {},
            [5]: {
                [6]: () => I(b, 15)
            }
        }
    };

    function up(a = q) {
        return a.ggeac || (a.ggeac = {})
    };

    function vp(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function wp(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function xp(a, b = navigator) {
        try {
            return !!b.protectedAudience ? .queryFeatureSupport ? .(a)
        } catch (c) {
            return !1
        }
    };

    function yp(a, b) {
        try {
            const d = a.split(".");
            a = q;
            let e = 0,
                f;
            for (; a != null && e < d.length; e++) f = a, a = a[d[e]], typeof a === "function" && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var zp = {
        [3]: {
            [8]: a => {
                try {
                    return ka(a) != null
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ka(a)
                } catch {
                    return
                }
                if (a = typeof b === "function") b = b && b.toString && b.toString(), a = typeof b === "string" && b.indexOf("[native code]") != -1;
                return a
            },
            [10]: () => window === window.top,
            [6]: a => Na(L(ch).g(), Number(a)),
            [27]: a => {
                a = yp(a, "boolean");
                return a !== void 0 ? a : void 0
            },
            [60]: a => {
                try {
                    return !!q.document.querySelector(a)
                } catch {}
            },
            [80]: a => {
                try {
                    return !!q.matchMedia(a).matches
                } catch {}
            },
            [69]: a => vp(a, q.document),
            [70]: a => wp(a, q.document),
            [79]: a => xp(a,
                q.navigator)
        },
        [4]: {
            [3]: () => Yd(),
            [6]: a => {
                a = yp(a, "number");
                return a !== void 0 ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = yp(a, "string");
                return a !== void 0 ? a : void 0
            },
            [12]: a => {
                try {
                    const b = yp(a, "string");
                    if (b !== void 0) return atob(b)
                } catch (b) {}
            }
        }
    };
    var Ap = class extends K {
        getId() {
            return H(this, 1)
        }
    };

    function Bp(a) {
        return E(a, Ap, 2, C())
    }
    var Cp = class extends K {};
    var Dp = class extends K {};
    var Ep = class extends K {
        g() {
            return Sc(this, 2) ? ? sc
        }
        j() {
            return Sc(this, 4) ? ? sc
        }
        u() {
            return G(this, 3)
        }
    };
    var Fp = class extends K {};

    function Gp(a) {
        return Hp({
            [0]: new Map,
            [1]: new Map,
            [2]: new Map
        }, a)
    }

    function Hp(a, b) {
        const c = new Map;
        for (const [f, g] of a[1].entries()) {
            var d = f,
                e = g;
            const {
                bb: h,
                Wa: k,
                Xa: n
            } = e[e.length - 1];
            c.set(d, h + k * n)
        }
        for (const f of b)
            for (const g of E(f, Cp, 2, C()))
                if (Bp(g).length !== 0) {
                    b = Ub(y(g, 8)) ? ? 0;
                    !J(g, 4) || J(g, 13) || J(g, 14) || (b = c.get(J(g, 4)) ? ? 0, d = (Ub(y(g, 1)) ? ? 0) * Bp(g).length, c.set(J(g, 4), b + d));
                    d = [];
                    for (e = 0; e < Bp(g).length; e++) {
                        const h = {
                            bb: b,
                            Wa: Ub(y(g, 1)) ? ? 0,
                            Xa: Bp(g).length,
                            Bb: e,
                            ha: J(f, 1),
                            qa: g,
                            U: Bp(g)[e]
                        };
                        d.push(h)
                    }
                    Ip(a[2], J(g, 10), d) || Ip(a[1], J(g, 4), d) || Ip(a[0], Bp(g)[0].getId(), d)
                }
        return a
    }

    function Ip(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a.get(b).push(...c);
        return !0
    };

    function Jp(a = Sd()) {
        return b => Dh(`${b} + ${a}`) % 1E3
    };
    const Kp = [12, 13, 20];

    function Lp(a, b) {
        var c = L(Eg).N;
        const d = lf(D(b.qa, df, 3), c);
        if (!d.success) return Cg(a.M, D(b.qa, df, 3), b.ha, b.U.getId(), d), !1;
        if (!d.value) return !1;
        c = lf(D(b.U, df, 3), c);
        return c.success ? c.value ? !0 : !1 : (Cg(a.M, D(b.U, df, 3), b.ha, b.U.getId(), c), !1)
    }

    function Mp(a, b, c) {
        a.g[c] || (a.g[c] = []);
        a = a.g[c];
        a.includes(b) || a.push(b)
    }

    function Np(a, b, c, d) {
        const e = [];
        var f;
        if (f = b !== 9) a.u[b] ? f = !0 : (a.u[b] = !0, f = !1);
        if (f) return Ag(a.M, b, c, e, [], 4), e;
        f = Kp.includes(b);
        const g = [],
            h = [];
        for (const m of [0, 1, 2])
            for (const [p, w] of a.la[m].entries()) {
                var k = p,
                    n = w;
                const t = new Rf;
                var l = n.filter(z => z.ha === b && a.i[z.U.getId()] && Lp(a, z));
                if (l.length)
                    for (const z of l) h.push(z.U);
                else if (!a.xa && (m === 2 ? (l = d[1], gd(t, 2, Sf, k)) : l = d[0], k = l ? .(String(k)) ? ? (m === 2 && J(n[0].qa, 11) === 1 ? void 0 : d[0](String(k))), k !== void 0)) {
                    for (const z of n) {
                        if (z.ha !== b) continue;
                        n = k -
                            z.bb;
                        l = z.Wa;
                        const F = z.Xa,
                            ja = z.Bb;
                        n < 0 || n >= l * F || n % F !== ja || !Lp(a, z) || (n = J(z.qa, 13), n !== 0 && n !== void 0 && (l = a.j[String(n)], l !== void 0 && l !== z.U.getId() ? Bg(a.M, a.j[String(n)], z.U.getId(), n) : a.j[String(n)] = z.U.getId()), h.push(z.U))
                    }
                    Jc(t, Sf) !== 0 && ($c(t, 3, k), g.push(t))
                }
            }
        for (const m of h) d = m.getId(), e.push(d), Mp(a, d, f ? 4 : c), Ug(E(m, of , 2, C()), f ? Wg() : [c], a.M, d);
        Ag(a.M, b, c, e, g, 1);
        return e
    }

    function Op(a, b) {
        b = b.map(c => new Dp(c)).filter(c => !Kp.includes(J(c, 1)));
        a.la = Hp(a.la, b)
    }

    function Pp(a, b) {
        N(1, c => {
            a.i[c] = !0
        }, b);
        N(2, (c, d, e) => Np(a, c, d, e), b);
        N(3, c => (a.g[c] || []).concat(a.g[4]), b);
        N(12, c => void Op(a, c), b);
        N(16, (c, d) => void Mp(a, c, d), b)
    }
    var Qp = class {
        constructor(a, b, c, {
            xa: d = !1,
            yc: e = []
        } = {}) {
            this.la = a;
            this.M = c;
            this.u = {};
            this.xa = d;
            this.g = {
                [b]: [],
                [4]: []
            };
            this.i = {};
            this.j = {};
            if (a = Ge()) {
                a = a.split(",") || [];
                for (const f of a)(a = Number(f)) && (this.i[a] = !0)
            }
            for (const f of e) this.i[f] = !0
        }
    };

    function Rp(a, b) {
        a.g = Yg(14, b, () => {})
    }
    class Sp {
        constructor() {
            this.g = () => {}
        }
    }

    function Tp(a) {
        L(Sp).g(a)
    };

    function Up({
        tb: a,
        N: b,
        config: c,
        mb: d = up(),
        nb: e = 0,
        M: f = new Dg(rm(D(a, Ep, 5) ? .g()) ? ? 0, rm(D(a, Ep, 5) ? .j()) ? ? 0, D(a, Ep, 5) ? .u() ? ? !1),
        la: g = Gp(E(a, Dp, 2, C(pb)))
    }) {
        d.hasOwnProperty("init-done") ? (Yg(12, d, () => {})(E(a, Dp, 2, C()).map(h => x(h))), Yg(13, d, () => {})(E(a, of , 1, C()).map(h => x(h)), e), b && Yg(14, d, () => {})(b), Vp(e, d)) : (Pp(new Qp(g, e, f, c), d), Zg(d), $g(d), ah(d), Vp(e, d), Ug(E(a, of , 1, C(pb)), [e], f, void 0, !0), Fg = Fg || !(!c || !c.zb), Tp(zp), b && Tp(b))
    }

    function Vp(a, b = up()) {
        bh(L(ch), b, a);
        Wp(b, a);
        Rp(L(Sp), b);
        L(ae).B()
    }

    function Wp(a, b) {
        const c = L(ae);
        c.j = (d, e) => Yg(5, a, () => !1)(d, e, b);
        c.u = (d, e) => Yg(6, a, () => 0)(d, e, b);
        c.i = (d, e) => Yg(7, a, () => "")(d, e, b);
        c.A = (d, e) => Yg(8, a, () => [])(d, e, b);
        c.g = (d, e) => Yg(17, a, () => [])(d, e, b);
        c.B = () => {
            Yg(15, a, () => {})(b)
        }
    };

    function Xp(a, b) {
        b = {
            [0]: Jp(ce(b).toString())
        };
        b = L(ch).u(a, b);
        a = op(L(kp), a, b);
        fh.pa(1085, a)
    }

    function Yp(a, b, c) {
        var d = X(a);
        if (d.plle) Vp(1, up(a));
        else {
            d.plle = !0;
            d = D(b, Fp, 12);
            var e = G(b, 9);
            Up({
                tb: d,
                N: tp(c, b),
                config: {
                    xa: e && !!a.google_disable_experiments,
                    zb: e
                },
                mb: up(a),
                nb: 1
            });
            if (c = I(b, 15)) c = Number(c), L(ch).j(c);
            for (const f of xc(b, 19, Tb, C())) L(ch).i(f);
            Xp(12, a);
            Xp(10, a);
            a = Od(a) || a;
            nn(a.location, "google_mc_lab") && L(ch).i(44738307)
        }
    };

    function Zp(a) {
        qk.A(b => {
            b.shv = String(a);
            b.mjsv = hg();
            const c = L(ch).g(),
                d = qp();
            b.eid = c.concat(d).join(",")
        })
    };

    function $p(a) {
        return {
            fy: H(a, 1),
            bv: I(a, 2),
            iur: G(a, 20),
            idi: G(a, 9),
            pem: H(a, 18) !== -1 ? H(a, 18) : void 0,
            gd: I(a, 8) || void 0,
            bvcb: I(a, 3),
            gcs: {
                igc: !!D(a, Sm, 26) ? .g(),
                iga: !!D(a, Sm, 26) ? .u(),
                iuswfcoor: !!D(a, Sm, 26) ? .j()
            },
            ssc: {
                ssl: (Zm(a) ? .da() ? .g() || []).map(b => ({
                    nn: b.getName(),
                    jlu: I(b, 2)
                }))
            },
            mcc: Zm(a) ? .u() ? ? void 0,
            pwpc: Zm(a) ? .g() ? .g() ? ? void 0,
            hwrj: I(a, 17) ? ? void 0,
            fc: Zm(a) ? .D() ? .B() || void 0,
            epla: Zm(a) ? .ca() ? ? !0
        }
    };
    var aq = ["google_pause_ad_requests", "google_user_agent_client_hint"];
    var bq = class extends K {
        g() {
            return I(this, 1)
        }
        j() {
            return J(this, 2)
        }
    };
    var cq = class extends K {
        getName() {
            return I(this, 1)
        }
    };
    var dq = class extends K {
        g() {
            return E(this, cq, 1, C())
        }
    };
    var eq = class extends K {
        u() {
            return I(this, 1)
        }
        g() {
            return D(this, bq, 2)
        }
        F() {
            return G(this, 3)
        }
        j() {
            return G(this, 4)
        }
        H() {
            return D(this, Fl, 5)
        }
        T() {
            return D(this, Gl, 6)
        }
        da() {
            return D(this, dq, 7)
        }
        ca() {
            return G(this, 8)
        }
        D() {
            return D(this, Aj, 9)
        }
    };
    var Sm = class extends K {
        g() {
            return G(this, 1)
        }
        u() {
            return G(this, 2)
        }
        j() {
            return G(this, 3)
        }
    };

    function Zm(a) {
        return Wc(a, eq, 27, fq)
    }
    var gq = class extends K {},
        fq = [27, 28];

    function hq(a) {
        var b = qk;
        try {
            if (!tb(a)) throw Error(String(a));
            if (a.length > 0) return new gq(JSON.parse(a))
        } catch (c) {
            b.J(838, c instanceof Error ? c : Error(String(c)))
        }
        return new gq
    };

    function iq(a, b) {
        if (G(b, 22)) return 7;
        if (G(b, 16)) return 6;
        const c = Zm(b) ? .g() ? .g();
        b = Zm(b) ? .g() ? .j() ? ? 0;
        a = c === a;
        switch (b) {
            case 1:
                return a ? 9 : 8;
            case 2:
                return a ? 11 : 10;
            case 3:
                return a ? 13 : 12
        }
        return 1
    }

    function jq(a, b, c) {
        b.google_loader_used !== "sd" && (b.abgtt = iq(a, c))
    };

    function kq(a, b) {
        var c = new lq;
        try {
            const f = a.createElement("link");
            if (f.relList ? .supports ? .("compression-dictionary") && Fa()) {
                var d = f;
                if (b instanceof Dd) d.href = Fd(b).toString(), d.rel = "compression-dictionary";
                else {
                    if (Id.indexOf("compression-dictionary") === -1) throw Error('TrustedResourceUrl href attribute required with rel="compression-dictionary"');
                    var e = Gd.test(b) ? b : void 0;
                    e !== void 0 && (d.href = e, d.rel = "compression-dictionary")
                }
                a.head.appendChild(f)
            }
        } catch (f) {
            c.ma({
                methodName: 1296,
                ua: f
            })
        }
    }

    function mq(a) {
        return Kd `https://googleads.g.doubleclick.net/pagead/managed/dict/${a}/adsbygoogle`
    };
    var lq = class {
        constructor() {
            this.g = qk
        }
        ma(a) {
            const b = a.ua;
            this.g.J(a.methodName ? ? 0, b instanceof Error ? b : Error(String(b)))
        }
    };

    function nq(a) {
        ie(window, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || c.googMsgType !== "sc-cnf" || a(c, b)
        })
    };

    function oq(a, b) {
        return b == null ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function pq(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function qq() {
        const a = new Set,
            b = Kk();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function rq(a) {
        a = a.id;
        return a != null && (qq().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function sq(a, b, c) {
        if (!a.sources) return !1;
        switch (tq(a)) {
            case 2:
                const d = uq(a);
                if (d) return c.some(f => vq(d, f));
                break;
            case 1:
                const e = wq(a);
                if (e) return b.some(f => vq(e, f))
        }
        return !1
    }

    function tq(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function wq(a) {
        return xq(a, b => b.currentRect)
    }

    function uq(a) {
        return xq(a, b => b.previousRect)
    }

    function xq(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function vq(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : c * a * 100 / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }

    function yq() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(rq),
            b = [...qq()].map(c => document.getElementById(c)).filter(c => c !== null);
        zq = window.scrollX;
        Aq = window.scrollY;
        return Bq = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function Cq() {
        var a = new Dq;
        if (Q(Li)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                a.gb.qb && b.push("event");
                for (const c of b) b = {
                    type: c,
                    buffered: !0
                }, c === "event" && (b.durationThreshold = 40), Eq(a).observe(b);
                Fq(a)
            }
        }
    }

    function Gq(a, b) {
        const c = zq !== window.scrollX || Aq !== window.scrollY ? [] : Bq,
            d = yq();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                Hq(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Ga = Math.floor(b.renderTime || b.loadTime);
                a.Fa = b.size;
                break;
            case "first-input":
                b = e;
                a.Ca = Number((b.processingStart - b.startTime).toFixed(3));
                a.Da = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || Iq(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.B +=
                    b;
                a.H = Math.max(a.H, b);
                a.ra += 1;
                break;
            case "event":
                Iq(a, e);
                break;
            default:
                Gb(b, void 0)
        }
    }

    function Eq(a) {
        a.M || (a.M = new PerformanceObserver(Qj(640, b => {
            Gq(a, b)
        })));
        return a.M
    }

    function Fq(a) {
        const b = Qj(641, () => {
                var d = document;
                (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5,
                    "": 0
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] ? ? 0) === 2 && Jq(a)
            }),
            c = Qj(641, () => void Jq(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.Ba = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            Eq(a).disconnect()
        }
    }

    function Jq(a) {
        if (!a.Ja) {
            a.Ja = !0;
            Eq(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += pq("cls", a.D), b += pq("mls", a.T), b += oq("nls", a.da), window.LayoutShiftAttribution && (b += pq("cas", a.A), b += oq("nas", a.Ia), b += pq("was", a.Na)), b += pq("wls", a.sa), b += pq("tls", a.Ma));
            window.LargestContentfulPaint && (b += oq("lcp", a.Ga), b += oq("lcps", a.Fa));
            window.PerformanceEventTiming && a.Da && (b += oq("fid", a.Ca));
            window.PerformanceLongTaskTiming && (b += oq("cbt", a.B),
                b += oq("mbt", a.H), b += oq("nlt", a.ra));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) rq(c) && d++;
            b += oq("nif", d);
            b += oq("ifi", ve(window));
            c = L(ch).g();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${q===q.top?1:0}`;
            b += a.La ? `&${"qqid"}=${encodeURIComponent(a.La)}` : oq("pvsid", ce(q));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.M ? a.Ea : performance.interactionCount || 0) / 50));
            c >= 0 && (c = a.g[c].latency, c >= 0 && (b += oq("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.Ba()
        }
    }

    function Hq(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.D += Number(b.value);
            Number(b.value) > a.T && (a.T = Number(b.value));
            a.da += 1;
            if (c = sq(b, c, d)) a.A += b.value, a.Ia++;
            if (b.startTime - a.Ha > 5E3 || b.startTime - a.Ka > 1E3) a.Ha = b.startTime, a.i = 0, a.j = 0;
            a.Ka = b.startTime;
            a.i += b.value;
            c && (a.j += b.value);
            a.i > a.sa && (a.sa = a.i, a.Na = a.j, a.Ma = b.startTime + b.duration)
        }
    }

    function Iq(a, b) {
        Kq(a, b);
        const c = a.g[a.g.length - 1],
            d = a.F[b.interactionId];
        if (d || a.g.length < 10 || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.F[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.F[e.id]
        })
    }

    function Kq(a, b) {
        b.interactionId && (a.ca = Math.min(a.ca, b.interactionId), a.u = Math.max(a.u, b.interactionId), a.Ea = a.u ? (a.u - a.ca) / 7 + 1 : 0)
    }
    var Dq = class {
            constructor() {
                this.gb = {
                    qb: !0
                };
                this.j = this.i = this.da = this.T = this.D = 0;
                this.Ka = this.Ha = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.F = {};
                this.Ea = 0;
                this.ca = Infinity;
                this.Ca = this.Fa = this.Ga = this.Ia = this.Na = this.A = this.Ma = this.sa = this.u = 0;
                this.Da = !1;
                this.ra = this.H = this.B = 0;
                this.M = null;
                this.Ja = !1;
                this.Ba = () => {};
                const a = document.querySelector("[data-google-query-id]");
                this.La = a ? a.getAttribute("data-google-query-id") : null
            }
        },
        zq, Aq, Bq = [];
    let Lq = null;
    const Mq = [],
        Nq = new Map;
    let Oq = -1;

    function Pq(a) {
        return pj.test(a.className) && a.dataset.adsbygoogleStatus !== "done"
    }

    function Qq(a, b, c, d) {
        a.dataset.adsbygoogleStatus = "done";
        Rq(a, b, c, d)
    }

    function Rq(a, b, c, d) {
        var e = window;
        const f = b.google_reactive_ads_config;
        f || Vo(a, b, e, c);
        Xn(e, b);
        if (!Sq(a, b, e)) {
            if (f) {
                c = f.page_level_pubvars || {};
                if (X(M).page_contains_reactive_tag && !X(M).allow_second_reactive_tag) {
                    if (c.pltais) {
                        Km(!1);
                        return
                    }
                    throw new T("Only one 'enable_page_level_ads' allowed per page.");
                }
                X(M).page_contains_reactive_tag = !0;
                Km(c.google_pgb_reactive === 7)
            }
            b.google_unique_id = ue(e);
            for (const g of aq) b[g] = b[g] || e[g];
            b.google_loader_used !== "sd" && (b.google_loader_used = "aa");
            b.google_reactive_tag_first =
                (X(M).first_tag_on_page || 0) === 1;
            uk(164, () => {
                bo(e, b, a, d)
            })
        }
    }

    function Sq(a, b, c) {
        var d = b.google_reactive_ads_config,
            e = typeof a.className === "string" && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className),
            f = Im(c);
        if (f && f.Oa && b.google_adtest !== "on" && !e) {
            e = Zi(a, c);
            const g = Vi(c).clientHeight;
            e = g === 0 ? null : e / g;
            if (!f.ta || f.ta && (e || 0) >= f.ta) return a.className += " adsbygoogle-ablated-ad-slot", c = c.google_sv_map = c.google_sv_map || {}, d = ma(a), b.google_element_uid = d, c[b.google_element_uid] = b, a.setAttribute("google_element_uid", String(d)), f.Jb === "slot" && (Wd(a.getAttribute("width")) !==
                null && a.setAttribute("width", "0"), Wd(a.getAttribute("height")) !== null && a.setAttribute("height", "0"), a.style.width = "0px", a.style.height = "0px"), !0
        }
        if ((f = Rd(a, c)) && f.display === "none" && !(b.google_adtest === "on" || b.google_reactive_ad_format > 0 || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")), !0;
        a = b.google_pgb_reactive == null || b.google_pgb_reactive === 3;
        return b.google_reactive_ad_format !== 1 && b.google_reactive_ad_format !==
            8 || !a ? !1 : (q.console && q.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(b.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
    }

    function Tq(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (Pq(c) && c.dataset.adsbygoogleStatus !== "reserved" && (!a || e.id === a)) return e
        }
        return null
    }

    function Uq(a, b, c) {
        if (a && "shift" in a) {
            jp(e => {
                var f = Ff(e);
                Uc(f, 2) || (e = Ff(e), bd(e, 2))
            });
            for (var d = 20; a.length > 0 && d > 0;) {
                try {
                    Vq(a.shift(), b, c)
                } catch (e) {
                    setTimeout(() => {
                        throw e;
                    })
                }--d
            }
        }
    }

    function Wq() {
        const a = Qd("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        Zd(a);
        return a
    }

    function Xq(a, b) {
        const c = {},
            d = Ym(a.google_ad_client, b);
        Td(Ui, (g, h) => {
            a.enable_page_level_ads === !1 ? c[h] = !1 : a.hasOwnProperty(h) ? c[h] = a[h] : d.includes(g) && (c[h] = !1)
        });
        la(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
        const e = Wq();
        le.body.appendChild(e);
        const f = {
            google_reactive_ads_config: c,
            google_ad_client: a.google_ad_client
        };
        f.google_pause_ad_requests = !!X(M).pause_ad_requests;
        jq(Yq(a) || Fn(M), f, b);
        Qq(e, f, b, {
            fldt: {}
        });
        jp(g => {
            var h = Ff(g);
            Uc(h, 6) || (g = Ff(g), bd(g, 6))
        })
    }

    function Zq(a, b) {
        un(q).wasPlaTagProcessed = !0;
        const c = () => {
                Xq(a, b)
            },
            d = q.document;
        if (d.body || d.readyState === "complete" || d.readyState === "interactive") Xq(a, b);
        else {
            const e = td(vk(191, c));
            ie(d, "DOMContentLoaded", e);
            q.MutationObserver != null && (new q.MutationObserver((f, g) => {
                d.body && (e(), g.disconnect())
            })).observe(d, {
                childList: !0,
                subtree: !0
            })
        }
    }

    function Vq(a, b, c) {
        const d = {};
        uk(165, () => {
            $q(a, d, b, c)
        }, e => {
            e.client = e.client || d.google_ad_client || a.google_ad_client;
            e.slotname = e.slotname || d.google_ad_slot;
            e.tag_origin = e.tag_origin || d.google_tag_origin
        })
    }

    function ar(a) {
        delete a.google_checked_head;
        Td(a, (b, c) => {
            oj[c] || (delete a[c], b = c.replace("google", "data").replace(/_/g, "-"), q.console.warn(`AdSense head tag doesn't support ${b} attribute.`))
        })
    }

    function br(a, b) {
        var c = M.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || M.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js?client="]:not([data-checked-head])') || M.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])') || M.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js"][data-ad-client]:not([data-checked-head])');
        if (c) {
            c.setAttribute("data-checked-head",
                "true");
            var d = X(window);
            if (d.head_tag_slot_vars) cr(c);
            else {
                jp(g => {
                    g = Ff(g);
                    Ec(g, 7, Mb(!0), !1)
                });
                var e = {};
                To(c, e);
                ar(e);
                e.google_ad_intent_query && (e.google_responsive_auto_format = 17, e.google_reactive_ad_format = 42);
                var f = zd(e);
                d.head_tag_slot_vars = f;
                c = {
                    google_ad_client: e.google_ad_client,
                    enable_page_level_ads: e
                };
                e.google_ad_intent_query && (c.enable_ad_intent_display_ads = !0);
                e.google_overlays === "bottom" && (c.overlays = {
                    bottom: !0
                });
                Q(Gi) && e.google_overlays === "collapsed-bottom" && (c.overlays = {
                    bottom: !0,
                    ["collapsed-bottom"]: !0
                });
                delete e.google_overlays;
                M.adsbygoogle || (M.adsbygoogle = []);
                d = M.adsbygoogle;
                d.loaded ? d.push(c) : d.splice && d.splice(0, 0, c);
                b = Zm(b) ? .j();
                e.google_adbreak_test || b ? dr(f, a) : nq(() => {
                    dr(f, a)
                })
            }
        }
    }

    function er(a, b) {
        var c = fr();
        if (c) {
            var d = {};
            To(c, d);
            ar(d);
            d.google_ad_intent_query && (d.google_responsive_auto_format = 17, d.google_reactive_ad_format = 42);
            X(window).head_tag_slot_vars = zd(d);
            c = d;
            d = {
                google_ad_client: c.google_ad_client,
                enable_page_level_ads: c
            };
            c.google_ad_intent_query && (d.enable_ad_intent_display_ads = !0);
            c.google_overlays === "bottom" && (d.overlays = {
                bottom: !0
            });
            Q(Gi) && c.google_overlays === "collapsed-bottom" && (d.overlays = {
                bottom: !0,
                ["collapsed-bottom"]: !0
            });
            delete c.google_overlays;
            M.adsbygoogle ||
                (M.adsbygoogle = []);
            const e = M.adsbygoogle;
            e.loaded ? e.push(d) : e.splice && e.splice(0, 0, d);
            gr(c, b, a)
        }
    }

    function fr() {
        var a = M;
        if (a = a.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js?client="]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])') || a.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js"][data-ad-client]:not([data-checked-head])'))
            if (a.setAttribute("data-checked-head", "true"),
                X(window).head_tag_slot_vars) cr(a);
            else return jp(b => {
                b = Ff(b);
                Ec(b, 7, Mb(!0), !1)
            }), a
    }

    function gr(a, b, c) {
        b = Zm(b) ? .j();
        a.google_adbreak_test || b ? dr(a, c) : nq(() => {
            dr(a, c)
        })
    }

    function cr(a) {
        const b = X(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = Ye(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new T(`Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page ${a}, ${String(b.google_ad_client)}`);
    }

    function hr(a) {
        if (typeof a === "object" && a != null) {
            if (typeof a.type === "string") return 2;
            if (typeof a.sound === "string" || typeof a.preloadAdBreaks === "string" || typeof a.h5AdsConfig === "object") return 3
        }
        return 0
    }

    function $q(a, b, c, d) {
        if (a == null) throw new T("push() called with no parameters.");
        jp(f => {
            var g = Ff(f);
            Uc(g, 3) || (f = Ff(f), bd(f, 3))
        });
        var e = hr(a);
        if (e !== 0)
            if (d = Lm(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = hh), Lq == null) ir(a), Mq.push(a);
            else if (e === 3) {
            const f = Lq;
            uk(787, () => {
                f.handleAdConfig(a)
            })
        } else wk(730, Lq.handleAdBreak(a));
        else {
            hh = (new Date).getTime();
            Yn(c, d, Yq(a));
            jr();
            a: {
                if (!a.enable_ad_intent_display_ads && a.enable_page_level_ads !=
                    void 0) {
                    if (typeof a.google_ad_client === "string") {
                        e = !0;
                        break a
                    }
                    throw new T("'google_ad_client' is missing from the tag config.");
                }
                e = !1
            }
            if (e) jp(f => {
                var g = Ff(f);
                Uc(g, 4) || (f = Ff(f), bd(f, 4))
            }), kr(a, d);
            else if ((e = a.params) && Td(e, (f, g) => {
                    b[g] = f
                }), b.google_ad_output === "js") console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                jq(Yq(a) || Fn(M), b, d);
                e = lr(b, a);
                To(e, b);
                c = X(q).head_tag_slot_vars || {};
                Td(c,
                    (f, g) => {
                        b.hasOwnProperty(g) || (b[g] = f)
                    });
                if (e.hasAttribute("data-require-head") && !X(q).head_tag_slot_vars) throw new T("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new T("Ad client is missing from the slot.");
                if (c = (X(M).first_tag_on_page || 0) === 0 && xn(b)) jp(f => {
                    var g = Ff(f);
                    Uc(g, 5) || (f = Ff(f), bd(f, 5))
                }), mr(c);
                (X(M).first_tag_on_page || 0) === 0 && (X(M).first_tag_on_page = 2);
                b.google_pause_ad_requests = !!X(M).pause_ad_requests;
                Qq(e, b, d, Dn(a.params, e))
            }
        }
    }

    function Yq(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : ""
    }

    function jr() {
        if (Q(ni)) {
            const a = Im(M);
            a && a.Oa || Jm(M)
        }
    }

    function mr(a) {
        ke(() => {
            un(q).wasPlaTagProcessed || q.adsbygoogle && q.adsbygoogle.push(a)
        })
    }

    function kr(a, b) {
        (X(M).first_tag_on_page || 0) === 0 && (X(M).first_tag_on_page = 1);
        if (a.tag_partner) {
            var c = a.tag_partner;
            const d = X(q);
            d.tag_partners = d.tag_partners || [];
            d.tag_partners.push(c)
        }
        yn(a, b);
        Zq(a, b)
    }

    function lr(a, b) {
        if (a.google_ad_format === "rewarded") {
            if (a.google_ad_slot == null) throw new T("Rewarded format does not have valid ad slot");
            if (a.google_ad_loaded_callback == null) throw new T("Rewarded format does not have ad loaded callback");
            a.google_reactive_ad_format = 11;
            a.google_wrap_fullscreen_ad = !0;
            a.google_video_play_muted = !1;
            a.google_acr = a.google_ad_loaded_callback;
            delete a.google_ad_loaded_callback;
            delete a.google_ad_format
        }
        var c = !!a.google_wrap_fullscreen_ad;
        if (c) b = Wq(), b.dataset.adsbygoogleStatus =
            "reserved", le.documentElement.appendChild(b);
        else if (b = b.element) {
            if (!Pq(b) && (b.id ? b = Tq(b.id) : b = null, !b)) throw new T("'element' has already been filled.");
            if (!("innerHTML" in b)) throw new T("'element' is not a good DOM element.");
        } else if (b = Tq(), !b) throw new T("All 'ins' elements in the DOM with class=adsbygoogle already have ads in them.");
        if (c) {
            c = M;
            try {
                const e = (c || window).document,
                    f = e.compatMode == "CSS1Compat" ? e.documentElement : e.body;
                var d = (new fe(f.clientWidth, f.clientHeight)).round()
            } catch (e) {
                d =
                    new fe(-12245933, -12245933)
            }
            a.google_ad_height = d.height;
            a.google_ad_width = d.width;
            a.fsapi = !0
        }
        return b
    }

    function nr(a) {
        dl().S[gl(26)] = !!Number(a)
    }

    function or(a) {
        Number(a) ? X(M).pause_ad_requests = !0 : (X(M).pause_ad_requests = !1, a = () => {
            if (!X(M).pause_ad_requests) {
                var b = {};
                let c;
                typeof window.CustomEvent === "function" ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                M.dispatchEvent(c)
            }
        }, q.setTimeout(a, 0), q.setTimeout(a, 1E3))
    }

    function pr(a) {
        typeof a === "function" && window.setTimeout(a, 0)
    }

    function dr(a, b) {
        const c = { ...pn()
            },
            d = R(Ki);
        [0, 1].includes(d) && (c.osttc = `${d}`);
        b = tn(Ld(b.Ib, new Map(Object.entries(c)))).then(e => {
            Lq == null && (e.init(a), Lq = e, qr(e))
        });
        wk(723, b);
        b.finally(() => {
            Mq.length = 0;
            xk("slotcar", {
                event: "api_ld",
                time: Date.now() - hh,
                time_pr: Date.now() - Oq
            });
            pp(L(kp), Jf(23))
        })
    }

    function qr(a) {
        for (const [c, d] of Nq) {
            var b = c;
            const e = d;
            e !== -1 && (q.clearTimeout(e), Nq.delete(b))
        }
        for (b = 0; b < Mq.length; b++) {
            if (Nq.has(b)) continue;
            const c = Mq[b],
                d = hr(c);
            uk(723, () => {
                d === 3 ? a.handleAdConfig(c) : d === 2 && wk(730, a.handleAdBreakBeforeReady(c))
            })
        }
    }

    function ir(a) {
        var b = Mq.length;
        if (hr(a) === 2 && a.type === "preroll" && a.adBreakDone != null) {
            var c = a.adBreakDone;
            Oq === -1 && (Oq = Date.now());
            var d = q.setTimeout(() => {
                try {
                    c({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), Nq.set(b, -1), xk("slotcar", {
                        event: "pr_to",
                        source: "adsbygoogle"
                    }), pp(L(kp), Jf(22))
                } catch (e) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", e instanceof Error ? e : Error(String(e)))
                }
            }, R(Mi) * 1E3);
            Nq.set(b, d)
        }
    };
    (function(a, b, c, d = () => {}) {
        qk.H(zk);
        uk(166, () => {
            const e = new yg(2, a);
            try {
                Za(l => {
                    ik(e, 1191, l)
                })
            } catch (l) {}
            const f = hq(b);
            Zp(I(f, 2));
            d();
            re(16, [1, x(f)]);
            var g = te(se(M)) || M;
            const h = c(a, f);
            var k = M.document.currentScript === null ? 1 : sp(h.Kb);
            Yp(g, f, k);
            Q(Hi) && I(f, 29) && kq(g.document, mq(I(f, 29)));
            jp(l => {
                var m = H(l, 1) + 1;
                $c(l, 1, m);
                M.top === M && (m = H(l, 2) + 1, $c(l, 2, m));
                m = Ff(l);
                Uc(m, 1) || (l = Ff(l), bd(l, 1))
            });
            wk(1086, np(k === 0));
            if (!Ea() || va(Ha(), 11) >= 0) {
                sk(Q(Pi));
                fo();
                tm(Kc(f, Sm, 26));
                try {
                    Cq()
                } catch {}
                eo();
                Q(hi) ? er(h, f) : br(h,
                    f);
                g = window;
                k = g.adsbygoogle;
                if (!k || !k.loaded) {
                    var n = {
                        push: l => {
                            Vq(l, h, f)
                        },
                        loaded: !0,
                        pageStateTs: $p(f)
                    };
                    try {
                        Object.defineProperty(n, "requestNonPersonalizedAds", {
                            set: nr
                        }), Object.defineProperty(n, "pauseAdRequests", {
                            set: or
                        }), Object.defineProperty(n, "onload", {
                            set: pr
                        })
                    } catch {}
                    if (k)
                        for (const l of ["requestNonPersonalizedAds", "pauseAdRequests"]) k[l] !== void 0 && (n[l] = k[l]);
                    Uq(k, h, f);
                    g.adsbygoogle = n;
                    k && (n.onload = k.onload)
                }
            }
        })
    })(hg(), typeof sttc === "undefined" ? void 0 : sttc, function(a, b) {
        b = H(b, 1) > 2012 ? `_fy${H(b,1)}` :
            "";
        Kd `data:text/javascript,//show_ads_impl_preview.js`;
        return {
            Ib: Kd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
            ab: Kd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${b}.js`,
            Za: Kd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${b}.js`,
            Kb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle(_direct)?)\.js(?:[?#].*)?$/
        }
    });
}).call(this, "[2021,\"r20250730\",\"r20190131\",null,null,null,null,\".google.co.in\",null,null,null,[[[698926295,null,null,[1]],[785426718,null,null,[1]],[null,619278254,null,[null,10]],[null,45696523,null,[]],[676894296,null,null,[1]],[45693370,null,null,null,[[[6,null,null,3,null,2],[1]]]],[682658313,null,null,[1]],[null,1130,null,[null,100]],[null,1340,null,[null,0.2]],[null,1338,null,[null,0.3]],[null,1339,null,[null,0.3]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[null,728201648,null,[null,100]],[null,766318165,null,[null,-1]],[null,1224,null,[null,0.01]],[null,1346,null,[null,6]],[null,1347,null,[null,3]],[null,1343,null,[null,300]],[null,1263,null,[null,-1]],[null,1323,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1241,null,null,[1]],[1300,null,null,[1]],[null,null,null,[null,null,null,[\"en\",\"de\",\"fr\",\"es\",\"ja\"]],null,1273],[null,null,null,[null,null,null,[\"44786015\",\"44786016\"]],null,1261],[1318,null,null,[1]],[752401956,null,null,[1]],[1372,null,null,[1]],[45682913,null,null,[1]],[45709472,null,null,[]],[622128248,null,null,[]],[768003785,null,null,[1]],[781016954,null,null,[1]],[null,null,null,[null,null,null,[\"29_18\",\"30_19\"]],null,null,null,635821288],[null,null,780033902,[null,null,\"calc(\\u003cDH\\u003e - 74px)\"]],[null,null,716722045,[null,null,\"calc(\\u003cDH\\u003e - 30px)\"]],[null,666400580,null,[null,22]],[null,null,null,[null,null,null,[\"\",\"ar\",\"bn\",\"en\",\"es\",\"fr\",\"hi\",\"id\",\"ja\",\"ko\",\"mr\",\"pt\",\"ru\",\"sr\",\"te\",\"th\",\"tr\",\"uk\",\"vi\",\"zh\"]],null,712458671],[null,null,null,[],null,null,null,683929765],[742688665,null,null,[1]],[767072600,null,null,[1]],[null,null,45701677,[null,null,\"763856898\"]],[null,775999093,null,[null,1]],[null,717888910,null,[null,0.5423]],[null,9604,null,[null,0.5423]],[null,643258048,null,[null,0.1542]],[null,9601,null,[null,0.1542]],[null,643258049,null,[null,0.16]],[null,9602,null,[null,0.16]],[null,618163195,null,[null,14141]],[null,624950166,null,[null,15000]],[null,623405755,null,[null,300]],[null,508040914,null,[null,622]],[null,547455356,null,[null,49]],[null,717888911,null,[null,0.7]],[null,9605,null,[null,0.5799]],[null,717888912,null,[null,0.5849]],[null,9606,null,[null,0.65]],[null,727864505,null,[null,3]],[null,652486359,null,[null,9]],[null,626062006,null,[null,670]],[null,748662193,null,[null,4]],[null,9603,null,[null,4]],[null,688905693,null,[null,2]],[null,650548030,null,[null,3]],[null,650548032,null,[null,300]],[null,650548031,null,[null,1]],[null,655966487,null,[null,300]],[null,655966486,null,[null,250]],[null,687270738,null,[null,500]],[null,469675170,null,[null,68040]],[45689742,null,null,[1]],[760801919,null,null,[1]],[675298507,null,null,[]],[711741274,null,null,[]],[772174848,null,null,[1]],[45712203,null,null,[1]],[785440426,null,null,[]],[776685355,null,null,[]],[null,684147713,null,[null,-1]],[null,684147711,null,[null,-1]],[null,684147712,null,[null,-1]],[45675667,null,null,[1]],[570863962,null,null,[1]],[null,null,570879859,[null,null,\"control_1\\\\.\\\\d\"]],[null,570863961,null,[null,50]],[570879858,null,null,[1]],[781146026,null,null,[1]],[null,null,754933823,[null,null,\"1-0-45\"]],[762046321,null,null,[1]],[10028,null,null,[1]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[null,10019,null,[null,5]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[1134,null,null,[1]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[null,58,null,[null,120]],[781693592,null,null,[]],[751557128,null,null,[1]],[715572365,null,null,[1]],[715572366,null,null,[1]],[767255412,null,null,[1]],[null,732217386,null,[null,10000]],[null,732217387,null,[null,500]],[null,733329086,null,[null,30000]],[null,629808663,null,[null,100]],[null,736623795,null,[null,250]],[null,745376892,null,[null,1]],[null,745376893,null,[null,2]],[null,550718588,null,[null,250]],[null,624290870,null,[null,50]],[null,null,null,[null,null,null,[\"AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"Amm8\/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq\/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A9wSqI5i0iwGdf6L1CERNdmsTPgVu44ewj8QxTBYgsv1LCPUVF7YmWOvTappqB1139jAymxUW\/RO8zmMqo4zlAAAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A+d7vJfYtay4OUbdtRPZA3y7bKQLsxaMEPmxgfhBGqKXNrdkCQeJlUwqa6EBbSfjwFtJWTrWIioXeMW+y8bWAgQAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,59],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]]]],[10,[[50,[[31067422],[31067423,[[null,1032,null,[]]]]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[31084127],[31084128]]],[1,[[31089628],[31089629,[[710737579,null,null,[1]]]]]],[50,[[31093039],[31093040,[[null,766318165,null,[null,150]]]]]],[1000,[[31093689,[[null,null,14,[null,null,\"31093689\"]]],[6,null,null,null,6,null,\"31093689\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093690,[[null,null,14,[null,null,\"31093690\"]]],[6,null,null,null,6,null,\"31093690\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093739,[[null,null,14,[null,null,\"31093739\"]]],[6,null,null,null,6,null,\"31093739\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093740,[[null,null,14,[null,null,\"31093740\"]]],[6,null,null,null,6,null,\"31093740\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[null,[[31093741],[31093742,[[675298507,null,null,[1]]]]]],[1000,[[31093766,[[null,null,14,[null,null,\"31093766\"]]],[6,null,null,null,6,null,\"31093766\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093767,[[null,null,14,[null,null,\"31093767\"]]],[6,null,null,null,6,null,\"31093767\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093796,[[null,null,14,[null,null,\"31093796\"]]],[6,null,null,null,6,null,\"31093796\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093797,[[null,null,14,[null,null,\"31093797\"]]],[6,null,null,null,6,null,\"31093797\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093824,[[null,null,14,[null,null,\"31093824\"]]],[6,null,null,null,6,null,\"31093824\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31093825,[[null,null,14,[null,null,\"31093825\"]]],[6,null,null,null,6,null,\"31093825\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[50,[[42531705],[42531706]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[50,[[42532523],[42532524,[[1300,null,null,[]]]]]],[null,[[42532525],[42532526]]],[100,[[42533293],[42533294,[[1383,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]],null,145],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55],143],[50,[[95344787,[[null,null,null,[null,null,null,[\"95344792\"]],null,null,null,630330362]]],[95344788,[[566279275,null,null,[1]],[622128248,null,null,[1]],[null,null,null,[null,null,null,[\"95344793\"]],null,null,null,630330362]]],[95344789,[[622128248,null,null,[1]],[566279276,null,null,[1]],[null,null,null,[null,null,null,[\"95344794\"]],null,null,null,630330362]]],[95344790,[[566279275,null,null,[1]],[566279276,null,null,[1]],[null,null,null,[null,null,null,[\"95344795\"]],null,null,null,630330362]]],[95344791,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]],[null,null,null,[null,null,null,[\"95344796\"]],null,null,null,630330362]]]],[4,null,55],143],[1,[[95345037],[95345038,[[1377,null,null,[1]]]]],[4,null,55]],[10,[[95352051,[[null,null,null,[null,null,null,[\"95352054\"]],null,null,null,630330362]]],[95352052,[[null,643258048,null,[]],[null,null,null,[null,null,null,[\"95352055\"]],null,null,null,630330362]]],[95352053,[[null,643258048,null,[]],[null,643258049,null,[]],[null,null,null,[null,null,null,[\"95352056\"]],null,null,null,630330362]]]],[4,null,55],143],[500,[[95359265],[95359266,[[45650867,null,null,[1]]]]],null,130,null,null,null,null,null,null,null,null,null,7],[1,[[95362036,[[null,null,null,[null,null,null,[\"95361930\"]],null,null,null,630330362]]],[95362038,[[742688665,null,null,[]],[null,null,null,[null,null,null,[\"95361932\"]],null,null,null,630330362]]],[95362039,[[null,null,716722045,[null,null,\"calc(\\u003cDH\\u003e - 130px)\"]],[742688665,null,null,[]],[null,null,null,[null,null,null,[\"95361933\"]],null,null,null,630330362]]]],[4,null,55]],[500,[[95362655,[[null,null,null,[null,null,null,[\"95362657\"]],null,null,null,630330362]]],[95362656,[[763847817,null,null,[1]],[null,null,null,[null,null,null,[\"95362658\"]],null,null,null,630330362]]]],[4,null,55]],[null,[[95363277,[[null,null,null,[null,null,null,[\"95363279\"]],null,null,null,630330362]]],[95363278,[[759602315,null,null,[1]],[null,null,null,[null,null,null,[\"95363280\"]],null,null,null,630330362]]]],[4,null,55]],[null,[[95363799,[[null,null,null,[null,null,null,[\"95363801\"]],null,null,null,630330362]]],[95363800,[[747408261,null,null,[1]],[null,null,null,[null,null,null,[\"95363802\"]],null,null,null,630330362]]]],[4,null,55]],[50,[[95365698,[[null,null,null,[null,null,null,[\"95365701\"]],null,null,null,630330362]]],[95365700,[[767072600,null,null,[1]],[null,null,null,[null,null,null,[\"95365703\"]],null,null,null,630330362]]]],[4,null,55]],[10,[[95366174],[95366175,[[1389,null,null,[1]],[null,1388,null,[null,0.3]]]],[95366176,[[1390,null,null,[1]],[null,1388,null,[null,0.3]]]],[95366177,[[1389,null,null,[1]],[null,1388,null,[null,0.27]]]],[95366178,[[1390,null,null,[1]],[null,1388,null,[null,0.27]]]]]],[null,[[95366179],[95366180],[95366181],[95366182],[95366183]]],[null,[[95366427,[[null,null,null,[null,null,null,[\"95366429\"]],null,null,null,630330362]]],[95366428,[[767123927,null,null,[1]],[null,null,null,[null,null,null,[\"95366430\"]],null,null,null,630330362]]]],[4,null,55],150],[50,[[95366794],[95366795,[[781693592,null,null,[1]]]]]],[71,[[95366846,[[null,null,null,[null,null,null,[\"95366846\"]],null,null,null,630330362]]],[95366847,[[null,717888910,null,[null,0.65]],[null,643258048,null,[null,0.1]],[null,508040914,null,[null,500]],[null,717888911,null,[null,0.65]],[null,717888912,null,[null,0.65]],[null,748662193,null,[null,6]],[null,650548030,null,[null,2]],[null,null,null,[null,null,null,[\"95366847\"]],null,null,null,630330362]]],[95366848,[[null,717888910,null,[null,0.71142965279701276]],[null,643258048,null,[null,0.081623539457379685]],[null,508040914,null,[null,480]],[null,717888911,null,[null,0.71199815260525789]],[null,717888912,null,[null,0.67537038818543416]],[null,748662193,null,[null,7]],[null,650548030,null,[null,3]],[null,null,null,[null,null,null,[\"95366848\"]],null,null,null,630330362]]],[95366849,[[null,717888910,null,[null,0.67323417347694614]],[null,643258048,null,[null,0.13432327593702753]],[null,508040914,null,[null,526]],[null,717888911,null,[null,0.58605052440184613]],[null,717888912,null,[null,0.71389798681303662]],[null,748662193,null,[null,7]],[null,650548030,null,[null,2]],[null,null,null,[null,null,null,[\"95366849\"]],null,null,null,630330362]]],[95366850,[[null,717888910,null,[null,0.70367464124193657]],[null,643258048,null,[null,0.1439116616446722]],[null,508040914,null,[null,543]],[null,717888911,null,[null,0.70287149005405336]],[null,717888912,null,[null,0.68145421030061282]],[null,748662193,null,[null,7]],[null,650548030,null,[null,1]],[null,null,null,[null,null,null,[\"95366850\"]],null,null,null,630330362]]],[95366851,[[null,717888910,null,[null,0.5820529801689861]],[null,643258048,null,[null,0.14097869068639149]],[null,508040914,null,[null,580]],[null,717888911,null,[null,0.71799517543310076]],[null,717888912,null,[null,0.60315977365118822]],[null,748662193,null,[null,5]],[null,650548030,null,[null,3]],[null,null,null,[null,null,null,[\"95366851\"]],null,null,null,630330362]]],[95366852,[[null,717888910,null,[null,0.67355296004854481]],[null,643258048,null,[null,0.053341932491135717]],[null,508040914,null,[null,550]],[null,717888911,null,[null,0.60150379967380574]],[null,717888912,null,[null,0.70589940688780961]],[null,748662193,null,[null,7]],[null,650548030,null,[null,3]],[null,null,null,[null,null,null,[\"95366852\"]],null,null,null,630330362]]],[95366853,[[null,717888910,null,[null,0.60137222681092539]],[null,643258048,null,[null,0.095082268260666292]],[null,508040914,null,[null,646]],[null,717888911,null,[null,0.63756698895768216]],[null,717888912,null,[null,0.72720014333046368]],[null,748662193,null,[null,6]],[null,650548030,null,[null,3]],[null,null,null,[null,null,null,[\"95366853\"]],null,null,null,630330362]]],[95366854,[[null,717888910,null,[null,0.67001560178661956]],[null,643258048,null,[null,0.14327457396054721]],[null,508040914,null,[null,449]],[null,717888911,null,[null,0.72399525335306825]],[null,717888912,null,[null,0.59172570114719236]],[null,748662193,null,[null,6]],[null,650548030,null,[null,3]],[null,null,null,[null,null,null,[\"95366854\"]],null,null,null,630330362]]],[95366855,[[null,717888910,null,[null,0.72594806183307814]],[null,643258048,null,[null,0.15013844186058889]],[null,508040914,null,[null,557]],[null,717888911,null,[null,0.68411759648406922]],[null,717888912,null,[null,0.60954925701952178]],[null,748662193,null,[null,7]],[null,650548030,null,[null,2]],[null,null,null,[null,null,null,[\"95366855\"]],null,null,null,630330362]]]],[4,null,55],143],[50,[[95366911,[[null,null,null,[null,null,null,[\"95366911\"]],null,null,null,630330362]]],[95366912,[[45714120,null,null,[1]],[45701765,null,null,[1]],[null,null,45701677,[null,null,\"784267869\"]],[null,null,null,[null,null,null,[\"95366912\"]],null,null,null,630330362]]]],[4,null,55]],[333,[[95366913,[[null,null,null,[null,null,null,[\"95366916\"]],null,null,null,630330362]]],[95366914,[[null,618163195,null,[null,10000]],[null,null,null,[null,null,null,[\"95366917\"]],null,null,null,630330362]]],[95366915,[[null,618163195,null,[null,8000]],[null,null,null,[null,null,null,[\"95366918\"]],null,null,null,630330362]]]],[4,null,55]],[125,[[95367165,[[null,null,null,[null,null,null,[\"95367165\"]],null,null,null,630330362]]],[95367166,[[null,652486359,null,[null,12]],[null,688905693,null,[null,2]],[null,751018117,null,[null,505]],[null,687270738,null,[null,550]],[null,null,null,[null,null,null,[\"95367166\"]],null,null,null,630330362]]],[95367167,[[null,652486359,null,[null,15]],[null,688905693,null,[null,1]],[null,751018117,null,[null,381]],[null,687270738,null,[null,361]],[null,null,null,[null,null,null,[\"95367167\"]],null,null,null,630330362]]],[95367168,[[null,652486359,null,[null,8]],[null,688905693,null,[null,3]],[null,751018117,null,[null,602]],[null,687270738,null,[null,574]],[null,null,null,[null,null,null,[\"95367168\"]],null,null,null,630330362]]],[95367169,[[null,652486359,null,[null,9]],[null,688905693,null,[null,1]],[null,751018117,null,[null,733]],[null,687270738,null,[null,502]],[null,null,null,[null,null,null,[\"95367169\"]],null,null,null,630330362]]],[95367170,[[null,652486359,null,[null,17]],[null,688905693,null,[null,3]],[null,751018117,null,[null,739]],[null,687270738,null,[null,766]],[null,null,null,[null,null,null,[\"95367170\"]],null,null,null,630330362]]],[95367171,[[null,652486359,null,[null,17]],[null,688905693,null,[null,3]],[null,751018117,null,[null,752]],[null,687270738,null,[null,329]],[null,null,null,[null,null,null,[\"95367171\"]],null,null,null,630330362]]],[95367172,[[null,652486359,null,[null,16]],[null,688905693,null,[null,2]],[null,751018117,null,[null,639]],[null,687270738,null,[null,317]],[null,null,null,[null,null,null,[\"95367172\"]],null,null,null,630330362]]]],[4,null,55],148],[10,[[95367393],[95367394,[[null,770241922,null,[null,1000]]]],[95367395,[[null,770241922,null,[null,100]]]]]],[50,[[95367554],[95367555,[[45693370,null,null,[]]]]]],[1,[[95367797,[[null,null,null,[null,null,null,[\"95367799\"]],null,null,null,630330362]]],[95367798,[[null,9604,null,[null,0.7]],[null,9601,null,[null,0.18482]],[null,9602,null,[null,0.41402]],[null,null,null,[null,null,null,[\"95367800\"]],null,null,null,630330362]]]],[4,null,55],143]]],[17,[[10,[[31084487],[31084488]],null,null,null,null,32,null,null,142,1],[10,[[31089209],[31089210]],null,null,null,null,39,null,null,189,1],[96,[[95353306]],[2,[[4,null,55],[7,null,null,15,null,20250214],[6,null,null,3,null,2]]],null,null,null,null,null,null,215,1],[896,[[95353307,null,[4,null,71,null,null,null,null,[\"215\",\"14\"]]]],[2,[[4,null,55],[7,null,null,15,null,20250214],[6,null,null,3,null,2]]],null,null,null,null,96,null,215,1],[50,[[95360683],[95360684],[95360685]],[7,null,null,15,null,20250514],null,null,null,42,850,null,189,1],[50,[[95360691],[95360692],[95360693]],[2,[[8,null,null,15,null,20250514],[7,null,null,15,null,20250528]]],null,null,null,42,850,null,189,1],[10,[[95361163],[95361164]],[7,null,null,15,null,20250514],null,null,null,39,null,null,189,1]]],[11,[[50,[[31092546],[31092547],[31092548]],[4,null,8,null,null,null,null,[\"scheduler\"]],147,null,null,null,null,null,null,null,null,null,9]]]],null,null,[null,1000,1,1000]],null,null,\"31093690\",null,\"www.pramukhfontconverter.com\",853125289,null,null,null,null,null,null,null,[0,0,0],[null,[\"ca-pub-4833571608350221\",1],1,null,[[[[null,0,null,null,null,null,\"DIV#content\\u003eARTICLE.page.type-page.status-publish.hentry.entry\\u003eDIV.entry-content\\u003eP\"],1,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"DIV#lblWarning\"],4,[\"10px\",\"16px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"NAV\"],4,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"DIV#lblWarning\"],1,[\"10px\",\"24px\",1],[2],null,null,null,1]],[[null,[1,3,2],null,\"8313476112\",[[[[[null,null,null,null,null,null,\"NAV\"],4],[[null,null,null,null,null,null,\"DIV#content\"],2],[[null,0,null,null,null,null,\"NAV\"],4]]]],null,[0,2],null,null,[0.59,null,2,11,350,1],[1]]]],[null,null,[1,2,7]]],null,\"m202507310101\"]");